--
-- PostgreSQL database cluster dump
--

\restrict KwuhMjC5XIdEB33s7AYNtfeBujJW3P30vkV6Em4h2g8nsRkQ65e7AfG0qgPLwrp

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Drop databases (except postgres and template1)
--

DROP DATABASE IF EXISTS agentshield;
DROP DATABASE IF EXISTS appsmith;
DROP DATABASE IF EXISTS keycloak;
DROP DATABASE IF EXISTS langfuse;
DROP DATABASE IF EXISTS langgraph;




--
-- Drop roles
--

DROP ROLE IF EXISTS agentshield_user;
DROP ROLE IF EXISTS appsmith_user;
DROP ROLE IF EXISTS keycloak_user;
DROP ROLE IF EXISTS langfuse_user;
DROP ROLE IF EXISTS langgraph_user;
DROP ROLE IF EXISTS postgres;


--
-- Roles
--

CREATE ROLE agentshield_user;
ALTER ROLE agentshield_user WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:vbESWc1sr5ak5PFYJpKtfg==$sgFVHeFBvjXu8DYW9UrWyDIu67kznQfvrBjolG0Rbho=:WLQ3ICzxNQp9IagDd8BDtgPkF+1ACXL+Sixw1t09mOI=';
CREATE ROLE appsmith_user;
ALTER ROLE appsmith_user WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:7bJ23tRiARVwqdJ5oBgpJw==$O9Xm1Gp+FfNHzpVRN5qd4amcdUsADZwq41G8pPRapHw=:3TJkFKL4lv5s78E5zSoOB4kzcZKBP0jiqvAKKrGlqMQ=';
CREATE ROLE keycloak_user;
ALTER ROLE keycloak_user WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:YH5sCkRZmpfZk5X0nIGs/A==$nxbenBfwqMpPgVc+Tq50MqpLWVvONM5jrsbp3GiCqTg=:wcahrGVuGVzAFraUDDLAj2XO8V7vV6cHBkaCrJ5+T5g=';
CREATE ROLE langfuse_user;
ALTER ROLE langfuse_user WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:ZJnvqjjbrA2PLRRGe68LYA==$tuU6Z49EXqbSS3vql4YpXUfGE781yIUsYIlkjHVBzJ0=:5Gza563IMvIlGhHVWpyoL6xkiOC2P8/sx7fB25Cb6tI=';
CREATE ROLE langgraph_user;
ALTER ROLE langgraph_user WITH NOSUPERUSER INHERIT NOCREATEROLE NOCREATEDB LOGIN NOREPLICATION NOBYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:9/rt763G6SBC8ouXf3gxRg==$jk7DWqGAqXG1qoZP7KuDGvGv13/PvLYZV0twCyhULSI=:YlwnbAKStRwI18eEPPPMiufXbtEuPa9aZBEN6GSQmM8=';
CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:mFELZzRULsYX9I4J9cE0MA==$CoSkiiohj6rghD+rP6NAGK1klzg1M3+Koa6QtPE8EpU=:3oBHxZOXeL6tssZ2ajA2MU9huknxTQMiFOtHtnjy1cU=';

--
-- User Configurations
--








\unrestrict KwuhMjC5XIdEB33s7AYNtfeBujJW3P30vkV6Em4h2g8nsRkQ65e7AfG0qgPLwrp

--
-- Databases
--

--
-- Database "template1" dump
--

--
-- PostgreSQL database dump
--

\restrict Oy1zWUTpFbJhLegnwTyoh0uWglhI2DNbYzkkNguibSjovlfocAUny0gEiHdiHVX

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

UPDATE pg_catalog.pg_database SET datistemplate = false WHERE datname = 'template1';
DROP DATABASE template1;
--
-- Name: template1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE template1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE template1 OWNER TO postgres;

\unrestrict Oy1zWUTpFbJhLegnwTyoh0uWglhI2DNbYzkkNguibSjovlfocAUny0gEiHdiHVX
\connect template1
\restrict Oy1zWUTpFbJhLegnwTyoh0uWglhI2DNbYzkkNguibSjovlfocAUny0gEiHdiHVX

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE template1 IS 'default template for new databases';


--
-- Name: template1; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE template1 IS_TEMPLATE = true;


\unrestrict Oy1zWUTpFbJhLegnwTyoh0uWglhI2DNbYzkkNguibSjovlfocAUny0gEiHdiHVX
\connect template1
\restrict Oy1zWUTpFbJhLegnwTyoh0uWglhI2DNbYzkkNguibSjovlfocAUny0gEiHdiHVX

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE template1; Type: ACL; Schema: -; Owner: postgres
--

REVOKE CONNECT,TEMPORARY ON DATABASE template1 FROM PUBLIC;
GRANT CONNECT ON DATABASE template1 TO PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict Oy1zWUTpFbJhLegnwTyoh0uWglhI2DNbYzkkNguibSjovlfocAUny0gEiHdiHVX

--
-- Database "agentshield" dump
--

--
-- PostgreSQL database dump
--

\restrict dYIg5vG72K2srerkPkToEthCXeelOb6PoNeRXo4Mun8hRiSBFw1df62EiG62jLc

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: agentshield; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE agentshield WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE agentshield OWNER TO postgres;

\unrestrict dYIg5vG72K2srerkPkToEthCXeelOb6PoNeRXo4Mun8hRiSBFw1df62EiG62jLc
\connect agentshield
\restrict dYIg5vG72K2srerkPkToEthCXeelOb6PoNeRXo4Mun8hRiSBFw1df62EiG62jLc

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: asset_visible(uuid, text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.asset_visible(p_asset_id uuid, p_user_sub text, p_user_team text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
          SELECT EXISTS (
            SELECT 1 FROM agents
            WHERE id = p_asset_id AND created_by = p_user_sub

            UNION ALL

            SELECT 1 FROM agents a
            JOIN asset_grants g ON g.asset_id = a.id
            WHERE a.id = p_asset_id
              AND a.publish_status = 'published'
              AND g.grantee_team = p_user_team
              AND g.revoked_at IS NULL
              AND (g.expires_at IS NULL OR g.expires_at > NOW())
          );
        $$;


ALTER FUNCTION public.asset_visible(p_asset_id uuid, p_user_sub text, p_user_team text) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    trigger_id uuid,
    agent_name character varying(256) NOT NULL,
    status character varying(16) NOT NULL,
    filter_reason text,
    payload jsonb,
    run_id uuid,
    source_ip inet,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    workflow_id uuid,
    CONSTRAINT ck_agent_events_status CHECK (((status)::text = ANY ((ARRAY['matched'::character varying, 'filtered'::character varying, 'rejected'::character varying])::text[])))
);


ALTER TABLE public.agent_events OWNER TO postgres;

--
-- Name: agent_graph_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_graph_versions (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT workflow_versions_id_not_null NOT NULL,
    agent_graph_id uuid CONSTRAINT workflow_versions_workflow_id_not_null NOT NULL,
    version_number integer CONSTRAINT workflow_versions_version_number_not_null NOT NULL,
    definition jsonb CONSTRAINT workflow_versions_definition_not_null NOT NULL,
    change_summary text,
    created_at timestamp with time zone DEFAULT now() CONSTRAINT workflow_versions_created_at_not_null NOT NULL,
    created_by character varying(256)
);


ALTER TABLE public.agent_graph_versions OWNER TO postgres;

--
-- Name: agent_graphs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_graphs (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT workflows_id_not_null NOT NULL,
    name character varying(256) CONSTRAINT workflows_name_not_null NOT NULL,
    team character varying(128) CONSTRAINT workflows_team_not_null NOT NULL,
    description text,
    status character varying(32) DEFAULT 'draft'::character varying CONSTRAINT workflows_status_not_null NOT NULL,
    created_at timestamp with time zone DEFAULT now() CONSTRAINT workflows_created_at_not_null NOT NULL,
    updated_at timestamp with time zone DEFAULT now() CONSTRAINT workflows_updated_at_not_null NOT NULL,
    created_by character varying(256),
    metadata jsonb DEFAULT '{}'::jsonb CONSTRAINT workflows_metadata_not_null NOT NULL,
    CONSTRAINT ck_workflows_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'published'::character varying, 'archived'::character varying])::text[])))
);


ALTER TABLE public.agent_graphs OWNER TO postgres;

--
-- Name: agent_identities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_identities (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_name character varying(128) NOT NULL,
    deployment_id uuid,
    sa_subject character varying(512) NOT NULL,
    sa_namespace character varying(256) NOT NULL,
    provisioned_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


ALTER TABLE public.agent_identities OWNER TO postgres;

--
-- Name: agent_memory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_memory (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_name character varying(256) NOT NULL,
    team character varying(128) NOT NULL,
    thread_id character varying(256) NOT NULL,
    user_id character varying(256),
    role character varying(16) NOT NULL,
    content text NOT NULL,
    message_index integer NOT NULL,
    session_id character varying(256),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    content_embedding public.vector(1536),
    CONSTRAINT ck_agent_memory_role CHECK (((role)::text = ANY ((ARRAY['user'::character varying, 'assistant'::character varying, 'system'::character varying, 'tool'::character varying])::text[])))
);


ALTER TABLE public.agent_memory OWNER TO postgres;

--
-- Name: agent_policies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_policies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid NOT NULL,
    rego_policy text NOT NULL,
    tool_allowlist jsonb DEFAULT '[]'::jsonb NOT NULL,
    risk_map jsonb DEFAULT '{}'::jsonb NOT NULL,
    configmap_name character varying(256),
    version integer DEFAULT 1 NOT NULL,
    generated_at timestamp with time zone DEFAULT now() NOT NULL,
    generated_from_version_id uuid
);


ALTER TABLE public.agent_policies OWNER TO postgres;

--
-- Name: agent_runs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_name character varying(256) NOT NULL,
    agent_version_id uuid,
    session_id character varying(256),
    user_id character varying(256),
    input text,
    output text,
    langfuse_trace_id character varying(256),
    cost_usd numeric(10,6),
    prompt_tokens integer,
    completion_tokens integer,
    latency_ms integer,
    status character varying(32) DEFAULT 'running'::character varying NOT NULL,
    context character varying(32) DEFAULT 'production'::character varying NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    trigger_type character varying(16) DEFAULT 'manual'::character varying,
    run_by character varying(255),
    team character varying(100),
    thread_id character varying(255),
    parent_run_id uuid,
    schedule_id uuid,
    trigger_id uuid,
    trigger_payload jsonb,
    error_message text,
    workflow_id uuid,
    orchestrator_state jsonb,
    CONSTRAINT ck_agent_runs_context CHECK (((context)::text = ANY ((ARRAY['production'::character varying, 'playground'::character varying])::text[]))),
    CONSTRAINT ck_agent_runs_status CHECK (((status)::text = ANY ((ARRAY['queued'::character varying, 'running'::character varying, 'completed'::character varying, 'failed'::character varying, 'blocked'::character varying, 'awaiting_approval'::character varying, 'cancelled'::character varying])::text[]))),
    CONSTRAINT ck_agent_runs_trigger_type CHECK (((trigger_type)::text = ANY ((ARRAY['manual'::character varying, 'api'::character varying, 'schedule'::character varying, 'webhook'::character varying, 'workflow'::character varying])::text[])))
);


ALTER TABLE public.agent_runs OWNER TO postgres;

--
-- Name: agent_tools; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_tools (
    agent_id uuid NOT NULL,
    tool_id uuid NOT NULL,
    added_by character varying(256),
    added_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.agent_tools OWNER TO postgres;

--
-- Name: agent_triggers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_triggers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid,
    trigger_type character varying(16) NOT NULL,
    cron_expression character varying(100),
    timezone character varying(50) DEFAULT 'UTC'::character varying,
    enabled boolean DEFAULT true NOT NULL,
    token_hash character varying(128),
    filter_conditions jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    alert_email character varying(255),
    alert_on_failure boolean DEFAULT true NOT NULL,
    workflow_id uuid,
    input_payload jsonb,
    CONSTRAINT ck_agent_triggers_target CHECK ((num_nonnulls(agent_id, workflow_id) = 1)),
    CONSTRAINT ck_agent_triggers_type CHECK (((trigger_type)::text = ANY ((ARRAY['schedule'::character varying, 'webhook'::character varying])::text[])))
);


ALTER TABLE public.agent_triggers OWNER TO postgres;

--
-- Name: agent_versions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agent_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid NOT NULL,
    version_number integer NOT NULL,
    image_tag character varying(512),
    agent_graph_id uuid,
    tools jsonb DEFAULT '[]'::jsonb NOT NULL,
    eval_passed boolean DEFAULT false NOT NULL,
    git_sha character varying(64),
    git_branch character varying(256),
    notes text,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by character varying(256),
    adversarial_eval_passed boolean DEFAULT false NOT NULL,
    CONSTRAINT ck_agent_versions_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'eval_passed'::character varying, 'eval_failed'::character varying, 'deployed'::character varying, 'retired'::character varying])::text[])))
);


ALTER TABLE public.agent_versions OWNER TO postgres;

--
-- Name: agents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.agents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(128) NOT NULL,
    team character varying(128) NOT NULL,
    description text,
    status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    agent_type character varying(32) DEFAULT 'sdk'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by character varying(256) DEFAULT 'system'::character varying NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    team_id uuid,
    llm_provider_id uuid,
    agent_class character varying(32),
    publish_status character varying(32) DEFAULT 'private'::character varying NOT NULL,
    execution_shape character varying(16) DEFAULT 'reactive'::character varying NOT NULL,
    memory_enabled boolean DEFAULT false NOT NULL,
    CONSTRAINT ck_agents_agent_class CHECK (((agent_class IS NULL) OR ((agent_class)::text = ANY ((ARRAY['daemon'::character varying, 'user_delegated'::character varying])::text[])))),
    CONSTRAINT ck_agents_execution_shape CHECK (((execution_shape)::text = ANY ((ARRAY['reactive'::character varying, 'durable'::character varying])::text[]))),
    CONSTRAINT ck_agents_publish_status CHECK (((publish_status)::text = ANY ((ARRAY['private'::character varying, 'pending_review'::character varying, 'published'::character varying])::text[]))),
    CONSTRAINT ck_agents_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'archived'::character varying, 'deprecated'::character varying, 'quarantined'::character varying])::text[]))),
    CONSTRAINT ck_agents_type CHECK (((agent_type)::text = ANY ((ARRAY['sdk'::character varying, 'declarative'::character varying])::text[])))
);


ALTER TABLE public.agents OWNER TO postgres;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO postgres;

--
-- Name: approval_authority; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.approval_authority (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    resource_type character varying(16) NOT NULL,
    resource_id text NOT NULL,
    approver_user_id text,
    approver_role text,
    granted_by text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    CONSTRAINT ck_approval_authority_approver CHECK (((approver_user_id IS NOT NULL) OR (approver_role IS NOT NULL))),
    CONSTRAINT ck_approval_authority_resource_type CHECK (((resource_type)::text = ANY ((ARRAY['agent'::character varying, 'tool'::character varying, 'skill'::character varying])::text[])))
);


ALTER TABLE public.approval_authority OWNER TO postgres;

--
-- Name: approvals; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.approvals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid NOT NULL,
    agent_name character varying(128) NOT NULL,
    team character varying(128) NOT NULL,
    thread_id character varying(256) NOT NULL,
    tool_name character varying(256) NOT NULL,
    tool_args jsonb DEFAULT '{}'::jsonb NOT NULL,
    risk_level character varying(32) DEFAULT 'high'::character varying NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    reviewer_id character varying(256),
    reviewer_notes text,
    trace_id character varying(256),
    session_id uuid,
    opa_decision_id uuid,
    decision_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    version integer DEFAULT 0 NOT NULL,
    context text DEFAULT 'production'::text NOT NULL,
    notify_slack boolean DEFAULT true NOT NULL,
    CONSTRAINT ck_approvals_risk CHECK (((risk_level)::text = ANY ((ARRAY['high'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT ck_approvals_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'approved'::character varying, 'rejected'::character varying, 'timed_out'::character varying])::text[])))
);


ALTER TABLE public.approvals OWNER TO postgres;

--
-- Name: asset_grants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.asset_grants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_id uuid NOT NULL,
    asset_type character varying(32) NOT NULL,
    grantee_team text NOT NULL,
    granted_by text NOT NULL,
    granted_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    revoked_at timestamp with time zone,
    CONSTRAINT ck_asset_grants_asset_type CHECK (((asset_type)::text = ANY ((ARRAY['tool'::character varying, 'agent'::character varying, 'skill'::character varying, 'workflow'::character varying])::text[])))
);


ALTER TABLE public.asset_grants OWNER TO postgres;

--
-- Name: auth_configs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_configs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(256) NOT NULL,
    type character varying(32) NOT NULL,
    k8s_secret_ref character varying(512),
    owner_team character varying(128),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_auth_configs_type CHECK (((type)::text = ANY ((ARRAY['api_key'::character varying, 'oauth2'::character varying, 'bearer'::character varying, 'mtls'::character varying])::text[])))
);


ALTER TABLE public.auth_configs OWNER TO postgres;

--
-- Name: deployments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deployments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid NOT NULL,
    version_id uuid NOT NULL,
    environment character varying(64) DEFAULT 'production'::character varying NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    replicas integer DEFAULT 1 NOT NULL,
    canary_percent integer,
    k8s_namespace character varying(128) NOT NULL,
    k8s_deployment_name character varying(256),
    error_message text,
    deployed_at timestamp with time zone DEFAULT now() NOT NULL,
    terminated_at timestamp with time zone,
    deployed_by character varying(256),
    previous_version_id uuid,
    llm_secret_name character varying(256),
    llm_env_keys jsonb,
    llm_provider_type character varying(32),
    llm_provider_model character varying(256),
    CONSTRAINT ck_canary_percent CHECK (((canary_percent >= 0) AND (canary_percent <= 100))),
    CONSTRAINT ck_deployments_env CHECK (((environment)::text = ANY ((ARRAY['production'::character varying, 'staging'::character varying, 'canary'::character varying, 'sandbox'::character varying])::text[]))),
    CONSTRAINT ck_deployments_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'deploying'::character varying, 'running'::character varying, 'failed'::character varying, 'rolled_back'::character varying, 'terminated'::character varying, 'gate_failed'::character varying])::text[])))
);


ALTER TABLE public.deployments OWNER TO postgres;

--
-- Name: eval_run_results; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.eval_run_results (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    eval_run_id uuid NOT NULL,
    dataset_item_idx integer NOT NULL,
    input_message text,
    response text,
    judge_score double precision,
    judge_reasoning text,
    passed boolean,
    langfuse_trace_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.eval_run_results OWNER TO postgres;

--
-- Name: eval_runs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.eval_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    agent_name character varying(128) NOT NULL,
    agent_version_id uuid,
    dataset_id uuid NOT NULL,
    status character varying(32) DEFAULT 'pending'::character varying NOT NULL,
    total_items integer,
    passed_count integer,
    failed_count integer,
    overall_score double precision,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.eval_runs OWNER TO postgres;

--
-- Name: grant_audit; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grant_audit (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_id text NOT NULL,
    action character varying(16) NOT NULL,
    asset_id uuid NOT NULL,
    grantee_team text NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_grant_audit_action CHECK (((action)::text = ANY ((ARRAY['created'::character varying, 'revoked'::character varying, 'expired'::character varying])::text[])))
);


ALTER TABLE public.grant_audit OWNER TO postgres;

--
-- Name: llm_providers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.llm_providers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(128) NOT NULL,
    provider character varying(32) NOT NULL,
    default_model character varying(256) NOT NULL,
    credentials_encrypted text NOT NULL,
    team character varying(128) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_llm_providers_provider CHECK (((provider)::text = ANY ((ARRAY['anthropic'::character varying, 'bedrock'::character varying])::text[])))
);


ALTER TABLE public.llm_providers OWNER TO postgres;

--
-- Name: mcp_servers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mcp_servers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(256) NOT NULL,
    description text,
    server_url character varying(1024) NOT NULL,
    transport character varying(32) DEFAULT 'streamable_http'::character varying NOT NULL,
    auth_config_id uuid,
    owner_team character varying(128),
    status character varying(32) DEFAULT 'disconnected'::character varying NOT NULL,
    last_synced_at timestamp with time zone,
    discovered_tool_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_mcp_servers_status CHECK (((status)::text = ANY ((ARRAY['connected'::character varying, 'disconnected'::character varying, 'error'::character varying])::text[]))),
    CONSTRAINT ck_mcp_servers_transport CHECK (((transport)::text = ANY ((ARRAY['streamable_http'::character varying, 'stdio'::character varying])::text[])))
);


ALTER TABLE public.mcp_servers OWNER TO postgres;

--
-- Name: opa_decisions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.opa_decisions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_name text NOT NULL,
    tool_name text NOT NULL,
    decision text NOT NULL,
    policy_version text NOT NULL,
    input_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    deny_reason text,
    thread_id text,
    trace_id text,
    decided_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ck_opa_decisions_decision CHECK ((decision = ANY (ARRAY['allow'::text, 'deny'::text, 'require_approval'::text])))
);


ALTER TABLE public.opa_decisions OWNER TO postgres;

--
-- Name: pii_mappings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pii_mappings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id character varying(256) NOT NULL,
    agent_name character varying(128) NOT NULL,
    original_text text NOT NULL,
    anonymized_text text NOT NULL,
    entity_type character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


ALTER TABLE public.pii_mappings OWNER TO postgres;

--
-- Name: playground_datasets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.playground_datasets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    owner_user_id text NOT NULL,
    name character varying(256) NOT NULL,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.playground_datasets OWNER TO postgres;

--
-- Name: playground_runs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.playground_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id text NOT NULL,
    agent_name character varying(128) NOT NULL,
    agent_version_id uuid,
    context text DEFAULT 'playground'::text NOT NULL,
    sandbox boolean DEFAULT true NOT NULL,
    input_message text,
    langfuse_trace_id text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    status character varying(32) DEFAULT 'running'::character varying NOT NULL,
    judge_score numeric(4,3),
    judge_status character varying(32),
    judge_reason text,
    execution_shape character varying(16) DEFAULT 'reactive'::character varying NOT NULL,
    input_payload jsonb,
    trigger_type character varying(16),
    trigger_payload jsonb,
    output_text text
);


ALTER TABLE public.playground_runs OWNER TO postgres;

--
-- Name: publish_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.publish_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    asset_id uuid NOT NULL,
    asset_type character varying(32) NOT NULL,
    submitted_by text NOT NULL,
    submitted_at timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(32) DEFAULT 'pending_review'::character varying NOT NULL,
    highest_risk_level character varying(16) NOT NULL,
    dependency_declaration jsonb DEFAULT '{}'::jsonb NOT NULL,
    reviewed_by text,
    reviewed_at timestamp with time zone,
    review_notes text,
    CONSTRAINT ck_publish_requests_asset_type CHECK (((asset_type)::text = ANY ((ARRAY['tool'::character varying, 'agent'::character varying, 'skill'::character varying, 'workflow'::character varying])::text[]))),
    CONSTRAINT ck_publish_requests_risk_level CHECK (((highest_risk_level)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying])::text[]))),
    CONSTRAINT ck_publish_requests_status CHECK (((status)::text = ANY ((ARRAY['pending_review'::character varying, 'approved'::character varying, 'rejected'::character varying])::text[])))
);


ALTER TABLE public.publish_requests OWNER TO postgres;

--
-- Name: run_steps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.run_steps (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    step_number integer NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(24) DEFAULT 'pending'::character varying NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    output jsonb,
    approval_id uuid,
    error_message text,
    CONSTRAINT ck_run_steps_status CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'running'::character varying, 'completed'::character varying, 'failed'::character varying, 'awaiting_approval'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.run_steps OWNER TO postgres;

--
-- Name: skills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.skills (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(256) NOT NULL,
    team character varying(128) NOT NULL,
    description text,
    tool_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by character varying(256)
);


ALTER TABLE public.skills OWNER TO postgres;

--
-- Name: teams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teams (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(128) NOT NULL,
    namespace character varying(128) NOT NULL,
    keycloak_role_id character varying(256),
    description text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.teams OWNER TO postgres;

--
-- Name: tools; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tools (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(256) NOT NULL,
    display_name character varying(256),
    description text,
    category character varying(128),
    tags character varying[],
    type character varying(32) NOT NULL,
    input_schema jsonb,
    output_schema jsonb,
    risk_level character varying(32) DEFAULT 'low'::character varying NOT NULL,
    auth_config_id uuid,
    owner_team character varying(128),
    version integer DEFAULT 1 NOT NULL,
    status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    http_method character varying(16),
    http_url character varying(2048),
    http_headers jsonb,
    http_body_template text,
    http_timeout_ms integer,
    mcp_server_id uuid,
    mcp_tool_name character varying(256),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    python_code text,
    CONSTRAINT ck_tools_risk_level CHECK (((risk_level)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[]))),
    CONSTRAINT ck_tools_status CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'inactive'::character varying, 'deprecated'::character varying])::text[]))),
    CONSTRAINT ck_tools_type CHECK (((type)::text = ANY ((ARRAY['native'::character varying, 'http'::character varying, 'mcp_tool'::character varying, 'python'::character varying])::text[])))
);


ALTER TABLE public.tools OWNER TO postgres;

--
-- Name: user_team_assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_team_assignments (
    user_sub character varying(255) NOT NULL,
    team_name character varying(255) NOT NULL,
    role character varying(64) DEFAULT 'operator'::character varying NOT NULL,
    assigned_by character varying(255),
    assigned_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_team_assignments OWNER TO postgres;

--
-- Name: workflow_edges; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workflow_edges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workflow_id uuid NOT NULL,
    source_agent_id uuid NOT NULL,
    target_agent_id uuid NOT NULL,
    condition text,
    "position" integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.workflow_edges OWNER TO postgres;

--
-- Name: workflow_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workflow_members (
    workflow_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    role character varying(64),
    "position" integer,
    routing jsonb DEFAULT '{}'::jsonb NOT NULL,
    added_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.workflow_members OWNER TO postgres;

--
-- Name: workflows; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workflows (
    id uuid DEFAULT gen_random_uuid() CONSTRAINT workflows_id_not_null1 NOT NULL,
    name character varying(256) CONSTRAINT workflows_name_not_null1 NOT NULL,
    team character varying(128) CONSTRAINT workflows_team_not_null1 NOT NULL,
    description text,
    execution_shape character varying(16) DEFAULT 'durable'::character varying NOT NULL,
    memory_enabled boolean DEFAULT false NOT NULL,
    orchestration character varying(32) DEFAULT 'sequential'::character varying NOT NULL,
    status character varying(32) DEFAULT 'draft'::character varying CONSTRAINT workflows_status_not_null1 NOT NULL,
    publish_status character varying(32) DEFAULT 'private'::character varying NOT NULL,
    created_by character varying(256),
    created_at timestamp with time zone DEFAULT now() CONSTRAINT workflows_created_at_not_null1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() CONSTRAINT workflows_updated_at_not_null1 NOT NULL,
    CONSTRAINT ck_workflows_execution_shape CHECK (((execution_shape)::text = ANY ((ARRAY['reactive'::character varying, 'durable'::character varying])::text[]))),
    CONSTRAINT ck_workflows_orchestration CHECK (((orchestration)::text = ANY ((ARRAY['sequential'::character varying, 'supervisor'::character varying, 'handoff'::character varying, 'conditional'::character varying])::text[]))),
    CONSTRAINT ck_workflows_status CHECK (((status)::text = ANY ((ARRAY['draft'::character varying, 'published'::character varying, 'archived'::character varying])::text[])))
);


ALTER TABLE public.workflows OWNER TO postgres;

--
-- Data for Name: agent_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_events (id, trigger_id, agent_name, status, filter_reason, payload, run_id, source_ip, received_at, workflow_id) FROM stdin;
\.


--
-- Data for Name: agent_graph_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_graph_versions (id, agent_graph_id, version_number, definition, change_summary, created_at, created_by) FROM stdin;
\.


--
-- Data for Name: agent_graphs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_graphs (id, name, team, description, status, created_at, updated_at, created_by, metadata) FROM stdin;
\.


--
-- Data for Name: agent_identities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_identities (id, agent_name, deployment_id, sa_subject, sa_namespace, provisioned_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: agent_memory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_memory (id, agent_name, team, thread_id, user_id, role, content, message_index, session_id, created_at, expires_at, content_embedding) FROM stdin;
\.


--
-- Data for Name: agent_policies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_policies (id, agent_id, rego_policy, tool_allowlist, risk_map, configmap_name, version, generated_at, generated_from_version_id) FROM stdin;
5bc9663c-3e07-47e9-acff-50afbb163548	46114fc1-941e-4204-a026-a7ed79eb5b80	package agentshield.agent.news_announcements_researcher\n\nimport future.keywords.if\nimport future.keywords.in\n\n# Default deny — fail-closed\ndefault allow = false\ndefault action = "deny"\n\n# Unlisted tools fall through to default deny\nallow if { action == "log" }	[]	{}	news-announcements-researcher-policy	1	2026-07-07 01:35:05.20641+00	e619a523-939c-49c1-b90c-7bba4b0173a5
7fa53cae-8f21-4b28-af37-617b8f7711e2	f7b20a25-a254-46d0-ba2d-9d31f79fa0ce	package agentshield.agent.analyst_synthesizer\n\nimport future.keywords.if\nimport future.keywords.in\n\n# Default deny — fail-closed\ndefault allow = false\ndefault action = "deny"\n\n# Unlisted tools fall through to default deny\nallow if { action == "log" }	[]	{}	analyst-synthesizer-policy	1	2026-07-07 01:35:12.376038+00	75c0e4df-704a-44bd-b7df-b98f4f865ae9
\.


--
-- Data for Name: agent_runs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_runs (id, agent_name, agent_version_id, session_id, user_id, input, output, langfuse_trace_id, cost_usd, prompt_tokens, completion_tokens, latency_ms, status, context, started_at, completed_at, trigger_type, run_by, team, thread_id, parent_run_id, schedule_id, trigger_id, trigger_payload, error_message, workflow_id, orchestrator_state) FROM stdin;
\.


--
-- Data for Name: agent_tools; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_tools (agent_id, tool_id, added_by, added_at) FROM stdin;
\.


--
-- Data for Name: agent_triggers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_triggers (id, agent_id, trigger_type, cron_expression, timezone, enabled, token_hash, filter_conditions, created_at, updated_at, alert_email, alert_on_failure, workflow_id, input_payload) FROM stdin;
\.


--
-- Data for Name: agent_versions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agent_versions (id, agent_id, version_number, image_tag, agent_graph_id, tools, eval_passed, git_sha, git_branch, notes, status, created_at, created_by, adversarial_eval_passed) FROM stdin;
e619a523-939c-49c1-b90c-7bba4b0173a5	46114fc1-941e-4204-a026-a7ed79eb5b80	1	\N	\N	[]	f	\N	\N	\N	pending	2026-07-07 01:35:02.642544+00	\N	f
75c0e4df-704a-44bd-b7df-b98f4f865ae9	f7b20a25-a254-46d0-ba2d-9d31f79fa0ce	1	\N	\N	[]	f	\N	\N	\N	pending	2026-07-07 01:35:11.514166+00	\N	f
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.agents (id, name, team, description, status, agent_type, created_at, updated_at, created_by, metadata, team_id, llm_provider_id, agent_class, publish_status, execution_shape, memory_enabled) FROM stdin;
72b20bce-be0e-4b5b-813c-f3c03909104d	research-assistant	platform	Searches the web, looks up weather, geolocates IPs. Uses web_research_skill.	active	declarative	2026-07-07 00:39:54.988222+00	2026-07-07 00:39:54.988222+00	system	{}	\N	\N	\N	private	reactive	f
4bdf5f87-437d-4b81-8cf5-7c1759b4b96b	calculator-bot	platform	Evaluates math expressions using the AST-safe calculator tool.	active	declarative	2026-07-07 00:39:55.032264+00	2026-07-07 00:39:55.032264+00	system	{}	\N	\N	\N	private	reactive	f
c16137fe-0aa3-4c99-982c-37a922197591	slack-notifier	platform	Sends Slack notifications via webhook. Uses notification_skill.	active	declarative	2026-07-07 00:39:55.122841+00	2026-07-07 00:39:55.122841+00	system	{}	\N	\N	\N	private	reactive	f
7823dd18-16ca-4b2b-835f-6418f3c6df5c	echo-agent	platform	Minimal reference SDK agent. Source: services/echo-agent/. Responds to /health and /ready.	active	sdk	2026-07-07 00:39:55.158591+00	2026-07-07 00:39:55.158591+00	system	{}	\N	\N	\N	private	reactive	f
885ca44b-4b76-45e8-aab2-977f36d12356	order-agent	platform	Example order-processing SDK agent with HITL approval gate. Source: examples/order-agent/.	active	sdk	2026-07-07 00:39:55.196539+00	2026-07-07 00:39:55.196539+00	system	{}	\N	\N	\N	private	reactive	f
f7b20a25-a254-46d0-ba2d-9d31f79fa0ce	analyst-synthesizer	platform	Consume all research outputs, synthesize, produce actionable insight.	active	declarative	2026-07-07 01:31:14.33809+00	2026-07-07 01:31:14.33809+00	643b0e62-b437-40f8-8104-57c34203624b	{"tools": [], "instructions": "Role: Consume all research outputs, synthesize, produce actionable insight.\\n\\nInstructions:\\nYou are a senior equity analyst. You receive structured research from\\nthree specialized agents covering: (1) company news/announcements,\\n(2) earnings/financials, (3) industry/macro trends.\\n\\n## Your task\\nSynthesize all inputs into a coherent investment thesis and trade recommendation.\\n\\n## Analysis framework\\n1. **Bull case** — strongest 2-3 arguments for upside\\n2. **Bear case** — strongest 2-3 arguments for downside\\n3. **Catalyst map** — upcoming events that could move the stock (with dates)\\n4. **Signal conflicts** — where the data disagrees with itself\\n5. **What's not priced in** — the edge, if any\\n\\n## Output format (JSON)\\n{\\n  \\"ticker\\": \\"AAPL\\",\\n  \\"analysis_date\\": \\"2026-07-06\\",\\n  \\"executive_summary\\": \\"2-3 sentence thesis\\",\\n  \\"bull_case\\": [\\"...\\", \\"...\\"],\\n  \\"bear_case\\": [\\"...\\", \\"...\\"],\\n  \\"catalysts\\": [\\n    {\\"date\\": \\"...\\", \\"event\\": \\"...\\", \\"expected_impact\\": \\"...\\"}\\n  ],\\n  \\"signal_conflicts\\": [\\"...\\"],\\n  \\"not_priced_in\\": \\"...\\",\\n  \\"recommendation\\": {\\n    \\"action\\": \\"BUY|SELL|HOLD|AVOID\\",\\n   \\"conviction\\": \\"high|medium|low\\",\\n    \\"timeframe\\": \\"short-term (<1mo)|medium-term (1-6mo)|long-term (6mo+)\\",\\n    \\"entry_zone\\": \\"price range or 'at market'\\",\\n    \\"stop_loss\\": \\"price or percentage\\",\\n    \\"target\\": \\"price or percentage upside\\",\\n    \\"position_size\\": \\"full|half|starter\\",\\n    \\"rationale\\": \\"1-2 sentences on WHY this action NOW\\"\\n  },\\n  \\"risk_factors\\": [\\"...\\"],\\n  \\"confidence_level\\": \\"high|medium|low\\",\\n  \\"data_gaps\\": [\\"things we couldn't find that would change the view\\"]\\n}\\n\\n## Rules\\n- NEVER fabricate data points — cite which research agent provided each claim\\n- State confidence honestly — if data is thin, say so\\n- Distinguish between \\"good company\\" and \\"good stock at this price\\"\\n- Account for timing — is the move already done?\\n- Flag if you'd want more data before acting (and what data)\\n- Include explicit risk management (stop loss, position sizing)\\n- Disclaimer: This is AI-generated analysis, not financial advice\\n", "llm_provider_id": "0d1ed29f-9046-4025-b28b-bcaaa5845015"}	\N	\N	\N	private	reactive	t
40eb1326-5596-44f6-8670-cc63b8a90249	research-agent	platform	It is research agent	deprecated	declarative	2026-07-07 01:24:56.241919+00	2026-07-07 01:31:32.703401+00	643b0e62-b437-40f8-8104-57c34203624b	{"tools": ["web_search"], "instructions": "You are a financial research agent. Given a company ticker and name,\\n  search for and collect the most impactful recent announcements.\\n\\n  ## Search targets\\n  - Press releases (last 30 days)\\n  - SEC filings (8-K, 10-Q, proxy statements)\\n  - Product launches, partnerships, acquisitions\\n  - Executive changes (CEO/CFO/CTO turnover)\\n  - Litigation, regulatory actions\\n  - Insider trading activity (Form 4 filings)\\n\\n  ## Output format (JSON)\\n  {\\n    \\"ticker\\": \\"AAPL\\",\\n    \\"period\\": \\"2026-06-06 to 2026-07-06\\",\\n    \\"announcements\\": [\\n      {\\n        \\"date\\": \\"2026-07-01\\",\\n        \\"headline\\": \\"...\\",\\n        \\"source\\": \\"url\\",\\n        \\"category\\": \\"product_launch|executive|legal|partnership|filing|insider\\",\\n        \\"sentiment\\": \\"bullish|bearish|neutral\\",\\n        \\"magnitude\\": \\"high|medium|low\\",\\n        \\"summary\\": \\"2-3 sentence impact assessment\\"\\n      }\\n    ]\\n  }\\n\\n  ## Rules\\n  - Cite sources with URLs\\n  - Rank by potential stock-price impact (magnitude)\\n  - Flag anything that hasn't been priced in yet (after-hours, pre-market)\\n  - Distinguish confirmed news from rumors\\n  - No hallucinated data — if you can't find it, say so"}	\N	\N	\N	private	reactive	t
46114fc1-941e-4204-a026-a7ed79eb5b80	news-announcements-researcher	platform	Find recent company-specific news that could move stock price.	active	declarative	2026-07-07 01:33:16.660484+00	2026-07-07 01:33:16.660484+00	643b0e62-b437-40f8-8104-57c34203624b	{"tools": ["web_search"], "instructions": "Role: Find recent company-specific news that could move stock price.\\n\\nInstructions:\\nYou are a financial research agent. Given a company ticker and name,\\nsearch for and collect the most impactful recent announcements.\\n\\n## Search targets\\n- Press releases (last 30 days)\\n- SEC filings (8-K, 10-Q, proxy statements)\\n- Product launches, partnerships, acquisitions\\n- Executive changes (CEO/CFO/CTO turnover)\\n- Litigation, regulatory actions\\n- Insider trading activity (Form 4 filings)\\n\\n## Output format (JSON)\\n{\\n  \\"ticker\\": \\"AAPL\\",\\n  \\"period\\": \\"2026-06-06 to 2026-07-06\\",\\n  \\"announcements\\": [\\n    {\\n      \\"date\\": \\"2026-07-01\\",\\n      \\"headline\\": \\"...\\",\\n      \\"source\\": \\"url\\",\\n      \\"category\\": \\"product_launch|executive|legal|partnership|filing|insider\\",\\n      \\"sentiment\\": \\"bullish|bearish|neutral\\",\\n      \\"magnitude\\": \\"high|medium|low\\",\\n      \\"summary\\": \\"2-3 sentence impact assessment\\"\\n    }\\n  ]\\n}\\n\\n## Rules\\n- Cite sources with URLs\\n- Rank by potential stock-price impact (magnitude)\\n- Flag anything that hasn't been priced in yet (after-hours, pre-market)\\n- Distinguish confirmed news from rumors\\n- No hallucinated data — if you can't find it, say so", "llm_provider_id": "0d1ed29f-9046-4025-b28b-bcaaa5845015"}	\N	\N	\N	private	reactive	f
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alembic_version (version_num) FROM stdin;
0032
\.


--
-- Data for Name: approval_authority; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.approval_authority (id, resource_type, resource_id, approver_user_id, approver_role, granted_by, granted_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: approvals; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.approvals (id, agent_id, agent_name, team, thread_id, tool_name, tool_args, risk_level, status, reviewer_id, reviewer_notes, trace_id, session_id, opa_decision_id, decision_at, expires_at, created_at, version, context, notify_slack) FROM stdin;
\.


--
-- Data for Name: asset_grants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.asset_grants (id, asset_id, asset_type, grantee_team, granted_by, granted_at, expires_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: auth_configs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_configs (id, name, type, k8s_secret_ref, owner_team, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: deployments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deployments (id, agent_id, version_id, environment, status, replicas, canary_percent, k8s_namespace, k8s_deployment_name, error_message, deployed_at, terminated_at, deployed_by, previous_version_id, llm_secret_name, llm_env_keys, llm_provider_type, llm_provider_model) FROM stdin;
898bcd45-ec68-44e1-a39b-b71f1f4556c2	46114fc1-941e-4204-a026-a7ed79eb5b80	e619a523-939c-49c1-b90c-7bba4b0173a5	sandbox	gate_failed	1	\N	agents-platform	\N	version eval has not passed	2026-07-07 01:35:05.20641+00	\N	\N	\N	\N	null	\N	\N
17fa8dc4-b022-47ca-90c2-38a3f866b7f0	f7b20a25-a254-46d0-ba2d-9d31f79fa0ce	75c0e4df-704a-44bd-b7df-b98f4f865ae9	sandbox	gate_failed	1	\N	agents-platform	\N	version eval has not passed	2026-07-07 01:35:12.376038+00	\N	\N	\N	\N	null	\N	\N
\.


--
-- Data for Name: eval_run_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.eval_run_results (id, eval_run_id, dataset_item_idx, input_message, response, judge_score, judge_reasoning, passed, langfuse_trace_id, created_at) FROM stdin;
\.


--
-- Data for Name: eval_runs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.eval_runs (id, user_id, agent_name, agent_version_id, dataset_id, status, total_items, passed_count, failed_count, overall_score, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: grant_audit; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.grant_audit (id, admin_id, action, asset_id, grantee_team, "timestamp") FROM stdin;
\.


--
-- Data for Name: llm_providers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.llm_providers (id, name, provider, default_model, credentials_encrypted, team, created_at, updated_at) FROM stdin;
0d1ed29f-9046-4025-b28b-bcaaa5845015	bedrock	bedrock	claude-sonnet-4-6	gAAAAABqTFZvzQg8e_VJUwPR1jzSBaJQZEomQzixgnWCjdStNKjspd-RiyCm70c4pbzp7m5nKBl31SqswCT6WI--h3QRReJ20WCLWTj8cK6SNkyPGJiUyGpXAChLUKphBsPwdUTDZO5AD8aUIB-mKDocN5CbgCzDjtAEqjF0ELg8RP1YMM4_qOYplGJhR2yOt9djrls7zDws	platform	2026-07-07 01:29:19.708727+00	2026-07-07 01:29:19.708727+00
\.


--
-- Data for Name: mcp_servers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mcp_servers (id, name, description, server_url, transport, auth_config_id, owner_team, status, last_synced_at, discovered_tool_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: opa_decisions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.opa_decisions (id, agent_name, tool_name, decision, policy_version, input_snapshot, deny_reason, thread_id, trace_id, decided_at) FROM stdin;
\.


--
-- Data for Name: pii_mappings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pii_mappings (id, session_id, agent_name, original_text, anonymized_text, entity_type, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: playground_datasets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.playground_datasets (id, owner_user_id, name, items, created_at) FROM stdin;
\.


--
-- Data for Name: playground_runs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.playground_runs (id, user_id, agent_name, agent_version_id, context, sandbox, input_message, langfuse_trace_id, started_at, completed_at, status, judge_score, judge_status, judge_reason, execution_shape, input_payload, trigger_type, trigger_payload, output_text) FROM stdin;
\.


--
-- Data for Name: publish_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.publish_requests (id, asset_id, asset_type, submitted_by, submitted_at, status, highest_risk_level, dependency_declaration, reviewed_by, reviewed_at, review_notes) FROM stdin;
\.


--
-- Data for Name: run_steps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.run_steps (id, run_id, step_number, name, status, started_at, completed_at, output, approval_id, error_message) FROM stdin;
\.


--
-- Data for Name: skills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.skills (id, name, team, description, tool_ids, status, created_at, updated_at, created_by) FROM stdin;
ddd5a8d3-c383-4d27-8191-a060a38b837a	web_research_skill	platform	Bundled search + weather + geolocation tools for research agents.	[]	active	2026-07-07 00:39:54.806643+00	2026-07-07 00:39:54.806643+00	\N
161c3316-dda8-4f1a-94ef-788a606e8568	notification_skill	platform	Slack notification tool bundle.	[]	active	2026-07-07 00:39:54.881863+00	2026-07-07 00:39:54.881863+00	\N
\.


--
-- Data for Name: teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teams (id, name, namespace, keycloak_role_id, description, created_at, updated_at) FROM stdin;
d1c5306c-bd79-452c-bfda-5136dd47a5dd	platform	agents-platform	\N	\N	2026-07-07 00:39:50.99026+00	2026-07-07 00:39:50.99026+00
486f34ec-3fcb-43b4-bc91-59096435a395	operations	agents-operations	\N	\N	2026-07-07 00:39:51.068746+00	2026-07-07 00:39:51.068746+00
\.


--
-- Data for Name: tools; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tools (id, name, display_name, description, category, tags, type, input_schema, output_schema, risk_level, auth_config_id, owner_team, version, status, http_method, http_url, http_headers, http_body_template, http_timeout_ms, mcp_server_id, mcp_tool_name, created_at, updated_at, python_code) FROM stdin;
b08a926a-4864-4446-a057-d574e401d3a3	web_search	Web Search	Search the web using Serper.dev. Pass X-API-KEY header via agent auth config.	\N	\N	http	null	null	low	\N	platform	1	active	POST	https://google.serper.dev/search	{"X-API-KEY": "{{serper_api_key}}", "Content-Type": "application/json"}	{"q":"{{query}}","num":5}	\N	\N	\N	2026-07-07 00:39:54.146538+00	2026-07-07 00:39:54.146538+00	\N
faba1f79-82d4-47a5-9d89-559051b6fc59	weather_lookup	Weather Lookup	Get current weather for a location using Open-Meteo (free, no API key required).	\N	\N	http	null	null	low	\N	platform	1	active	GET	https://api.open-meteo.com/v1/forecast?latitude={{latitude}}&longitude={{longitude}}&current_weather=true	null	\N	\N	\N	\N	2026-07-07 00:39:54.386772+00	2026-07-07 00:39:54.386772+00	\N
1ab75805-fecc-441e-ada3-8667316923cf	ip_geolocation	IP Geolocation	Geolocate an IP address using ip-api.com (free, no key required).	\N	\N	http	null	null	low	\N	platform	1	active	GET	http://ip-api.com/json/{{ip}}	null	\N	\N	\N	\N	2026-07-07 00:39:54.465277+00	2026-07-07 00:39:54.465277+00	\N
5f0c4dbd-3867-4c6a-8ffd-20b15a99850d	slack_notify	Slack Notify	Send a message to a Slack channel via webhook. Pass webhook_url and message at call time.	\N	\N	http	null	null	medium	\N	platform	1	active	POST	{{webhook_url}}	{"Content-Type": "application/json"}	{"text":"{{message}}"}	\N	\N	\N	2026-07-07 00:39:54.535522+00	2026-07-07 00:39:54.535522+00	\N
76f18603-14fb-4197-9d75-23ac77d2b37c	http_echo	HTTP Echo	Echo HTTP requests back via httpbin.org. Useful for testing tool integration.	\N	\N	http	null	null	low	\N	platform	1	active	GET	https://httpbin.org/anything/{{path}}	null	\N	\N	\N	\N	2026-07-07 00:39:54.602457+00	2026-07-07 00:39:54.602457+00	\N
d94a4660-cb9c-4df6-94e3-495553bb10ab	calculator	Calculator	Evaluate math expressions safely using Python AST. No eval(), no imports.	\N	\N	python	null	null	low	\N	platform	1	active	\N	\N	null	\N	\N	\N	\N	2026-07-07 00:39:54.705154+00	2026-07-07 00:39:54.705154+00	def run_tool(args: dict) -> str:\n    """Evaluate a math expression. args: {"expression": "(5+3)*2"}"""\n    import ast, operator\n    ops = {\n        ast.Add: operator.add, ast.Sub: operator.sub,\n        ast.Mult: operator.mul, ast.Div: operator.truediv,\n        ast.Pow: operator.pow, ast.Mod: operator.mod,\n    }\n    def _eval(node):\n        if isinstance(node, ast.Constant):\n            return node.value\n        if isinstance(node, ast.BinOp):\n            return ops[type(node.op)](_eval(node.left), _eval(node.right))\n        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):\n            return -_eval(node.operand)\n        raise ValueError(f"Unsupported operation: {ast.dump(node)}")\n    tree = ast.parse(args["expression"], mode="eval")\n    result = _eval(tree.body)\n    return str(result)
\.


--
-- Data for Name: user_team_assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_team_assignments (user_sub, team_name, role, assigned_by, assigned_at) FROM stdin;
643b0e62-b437-40f8-8104-57c34203624b	platform	admin	admin	2026-07-07 01:11:00.211963+00
\.


--
-- Data for Name: workflow_edges; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workflow_edges (id, workflow_id, source_agent_id, target_agent_id, condition, "position", created_at) FROM stdin;
\.


--
-- Data for Name: workflow_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workflow_members (workflow_id, agent_id, role, "position", routing, added_at) FROM stdin;
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workflows (id, name, team, description, execution_shape, memory_enabled, orchestration, status, publish_status, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Name: agent_events agent_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_events
    ADD CONSTRAINT agent_events_pkey PRIMARY KEY (id);


--
-- Name: agent_identities agent_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_identities
    ADD CONSTRAINT agent_identities_pkey PRIMARY KEY (id);


--
-- Name: agent_memory agent_memory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_memory
    ADD CONSTRAINT agent_memory_pkey PRIMARY KEY (id);


--
-- Name: agent_policies agent_policies_agent_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_policies
    ADD CONSTRAINT agent_policies_agent_id_key UNIQUE (agent_id);


--
-- Name: agent_policies agent_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_policies
    ADD CONSTRAINT agent_policies_pkey PRIMARY KEY (id);


--
-- Name: agent_runs agent_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_runs
    ADD CONSTRAINT agent_runs_pkey PRIMARY KEY (id);


--
-- Name: agent_tools agent_tools_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_tools
    ADD CONSTRAINT agent_tools_pkey PRIMARY KEY (agent_id, tool_id);


--
-- Name: agent_triggers agent_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_triggers
    ADD CONSTRAINT agent_triggers_pkey PRIMARY KEY (id);


--
-- Name: agent_versions agent_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_versions
    ADD CONSTRAINT agent_versions_pkey PRIMARY KEY (id);


--
-- Name: agents agents_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_name_key UNIQUE (name);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: approval_authority approval_authority_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approval_authority
    ADD CONSTRAINT approval_authority_pkey PRIMARY KEY (id);


--
-- Name: approvals approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_pkey PRIMARY KEY (id);


--
-- Name: asset_grants asset_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.asset_grants
    ADD CONSTRAINT asset_grants_pkey PRIMARY KEY (id);


--
-- Name: auth_configs auth_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_configs
    ADD CONSTRAINT auth_configs_pkey PRIMARY KEY (id);


--
-- Name: deployments deployments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_pkey PRIMARY KEY (id);


--
-- Name: eval_run_results eval_run_results_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eval_run_results
    ADD CONSTRAINT eval_run_results_pkey PRIMARY KEY (id);


--
-- Name: eval_runs eval_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eval_runs
    ADD CONSTRAINT eval_runs_pkey PRIMARY KEY (id);


--
-- Name: grant_audit grant_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grant_audit
    ADD CONSTRAINT grant_audit_pkey PRIMARY KEY (id);


--
-- Name: llm_providers llm_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_providers
    ADD CONSTRAINT llm_providers_pkey PRIMARY KEY (id);


--
-- Name: mcp_servers mcp_servers_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_servers
    ADD CONSTRAINT mcp_servers_name_key UNIQUE (name);


--
-- Name: mcp_servers mcp_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_servers
    ADD CONSTRAINT mcp_servers_pkey PRIMARY KEY (id);


--
-- Name: opa_decisions opa_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.opa_decisions
    ADD CONSTRAINT opa_decisions_pkey PRIMARY KEY (id);


--
-- Name: pii_mappings pii_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pii_mappings
    ADD CONSTRAINT pii_mappings_pkey PRIMARY KEY (id);


--
-- Name: playground_datasets playground_datasets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playground_datasets
    ADD CONSTRAINT playground_datasets_pkey PRIMARY KEY (id);


--
-- Name: playground_runs playground_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playground_runs
    ADD CONSTRAINT playground_runs_pkey PRIMARY KEY (id);


--
-- Name: publish_requests publish_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.publish_requests
    ADD CONSTRAINT publish_requests_pkey PRIMARY KEY (id);


--
-- Name: run_steps run_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.run_steps
    ADD CONSTRAINT run_steps_pkey PRIMARY KEY (id);


--
-- Name: skills skills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_pkey PRIMARY KEY (id);


--
-- Name: teams teams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT teams_pkey PRIMARY KEY (id);


--
-- Name: tools tools_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tools
    ADD CONSTRAINT tools_name_key UNIQUE (name);


--
-- Name: tools tools_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tools
    ADD CONSTRAINT tools_pkey PRIMARY KEY (id);


--
-- Name: agent_graph_versions uq_agent_graph_versions; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_graph_versions
    ADD CONSTRAINT uq_agent_graph_versions UNIQUE (agent_graph_id, version_number);


--
-- Name: agent_versions uq_agent_versions; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_versions
    ADD CONSTRAINT uq_agent_versions UNIQUE (agent_id, version_number);


--
-- Name: llm_providers uq_llm_providers_name_team; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.llm_providers
    ADD CONSTRAINT uq_llm_providers_name_team UNIQUE (name, team);


--
-- Name: run_steps uq_run_steps_run_step; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.run_steps
    ADD CONSTRAINT uq_run_steps_run_step UNIQUE (run_id, step_number);


--
-- Name: skills uq_skills_name_team; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT uq_skills_name_team UNIQUE (name, team);


--
-- Name: teams uq_teams_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teams
    ADD CONSTRAINT uq_teams_name UNIQUE (name);


--
-- Name: user_team_assignments user_team_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_team_assignments
    ADD CONSTRAINT user_team_assignments_pkey PRIMARY KEY (user_sub);


--
-- Name: workflow_edges workflow_edges_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_edges
    ADD CONSTRAINT workflow_edges_pkey PRIMARY KEY (id);


--
-- Name: workflow_members workflow_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_members
    ADD CONSTRAINT workflow_members_pkey PRIMARY KEY (workflow_id, agent_id);


--
-- Name: agent_graph_versions workflow_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_graph_versions
    ADD CONSTRAINT workflow_versions_pkey PRIMARY KEY (id);


--
-- Name: agent_graphs workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_graphs
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey1 PRIMARY KEY (id);


--
-- Name: idx_agent_events_agent_received; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_events_agent_received ON public.agent_events USING btree (agent_name, received_at DESC);


--
-- Name: idx_agent_events_trigger_received; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_events_trigger_received ON public.agent_events USING btree (trigger_id, received_at DESC);


--
-- Name: idx_agent_graph_versions_agent_graph_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_graph_versions_agent_graph_id ON public.agent_graph_versions USING btree (agent_graph_id);


--
-- Name: idx_agent_graphs_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_graphs_status ON public.agent_graphs USING btree (status);


--
-- Name: idx_agent_graphs_team; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_graphs_team ON public.agent_graphs USING btree (team);


--
-- Name: idx_agent_identities_agent_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_identities_agent_name ON public.agent_identities USING btree (agent_name);


--
-- Name: idx_agent_identities_sa_subject; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_agent_identities_sa_subject ON public.agent_identities USING btree (sa_subject) WHERE (revoked_at IS NULL);


--
-- Name: idx_agent_policies_agent_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_policies_agent_id ON public.agent_policies USING btree (agent_id);


--
-- Name: idx_agent_runs_workflow_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_runs_workflow_id ON public.agent_runs USING btree (workflow_id) WHERE (workflow_id IS NOT NULL);


--
-- Name: idx_agent_tools_tool_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_tools_tool_id ON public.agent_tools USING btree (tool_id);


--
-- Name: idx_agent_triggers_agent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_triggers_agent ON public.agent_triggers USING btree (agent_id);


--
-- Name: idx_agent_triggers_workflow; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_triggers_workflow ON public.agent_triggers USING btree (workflow_id) WHERE (workflow_id IS NOT NULL);


--
-- Name: idx_agent_versions_agent_created_desc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_versions_agent_created_desc ON public.agent_versions USING btree (agent_id, created_at DESC NULLS LAST);


--
-- Name: idx_agent_versions_agent_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_versions_agent_id ON public.agent_versions USING btree (agent_id);


--
-- Name: idx_agent_versions_eval; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_versions_eval ON public.agent_versions USING btree (agent_id, eval_passed);


--
-- Name: idx_agent_versions_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agent_versions_status ON public.agent_versions USING btree (status);


--
-- Name: idx_agents_llm_provider_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_llm_provider_id ON public.agents USING btree (llm_provider_id);


--
-- Name: idx_agents_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_name ON public.agents USING btree (name);


--
-- Name: idx_agents_publish_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_publish_status ON public.agents USING btree (publish_status);


--
-- Name: idx_agents_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_status ON public.agents USING btree (status);


--
-- Name: idx_agents_team; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_team ON public.agents USING btree (team);


--
-- Name: idx_agents_team_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_agents_team_id ON public.agents USING btree (team_id);


--
-- Name: idx_approval_authority_resource; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_approval_authority_resource ON public.approval_authority USING btree (resource_type, resource_id, revoked_at);


--
-- Name: idx_approvals_agent_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_approvals_agent_id ON public.approvals USING btree (agent_id);


--
-- Name: idx_approvals_created_at_desc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_approvals_created_at_desc ON public.approvals USING btree (created_at);


--
-- Name: idx_approvals_expires_at_pending; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_approvals_expires_at_pending ON public.approvals USING btree (expires_at) WHERE ((status)::text = 'pending'::text);


--
-- Name: idx_approvals_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_approvals_status ON public.approvals USING btree (status);


--
-- Name: idx_approvals_thread_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_approvals_thread_id ON public.approvals USING btree (thread_id);


--
-- Name: idx_asset_grants_lookup; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_asset_grants_lookup ON public.asset_grants USING btree (asset_id, grantee_team, revoked_at, expires_at);


--
-- Name: idx_deployments_agent_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deployments_agent_active ON public.deployments USING btree (agent_id) WHERE ((status)::text = ANY ((ARRAY['deploying'::character varying, 'running'::character varying])::text[]));


--
-- Name: idx_deployments_agent_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deployments_agent_id ON public.deployments USING btree (agent_id);


--
-- Name: idx_deployments_agent_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deployments_agent_status ON public.deployments USING btree (agent_id, status);


--
-- Name: idx_deployments_deployed_at_desc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deployments_deployed_at_desc ON public.deployments USING btree (deployed_at DESC NULLS LAST);


--
-- Name: idx_deployments_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_deployments_status ON public.deployments USING btree (status);


--
-- Name: idx_eval_run_results_eval_run_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_eval_run_results_eval_run_id ON public.eval_run_results USING btree (eval_run_id);


--
-- Name: idx_eval_runs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_eval_runs_user_id ON public.eval_runs USING btree (user_id);


--
-- Name: idx_llm_providers_team; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_llm_providers_team ON public.llm_providers USING btree (team);


--
-- Name: idx_opa_decisions_agent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_opa_decisions_agent ON public.opa_decisions USING btree (agent_name, decided_at);


--
-- Name: idx_opa_decisions_decision_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_opa_decisions_decision_time ON public.opa_decisions USING btree (decision, decided_at);


--
-- Name: idx_opa_decisions_thread; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_opa_decisions_thread ON public.opa_decisions USING btree (thread_id);


--
-- Name: idx_pii_mappings_expires_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pii_mappings_expires_at ON public.pii_mappings USING btree (expires_at);


--
-- Name: idx_pii_mappings_session_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_pii_mappings_session_id ON public.pii_mappings USING btree (session_id);


--
-- Name: idx_playground_datasets_owner; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_playground_datasets_owner ON public.playground_datasets USING btree (owner_user_id);


--
-- Name: idx_playground_runs_agent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_playground_runs_agent ON public.playground_runs USING btree (agent_name);


--
-- Name: idx_playground_runs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_playground_runs_user_id ON public.playground_runs USING btree (user_id);


--
-- Name: idx_publish_requests_asset; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_publish_requests_asset ON public.publish_requests USING btree (asset_id, status);


--
-- Name: idx_run_steps_run_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_run_steps_run_id ON public.run_steps USING btree (run_id);


--
-- Name: idx_skills_team; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_skills_team ON public.skills USING btree (team);


--
-- Name: idx_teams_keycloak_role_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_teams_keycloak_role_id ON public.teams USING btree (keycloak_role_id);


--
-- Name: idx_teams_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_teams_name ON public.teams USING btree (name);


--
-- Name: idx_tools_type_risk_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tools_type_risk_active ON public.tools USING btree (type, risk_level) WHERE ((status)::text = 'active'::text);


--
-- Name: idx_workflow_edges_source; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflow_edges_source ON public.workflow_edges USING btree (source_agent_id);


--
-- Name: idx_workflow_edges_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflow_edges_target ON public.workflow_edges USING btree (target_agent_id);


--
-- Name: idx_workflow_edges_workflow_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflow_edges_workflow_id ON public.workflow_edges USING btree (workflow_id);


--
-- Name: idx_workflow_members_agent_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflow_members_agent_id ON public.workflow_members USING btree (agent_id);


--
-- Name: idx_workflows_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflows_status ON public.workflows USING btree (status);


--
-- Name: idx_workflows_team; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_workflows_team ON public.workflows USING btree (team);


--
-- Name: ix_agent_memory_agent_team; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_agent_memory_agent_team ON public.agent_memory USING btree (agent_name, team);


--
-- Name: ix_agent_memory_embedding; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_agent_memory_embedding ON public.agent_memory USING ivfflat (content_embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: ix_agent_memory_thread_msg; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_agent_memory_thread_msg ON public.agent_memory USING btree (thread_id, message_index);


--
-- Name: ix_agent_runs_agent_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_agent_runs_agent_name ON public.agent_runs USING btree (agent_name);


--
-- Name: ix_agent_runs_session_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_agent_runs_session_id ON public.agent_runs USING btree (session_id);


--
-- Name: ix_agent_runs_started_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_agent_runs_started_at ON public.agent_runs USING btree (started_at DESC);


--
-- Name: ix_uta_team_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_uta_team_name ON public.user_team_assignments USING btree (team_name);


--
-- Name: uq_workflow_edges_src_tgt; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_workflow_edges_src_tgt ON public.workflow_edges USING btree (workflow_id, source_agent_id, target_agent_id);


--
-- Name: uq_workflows_name_team; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_workflows_name_team ON public.workflows USING btree (name, team);


--
-- Name: agent_events agent_events_trigger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_events
    ADD CONSTRAINT agent_events_trigger_id_fkey FOREIGN KEY (trigger_id) REFERENCES public.agent_triggers(id) ON DELETE SET NULL;


--
-- Name: agent_graph_versions agent_graph_versions_agent_graph_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_graph_versions
    ADD CONSTRAINT agent_graph_versions_agent_graph_id_fkey FOREIGN KEY (agent_graph_id) REFERENCES public.agent_graphs(id) ON DELETE CASCADE;


--
-- Name: agent_identities agent_identities_agent_name_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_identities
    ADD CONSTRAINT agent_identities_agent_name_fkey FOREIGN KEY (agent_name) REFERENCES public.agents(name) ON DELETE CASCADE;


--
-- Name: agent_identities agent_identities_deployment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_identities
    ADD CONSTRAINT agent_identities_deployment_id_fkey FOREIGN KEY (deployment_id) REFERENCES public.deployments(id) ON DELETE SET NULL;


--
-- Name: agent_policies agent_policies_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_policies
    ADD CONSTRAINT agent_policies_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_policies agent_policies_generated_from_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_policies
    ADD CONSTRAINT agent_policies_generated_from_version_id_fkey FOREIGN KEY (generated_from_version_id) REFERENCES public.agent_versions(id);


--
-- Name: agent_runs agent_runs_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_runs
    ADD CONSTRAINT agent_runs_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE SET NULL;


--
-- Name: agent_tools agent_tools_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_tools
    ADD CONSTRAINT agent_tools_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_tools agent_tools_tool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_tools
    ADD CONSTRAINT agent_tools_tool_id_fkey FOREIGN KEY (tool_id) REFERENCES public.tools(id) ON DELETE CASCADE;


--
-- Name: agent_triggers agent_triggers_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_triggers
    ADD CONSTRAINT agent_triggers_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agent_triggers agent_triggers_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_triggers
    ADD CONSTRAINT agent_triggers_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE CASCADE;


--
-- Name: agent_versions agent_versions_agent_graph_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_versions
    ADD CONSTRAINT agent_versions_agent_graph_id_fkey FOREIGN KEY (agent_graph_id) REFERENCES public.agent_graphs(id);


--
-- Name: agent_versions agent_versions_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_versions
    ADD CONSTRAINT agent_versions_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: agents agents_llm_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_llm_provider_id_fkey FOREIGN KEY (llm_provider_id) REFERENCES public.llm_providers(id) ON DELETE SET NULL;


--
-- Name: agents agents_team_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_team_id_fkey FOREIGN KEY (team_id) REFERENCES public.teams(id);


--
-- Name: approvals approvals_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: approvals approvals_opa_decision_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_opa_decision_id_fkey FOREIGN KEY (opa_decision_id) REFERENCES public.opa_decisions(id);


--
-- Name: deployments deployments_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: deployments deployments_previous_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_previous_version_id_fkey FOREIGN KEY (previous_version_id) REFERENCES public.agent_versions(id);


--
-- Name: deployments deployments_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deployments
    ADD CONSTRAINT deployments_version_id_fkey FOREIGN KEY (version_id) REFERENCES public.agent_versions(id);


--
-- Name: eval_runs eval_runs_dataset_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.eval_runs
    ADD CONSTRAINT eval_runs_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES public.playground_datasets(id) ON DELETE RESTRICT;


--
-- Name: agent_runs fk_agent_runs_parent; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.agent_runs
    ADD CONSTRAINT fk_agent_runs_parent FOREIGN KEY (parent_run_id) REFERENCES public.agent_runs(id);


--
-- Name: mcp_servers mcp_servers_auth_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mcp_servers
    ADD CONSTRAINT mcp_servers_auth_config_id_fkey FOREIGN KEY (auth_config_id) REFERENCES public.auth_configs(id);


--
-- Name: playground_runs playground_runs_agent_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.playground_runs
    ADD CONSTRAINT playground_runs_agent_version_id_fkey FOREIGN KEY (agent_version_id) REFERENCES public.agent_versions(id) ON DELETE SET NULL;


--
-- Name: run_steps run_steps_approval_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.run_steps
    ADD CONSTRAINT run_steps_approval_id_fkey FOREIGN KEY (approval_id) REFERENCES public.approvals(id);


--
-- Name: tools tools_auth_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tools
    ADD CONSTRAINT tools_auth_config_id_fkey FOREIGN KEY (auth_config_id) REFERENCES public.auth_configs(id);


--
-- Name: tools tools_mcp_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tools
    ADD CONSTRAINT tools_mcp_server_id_fkey FOREIGN KEY (mcp_server_id) REFERENCES public.mcp_servers(id);


--
-- Name: workflow_edges workflow_edges_source_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_edges
    ADD CONSTRAINT workflow_edges_source_agent_id_fkey FOREIGN KEY (source_agent_id) REFERENCES public.agents(id);


--
-- Name: workflow_edges workflow_edges_target_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_edges
    ADD CONSTRAINT workflow_edges_target_agent_id_fkey FOREIGN KEY (target_agent_id) REFERENCES public.agents(id);


--
-- Name: workflow_edges workflow_edges_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_edges
    ADD CONSTRAINT workflow_edges_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE CASCADE;


--
-- Name: workflow_members workflow_members_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_members
    ADD CONSTRAINT workflow_members_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id);


--
-- Name: workflow_members workflow_members_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workflow_members
    ADD CONSTRAINT workflow_members_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE CASCADE;


--
-- Name: DATABASE agentshield; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE agentshield TO agentshield_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO agentshield_user;


--
-- PostgreSQL database dump complete
--

\unrestrict dYIg5vG72K2srerkPkToEthCXeelOb6PoNeRXo4Mun8hRiSBFw1df62EiG62jLc

--
-- Database "appsmith" dump
--

--
-- PostgreSQL database dump
--

\restrict 2DQvK42ZLYV5dzIzrXKbXaTKHRFUg3OVwY2g5ZvEg9pfX9IUee0xUg5UYwbEUsC

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: appsmith; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE appsmith WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE appsmith OWNER TO postgres;

\unrestrict 2DQvK42ZLYV5dzIzrXKbXaTKHRFUg3OVwY2g5ZvEg9pfX9IUee0xUg5UYwbEUsC
\connect appsmith
\restrict 2DQvK42ZLYV5dzIzrXKbXaTKHRFUg3OVwY2g5ZvEg9pfX9IUee0xUg5UYwbEUsC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE appsmith; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE appsmith TO appsmith_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO appsmith_user;


--
-- PostgreSQL database dump complete
--

\unrestrict 2DQvK42ZLYV5dzIzrXKbXaTKHRFUg3OVwY2g5ZvEg9pfX9IUee0xUg5UYwbEUsC

--
-- Database "keycloak" dump
--

--
-- PostgreSQL database dump
--

\restrict n1etryO2MJJGAs4QaZ1des44nowfSsYp8G3J4ne3FDa76tb8dPRhRXLV7vxwCrV

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: keycloak; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE keycloak WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE keycloak OWNER TO postgres;

\unrestrict n1etryO2MJJGAs4QaZ1des44nowfSsYp8G3J4ne3FDa76tb8dPRhRXLV7vxwCrV
\connect keycloak
\restrict n1etryO2MJJGAs4QaZ1des44nowfSsYp8G3J4ne3FDa76tb8dPRhRXLV7vxwCrV

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_event_entity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin_event_entity (
    id character varying(36) NOT NULL,
    admin_event_time bigint,
    realm_id character varying(255),
    operation_type character varying(255),
    auth_realm_id character varying(255),
    auth_client_id character varying(255),
    auth_user_id character varying(255),
    ip_address character varying(255),
    resource_path character varying(2550),
    representation text,
    error character varying(255),
    resource_type character varying(64),
    details_json text
);


ALTER TABLE public.admin_event_entity OWNER TO postgres;

--
-- Name: associated_policy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.associated_policy (
    policy_id character varying(36) NOT NULL,
    associated_policy_id character varying(36) NOT NULL
);


ALTER TABLE public.associated_policy OWNER TO postgres;

--
-- Name: authentication_execution; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authentication_execution (
    id character varying(36) NOT NULL,
    alias character varying(255),
    authenticator character varying(36),
    realm_id character varying(36),
    flow_id character varying(36),
    requirement integer,
    priority integer,
    authenticator_flow boolean DEFAULT false NOT NULL,
    auth_flow_id character varying(36),
    auth_config character varying(36)
);


ALTER TABLE public.authentication_execution OWNER TO postgres;

--
-- Name: authentication_flow; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authentication_flow (
    id character varying(36) NOT NULL,
    alias character varying(255),
    description character varying(255),
    realm_id character varying(36),
    provider_id character varying(36) DEFAULT 'basic-flow'::character varying NOT NULL,
    top_level boolean DEFAULT false NOT NULL,
    built_in boolean DEFAULT false NOT NULL
);


ALTER TABLE public.authentication_flow OWNER TO postgres;

--
-- Name: authenticator_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authenticator_config (
    id character varying(36) CONSTRAINT authenticator_id_not_null NOT NULL,
    alias character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.authenticator_config OWNER TO postgres;

--
-- Name: authenticator_config_entry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authenticator_config_entry (
    authenticator_id character varying(36) CONSTRAINT authenticator_config_authenticator_id_not_null NOT NULL,
    value text,
    name character varying(255) CONSTRAINT authenticator_config_name_not_null NOT NULL
);


ALTER TABLE public.authenticator_config_entry OWNER TO postgres;

--
-- Name: broker_link; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.broker_link (
    identity_provider character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL,
    broker_user_id character varying(255),
    broker_username character varying(255),
    token text,
    user_id character varying(255) NOT NULL
);


ALTER TABLE public.broker_link OWNER TO postgres;

--
-- Name: client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client (
    id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    full_scope_allowed boolean DEFAULT false NOT NULL,
    client_id character varying(255),
    not_before integer,
    public_client boolean DEFAULT false NOT NULL,
    secret character varying(255),
    base_url character varying(255),
    bearer_only boolean DEFAULT false NOT NULL,
    management_url character varying(255),
    surrogate_auth_required boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    protocol character varying(255),
    node_rereg_timeout integer DEFAULT 0,
    frontchannel_logout boolean DEFAULT false NOT NULL,
    consent_required boolean DEFAULT false NOT NULL,
    name character varying(255),
    service_accounts_enabled boolean DEFAULT false NOT NULL,
    client_authenticator_type character varying(255),
    root_url character varying(255),
    description character varying(255),
    registration_token character varying(255),
    standard_flow_enabled boolean DEFAULT true NOT NULL,
    implicit_flow_enabled boolean DEFAULT false NOT NULL,
    direct_access_grants_enabled boolean DEFAULT false NOT NULL,
    always_display_in_console boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client OWNER TO postgres;

--
-- Name: client_attributes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_attributes (
    client_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.client_attributes OWNER TO postgres;

--
-- Name: client_auth_flow_bindings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_auth_flow_bindings (
    client_id character varying(36) NOT NULL,
    flow_id character varying(36),
    binding_name character varying(255) NOT NULL
);


ALTER TABLE public.client_auth_flow_bindings OWNER TO postgres;

--
-- Name: client_initial_access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_initial_access (
    id character varying(36) NOT NULL,
    realm_id character varying(36) NOT NULL,
    "timestamp" integer,
    expiration integer,
    count integer,
    remaining_count integer
);


ALTER TABLE public.client_initial_access OWNER TO postgres;

--
-- Name: client_node_registrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_node_registrations (
    client_id character varying(36) CONSTRAINT app_node_registrations_application_id_not_null NOT NULL,
    value integer,
    name character varying(255) CONSTRAINT app_node_registrations_name_not_null NOT NULL
);


ALTER TABLE public.client_node_registrations OWNER TO postgres;

--
-- Name: client_scope; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_scope (
    id character varying(36) CONSTRAINT client_template_id_not_null NOT NULL,
    name character varying(255),
    realm_id character varying(36),
    description character varying(255),
    protocol character varying(255)
);


ALTER TABLE public.client_scope OWNER TO postgres;

--
-- Name: client_scope_attributes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_scope_attributes (
    scope_id character varying(36) CONSTRAINT client_template_attributes_template_id_not_null NOT NULL,
    value character varying(2048),
    name character varying(255) CONSTRAINT client_template_attributes_name_not_null NOT NULL
);


ALTER TABLE public.client_scope_attributes OWNER TO postgres;

--
-- Name: client_scope_client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_scope_client (
    client_id character varying(255) NOT NULL,
    scope_id character varying(255) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.client_scope_client OWNER TO postgres;

--
-- Name: client_scope_role_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.client_scope_role_mapping (
    scope_id character varying(36) CONSTRAINT template_scope_mapping_template_id_not_null NOT NULL,
    role_id character varying(36) CONSTRAINT template_scope_mapping_role_id_not_null NOT NULL
);


ALTER TABLE public.client_scope_role_mapping OWNER TO postgres;

--
-- Name: component; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.component (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_id character varying(36),
    provider_id character varying(36),
    provider_type character varying(255),
    realm_id character varying(36),
    sub_type character varying(255)
);


ALTER TABLE public.component OWNER TO postgres;

--
-- Name: component_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.component_config (
    id character varying(36) NOT NULL,
    component_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.component_config OWNER TO postgres;

--
-- Name: composite_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.composite_role (
    composite character varying(36) NOT NULL,
    child_role character varying(36) NOT NULL
);


ALTER TABLE public.composite_role OWNER TO postgres;

--
-- Name: credential; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    user_id character varying(36),
    created_date bigint,
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.credential OWNER TO postgres;

--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO postgres;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE public.databasechangeloglock OWNER TO postgres;

--
-- Name: default_client_scope; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.default_client_scope (
    realm_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL,
    default_scope boolean DEFAULT false NOT NULL
);


ALTER TABLE public.default_client_scope OWNER TO postgres;

--
-- Name: event_entity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event_entity (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    details_json character varying(2550),
    error character varying(255),
    ip_address character varying(255),
    realm_id character varying(255),
    session_id character varying(255),
    event_time bigint,
    type character varying(255),
    user_id character varying(255),
    details_json_long_value text
);


ALTER TABLE public.event_entity OWNER TO postgres;

--
-- Name: fed_user_attribute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fed_user_attribute (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    value character varying(2024),
    long_value_hash bytea,
    long_value_hash_lower_case bytea,
    long_value text
);


ALTER TABLE public.fed_user_attribute OWNER TO postgres;

--
-- Name: fed_user_consent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fed_user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.fed_user_consent OWNER TO postgres;

--
-- Name: fed_user_consent_cl_scope; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fed_user_consent_cl_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.fed_user_consent_cl_scope OWNER TO postgres;

--
-- Name: fed_user_credential; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fed_user_credential (
    id character varying(36) NOT NULL,
    salt bytea,
    type character varying(255),
    created_date bigint,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36),
    user_label character varying(255),
    secret_data text,
    credential_data text,
    priority integer
);


ALTER TABLE public.fed_user_credential OWNER TO postgres;

--
-- Name: fed_user_group_membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fed_user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_group_membership OWNER TO postgres;

--
-- Name: fed_user_required_action; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fed_user_required_action (
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_required_action OWNER TO postgres;

--
-- Name: fed_user_role_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fed_user_role_mapping (
    role_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    storage_provider_id character varying(36)
);


ALTER TABLE public.fed_user_role_mapping OWNER TO postgres;

--
-- Name: federated_identity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.federated_identity (
    identity_provider character varying(255) NOT NULL,
    realm_id character varying(36),
    federated_user_id character varying(255),
    federated_username character varying(255),
    token text,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_identity OWNER TO postgres;

--
-- Name: federated_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.federated_user (
    id character varying(255) NOT NULL,
    storage_provider_id character varying(255),
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.federated_user OWNER TO postgres;

--
-- Name: group_attribute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.group_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_attribute OWNER TO postgres;

--
-- Name: group_role_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.group_role_mapping (
    role_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.group_role_mapping OWNER TO postgres;

--
-- Name: identity_provider; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.identity_provider (
    internal_id character varying(36) NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    provider_alias character varying(255),
    provider_id character varying(255),
    store_token boolean DEFAULT false NOT NULL,
    authenticate_by_default boolean DEFAULT false NOT NULL,
    realm_id character varying(36),
    add_token_role boolean DEFAULT true NOT NULL,
    trust_email boolean DEFAULT false NOT NULL,
    first_broker_login_flow_id character varying(36),
    post_broker_login_flow_id character varying(36),
    provider_display_name character varying(255),
    link_only boolean DEFAULT false NOT NULL,
    organization_id character varying(255),
    hide_on_login boolean DEFAULT false
);


ALTER TABLE public.identity_provider OWNER TO postgres;

--
-- Name: identity_provider_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.identity_provider_config (
    identity_provider_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.identity_provider_config OWNER TO postgres;

--
-- Name: identity_provider_mapper; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.identity_provider_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    idp_alias character varying(255) NOT NULL,
    idp_mapper_name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.identity_provider_mapper OWNER TO postgres;

--
-- Name: idp_mapper_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.idp_mapper_config (
    idp_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.idp_mapper_config OWNER TO postgres;

--
-- Name: keycloak_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.keycloak_group (
    id character varying(36) NOT NULL,
    name character varying(255),
    parent_group character varying(36) NOT NULL,
    realm_id character varying(36),
    type integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.keycloak_group OWNER TO postgres;

--
-- Name: keycloak_role; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.keycloak_role (
    id character varying(36) NOT NULL,
    client_realm_constraint character varying(255),
    client_role boolean DEFAULT false CONSTRAINT keycloak_role_application_role_not_null NOT NULL,
    description character varying(255),
    name character varying(255),
    realm_id character varying(255),
    client character varying(36),
    realm character varying(36)
);


ALTER TABLE public.keycloak_role OWNER TO postgres;

--
-- Name: migration_model; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migration_model (
    id character varying(36) NOT NULL,
    version character varying(36),
    update_time bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.migration_model OWNER TO postgres;

--
-- Name: offline_client_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.offline_client_session (
    user_session_id character varying(36) NOT NULL,
    client_id character varying(255) NOT NULL,
    offline_flag character varying(4) NOT NULL,
    "timestamp" integer,
    data text,
    client_storage_provider character varying(36) DEFAULT 'local'::character varying NOT NULL,
    external_client_id character varying(255) DEFAULT 'local'::character varying NOT NULL,
    version integer DEFAULT 0
);


ALTER TABLE public.offline_client_session OWNER TO postgres;

--
-- Name: offline_user_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.offline_user_session (
    user_session_id character varying(36) NOT NULL,
    user_id character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    created_on integer NOT NULL,
    offline_flag character varying(4) NOT NULL,
    data text,
    last_session_refresh integer DEFAULT 0 NOT NULL,
    broker_session_id character varying(1024),
    version integer DEFAULT 0
);


ALTER TABLE public.offline_user_session OWNER TO postgres;

--
-- Name: org; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.org (
    id character varying(255) NOT NULL,
    enabled boolean NOT NULL,
    realm_id character varying(255) NOT NULL,
    group_id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(4000),
    alias character varying(255) NOT NULL,
    redirect_url character varying(2048)
);


ALTER TABLE public.org OWNER TO postgres;

--
-- Name: org_domain; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.org_domain (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    verified boolean NOT NULL,
    org_id character varying(255) NOT NULL
);


ALTER TABLE public.org_domain OWNER TO postgres;

--
-- Name: policy_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.policy_config (
    policy_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value text
);


ALTER TABLE public.policy_config OWNER TO postgres;

--
-- Name: protocol_mapper; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.protocol_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    protocol character varying(255) NOT NULL,
    protocol_mapper_name character varying(255) NOT NULL,
    client_id character varying(36),
    client_scope_id character varying(36)
);


ALTER TABLE public.protocol_mapper OWNER TO postgres;

--
-- Name: protocol_mapper_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.protocol_mapper_config (
    protocol_mapper_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.protocol_mapper_config OWNER TO postgres;

--
-- Name: realm; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.realm (
    id character varying(36) NOT NULL,
    access_code_lifespan integer,
    user_action_lifespan integer,
    access_token_lifespan integer,
    account_theme character varying(255),
    admin_theme character varying(255),
    email_theme character varying(255),
    enabled boolean DEFAULT false NOT NULL,
    events_enabled boolean DEFAULT false NOT NULL,
    events_expiration bigint,
    login_theme character varying(255),
    name character varying(255),
    not_before integer,
    password_policy character varying(2550),
    registration_allowed boolean DEFAULT false NOT NULL,
    remember_me boolean DEFAULT false NOT NULL,
    reset_password_allowed boolean DEFAULT false NOT NULL,
    social boolean DEFAULT false NOT NULL,
    ssl_required character varying(255),
    sso_idle_timeout integer,
    sso_max_lifespan integer,
    update_profile_on_soc_login boolean DEFAULT false NOT NULL,
    verify_email boolean DEFAULT false NOT NULL,
    master_admin_client character varying(36),
    login_lifespan integer,
    internationalization_enabled boolean DEFAULT false NOT NULL,
    default_locale character varying(255),
    reg_email_as_username boolean DEFAULT false NOT NULL,
    admin_events_enabled boolean DEFAULT false NOT NULL,
    admin_events_details_enabled boolean DEFAULT false NOT NULL,
    edit_username_allowed boolean DEFAULT false NOT NULL,
    otp_policy_counter integer DEFAULT 0,
    otp_policy_window integer DEFAULT 1,
    otp_policy_period integer DEFAULT 30,
    otp_policy_digits integer DEFAULT 6,
    otp_policy_alg character varying(36) DEFAULT 'HmacSHA1'::character varying,
    otp_policy_type character varying(36) DEFAULT 'totp'::character varying,
    browser_flow character varying(36),
    registration_flow character varying(36),
    direct_grant_flow character varying(36),
    reset_credentials_flow character varying(36),
    client_auth_flow character varying(36),
    offline_session_idle_timeout integer DEFAULT 0,
    revoke_refresh_token boolean DEFAULT false NOT NULL,
    access_token_life_implicit integer DEFAULT 0,
    login_with_email_allowed boolean DEFAULT true NOT NULL,
    duplicate_emails_allowed boolean DEFAULT false NOT NULL,
    docker_auth_flow character varying(36),
    refresh_token_max_reuse integer DEFAULT 0,
    allow_user_managed_access boolean DEFAULT false NOT NULL,
    sso_max_lifespan_remember_me integer DEFAULT 0 NOT NULL,
    sso_idle_timeout_remember_me integer DEFAULT 0 NOT NULL,
    default_role character varying(255)
);


ALTER TABLE public.realm OWNER TO postgres;

--
-- Name: realm_attribute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.realm_attribute (
    name character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL,
    value text
);


ALTER TABLE public.realm_attribute OWNER TO postgres;

--
-- Name: realm_default_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.realm_default_groups (
    realm_id character varying(36) NOT NULL,
    group_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_default_groups OWNER TO postgres;

--
-- Name: realm_enabled_event_types; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.realm_enabled_event_types (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_enabled_event_types OWNER TO postgres;

--
-- Name: realm_events_listeners; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.realm_events_listeners (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_events_listeners OWNER TO postgres;

--
-- Name: realm_localizations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.realm_localizations (
    realm_id character varying(255) NOT NULL,
    locale character varying(255) NOT NULL,
    texts text NOT NULL
);


ALTER TABLE public.realm_localizations OWNER TO postgres;

--
-- Name: realm_required_credential; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.realm_required_credential (
    type character varying(255) NOT NULL,
    form_label character varying(255),
    input boolean DEFAULT false NOT NULL,
    secret boolean DEFAULT false NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.realm_required_credential OWNER TO postgres;

--
-- Name: realm_smtp_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.realm_smtp_config (
    realm_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.realm_smtp_config OWNER TO postgres;

--
-- Name: realm_supported_locales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.realm_supported_locales (
    realm_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.realm_supported_locales OWNER TO postgres;

--
-- Name: redirect_uris; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.redirect_uris (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.redirect_uris OWNER TO postgres;

--
-- Name: required_action_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.required_action_config (
    required_action_id character varying(36) NOT NULL,
    value text,
    name character varying(255) NOT NULL
);


ALTER TABLE public.required_action_config OWNER TO postgres;

--
-- Name: required_action_provider; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.required_action_provider (
    id character varying(36) NOT NULL,
    alias character varying(255),
    name character varying(255),
    realm_id character varying(36),
    enabled boolean DEFAULT false NOT NULL,
    default_action boolean DEFAULT false NOT NULL,
    provider_id character varying(255),
    priority integer
);


ALTER TABLE public.required_action_provider OWNER TO postgres;

--
-- Name: resource_attribute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resource_attribute (
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255),
    resource_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_attribute OWNER TO postgres;

--
-- Name: resource_policy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resource_policy (
    resource_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_policy OWNER TO postgres;

--
-- Name: resource_scope; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resource_scope (
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.resource_scope OWNER TO postgres;

--
-- Name: resource_server; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resource_server (
    id character varying(36) CONSTRAINT resource_server_client_id_not_null NOT NULL,
    allow_rs_remote_mgmt boolean DEFAULT false NOT NULL,
    policy_enforce_mode smallint NOT NULL,
    decision_strategy smallint DEFAULT 1 NOT NULL
);


ALTER TABLE public.resource_server OWNER TO postgres;

--
-- Name: resource_server_perm_ticket; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resource_server_perm_ticket (
    id character varying(36) NOT NULL,
    owner character varying(255) NOT NULL,
    requester character varying(255) NOT NULL,
    created_timestamp bigint NOT NULL,
    granted_timestamp bigint,
    resource_id character varying(36) NOT NULL,
    scope_id character varying(36),
    resource_server_id character varying(36) NOT NULL,
    policy_id character varying(36)
);


ALTER TABLE public.resource_server_perm_ticket OWNER TO postgres;

--
-- Name: resource_server_policy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resource_server_policy (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    type character varying(255) NOT NULL,
    decision_strategy smallint,
    logic smallint,
    resource_server_id character varying(36) CONSTRAINT resource_server_policy_resource_server_client_id_not_null NOT NULL,
    owner character varying(255)
);


ALTER TABLE public.resource_server_policy OWNER TO postgres;

--
-- Name: resource_server_resource; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resource_server_resource (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(255),
    icon_uri character varying(255),
    owner character varying(255) NOT NULL,
    resource_server_id character varying(36) CONSTRAINT resource_server_resource_resource_server_client_id_not_null NOT NULL,
    owner_managed_access boolean DEFAULT false NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_resource OWNER TO postgres;

--
-- Name: resource_server_scope; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resource_server_scope (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    icon_uri character varying(255),
    resource_server_id character varying(36) CONSTRAINT resource_server_scope_resource_server_client_id_not_null NOT NULL,
    display_name character varying(255)
);


ALTER TABLE public.resource_server_scope OWNER TO postgres;

--
-- Name: resource_uris; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resource_uris (
    resource_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.resource_uris OWNER TO postgres;

--
-- Name: revoked_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.revoked_token (
    id character varying(255) NOT NULL,
    expire bigint NOT NULL
);


ALTER TABLE public.revoked_token OWNER TO postgres;

--
-- Name: role_attribute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_attribute (
    id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    value character varying(255)
);


ALTER TABLE public.role_attribute OWNER TO postgres;

--
-- Name: scope_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scope_mapping (
    client_id character varying(36) NOT NULL,
    role_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_mapping OWNER TO postgres;

--
-- Name: scope_policy; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scope_policy (
    scope_id character varying(36) NOT NULL,
    policy_id character varying(36) NOT NULL
);


ALTER TABLE public.scope_policy OWNER TO postgres;

--
-- Name: user_attribute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_attribute (
    name character varying(255) NOT NULL,
    value character varying(255),
    user_id character varying(36) NOT NULL,
    id character varying(36) DEFAULT 'sybase-needs-something-here'::character varying NOT NULL,
    long_value_hash bytea,
    long_value_hash_lower_case bytea,
    long_value text
);


ALTER TABLE public.user_attribute OWNER TO postgres;

--
-- Name: user_consent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_consent (
    id character varying(36) NOT NULL,
    client_id character varying(255),
    user_id character varying(36) NOT NULL,
    created_date bigint,
    last_updated_date bigint,
    client_storage_provider character varying(36),
    external_client_id character varying(255)
);


ALTER TABLE public.user_consent OWNER TO postgres;

--
-- Name: user_consent_client_scope; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_consent_client_scope (
    user_consent_id character varying(36) NOT NULL,
    scope_id character varying(36) NOT NULL
);


ALTER TABLE public.user_consent_client_scope OWNER TO postgres;

--
-- Name: user_entity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_entity (
    id character varying(36) NOT NULL,
    email character varying(255),
    email_constraint character varying(255),
    email_verified boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    federation_link character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    realm_id character varying(255),
    username character varying(255),
    created_timestamp bigint,
    service_account_client_link character varying(255),
    not_before integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.user_entity OWNER TO postgres;

--
-- Name: user_federation_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_federation_config (
    user_federation_provider_id character varying(36) NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_config OWNER TO postgres;

--
-- Name: user_federation_mapper; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_federation_mapper (
    id character varying(36) NOT NULL,
    name character varying(255) NOT NULL,
    federation_provider_id character varying(36) NOT NULL,
    federation_mapper_type character varying(255) NOT NULL,
    realm_id character varying(36) NOT NULL
);


ALTER TABLE public.user_federation_mapper OWNER TO postgres;

--
-- Name: user_federation_mapper_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_federation_mapper_config (
    user_federation_mapper_id character varying(36) CONSTRAINT user_federation_mapper_confi_user_federation_mapper_id_not_null NOT NULL,
    value character varying(255),
    name character varying(255) NOT NULL
);


ALTER TABLE public.user_federation_mapper_config OWNER TO postgres;

--
-- Name: user_federation_provider; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_federation_provider (
    id character varying(36) NOT NULL,
    changed_sync_period integer,
    display_name character varying(255),
    full_sync_period integer,
    last_sync integer,
    priority integer,
    provider_name character varying(255),
    realm_id character varying(36)
);


ALTER TABLE public.user_federation_provider OWNER TO postgres;

--
-- Name: user_group_membership; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_group_membership (
    group_id character varying(36) NOT NULL,
    user_id character varying(36) NOT NULL,
    membership_type character varying(255) NOT NULL
);


ALTER TABLE public.user_group_membership OWNER TO postgres;

--
-- Name: user_required_action; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_required_action (
    user_id character varying(36) NOT NULL,
    required_action character varying(255) DEFAULT ' '::character varying NOT NULL
);


ALTER TABLE public.user_required_action OWNER TO postgres;

--
-- Name: user_role_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_role_mapping (
    role_id character varying(255) NOT NULL,
    user_id character varying(36) NOT NULL
);


ALTER TABLE public.user_role_mapping OWNER TO postgres;

--
-- Name: username_login_failure; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.username_login_failure (
    realm_id character varying(36) NOT NULL,
    username character varying(255) NOT NULL,
    failed_login_not_before integer,
    last_failure bigint,
    last_ip_failure character varying(255),
    num_failures integer
);


ALTER TABLE public.username_login_failure OWNER TO postgres;

--
-- Name: web_origins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.web_origins (
    client_id character varying(36) NOT NULL,
    value character varying(255) NOT NULL
);


ALTER TABLE public.web_origins OWNER TO postgres;

--
-- Data for Name: admin_event_entity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin_event_entity (id, admin_event_time, realm_id, operation_type, auth_realm_id, auth_client_id, auth_user_id, ip_address, resource_path, representation, error, resource_type, details_json) FROM stdin;
\.


--
-- Data for Name: associated_policy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.associated_policy (policy_id, associated_policy_id) FROM stdin;
\.


--
-- Data for Name: authentication_execution; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authentication_execution (id, alias, authenticator, realm_id, flow_id, requirement, priority, authenticator_flow, auth_flow_id, auth_config) FROM stdin;
1d0ac1da-d531-4e98-8fe5-dee93667c3f1	\N	auth-cookie	29bb8813-da75-41e0-b440-8ab491e3ec8a	63194eec-ce6b-4eeb-b81a-9f454ebcf9d1	2	10	f	\N	\N
ffda7761-ab04-4f99-b57c-c66c01308f4d	\N	auth-spnego	29bb8813-da75-41e0-b440-8ab491e3ec8a	63194eec-ce6b-4eeb-b81a-9f454ebcf9d1	3	20	f	\N	\N
48a039fe-833a-4ea4-89f6-18ab30ef5d7d	\N	identity-provider-redirector	29bb8813-da75-41e0-b440-8ab491e3ec8a	63194eec-ce6b-4eeb-b81a-9f454ebcf9d1	2	25	f	\N	\N
d192d4fe-b485-4dda-a90c-317e58f0c332	\N	\N	29bb8813-da75-41e0-b440-8ab491e3ec8a	63194eec-ce6b-4eeb-b81a-9f454ebcf9d1	2	30	t	f7033c67-77d0-4f4e-8db1-deb0ed07c11c	\N
f1942542-d82a-41e4-bdec-568489d27535	\N	auth-username-password-form	29bb8813-da75-41e0-b440-8ab491e3ec8a	f7033c67-77d0-4f4e-8db1-deb0ed07c11c	0	10	f	\N	\N
63a6bd46-d1f6-43a5-9877-b4e6c1a47659	\N	\N	29bb8813-da75-41e0-b440-8ab491e3ec8a	f7033c67-77d0-4f4e-8db1-deb0ed07c11c	1	20	t	7f50f847-6943-46fe-934c-8474de6264ef	\N
38b9c3a6-620b-4519-aeda-48760cffa007	\N	conditional-user-configured	29bb8813-da75-41e0-b440-8ab491e3ec8a	7f50f847-6943-46fe-934c-8474de6264ef	0	10	f	\N	\N
8e8d6692-66ac-47e0-b357-69df53757e0f	\N	auth-otp-form	29bb8813-da75-41e0-b440-8ab491e3ec8a	7f50f847-6943-46fe-934c-8474de6264ef	0	20	f	\N	\N
4f29955a-7346-4b31-9145-7b674f856a88	\N	direct-grant-validate-username	29bb8813-da75-41e0-b440-8ab491e3ec8a	72df32c4-c017-466f-9e98-43057989ceba	0	10	f	\N	\N
cc4aa42d-d260-414b-912a-1aefb3a93cee	\N	direct-grant-validate-password	29bb8813-da75-41e0-b440-8ab491e3ec8a	72df32c4-c017-466f-9e98-43057989ceba	0	20	f	\N	\N
e8c62e5d-f9f5-4526-bd32-dddc0d18f8f7	\N	\N	29bb8813-da75-41e0-b440-8ab491e3ec8a	72df32c4-c017-466f-9e98-43057989ceba	1	30	t	2a7b8a9a-c039-46d5-aeac-5f7b93033753	\N
513f1e31-ea3c-4fac-bbc4-cd5c8411faea	\N	conditional-user-configured	29bb8813-da75-41e0-b440-8ab491e3ec8a	2a7b8a9a-c039-46d5-aeac-5f7b93033753	0	10	f	\N	\N
7dac6aee-4770-4dd3-89be-69c66e06b935	\N	direct-grant-validate-otp	29bb8813-da75-41e0-b440-8ab491e3ec8a	2a7b8a9a-c039-46d5-aeac-5f7b93033753	0	20	f	\N	\N
2dabb170-ee6e-4a19-a72e-a1a22af389f6	\N	registration-page-form	29bb8813-da75-41e0-b440-8ab491e3ec8a	b547a862-3a72-477a-9e64-cd3e379f17b0	0	10	t	34bdf2c8-bba0-42cc-9e51-4a86f2935279	\N
3dcdbc18-4b6f-4eb6-9f4b-60ccba1f05e2	\N	registration-user-creation	29bb8813-da75-41e0-b440-8ab491e3ec8a	34bdf2c8-bba0-42cc-9e51-4a86f2935279	0	20	f	\N	\N
6da29805-fd2a-42c3-a5de-b9191384260f	\N	registration-password-action	29bb8813-da75-41e0-b440-8ab491e3ec8a	34bdf2c8-bba0-42cc-9e51-4a86f2935279	0	50	f	\N	\N
fbf84762-f7d2-4ab3-902b-730556539b8d	\N	registration-recaptcha-action	29bb8813-da75-41e0-b440-8ab491e3ec8a	34bdf2c8-bba0-42cc-9e51-4a86f2935279	3	60	f	\N	\N
d3d7b5c8-7c5a-4747-bf40-b1b62f69df5c	\N	registration-terms-and-conditions	29bb8813-da75-41e0-b440-8ab491e3ec8a	34bdf2c8-bba0-42cc-9e51-4a86f2935279	3	70	f	\N	\N
5d1b9c27-6121-4562-a79a-7a3df2c19721	\N	reset-credentials-choose-user	29bb8813-da75-41e0-b440-8ab491e3ec8a	bae1abb4-6a83-4415-928c-2d5d5ae80d76	0	10	f	\N	\N
67e65ac8-a9db-420e-894b-b6cfbc653f4f	\N	reset-credential-email	29bb8813-da75-41e0-b440-8ab491e3ec8a	bae1abb4-6a83-4415-928c-2d5d5ae80d76	0	20	f	\N	\N
d6b0abd0-52c3-4aa6-8ca2-8b0a52795df4	\N	reset-password	29bb8813-da75-41e0-b440-8ab491e3ec8a	bae1abb4-6a83-4415-928c-2d5d5ae80d76	0	30	f	\N	\N
b6debfed-b30e-4f8c-b21d-8b8d2cd4c326	\N	\N	29bb8813-da75-41e0-b440-8ab491e3ec8a	bae1abb4-6a83-4415-928c-2d5d5ae80d76	1	40	t	bfb3a5b0-0d31-4277-ae02-1c7c34f9698d	\N
70364744-eb7a-4757-a5f1-7cccdc42c641	\N	conditional-user-configured	29bb8813-da75-41e0-b440-8ab491e3ec8a	bfb3a5b0-0d31-4277-ae02-1c7c34f9698d	0	10	f	\N	\N
1aef81e2-7a8a-4803-8dcc-5e5ba7facffa	\N	reset-otp	29bb8813-da75-41e0-b440-8ab491e3ec8a	bfb3a5b0-0d31-4277-ae02-1c7c34f9698d	0	20	f	\N	\N
a40118ee-f415-4bda-90d1-34dedfdcadfb	\N	client-secret	29bb8813-da75-41e0-b440-8ab491e3ec8a	20ca09c0-f56b-4b21-9d47-82b9198685d9	2	10	f	\N	\N
74725145-e5f4-4359-a790-fdbbd0dd4c91	\N	client-jwt	29bb8813-da75-41e0-b440-8ab491e3ec8a	20ca09c0-f56b-4b21-9d47-82b9198685d9	2	20	f	\N	\N
d17d6d2e-db9e-4e6b-9af9-64e1c8fc1204	\N	client-secret-jwt	29bb8813-da75-41e0-b440-8ab491e3ec8a	20ca09c0-f56b-4b21-9d47-82b9198685d9	2	30	f	\N	\N
8ec795b0-2160-4556-90c1-0a83acb2afad	\N	client-x509	29bb8813-da75-41e0-b440-8ab491e3ec8a	20ca09c0-f56b-4b21-9d47-82b9198685d9	2	40	f	\N	\N
37c942ce-8354-4ce0-b77b-5df0bf552252	\N	idp-review-profile	29bb8813-da75-41e0-b440-8ab491e3ec8a	c2ce6c00-2b94-4f8e-a1c9-96cb0650426f	0	10	f	\N	ea212438-55b2-4ed7-b07a-5e1d4b8e7070
d3b76a16-8e9b-4a25-b562-4739dacfff3f	\N	\N	29bb8813-da75-41e0-b440-8ab491e3ec8a	c2ce6c00-2b94-4f8e-a1c9-96cb0650426f	0	20	t	569ce800-6f86-4410-91e2-b8abbff80961	\N
4a3c8c8d-9b74-40e9-947d-253e4ef234ca	\N	idp-create-user-if-unique	29bb8813-da75-41e0-b440-8ab491e3ec8a	569ce800-6f86-4410-91e2-b8abbff80961	2	10	f	\N	8d5d002f-369d-4697-9165-df302ae470ce
1f91acb9-60dc-4d03-8502-1443cfaf70ab	\N	\N	29bb8813-da75-41e0-b440-8ab491e3ec8a	569ce800-6f86-4410-91e2-b8abbff80961	2	20	t	f80376c7-256a-4c55-8960-b00d9305d1cb	\N
cc48e489-ea76-4204-a139-c1d98f2e89cb	\N	idp-confirm-link	29bb8813-da75-41e0-b440-8ab491e3ec8a	f80376c7-256a-4c55-8960-b00d9305d1cb	0	10	f	\N	\N
4f5b9040-bd79-4a91-833f-d7b51e4e2e55	\N	\N	29bb8813-da75-41e0-b440-8ab491e3ec8a	f80376c7-256a-4c55-8960-b00d9305d1cb	0	20	t	7bab1849-ceea-41e6-a5e4-e223cfffe798	\N
6569d7e2-07f2-40f0-9035-c5b7a4664bde	\N	idp-email-verification	29bb8813-da75-41e0-b440-8ab491e3ec8a	7bab1849-ceea-41e6-a5e4-e223cfffe798	2	10	f	\N	\N
ff5606e7-9d12-4dc2-9022-34258b27602b	\N	\N	29bb8813-da75-41e0-b440-8ab491e3ec8a	7bab1849-ceea-41e6-a5e4-e223cfffe798	2	20	t	55a5903f-1e1e-4ab6-b8f6-660e39f05a68	\N
c2a905af-8fbc-44b2-8f8e-890ad4653a61	\N	idp-username-password-form	29bb8813-da75-41e0-b440-8ab491e3ec8a	55a5903f-1e1e-4ab6-b8f6-660e39f05a68	0	10	f	\N	\N
99a172e9-8efc-4815-b76e-e7780e689df1	\N	\N	29bb8813-da75-41e0-b440-8ab491e3ec8a	55a5903f-1e1e-4ab6-b8f6-660e39f05a68	1	20	t	2d43983d-7340-492d-9979-cc6654140482	\N
469c8e94-2003-4720-8130-61996094a81e	\N	conditional-user-configured	29bb8813-da75-41e0-b440-8ab491e3ec8a	2d43983d-7340-492d-9979-cc6654140482	0	10	f	\N	\N
0efb22e8-1437-47da-94c3-7fc088b5e015	\N	auth-otp-form	29bb8813-da75-41e0-b440-8ab491e3ec8a	2d43983d-7340-492d-9979-cc6654140482	0	20	f	\N	\N
bb739523-606c-41be-91d6-e127482b6c07	\N	http-basic-authenticator	29bb8813-da75-41e0-b440-8ab491e3ec8a	5589a68e-6f9b-41d4-9255-183321c5619c	0	10	f	\N	\N
c05b8b8f-78ce-4d84-8378-045d9945d252	\N	docker-http-basic-authenticator	29bb8813-da75-41e0-b440-8ab491e3ec8a	9efb454a-1d67-464e-9779-fffe9c405efd	0	10	f	\N	\N
54ef8cf4-9017-4231-8d7d-c4cb760d2a69	\N	auth-cookie	29105d11-1bed-40a5-9927-60d87c4deff3	ee672b99-bfea-4d79-abcd-dde94ecfec4c	2	10	f	\N	\N
f77b73d7-44a3-4332-9715-909f5d119e05	\N	auth-spnego	29105d11-1bed-40a5-9927-60d87c4deff3	ee672b99-bfea-4d79-abcd-dde94ecfec4c	3	20	f	\N	\N
ba5a6656-acbc-463c-929d-dc3ff4727e28	\N	identity-provider-redirector	29105d11-1bed-40a5-9927-60d87c4deff3	ee672b99-bfea-4d79-abcd-dde94ecfec4c	2	25	f	\N	\N
3b5da158-c244-4d3d-ac97-d09abad1b5c4	\N	\N	29105d11-1bed-40a5-9927-60d87c4deff3	ee672b99-bfea-4d79-abcd-dde94ecfec4c	2	30	t	094ced92-cff2-4e0c-b18b-46a3370977fe	\N
994230f6-3bf8-488b-92e2-ded0e0f5bf83	\N	auth-username-password-form	29105d11-1bed-40a5-9927-60d87c4deff3	094ced92-cff2-4e0c-b18b-46a3370977fe	0	10	f	\N	\N
9769f928-bdd0-4a56-b5e1-7d876ff39eed	\N	\N	29105d11-1bed-40a5-9927-60d87c4deff3	094ced92-cff2-4e0c-b18b-46a3370977fe	1	20	t	dd0beaa6-94eb-48e6-9de8-549ff63935a9	\N
5e4fe9be-7728-4960-b7a7-33e8d926cd5a	\N	conditional-user-configured	29105d11-1bed-40a5-9927-60d87c4deff3	dd0beaa6-94eb-48e6-9de8-549ff63935a9	0	10	f	\N	\N
49a25fdd-4887-443d-8d86-c9d1823b6e9b	\N	auth-otp-form	29105d11-1bed-40a5-9927-60d87c4deff3	dd0beaa6-94eb-48e6-9de8-549ff63935a9	0	20	f	\N	\N
5b4bb523-ebd8-4480-97d9-09caceb80ff7	\N	\N	29105d11-1bed-40a5-9927-60d87c4deff3	ee672b99-bfea-4d79-abcd-dde94ecfec4c	2	26	t	6b29f9f8-404e-472f-a509-2e97338ee49f	\N
4af986d6-e748-4dfc-be52-9d0733c05bdd	\N	\N	29105d11-1bed-40a5-9927-60d87c4deff3	6b29f9f8-404e-472f-a509-2e97338ee49f	1	10	t	933a9276-e800-4904-8040-c9812d966767	\N
be7af764-c705-4347-99f2-ffc81d7753aa	\N	conditional-user-configured	29105d11-1bed-40a5-9927-60d87c4deff3	933a9276-e800-4904-8040-c9812d966767	0	10	f	\N	\N
63406487-71df-4313-bcd7-6a356b4beade	\N	organization	29105d11-1bed-40a5-9927-60d87c4deff3	933a9276-e800-4904-8040-c9812d966767	2	20	f	\N	\N
8a154284-788c-4cb1-a3d4-78dce6a304e3	\N	direct-grant-validate-username	29105d11-1bed-40a5-9927-60d87c4deff3	fc780d10-589d-4f15-ba24-2e31e87e24fb	0	10	f	\N	\N
cff9f5c0-aa2e-4300-9f24-83c2b09a19cd	\N	direct-grant-validate-password	29105d11-1bed-40a5-9927-60d87c4deff3	fc780d10-589d-4f15-ba24-2e31e87e24fb	0	20	f	\N	\N
7c4bc871-5846-4bb4-95bb-2cf15a648e27	\N	\N	29105d11-1bed-40a5-9927-60d87c4deff3	fc780d10-589d-4f15-ba24-2e31e87e24fb	1	30	t	0e35b965-0c12-42ac-a7d7-7826c6180074	\N
10dbd3ae-6cdf-464f-8075-3fc3ba25b604	\N	conditional-user-configured	29105d11-1bed-40a5-9927-60d87c4deff3	0e35b965-0c12-42ac-a7d7-7826c6180074	0	10	f	\N	\N
4a13ac31-a6b1-4374-a332-eec6d4d0718a	\N	direct-grant-validate-otp	29105d11-1bed-40a5-9927-60d87c4deff3	0e35b965-0c12-42ac-a7d7-7826c6180074	0	20	f	\N	\N
b57efa3f-a1b3-40e9-8d2e-2c919b42a852	\N	registration-page-form	29105d11-1bed-40a5-9927-60d87c4deff3	d5ecf7dc-2fb0-43ac-a6b5-761c28efa605	0	10	t	8b0732bd-0651-4b99-9d86-f81bb110f650	\N
2c16fc85-ddae-4dc9-9e6e-6ed148138bb3	\N	registration-user-creation	29105d11-1bed-40a5-9927-60d87c4deff3	8b0732bd-0651-4b99-9d86-f81bb110f650	0	20	f	\N	\N
3da91a9d-675c-478f-b039-a1379a5240e0	\N	registration-password-action	29105d11-1bed-40a5-9927-60d87c4deff3	8b0732bd-0651-4b99-9d86-f81bb110f650	0	50	f	\N	\N
393f6d36-edb4-4d32-b030-ec72d4827d16	\N	registration-recaptcha-action	29105d11-1bed-40a5-9927-60d87c4deff3	8b0732bd-0651-4b99-9d86-f81bb110f650	3	60	f	\N	\N
52fc5076-5ab6-4533-93a0-ac556343f88a	\N	registration-terms-and-conditions	29105d11-1bed-40a5-9927-60d87c4deff3	8b0732bd-0651-4b99-9d86-f81bb110f650	3	70	f	\N	\N
cd6d0bb1-7079-41df-a956-164098c056d4	\N	reset-credentials-choose-user	29105d11-1bed-40a5-9927-60d87c4deff3	2bf59d35-f426-45d8-a3c7-ccbf2da5c626	0	10	f	\N	\N
81d6b400-2c08-494d-bb37-af91041f7f82	\N	reset-credential-email	29105d11-1bed-40a5-9927-60d87c4deff3	2bf59d35-f426-45d8-a3c7-ccbf2da5c626	0	20	f	\N	\N
6d823a75-c19c-49ca-90e2-5ca61a59b768	\N	reset-password	29105d11-1bed-40a5-9927-60d87c4deff3	2bf59d35-f426-45d8-a3c7-ccbf2da5c626	0	30	f	\N	\N
831013df-239f-4b09-9949-fc0c75faed14	\N	\N	29105d11-1bed-40a5-9927-60d87c4deff3	2bf59d35-f426-45d8-a3c7-ccbf2da5c626	1	40	t	e44677ef-e231-4c6d-9430-52755b11a43e	\N
243840d4-7751-43ae-bfbc-f373c6ad5a80	\N	conditional-user-configured	29105d11-1bed-40a5-9927-60d87c4deff3	e44677ef-e231-4c6d-9430-52755b11a43e	0	10	f	\N	\N
43d56daf-eae9-4275-9ccf-258563b0015f	\N	reset-otp	29105d11-1bed-40a5-9927-60d87c4deff3	e44677ef-e231-4c6d-9430-52755b11a43e	0	20	f	\N	\N
57ba3d21-df30-40d9-9fe3-56dc4799d37a	\N	client-secret	29105d11-1bed-40a5-9927-60d87c4deff3	556d147b-5125-4b16-95db-8afea7b350e5	2	10	f	\N	\N
f6b819ba-2a9c-47ce-aaae-884fbecdf5a5	\N	client-jwt	29105d11-1bed-40a5-9927-60d87c4deff3	556d147b-5125-4b16-95db-8afea7b350e5	2	20	f	\N	\N
3750b250-757e-4707-93ad-0724aa57c96d	\N	client-secret-jwt	29105d11-1bed-40a5-9927-60d87c4deff3	556d147b-5125-4b16-95db-8afea7b350e5	2	30	f	\N	\N
bd574bae-5772-4d9d-aa14-7c4101027744	\N	client-x509	29105d11-1bed-40a5-9927-60d87c4deff3	556d147b-5125-4b16-95db-8afea7b350e5	2	40	f	\N	\N
a63abf84-e349-4dbc-a319-ca2878a38547	\N	idp-review-profile	29105d11-1bed-40a5-9927-60d87c4deff3	40918f65-f3fd-4f7d-a839-1b665c6d3214	0	10	f	\N	0f0809e5-dfa1-4b73-8a99-bd912ad449e0
15de8596-b2e0-4490-aaa3-7fe8f9a56fc9	\N	\N	29105d11-1bed-40a5-9927-60d87c4deff3	40918f65-f3fd-4f7d-a839-1b665c6d3214	0	20	t	588046f5-c4d3-4f3a-b6d3-f3f56759a26e	\N
577af1fc-a53f-48cf-9d64-5600a25482b7	\N	idp-create-user-if-unique	29105d11-1bed-40a5-9927-60d87c4deff3	588046f5-c4d3-4f3a-b6d3-f3f56759a26e	2	10	f	\N	aca73ae2-5536-4d98-8487-45ee631870a5
da9bc868-8d49-45cd-b26c-84e3e6f0950b	\N	\N	29105d11-1bed-40a5-9927-60d87c4deff3	588046f5-c4d3-4f3a-b6d3-f3f56759a26e	2	20	t	2571b037-a109-4fb8-925e-3e645c9a85d0	\N
84a08249-4bc0-4bec-b3fc-69be1565b5f9	\N	idp-confirm-link	29105d11-1bed-40a5-9927-60d87c4deff3	2571b037-a109-4fb8-925e-3e645c9a85d0	0	10	f	\N	\N
248111c1-fa1f-4cae-bfe4-a63ad4f694a7	\N	\N	29105d11-1bed-40a5-9927-60d87c4deff3	2571b037-a109-4fb8-925e-3e645c9a85d0	0	20	t	0f1bc028-7668-4311-bc02-14a164dab7db	\N
e1554e87-74e6-4b51-a11b-b94bd093de15	\N	idp-email-verification	29105d11-1bed-40a5-9927-60d87c4deff3	0f1bc028-7668-4311-bc02-14a164dab7db	2	10	f	\N	\N
e29e55d2-4d2c-4d8e-9c90-17e1335a2890	\N	\N	29105d11-1bed-40a5-9927-60d87c4deff3	0f1bc028-7668-4311-bc02-14a164dab7db	2	20	t	22383499-41ce-48c0-be6a-c692b2b099ce	\N
2bf1cc9f-cd29-413e-b355-09eb5d49412a	\N	idp-username-password-form	29105d11-1bed-40a5-9927-60d87c4deff3	22383499-41ce-48c0-be6a-c692b2b099ce	0	10	f	\N	\N
09859415-60c2-4678-ba7b-0a1d320dff7b	\N	\N	29105d11-1bed-40a5-9927-60d87c4deff3	22383499-41ce-48c0-be6a-c692b2b099ce	1	20	t	beb6f867-dc9e-4fe2-abfc-7477034d6b4b	\N
6df9c6a6-165f-48ff-93b9-365f58dbb239	\N	conditional-user-configured	29105d11-1bed-40a5-9927-60d87c4deff3	beb6f867-dc9e-4fe2-abfc-7477034d6b4b	0	10	f	\N	\N
2ee51ca8-afca-4e30-bcd7-1a40514b99af	\N	auth-otp-form	29105d11-1bed-40a5-9927-60d87c4deff3	beb6f867-dc9e-4fe2-abfc-7477034d6b4b	0	20	f	\N	\N
394647a9-a44c-4b47-9ac1-f70e137bd360	\N	\N	29105d11-1bed-40a5-9927-60d87c4deff3	40918f65-f3fd-4f7d-a839-1b665c6d3214	1	50	t	0beb0f31-d060-4908-a180-227422594417	\N
a3573632-935f-420f-ba73-d34b0c0e6910	\N	conditional-user-configured	29105d11-1bed-40a5-9927-60d87c4deff3	0beb0f31-d060-4908-a180-227422594417	0	10	f	\N	\N
820dcdc9-3f69-40bf-ba54-cf34dd52fc26	\N	idp-add-organization-member	29105d11-1bed-40a5-9927-60d87c4deff3	0beb0f31-d060-4908-a180-227422594417	0	20	f	\N	\N
c6a045a4-f900-4fdb-a2e6-a1c563cfed6d	\N	http-basic-authenticator	29105d11-1bed-40a5-9927-60d87c4deff3	a1c71e80-1568-4bdd-bce2-3f707caf26c5	0	10	f	\N	\N
5621832a-845f-4077-b211-60962e2b73d7	\N	docker-http-basic-authenticator	29105d11-1bed-40a5-9927-60d87c4deff3	4c26b482-314f-482a-8c2d-f4673ddd5394	0	10	f	\N	\N
\.


--
-- Data for Name: authentication_flow; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authentication_flow (id, alias, description, realm_id, provider_id, top_level, built_in) FROM stdin;
63194eec-ce6b-4eeb-b81a-9f454ebcf9d1	browser	Browser based authentication	29bb8813-da75-41e0-b440-8ab491e3ec8a	basic-flow	t	t
f7033c67-77d0-4f4e-8db1-deb0ed07c11c	forms	Username, password, otp and other auth forms.	29bb8813-da75-41e0-b440-8ab491e3ec8a	basic-flow	f	t
7f50f847-6943-46fe-934c-8474de6264ef	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	29bb8813-da75-41e0-b440-8ab491e3ec8a	basic-flow	f	t
72df32c4-c017-466f-9e98-43057989ceba	direct grant	OpenID Connect Resource Owner Grant	29bb8813-da75-41e0-b440-8ab491e3ec8a	basic-flow	t	t
2a7b8a9a-c039-46d5-aeac-5f7b93033753	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	29bb8813-da75-41e0-b440-8ab491e3ec8a	basic-flow	f	t
b547a862-3a72-477a-9e64-cd3e379f17b0	registration	Registration flow	29bb8813-da75-41e0-b440-8ab491e3ec8a	basic-flow	t	t
34bdf2c8-bba0-42cc-9e51-4a86f2935279	registration form	Registration form	29bb8813-da75-41e0-b440-8ab491e3ec8a	form-flow	f	t
bae1abb4-6a83-4415-928c-2d5d5ae80d76	reset credentials	Reset credentials for a user if they forgot their password or something	29bb8813-da75-41e0-b440-8ab491e3ec8a	basic-flow	t	t
bfb3a5b0-0d31-4277-ae02-1c7c34f9698d	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	29bb8813-da75-41e0-b440-8ab491e3ec8a	basic-flow	f	t
20ca09c0-f56b-4b21-9d47-82b9198685d9	clients	Base authentication for clients	29bb8813-da75-41e0-b440-8ab491e3ec8a	client-flow	t	t
c2ce6c00-2b94-4f8e-a1c9-96cb0650426f	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	29bb8813-da75-41e0-b440-8ab491e3ec8a	basic-flow	t	t
569ce800-6f86-4410-91e2-b8abbff80961	User creation or linking	Flow for the existing/non-existing user alternatives	29bb8813-da75-41e0-b440-8ab491e3ec8a	basic-flow	f	t
f80376c7-256a-4c55-8960-b00d9305d1cb	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	29bb8813-da75-41e0-b440-8ab491e3ec8a	basic-flow	f	t
7bab1849-ceea-41e6-a5e4-e223cfffe798	Account verification options	Method with which to verity the existing account	29bb8813-da75-41e0-b440-8ab491e3ec8a	basic-flow	f	t
55a5903f-1e1e-4ab6-b8f6-660e39f05a68	Verify Existing Account by Re-authentication	Reauthentication of existing account	29bb8813-da75-41e0-b440-8ab491e3ec8a	basic-flow	f	t
2d43983d-7340-492d-9979-cc6654140482	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	29bb8813-da75-41e0-b440-8ab491e3ec8a	basic-flow	f	t
5589a68e-6f9b-41d4-9255-183321c5619c	saml ecp	SAML ECP Profile Authentication Flow	29bb8813-da75-41e0-b440-8ab491e3ec8a	basic-flow	t	t
9efb454a-1d67-464e-9779-fffe9c405efd	docker auth	Used by Docker clients to authenticate against the IDP	29bb8813-da75-41e0-b440-8ab491e3ec8a	basic-flow	t	t
ee672b99-bfea-4d79-abcd-dde94ecfec4c	browser	Browser based authentication	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	t	t
094ced92-cff2-4e0c-b18b-46a3370977fe	forms	Username, password, otp and other auth forms.	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	f	t
dd0beaa6-94eb-48e6-9de8-549ff63935a9	Browser - Conditional OTP	Flow to determine if the OTP is required for the authentication	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	f	t
6b29f9f8-404e-472f-a509-2e97338ee49f	Organization	\N	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	f	t
933a9276-e800-4904-8040-c9812d966767	Browser - Conditional Organization	Flow to determine if the organization identity-first login is to be used	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	f	t
fc780d10-589d-4f15-ba24-2e31e87e24fb	direct grant	OpenID Connect Resource Owner Grant	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	t	t
0e35b965-0c12-42ac-a7d7-7826c6180074	Direct Grant - Conditional OTP	Flow to determine if the OTP is required for the authentication	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	f	t
d5ecf7dc-2fb0-43ac-a6b5-761c28efa605	registration	Registration flow	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	t	t
8b0732bd-0651-4b99-9d86-f81bb110f650	registration form	Registration form	29105d11-1bed-40a5-9927-60d87c4deff3	form-flow	f	t
2bf59d35-f426-45d8-a3c7-ccbf2da5c626	reset credentials	Reset credentials for a user if they forgot their password or something	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	t	t
e44677ef-e231-4c6d-9430-52755b11a43e	Reset - Conditional OTP	Flow to determine if the OTP should be reset or not. Set to REQUIRED to force.	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	f	t
556d147b-5125-4b16-95db-8afea7b350e5	clients	Base authentication for clients	29105d11-1bed-40a5-9927-60d87c4deff3	client-flow	t	t
40918f65-f3fd-4f7d-a839-1b665c6d3214	first broker login	Actions taken after first broker login with identity provider account, which is not yet linked to any Keycloak account	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	t	t
588046f5-c4d3-4f3a-b6d3-f3f56759a26e	User creation or linking	Flow for the existing/non-existing user alternatives	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	f	t
2571b037-a109-4fb8-925e-3e645c9a85d0	Handle Existing Account	Handle what to do if there is existing account with same email/username like authenticated identity provider	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	f	t
0f1bc028-7668-4311-bc02-14a164dab7db	Account verification options	Method with which to verity the existing account	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	f	t
22383499-41ce-48c0-be6a-c692b2b099ce	Verify Existing Account by Re-authentication	Reauthentication of existing account	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	f	t
beb6f867-dc9e-4fe2-abfc-7477034d6b4b	First broker login - Conditional OTP	Flow to determine if the OTP is required for the authentication	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	f	t
0beb0f31-d060-4908-a180-227422594417	First Broker Login - Conditional Organization	Flow to determine if the authenticator that adds organization members is to be used	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	f	t
a1c71e80-1568-4bdd-bce2-3f707caf26c5	saml ecp	SAML ECP Profile Authentication Flow	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	t	t
4c26b482-314f-482a-8c2d-f4673ddd5394	docker auth	Used by Docker clients to authenticate against the IDP	29105d11-1bed-40a5-9927-60d87c4deff3	basic-flow	t	t
\.


--
-- Data for Name: authenticator_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authenticator_config (id, alias, realm_id) FROM stdin;
ea212438-55b2-4ed7-b07a-5e1d4b8e7070	review profile config	29bb8813-da75-41e0-b440-8ab491e3ec8a
8d5d002f-369d-4697-9165-df302ae470ce	create unique user config	29bb8813-da75-41e0-b440-8ab491e3ec8a
0f0809e5-dfa1-4b73-8a99-bd912ad449e0	review profile config	29105d11-1bed-40a5-9927-60d87c4deff3
aca73ae2-5536-4d98-8487-45ee631870a5	create unique user config	29105d11-1bed-40a5-9927-60d87c4deff3
\.


--
-- Data for Name: authenticator_config_entry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authenticator_config_entry (authenticator_id, value, name) FROM stdin;
8d5d002f-369d-4697-9165-df302ae470ce	false	require.password.update.after.registration
ea212438-55b2-4ed7-b07a-5e1d4b8e7070	missing	update.profile.on.first.login
0f0809e5-dfa1-4b73-8a99-bd912ad449e0	missing	update.profile.on.first.login
aca73ae2-5536-4d98-8487-45ee631870a5	false	require.password.update.after.registration
\.


--
-- Data for Name: broker_link; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.broker_link (identity_provider, storage_provider_id, realm_id, broker_user_id, broker_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client (id, enabled, full_scope_allowed, client_id, not_before, public_client, secret, base_url, bearer_only, management_url, surrogate_auth_required, realm_id, protocol, node_rereg_timeout, frontchannel_logout, consent_required, name, service_accounts_enabled, client_authenticator_type, root_url, description, registration_token, standard_flow_enabled, implicit_flow_enabled, direct_access_grants_enabled, always_display_in_console) FROM stdin;
0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	f	master-realm	0	f	\N	\N	t	\N	f	29bb8813-da75-41e0-b440-8ab491e3ec8a	\N	0	f	f	master Realm	f	client-secret	\N	\N	\N	t	f	f	f
d6fae655-39e6-4ff5-b705-e23facd2ef68	t	f	account	0	t	\N	/realms/master/account/	f	\N	f	29bb8813-da75-41e0-b440-8ab491e3ec8a	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
3178bb2f-9cbe-425d-a613-e8ffea66389e	t	f	account-console	0	t	\N	/realms/master/account/	f	\N	f	29bb8813-da75-41e0-b440-8ab491e3ec8a	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
58d2d4eb-cf03-4960-9972-cfbc1e823c5f	t	f	broker	0	f	\N	\N	t	\N	f	29bb8813-da75-41e0-b440-8ab491e3ec8a	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
39a33722-8fc5-45a0-b730-61e79cde444e	t	t	security-admin-console	0	t	\N	/admin/master/console/	f	\N	f	29bb8813-da75-41e0-b440-8ab491e3ec8a	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
656f2bbc-c841-48ca-9ebd-3c13709e682f	t	t	admin-cli	0	t	\N	\N	f	\N	f	29bb8813-da75-41e0-b440-8ab491e3ec8a	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
da88d06b-e956-42e8-a610-ba048d70e217	t	f	agentshield-realm	0	f	\N	\N	t	\N	f	29bb8813-da75-41e0-b440-8ab491e3ec8a	\N	0	f	f	agentshield Realm	f	client-secret	\N	\N	\N	t	f	f	f
012c8e1e-7ab8-47be-bb58-34d958059506	t	f	realm-management	0	f	\N	\N	t	\N	f	29105d11-1bed-40a5-9927-60d87c4deff3	openid-connect	0	f	f	${client_realm-management}	f	client-secret	\N	\N	\N	t	f	f	f
121642cc-8d33-4fbc-b80d-39f4e1f8b22c	t	f	account	0	t	\N	/realms/agentshield/account/	f	\N	f	29105d11-1bed-40a5-9927-60d87c4deff3	openid-connect	0	f	f	${client_account}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
db01877c-dcdc-4373-8120-6e7b48e26bab	t	f	account-console	0	t	\N	/realms/agentshield/account/	f	\N	f	29105d11-1bed-40a5-9927-60d87c4deff3	openid-connect	0	f	f	${client_account-console}	f	client-secret	${authBaseUrl}	\N	\N	t	f	f	f
29032148-f6b3-467c-bfea-bad134dfcf6d	t	f	broker	0	f	\N	\N	t	\N	f	29105d11-1bed-40a5-9927-60d87c4deff3	openid-connect	0	f	f	${client_broker}	f	client-secret	\N	\N	\N	t	f	f	f
7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	t	t	security-admin-console	0	t	\N	/admin/agentshield/console/	f	\N	f	29105d11-1bed-40a5-9927-60d87c4deff3	openid-connect	0	f	f	${client_security-admin-console}	f	client-secret	${authAdminUrl}	\N	\N	t	f	f	f
e2f03d00-cbad-4866-a46b-b7a8a58bf4f3	t	t	admin-cli	0	t	\N	\N	f	\N	f	29105d11-1bed-40a5-9927-60d87c4deff3	openid-connect	0	f	f	${client_admin-cli}	f	client-secret	\N	\N	\N	f	f	t	f
bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	t	t	registry-api	0	f	d2DLyCa4V2U7jVlU1dYATLCmGmXL8AaX	\N	f	\N	f	29105d11-1bed-40a5-9927-60d87c4deff3	openid-connect	-1	f	f	\N	t	client-secret	\N	\N	\N	t	f	t	f
3863be94-a32c-41dd-80c6-a847175f3a96	t	t	envoy-gateway	0	t	\N	\N	f	\N	f	29105d11-1bed-40a5-9927-60d87c4deff3	openid-connect	-1	f	f	\N	f	client-secret	\N	\N	\N	t	f	t	f
78fd174d-495c-4a9c-88ca-271608bc4f5f	t	t	agentshield-studio	0	t	\N	\N	f	\N	f	29105d11-1bed-40a5-9927-60d87c4deff3	openid-connect	-1	f	f	\N	f	client-secret	\N	\N	\N	t	f	t	f
\.


--
-- Data for Name: client_attributes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_attributes (client_id, name, value) FROM stdin;
d6fae655-39e6-4ff5-b705-e23facd2ef68	post.logout.redirect.uris	+
3178bb2f-9cbe-425d-a613-e8ffea66389e	post.logout.redirect.uris	+
3178bb2f-9cbe-425d-a613-e8ffea66389e	pkce.code.challenge.method	S256
39a33722-8fc5-45a0-b730-61e79cde444e	post.logout.redirect.uris	+
39a33722-8fc5-45a0-b730-61e79cde444e	pkce.code.challenge.method	S256
39a33722-8fc5-45a0-b730-61e79cde444e	client.use.lightweight.access.token.enabled	true
656f2bbc-c841-48ca-9ebd-3c13709e682f	client.use.lightweight.access.token.enabled	true
121642cc-8d33-4fbc-b80d-39f4e1f8b22c	post.logout.redirect.uris	+
db01877c-dcdc-4373-8120-6e7b48e26bab	post.logout.redirect.uris	+
db01877c-dcdc-4373-8120-6e7b48e26bab	pkce.code.challenge.method	S256
7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	post.logout.redirect.uris	+
7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	pkce.code.challenge.method	S256
7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	client.use.lightweight.access.token.enabled	true
e2f03d00-cbad-4866-a46b-b7a8a58bf4f3	client.use.lightweight.access.token.enabled	true
bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	client.secret.creation.time	1783384761
bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	backchannel.logout.session.required	true
bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	backchannel.logout.revoke.offline.tokens	false
3863be94-a32c-41dd-80c6-a847175f3a96	backchannel.logout.session.required	true
3863be94-a32c-41dd-80c6-a847175f3a96	backchannel.logout.revoke.offline.tokens	false
78fd174d-495c-4a9c-88ca-271608bc4f5f	pkce.code.challenge.method	S256
78fd174d-495c-4a9c-88ca-271608bc4f5f	backchannel.logout.session.required	true
78fd174d-495c-4a9c-88ca-271608bc4f5f	backchannel.logout.revoke.offline.tokens	false
\.


--
-- Data for Name: client_auth_flow_bindings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_auth_flow_bindings (client_id, flow_id, binding_name) FROM stdin;
\.


--
-- Data for Name: client_initial_access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_initial_access (id, realm_id, "timestamp", expiration, count, remaining_count) FROM stdin;
\.


--
-- Data for Name: client_node_registrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_node_registrations (client_id, value, name) FROM stdin;
\.


--
-- Data for Name: client_scope; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_scope (id, name, realm_id, description, protocol) FROM stdin;
44b67136-7503-4a50-8032-654238f1597e	offline_access	29bb8813-da75-41e0-b440-8ab491e3ec8a	OpenID Connect built-in scope: offline_access	openid-connect
c77e4009-b62f-4686-911d-9074d5a908eb	role_list	29bb8813-da75-41e0-b440-8ab491e3ec8a	SAML role list	saml
047b7ff2-a372-4226-a419-614a93042ca7	saml_organization	29bb8813-da75-41e0-b440-8ab491e3ec8a	Organization Membership	saml
15f84608-cfee-4646-8bd3-0790ce935bb3	profile	29bb8813-da75-41e0-b440-8ab491e3ec8a	OpenID Connect built-in scope: profile	openid-connect
d07f80b4-9492-4626-9ba4-6546c97024d5	email	29bb8813-da75-41e0-b440-8ab491e3ec8a	OpenID Connect built-in scope: email	openid-connect
37847a84-3ab5-43da-9fcc-0ac309abbc86	address	29bb8813-da75-41e0-b440-8ab491e3ec8a	OpenID Connect built-in scope: address	openid-connect
edbd3382-c73e-407b-ad90-4a80a863a3dd	phone	29bb8813-da75-41e0-b440-8ab491e3ec8a	OpenID Connect built-in scope: phone	openid-connect
609d4ae5-bf8a-48e2-b2a9-d81b42096dfd	roles	29bb8813-da75-41e0-b440-8ab491e3ec8a	OpenID Connect scope for add user roles to the access token	openid-connect
148b4ece-21c1-49ec-89ea-b9137b5500f8	web-origins	29bb8813-da75-41e0-b440-8ab491e3ec8a	OpenID Connect scope for add allowed web origins to the access token	openid-connect
acc3bdbb-18a3-4cf5-8ea2-0264f7c5fa36	microprofile-jwt	29bb8813-da75-41e0-b440-8ab491e3ec8a	Microprofile - JWT built-in scope	openid-connect
d3e92e3f-8e46-4b7d-9c8e-38d7281a1928	acr	29bb8813-da75-41e0-b440-8ab491e3ec8a	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
055dd76c-fd10-4e37-8c97-947d04648d0b	basic	29bb8813-da75-41e0-b440-8ab491e3ec8a	OpenID Connect scope for add all basic claims to the token	openid-connect
030d798b-c28b-481f-929a-3ec2c6e92e8d	organization	29bb8813-da75-41e0-b440-8ab491e3ec8a	Additional claims about the organization a subject belongs to	openid-connect
fe5a66e2-8ad9-4c9f-b17c-13ddb93d328f	offline_access	29105d11-1bed-40a5-9927-60d87c4deff3	OpenID Connect built-in scope: offline_access	openid-connect
b04f828c-43f0-4aa6-a6ec-e7e2e0f0578d	role_list	29105d11-1bed-40a5-9927-60d87c4deff3	SAML role list	saml
dd0215c5-7711-47b3-801c-2226122f3bc7	saml_organization	29105d11-1bed-40a5-9927-60d87c4deff3	Organization Membership	saml
bc0416cc-4e82-4346-85fa-1d4fe837ecf2	profile	29105d11-1bed-40a5-9927-60d87c4deff3	OpenID Connect built-in scope: profile	openid-connect
c796e839-148a-4f01-ba5c-2e38fbf1eeb6	email	29105d11-1bed-40a5-9927-60d87c4deff3	OpenID Connect built-in scope: email	openid-connect
4dd3b68c-89e1-4748-9a1d-bfc573a54bee	address	29105d11-1bed-40a5-9927-60d87c4deff3	OpenID Connect built-in scope: address	openid-connect
f7b2f01c-d622-435c-8bc8-33a21311e25b	phone	29105d11-1bed-40a5-9927-60d87c4deff3	OpenID Connect built-in scope: phone	openid-connect
5a0bd71b-5a3c-4cd8-a0da-81f64dc46ebe	roles	29105d11-1bed-40a5-9927-60d87c4deff3	OpenID Connect scope for add user roles to the access token	openid-connect
905f36f2-5b46-4f08-8d1d-ff48fd0abc87	web-origins	29105d11-1bed-40a5-9927-60d87c4deff3	OpenID Connect scope for add allowed web origins to the access token	openid-connect
3e92e7c3-ca3a-4b28-a741-da0850a79426	microprofile-jwt	29105d11-1bed-40a5-9927-60d87c4deff3	Microprofile - JWT built-in scope	openid-connect
c99d871b-9dfe-4e84-81bc-eb0759ef065e	acr	29105d11-1bed-40a5-9927-60d87c4deff3	OpenID Connect scope for add acr (authentication context class reference) to the token	openid-connect
291c177f-c12f-4341-be6a-7fa3d2faabb4	basic	29105d11-1bed-40a5-9927-60d87c4deff3	OpenID Connect scope for add all basic claims to the token	openid-connect
c26deb71-24b8-4715-be45-3baa4c818026	organization	29105d11-1bed-40a5-9927-60d87c4deff3	Additional claims about the organization a subject belongs to	openid-connect
\.


--
-- Data for Name: client_scope_attributes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_scope_attributes (scope_id, value, name) FROM stdin;
44b67136-7503-4a50-8032-654238f1597e	true	display.on.consent.screen
44b67136-7503-4a50-8032-654238f1597e	${offlineAccessScopeConsentText}	consent.screen.text
c77e4009-b62f-4686-911d-9074d5a908eb	true	display.on.consent.screen
c77e4009-b62f-4686-911d-9074d5a908eb	${samlRoleListScopeConsentText}	consent.screen.text
047b7ff2-a372-4226-a419-614a93042ca7	false	display.on.consent.screen
15f84608-cfee-4646-8bd3-0790ce935bb3	true	display.on.consent.screen
15f84608-cfee-4646-8bd3-0790ce935bb3	${profileScopeConsentText}	consent.screen.text
15f84608-cfee-4646-8bd3-0790ce935bb3	true	include.in.token.scope
d07f80b4-9492-4626-9ba4-6546c97024d5	true	display.on.consent.screen
d07f80b4-9492-4626-9ba4-6546c97024d5	${emailScopeConsentText}	consent.screen.text
d07f80b4-9492-4626-9ba4-6546c97024d5	true	include.in.token.scope
37847a84-3ab5-43da-9fcc-0ac309abbc86	true	display.on.consent.screen
37847a84-3ab5-43da-9fcc-0ac309abbc86	${addressScopeConsentText}	consent.screen.text
37847a84-3ab5-43da-9fcc-0ac309abbc86	true	include.in.token.scope
edbd3382-c73e-407b-ad90-4a80a863a3dd	true	display.on.consent.screen
edbd3382-c73e-407b-ad90-4a80a863a3dd	${phoneScopeConsentText}	consent.screen.text
edbd3382-c73e-407b-ad90-4a80a863a3dd	true	include.in.token.scope
609d4ae5-bf8a-48e2-b2a9-d81b42096dfd	true	display.on.consent.screen
609d4ae5-bf8a-48e2-b2a9-d81b42096dfd	${rolesScopeConsentText}	consent.screen.text
609d4ae5-bf8a-48e2-b2a9-d81b42096dfd	false	include.in.token.scope
148b4ece-21c1-49ec-89ea-b9137b5500f8	false	display.on.consent.screen
148b4ece-21c1-49ec-89ea-b9137b5500f8		consent.screen.text
148b4ece-21c1-49ec-89ea-b9137b5500f8	false	include.in.token.scope
acc3bdbb-18a3-4cf5-8ea2-0264f7c5fa36	false	display.on.consent.screen
acc3bdbb-18a3-4cf5-8ea2-0264f7c5fa36	true	include.in.token.scope
d3e92e3f-8e46-4b7d-9c8e-38d7281a1928	false	display.on.consent.screen
d3e92e3f-8e46-4b7d-9c8e-38d7281a1928	false	include.in.token.scope
055dd76c-fd10-4e37-8c97-947d04648d0b	false	display.on.consent.screen
055dd76c-fd10-4e37-8c97-947d04648d0b	false	include.in.token.scope
030d798b-c28b-481f-929a-3ec2c6e92e8d	true	display.on.consent.screen
030d798b-c28b-481f-929a-3ec2c6e92e8d	${organizationScopeConsentText}	consent.screen.text
030d798b-c28b-481f-929a-3ec2c6e92e8d	true	include.in.token.scope
fe5a66e2-8ad9-4c9f-b17c-13ddb93d328f	true	display.on.consent.screen
fe5a66e2-8ad9-4c9f-b17c-13ddb93d328f	${offlineAccessScopeConsentText}	consent.screen.text
b04f828c-43f0-4aa6-a6ec-e7e2e0f0578d	true	display.on.consent.screen
b04f828c-43f0-4aa6-a6ec-e7e2e0f0578d	${samlRoleListScopeConsentText}	consent.screen.text
dd0215c5-7711-47b3-801c-2226122f3bc7	false	display.on.consent.screen
bc0416cc-4e82-4346-85fa-1d4fe837ecf2	true	display.on.consent.screen
bc0416cc-4e82-4346-85fa-1d4fe837ecf2	${profileScopeConsentText}	consent.screen.text
bc0416cc-4e82-4346-85fa-1d4fe837ecf2	true	include.in.token.scope
c796e839-148a-4f01-ba5c-2e38fbf1eeb6	true	display.on.consent.screen
c796e839-148a-4f01-ba5c-2e38fbf1eeb6	${emailScopeConsentText}	consent.screen.text
c796e839-148a-4f01-ba5c-2e38fbf1eeb6	true	include.in.token.scope
4dd3b68c-89e1-4748-9a1d-bfc573a54bee	true	display.on.consent.screen
4dd3b68c-89e1-4748-9a1d-bfc573a54bee	${addressScopeConsentText}	consent.screen.text
4dd3b68c-89e1-4748-9a1d-bfc573a54bee	true	include.in.token.scope
f7b2f01c-d622-435c-8bc8-33a21311e25b	true	display.on.consent.screen
f7b2f01c-d622-435c-8bc8-33a21311e25b	${phoneScopeConsentText}	consent.screen.text
f7b2f01c-d622-435c-8bc8-33a21311e25b	true	include.in.token.scope
5a0bd71b-5a3c-4cd8-a0da-81f64dc46ebe	true	display.on.consent.screen
5a0bd71b-5a3c-4cd8-a0da-81f64dc46ebe	${rolesScopeConsentText}	consent.screen.text
5a0bd71b-5a3c-4cd8-a0da-81f64dc46ebe	false	include.in.token.scope
905f36f2-5b46-4f08-8d1d-ff48fd0abc87	false	display.on.consent.screen
905f36f2-5b46-4f08-8d1d-ff48fd0abc87		consent.screen.text
905f36f2-5b46-4f08-8d1d-ff48fd0abc87	false	include.in.token.scope
3e92e7c3-ca3a-4b28-a741-da0850a79426	false	display.on.consent.screen
3e92e7c3-ca3a-4b28-a741-da0850a79426	true	include.in.token.scope
c99d871b-9dfe-4e84-81bc-eb0759ef065e	false	display.on.consent.screen
c99d871b-9dfe-4e84-81bc-eb0759ef065e	false	include.in.token.scope
291c177f-c12f-4341-be6a-7fa3d2faabb4	false	display.on.consent.screen
291c177f-c12f-4341-be6a-7fa3d2faabb4	false	include.in.token.scope
c26deb71-24b8-4715-be45-3baa4c818026	true	display.on.consent.screen
c26deb71-24b8-4715-be45-3baa4c818026	${organizationScopeConsentText}	consent.screen.text
c26deb71-24b8-4715-be45-3baa4c818026	true	include.in.token.scope
\.


--
-- Data for Name: client_scope_client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_scope_client (client_id, scope_id, default_scope) FROM stdin;
d6fae655-39e6-4ff5-b705-e23facd2ef68	055dd76c-fd10-4e37-8c97-947d04648d0b	t
d6fae655-39e6-4ff5-b705-e23facd2ef68	d3e92e3f-8e46-4b7d-9c8e-38d7281a1928	t
d6fae655-39e6-4ff5-b705-e23facd2ef68	148b4ece-21c1-49ec-89ea-b9137b5500f8	t
d6fae655-39e6-4ff5-b705-e23facd2ef68	d07f80b4-9492-4626-9ba4-6546c97024d5	t
d6fae655-39e6-4ff5-b705-e23facd2ef68	15f84608-cfee-4646-8bd3-0790ce935bb3	t
d6fae655-39e6-4ff5-b705-e23facd2ef68	609d4ae5-bf8a-48e2-b2a9-d81b42096dfd	t
d6fae655-39e6-4ff5-b705-e23facd2ef68	37847a84-3ab5-43da-9fcc-0ac309abbc86	f
d6fae655-39e6-4ff5-b705-e23facd2ef68	44b67136-7503-4a50-8032-654238f1597e	f
d6fae655-39e6-4ff5-b705-e23facd2ef68	030d798b-c28b-481f-929a-3ec2c6e92e8d	f
d6fae655-39e6-4ff5-b705-e23facd2ef68	acc3bdbb-18a3-4cf5-8ea2-0264f7c5fa36	f
d6fae655-39e6-4ff5-b705-e23facd2ef68	edbd3382-c73e-407b-ad90-4a80a863a3dd	f
3178bb2f-9cbe-425d-a613-e8ffea66389e	055dd76c-fd10-4e37-8c97-947d04648d0b	t
3178bb2f-9cbe-425d-a613-e8ffea66389e	d3e92e3f-8e46-4b7d-9c8e-38d7281a1928	t
3178bb2f-9cbe-425d-a613-e8ffea66389e	148b4ece-21c1-49ec-89ea-b9137b5500f8	t
3178bb2f-9cbe-425d-a613-e8ffea66389e	d07f80b4-9492-4626-9ba4-6546c97024d5	t
3178bb2f-9cbe-425d-a613-e8ffea66389e	15f84608-cfee-4646-8bd3-0790ce935bb3	t
3178bb2f-9cbe-425d-a613-e8ffea66389e	609d4ae5-bf8a-48e2-b2a9-d81b42096dfd	t
3178bb2f-9cbe-425d-a613-e8ffea66389e	37847a84-3ab5-43da-9fcc-0ac309abbc86	f
3178bb2f-9cbe-425d-a613-e8ffea66389e	44b67136-7503-4a50-8032-654238f1597e	f
3178bb2f-9cbe-425d-a613-e8ffea66389e	030d798b-c28b-481f-929a-3ec2c6e92e8d	f
3178bb2f-9cbe-425d-a613-e8ffea66389e	acc3bdbb-18a3-4cf5-8ea2-0264f7c5fa36	f
3178bb2f-9cbe-425d-a613-e8ffea66389e	edbd3382-c73e-407b-ad90-4a80a863a3dd	f
656f2bbc-c841-48ca-9ebd-3c13709e682f	055dd76c-fd10-4e37-8c97-947d04648d0b	t
656f2bbc-c841-48ca-9ebd-3c13709e682f	d3e92e3f-8e46-4b7d-9c8e-38d7281a1928	t
656f2bbc-c841-48ca-9ebd-3c13709e682f	148b4ece-21c1-49ec-89ea-b9137b5500f8	t
656f2bbc-c841-48ca-9ebd-3c13709e682f	d07f80b4-9492-4626-9ba4-6546c97024d5	t
656f2bbc-c841-48ca-9ebd-3c13709e682f	15f84608-cfee-4646-8bd3-0790ce935bb3	t
656f2bbc-c841-48ca-9ebd-3c13709e682f	609d4ae5-bf8a-48e2-b2a9-d81b42096dfd	t
656f2bbc-c841-48ca-9ebd-3c13709e682f	37847a84-3ab5-43da-9fcc-0ac309abbc86	f
656f2bbc-c841-48ca-9ebd-3c13709e682f	44b67136-7503-4a50-8032-654238f1597e	f
656f2bbc-c841-48ca-9ebd-3c13709e682f	030d798b-c28b-481f-929a-3ec2c6e92e8d	f
656f2bbc-c841-48ca-9ebd-3c13709e682f	acc3bdbb-18a3-4cf5-8ea2-0264f7c5fa36	f
656f2bbc-c841-48ca-9ebd-3c13709e682f	edbd3382-c73e-407b-ad90-4a80a863a3dd	f
58d2d4eb-cf03-4960-9972-cfbc1e823c5f	055dd76c-fd10-4e37-8c97-947d04648d0b	t
58d2d4eb-cf03-4960-9972-cfbc1e823c5f	d3e92e3f-8e46-4b7d-9c8e-38d7281a1928	t
58d2d4eb-cf03-4960-9972-cfbc1e823c5f	148b4ece-21c1-49ec-89ea-b9137b5500f8	t
58d2d4eb-cf03-4960-9972-cfbc1e823c5f	d07f80b4-9492-4626-9ba4-6546c97024d5	t
58d2d4eb-cf03-4960-9972-cfbc1e823c5f	15f84608-cfee-4646-8bd3-0790ce935bb3	t
58d2d4eb-cf03-4960-9972-cfbc1e823c5f	609d4ae5-bf8a-48e2-b2a9-d81b42096dfd	t
58d2d4eb-cf03-4960-9972-cfbc1e823c5f	37847a84-3ab5-43da-9fcc-0ac309abbc86	f
58d2d4eb-cf03-4960-9972-cfbc1e823c5f	44b67136-7503-4a50-8032-654238f1597e	f
58d2d4eb-cf03-4960-9972-cfbc1e823c5f	030d798b-c28b-481f-929a-3ec2c6e92e8d	f
58d2d4eb-cf03-4960-9972-cfbc1e823c5f	acc3bdbb-18a3-4cf5-8ea2-0264f7c5fa36	f
58d2d4eb-cf03-4960-9972-cfbc1e823c5f	edbd3382-c73e-407b-ad90-4a80a863a3dd	f
0c385d9c-72ee-44a8-a993-aa8fc3317a70	055dd76c-fd10-4e37-8c97-947d04648d0b	t
0c385d9c-72ee-44a8-a993-aa8fc3317a70	d3e92e3f-8e46-4b7d-9c8e-38d7281a1928	t
0c385d9c-72ee-44a8-a993-aa8fc3317a70	148b4ece-21c1-49ec-89ea-b9137b5500f8	t
0c385d9c-72ee-44a8-a993-aa8fc3317a70	d07f80b4-9492-4626-9ba4-6546c97024d5	t
0c385d9c-72ee-44a8-a993-aa8fc3317a70	15f84608-cfee-4646-8bd3-0790ce935bb3	t
0c385d9c-72ee-44a8-a993-aa8fc3317a70	609d4ae5-bf8a-48e2-b2a9-d81b42096dfd	t
0c385d9c-72ee-44a8-a993-aa8fc3317a70	37847a84-3ab5-43da-9fcc-0ac309abbc86	f
0c385d9c-72ee-44a8-a993-aa8fc3317a70	44b67136-7503-4a50-8032-654238f1597e	f
0c385d9c-72ee-44a8-a993-aa8fc3317a70	030d798b-c28b-481f-929a-3ec2c6e92e8d	f
0c385d9c-72ee-44a8-a993-aa8fc3317a70	acc3bdbb-18a3-4cf5-8ea2-0264f7c5fa36	f
0c385d9c-72ee-44a8-a993-aa8fc3317a70	edbd3382-c73e-407b-ad90-4a80a863a3dd	f
39a33722-8fc5-45a0-b730-61e79cde444e	055dd76c-fd10-4e37-8c97-947d04648d0b	t
39a33722-8fc5-45a0-b730-61e79cde444e	d3e92e3f-8e46-4b7d-9c8e-38d7281a1928	t
39a33722-8fc5-45a0-b730-61e79cde444e	148b4ece-21c1-49ec-89ea-b9137b5500f8	t
39a33722-8fc5-45a0-b730-61e79cde444e	d07f80b4-9492-4626-9ba4-6546c97024d5	t
39a33722-8fc5-45a0-b730-61e79cde444e	15f84608-cfee-4646-8bd3-0790ce935bb3	t
39a33722-8fc5-45a0-b730-61e79cde444e	609d4ae5-bf8a-48e2-b2a9-d81b42096dfd	t
39a33722-8fc5-45a0-b730-61e79cde444e	37847a84-3ab5-43da-9fcc-0ac309abbc86	f
39a33722-8fc5-45a0-b730-61e79cde444e	44b67136-7503-4a50-8032-654238f1597e	f
39a33722-8fc5-45a0-b730-61e79cde444e	030d798b-c28b-481f-929a-3ec2c6e92e8d	f
39a33722-8fc5-45a0-b730-61e79cde444e	acc3bdbb-18a3-4cf5-8ea2-0264f7c5fa36	f
39a33722-8fc5-45a0-b730-61e79cde444e	edbd3382-c73e-407b-ad90-4a80a863a3dd	f
121642cc-8d33-4fbc-b80d-39f4e1f8b22c	5a0bd71b-5a3c-4cd8-a0da-81f64dc46ebe	t
121642cc-8d33-4fbc-b80d-39f4e1f8b22c	c99d871b-9dfe-4e84-81bc-eb0759ef065e	t
121642cc-8d33-4fbc-b80d-39f4e1f8b22c	291c177f-c12f-4341-be6a-7fa3d2faabb4	t
121642cc-8d33-4fbc-b80d-39f4e1f8b22c	c796e839-148a-4f01-ba5c-2e38fbf1eeb6	t
121642cc-8d33-4fbc-b80d-39f4e1f8b22c	905f36f2-5b46-4f08-8d1d-ff48fd0abc87	t
121642cc-8d33-4fbc-b80d-39f4e1f8b22c	bc0416cc-4e82-4346-85fa-1d4fe837ecf2	t
121642cc-8d33-4fbc-b80d-39f4e1f8b22c	3e92e7c3-ca3a-4b28-a741-da0850a79426	f
121642cc-8d33-4fbc-b80d-39f4e1f8b22c	fe5a66e2-8ad9-4c9f-b17c-13ddb93d328f	f
121642cc-8d33-4fbc-b80d-39f4e1f8b22c	c26deb71-24b8-4715-be45-3baa4c818026	f
121642cc-8d33-4fbc-b80d-39f4e1f8b22c	f7b2f01c-d622-435c-8bc8-33a21311e25b	f
121642cc-8d33-4fbc-b80d-39f4e1f8b22c	4dd3b68c-89e1-4748-9a1d-bfc573a54bee	f
db01877c-dcdc-4373-8120-6e7b48e26bab	5a0bd71b-5a3c-4cd8-a0da-81f64dc46ebe	t
db01877c-dcdc-4373-8120-6e7b48e26bab	c99d871b-9dfe-4e84-81bc-eb0759ef065e	t
db01877c-dcdc-4373-8120-6e7b48e26bab	291c177f-c12f-4341-be6a-7fa3d2faabb4	t
db01877c-dcdc-4373-8120-6e7b48e26bab	c796e839-148a-4f01-ba5c-2e38fbf1eeb6	t
db01877c-dcdc-4373-8120-6e7b48e26bab	905f36f2-5b46-4f08-8d1d-ff48fd0abc87	t
db01877c-dcdc-4373-8120-6e7b48e26bab	bc0416cc-4e82-4346-85fa-1d4fe837ecf2	t
db01877c-dcdc-4373-8120-6e7b48e26bab	3e92e7c3-ca3a-4b28-a741-da0850a79426	f
db01877c-dcdc-4373-8120-6e7b48e26bab	fe5a66e2-8ad9-4c9f-b17c-13ddb93d328f	f
db01877c-dcdc-4373-8120-6e7b48e26bab	c26deb71-24b8-4715-be45-3baa4c818026	f
db01877c-dcdc-4373-8120-6e7b48e26bab	f7b2f01c-d622-435c-8bc8-33a21311e25b	f
db01877c-dcdc-4373-8120-6e7b48e26bab	4dd3b68c-89e1-4748-9a1d-bfc573a54bee	f
e2f03d00-cbad-4866-a46b-b7a8a58bf4f3	5a0bd71b-5a3c-4cd8-a0da-81f64dc46ebe	t
e2f03d00-cbad-4866-a46b-b7a8a58bf4f3	c99d871b-9dfe-4e84-81bc-eb0759ef065e	t
e2f03d00-cbad-4866-a46b-b7a8a58bf4f3	291c177f-c12f-4341-be6a-7fa3d2faabb4	t
e2f03d00-cbad-4866-a46b-b7a8a58bf4f3	c796e839-148a-4f01-ba5c-2e38fbf1eeb6	t
e2f03d00-cbad-4866-a46b-b7a8a58bf4f3	905f36f2-5b46-4f08-8d1d-ff48fd0abc87	t
e2f03d00-cbad-4866-a46b-b7a8a58bf4f3	bc0416cc-4e82-4346-85fa-1d4fe837ecf2	t
e2f03d00-cbad-4866-a46b-b7a8a58bf4f3	3e92e7c3-ca3a-4b28-a741-da0850a79426	f
e2f03d00-cbad-4866-a46b-b7a8a58bf4f3	fe5a66e2-8ad9-4c9f-b17c-13ddb93d328f	f
e2f03d00-cbad-4866-a46b-b7a8a58bf4f3	c26deb71-24b8-4715-be45-3baa4c818026	f
e2f03d00-cbad-4866-a46b-b7a8a58bf4f3	f7b2f01c-d622-435c-8bc8-33a21311e25b	f
e2f03d00-cbad-4866-a46b-b7a8a58bf4f3	4dd3b68c-89e1-4748-9a1d-bfc573a54bee	f
29032148-f6b3-467c-bfea-bad134dfcf6d	5a0bd71b-5a3c-4cd8-a0da-81f64dc46ebe	t
29032148-f6b3-467c-bfea-bad134dfcf6d	c99d871b-9dfe-4e84-81bc-eb0759ef065e	t
29032148-f6b3-467c-bfea-bad134dfcf6d	291c177f-c12f-4341-be6a-7fa3d2faabb4	t
29032148-f6b3-467c-bfea-bad134dfcf6d	c796e839-148a-4f01-ba5c-2e38fbf1eeb6	t
29032148-f6b3-467c-bfea-bad134dfcf6d	905f36f2-5b46-4f08-8d1d-ff48fd0abc87	t
29032148-f6b3-467c-bfea-bad134dfcf6d	bc0416cc-4e82-4346-85fa-1d4fe837ecf2	t
29032148-f6b3-467c-bfea-bad134dfcf6d	3e92e7c3-ca3a-4b28-a741-da0850a79426	f
29032148-f6b3-467c-bfea-bad134dfcf6d	fe5a66e2-8ad9-4c9f-b17c-13ddb93d328f	f
29032148-f6b3-467c-bfea-bad134dfcf6d	c26deb71-24b8-4715-be45-3baa4c818026	f
29032148-f6b3-467c-bfea-bad134dfcf6d	f7b2f01c-d622-435c-8bc8-33a21311e25b	f
29032148-f6b3-467c-bfea-bad134dfcf6d	4dd3b68c-89e1-4748-9a1d-bfc573a54bee	f
012c8e1e-7ab8-47be-bb58-34d958059506	5a0bd71b-5a3c-4cd8-a0da-81f64dc46ebe	t
012c8e1e-7ab8-47be-bb58-34d958059506	c99d871b-9dfe-4e84-81bc-eb0759ef065e	t
012c8e1e-7ab8-47be-bb58-34d958059506	291c177f-c12f-4341-be6a-7fa3d2faabb4	t
012c8e1e-7ab8-47be-bb58-34d958059506	c796e839-148a-4f01-ba5c-2e38fbf1eeb6	t
012c8e1e-7ab8-47be-bb58-34d958059506	905f36f2-5b46-4f08-8d1d-ff48fd0abc87	t
012c8e1e-7ab8-47be-bb58-34d958059506	bc0416cc-4e82-4346-85fa-1d4fe837ecf2	t
012c8e1e-7ab8-47be-bb58-34d958059506	3e92e7c3-ca3a-4b28-a741-da0850a79426	f
012c8e1e-7ab8-47be-bb58-34d958059506	fe5a66e2-8ad9-4c9f-b17c-13ddb93d328f	f
012c8e1e-7ab8-47be-bb58-34d958059506	c26deb71-24b8-4715-be45-3baa4c818026	f
012c8e1e-7ab8-47be-bb58-34d958059506	f7b2f01c-d622-435c-8bc8-33a21311e25b	f
012c8e1e-7ab8-47be-bb58-34d958059506	4dd3b68c-89e1-4748-9a1d-bfc573a54bee	f
7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	5a0bd71b-5a3c-4cd8-a0da-81f64dc46ebe	t
7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	c99d871b-9dfe-4e84-81bc-eb0759ef065e	t
7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	291c177f-c12f-4341-be6a-7fa3d2faabb4	t
7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	c796e839-148a-4f01-ba5c-2e38fbf1eeb6	t
7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	905f36f2-5b46-4f08-8d1d-ff48fd0abc87	t
7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	bc0416cc-4e82-4346-85fa-1d4fe837ecf2	t
7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	3e92e7c3-ca3a-4b28-a741-da0850a79426	f
7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	fe5a66e2-8ad9-4c9f-b17c-13ddb93d328f	f
7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	c26deb71-24b8-4715-be45-3baa4c818026	f
7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	f7b2f01c-d622-435c-8bc8-33a21311e25b	f
7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	4dd3b68c-89e1-4748-9a1d-bfc573a54bee	f
bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	5a0bd71b-5a3c-4cd8-a0da-81f64dc46ebe	t
bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	c99d871b-9dfe-4e84-81bc-eb0759ef065e	t
bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	291c177f-c12f-4341-be6a-7fa3d2faabb4	t
bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	c796e839-148a-4f01-ba5c-2e38fbf1eeb6	t
bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	905f36f2-5b46-4f08-8d1d-ff48fd0abc87	t
bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	bc0416cc-4e82-4346-85fa-1d4fe837ecf2	t
bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	3e92e7c3-ca3a-4b28-a741-da0850a79426	f
bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	fe5a66e2-8ad9-4c9f-b17c-13ddb93d328f	f
bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	c26deb71-24b8-4715-be45-3baa4c818026	f
bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	f7b2f01c-d622-435c-8bc8-33a21311e25b	f
bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	4dd3b68c-89e1-4748-9a1d-bfc573a54bee	f
3863be94-a32c-41dd-80c6-a847175f3a96	5a0bd71b-5a3c-4cd8-a0da-81f64dc46ebe	t
3863be94-a32c-41dd-80c6-a847175f3a96	c99d871b-9dfe-4e84-81bc-eb0759ef065e	t
3863be94-a32c-41dd-80c6-a847175f3a96	291c177f-c12f-4341-be6a-7fa3d2faabb4	t
3863be94-a32c-41dd-80c6-a847175f3a96	c796e839-148a-4f01-ba5c-2e38fbf1eeb6	t
3863be94-a32c-41dd-80c6-a847175f3a96	905f36f2-5b46-4f08-8d1d-ff48fd0abc87	t
3863be94-a32c-41dd-80c6-a847175f3a96	bc0416cc-4e82-4346-85fa-1d4fe837ecf2	t
3863be94-a32c-41dd-80c6-a847175f3a96	3e92e7c3-ca3a-4b28-a741-da0850a79426	f
3863be94-a32c-41dd-80c6-a847175f3a96	fe5a66e2-8ad9-4c9f-b17c-13ddb93d328f	f
3863be94-a32c-41dd-80c6-a847175f3a96	c26deb71-24b8-4715-be45-3baa4c818026	f
3863be94-a32c-41dd-80c6-a847175f3a96	f7b2f01c-d622-435c-8bc8-33a21311e25b	f
3863be94-a32c-41dd-80c6-a847175f3a96	4dd3b68c-89e1-4748-9a1d-bfc573a54bee	f
78fd174d-495c-4a9c-88ca-271608bc4f5f	5a0bd71b-5a3c-4cd8-a0da-81f64dc46ebe	t
78fd174d-495c-4a9c-88ca-271608bc4f5f	c99d871b-9dfe-4e84-81bc-eb0759ef065e	t
78fd174d-495c-4a9c-88ca-271608bc4f5f	291c177f-c12f-4341-be6a-7fa3d2faabb4	t
78fd174d-495c-4a9c-88ca-271608bc4f5f	c796e839-148a-4f01-ba5c-2e38fbf1eeb6	t
78fd174d-495c-4a9c-88ca-271608bc4f5f	905f36f2-5b46-4f08-8d1d-ff48fd0abc87	t
78fd174d-495c-4a9c-88ca-271608bc4f5f	bc0416cc-4e82-4346-85fa-1d4fe837ecf2	t
78fd174d-495c-4a9c-88ca-271608bc4f5f	3e92e7c3-ca3a-4b28-a741-da0850a79426	f
78fd174d-495c-4a9c-88ca-271608bc4f5f	fe5a66e2-8ad9-4c9f-b17c-13ddb93d328f	f
78fd174d-495c-4a9c-88ca-271608bc4f5f	c26deb71-24b8-4715-be45-3baa4c818026	f
78fd174d-495c-4a9c-88ca-271608bc4f5f	f7b2f01c-d622-435c-8bc8-33a21311e25b	f
78fd174d-495c-4a9c-88ca-271608bc4f5f	4dd3b68c-89e1-4748-9a1d-bfc573a54bee	f
\.


--
-- Data for Name: client_scope_role_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.client_scope_role_mapping (scope_id, role_id) FROM stdin;
44b67136-7503-4a50-8032-654238f1597e	1c0b5c7d-bfb4-4eb5-bd0f-16b4c4fa8d35
fe5a66e2-8ad9-4c9f-b17c-13ddb93d328f	c597fc37-a767-412a-ac88-bbeba571cdb4
\.


--
-- Data for Name: component; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.component (id, name, parent_id, provider_id, provider_type, realm_id, sub_type) FROM stdin;
ee6e2ddb-1e8b-439e-a56e-66ef1819fdaa	Trusted Hosts	29bb8813-da75-41e0-b440-8ab491e3ec8a	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	29bb8813-da75-41e0-b440-8ab491e3ec8a	anonymous
e0637f7e-9f56-4e3a-8d70-c8b849a0362f	Consent Required	29bb8813-da75-41e0-b440-8ab491e3ec8a	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	29bb8813-da75-41e0-b440-8ab491e3ec8a	anonymous
77e0dc00-ac63-4f66-85dc-3944c7425ddc	Full Scope Disabled	29bb8813-da75-41e0-b440-8ab491e3ec8a	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	29bb8813-da75-41e0-b440-8ab491e3ec8a	anonymous
f494f036-2172-41a0-baa9-d1cdcad34d30	Max Clients Limit	29bb8813-da75-41e0-b440-8ab491e3ec8a	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	29bb8813-da75-41e0-b440-8ab491e3ec8a	anonymous
d44433c5-fe17-42b5-a996-5689f1864f38	Allowed Protocol Mapper Types	29bb8813-da75-41e0-b440-8ab491e3ec8a	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	29bb8813-da75-41e0-b440-8ab491e3ec8a	anonymous
0e668bd3-bebb-4be5-8cd9-667c48de8010	Allowed Client Scopes	29bb8813-da75-41e0-b440-8ab491e3ec8a	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	29bb8813-da75-41e0-b440-8ab491e3ec8a	anonymous
fe381875-2db5-4371-ba16-2dfa86e894f9	Allowed Protocol Mapper Types	29bb8813-da75-41e0-b440-8ab491e3ec8a	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	29bb8813-da75-41e0-b440-8ab491e3ec8a	authenticated
7548ba64-ba63-4972-83e7-773e24ed73e2	Allowed Client Scopes	29bb8813-da75-41e0-b440-8ab491e3ec8a	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	29bb8813-da75-41e0-b440-8ab491e3ec8a	authenticated
64e241d9-40a9-40bd-9fee-3efb365f5744	rsa-generated	29bb8813-da75-41e0-b440-8ab491e3ec8a	rsa-generated	org.keycloak.keys.KeyProvider	29bb8813-da75-41e0-b440-8ab491e3ec8a	\N
02627b05-7da7-4ffb-848e-6efc77dbb0a1	rsa-enc-generated	29bb8813-da75-41e0-b440-8ab491e3ec8a	rsa-enc-generated	org.keycloak.keys.KeyProvider	29bb8813-da75-41e0-b440-8ab491e3ec8a	\N
323ae9f9-2e00-419f-baf1-9537426050c6	hmac-generated-hs512	29bb8813-da75-41e0-b440-8ab491e3ec8a	hmac-generated	org.keycloak.keys.KeyProvider	29bb8813-da75-41e0-b440-8ab491e3ec8a	\N
3805c713-5ed8-4114-881e-20e7de84c5d1	aes-generated	29bb8813-da75-41e0-b440-8ab491e3ec8a	aes-generated	org.keycloak.keys.KeyProvider	29bb8813-da75-41e0-b440-8ab491e3ec8a	\N
00d22ba7-eb79-4413-8399-26583807d15f	\N	29bb8813-da75-41e0-b440-8ab491e3ec8a	declarative-user-profile	org.keycloak.userprofile.UserProfileProvider	29bb8813-da75-41e0-b440-8ab491e3ec8a	\N
841b4483-a26c-4e15-be3a-3419dd4b921c	rsa-generated	29105d11-1bed-40a5-9927-60d87c4deff3	rsa-generated	org.keycloak.keys.KeyProvider	29105d11-1bed-40a5-9927-60d87c4deff3	\N
ccb1d3e7-339b-45f2-a63a-ebb85af99a21	rsa-enc-generated	29105d11-1bed-40a5-9927-60d87c4deff3	rsa-enc-generated	org.keycloak.keys.KeyProvider	29105d11-1bed-40a5-9927-60d87c4deff3	\N
fd4edd93-7c52-4fe4-bf49-702ed97ccc98	hmac-generated-hs512	29105d11-1bed-40a5-9927-60d87c4deff3	hmac-generated	org.keycloak.keys.KeyProvider	29105d11-1bed-40a5-9927-60d87c4deff3	\N
aac5cc4c-17ef-4157-a8ca-f97da55f636e	aes-generated	29105d11-1bed-40a5-9927-60d87c4deff3	aes-generated	org.keycloak.keys.KeyProvider	29105d11-1bed-40a5-9927-60d87c4deff3	\N
0765ab68-6749-4872-ab2b-8ab29df7211b	Trusted Hosts	29105d11-1bed-40a5-9927-60d87c4deff3	trusted-hosts	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	29105d11-1bed-40a5-9927-60d87c4deff3	anonymous
eacd6292-67bc-4a0e-a388-375d6f524465	Consent Required	29105d11-1bed-40a5-9927-60d87c4deff3	consent-required	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	29105d11-1bed-40a5-9927-60d87c4deff3	anonymous
5c63d820-9554-4646-94e6-2500517cb776	Full Scope Disabled	29105d11-1bed-40a5-9927-60d87c4deff3	scope	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	29105d11-1bed-40a5-9927-60d87c4deff3	anonymous
ba1fdbf3-f5c0-4841-83b0-2dc11b0fbfd8	Max Clients Limit	29105d11-1bed-40a5-9927-60d87c4deff3	max-clients	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	29105d11-1bed-40a5-9927-60d87c4deff3	anonymous
b16ae371-72cc-4f3d-83ad-12f51d052e3c	Allowed Protocol Mapper Types	29105d11-1bed-40a5-9927-60d87c4deff3	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	29105d11-1bed-40a5-9927-60d87c4deff3	anonymous
fccd0ee0-12e5-4ffe-9649-cfa3d12ac744	Allowed Client Scopes	29105d11-1bed-40a5-9927-60d87c4deff3	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	29105d11-1bed-40a5-9927-60d87c4deff3	anonymous
7669bee9-164e-40cc-981c-466cd17c62da	Allowed Protocol Mapper Types	29105d11-1bed-40a5-9927-60d87c4deff3	allowed-protocol-mappers	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	29105d11-1bed-40a5-9927-60d87c4deff3	authenticated
4a2d6ece-3093-4736-ab69-b98696c54bcf	Allowed Client Scopes	29105d11-1bed-40a5-9927-60d87c4deff3	allowed-client-templates	org.keycloak.services.clientregistration.policy.ClientRegistrationPolicy	29105d11-1bed-40a5-9927-60d87c4deff3	authenticated
\.


--
-- Data for Name: component_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.component_config (id, component_id, name, value) FROM stdin;
4dd37a6a-3f95-46ad-8c58-dd4c2224617d	d44433c5-fe17-42b5-a996-5689f1864f38	allowed-protocol-mapper-types	oidc-address-mapper
e3e8e8d0-ef0c-47bf-945e-9e1df74ce78c	d44433c5-fe17-42b5-a996-5689f1864f38	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
49a266d1-dd59-4bd9-a934-610a6f8b1366	d44433c5-fe17-42b5-a996-5689f1864f38	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
bafbb118-ee49-4a95-ac04-085c7db08787	d44433c5-fe17-42b5-a996-5689f1864f38	allowed-protocol-mapper-types	saml-user-attribute-mapper
2d0ff50b-9eb4-4260-9397-afe8a672b045	d44433c5-fe17-42b5-a996-5689f1864f38	allowed-protocol-mapper-types	saml-role-list-mapper
b317f351-aa4c-48a6-a5c7-10cf99688845	d44433c5-fe17-42b5-a996-5689f1864f38	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
d3d7331a-4a0a-49ac-ac38-5c285b4300f0	d44433c5-fe17-42b5-a996-5689f1864f38	allowed-protocol-mapper-types	saml-user-property-mapper
ae8bd573-9e72-4a2f-9779-523236749c32	d44433c5-fe17-42b5-a996-5689f1864f38	allowed-protocol-mapper-types	oidc-full-name-mapper
a5312865-eec8-4a9c-8351-655977a1cbbc	f494f036-2172-41a0-baa9-d1cdcad34d30	max-clients	200
3ae03089-e379-4da1-8aba-9ff2970fdf1e	ee6e2ddb-1e8b-439e-a56e-66ef1819fdaa	host-sending-registration-request-must-match	true
bcc19fa2-c961-4806-b4ba-4040ce0e4076	ee6e2ddb-1e8b-439e-a56e-66ef1819fdaa	client-uris-must-match	true
4a1cfcc8-57ff-4421-9dec-d261b93987dd	7548ba64-ba63-4972-83e7-773e24ed73e2	allow-default-scopes	true
418830c1-dc50-420b-9e9b-b8f6b64c5522	0e668bd3-bebb-4be5-8cd9-667c48de8010	allow-default-scopes	true
32de71e9-36c3-44d6-b6c2-b4b725f8ebd6	fe381875-2db5-4371-ba16-2dfa86e894f9	allowed-protocol-mapper-types	oidc-full-name-mapper
f9cd60f3-f55d-4fb0-a94a-94894657715a	fe381875-2db5-4371-ba16-2dfa86e894f9	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
db914d98-4293-417d-bc70-a57dfd058334	fe381875-2db5-4371-ba16-2dfa86e894f9	allowed-protocol-mapper-types	saml-user-property-mapper
bca4e22b-92c6-4ce3-b826-672aefb98a6d	fe381875-2db5-4371-ba16-2dfa86e894f9	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
4734c05d-e8de-4614-b8d9-652d77a7c20f	fe381875-2db5-4371-ba16-2dfa86e894f9	allowed-protocol-mapper-types	saml-user-attribute-mapper
d9c22589-d09c-46e3-b6dc-e8fd70647f63	fe381875-2db5-4371-ba16-2dfa86e894f9	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
525c0f6b-48e4-431d-90b9-44529c168d82	fe381875-2db5-4371-ba16-2dfa86e894f9	allowed-protocol-mapper-types	oidc-address-mapper
1320b5f6-d681-4695-89d8-44dfed235646	fe381875-2db5-4371-ba16-2dfa86e894f9	allowed-protocol-mapper-types	saml-role-list-mapper
5a3d72d5-d2fc-411d-879c-b8393c3250e9	02627b05-7da7-4ffb-848e-6efc77dbb0a1	keyUse	ENC
cb575b60-523e-4916-8c93-564a267db95d	02627b05-7da7-4ffb-848e-6efc77dbb0a1	certificate	MIICmzCCAYMCBgGfOgOHfTANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjYwNzA3MDAzNzE3WhcNMzYwNzA3MDAzODU3WjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCQ9nPF/wjSuRrvInJts/uEs6BBwbdUxq7tEYrrXOYEgvMZows064I2+4ZJ9X1uWFfFtHQtcC6XtRaFk5Psm/sR/qzAUNMbfqpX0KfQ9j1cGeYWAmPJLGpwNRG9VonxvSv6E1tp4cPne22wHNJsd6rRojjGtmeeiP15GSWF1/PH7vgPQtmOah9GEqfhAtZCfWfkzjlTJyr8bWEpVNKsyN6Bz47scYwMfUOfVwmHrOd2KePCJhR8JzlO+FvKf2QhF0wHeyzIDYJwJI/pNN/wujC5X1JspleKjXQrOOoVZy0gQ455w3HVQzVh0Z9YbYRRi0iZEa4CNdhN7uNklYBmNPOhAgMBAAEwDQYJKoZIhvcNAQELBQADggEBAFF2LApoVZfsaUmaiA+elpKvIEenZZ8cdYZaqJYw3U9N+2nHa2pmg8t3Re9iKwg0IcmYAkVl8xBDHsD//A98fPbm1Uwi7YOZafztIgJ0Eh4LNpKkpr3gCDjoz1nFw1B9N7KRYdEaK/gLapIDmVDEiKkU0HPK5DPf3VM9NSJhwegFG8IOMZYc7hO+mh2QBUOKR5/esj930ntNzGhas82lWedGkdMkF4RPRlzPb0qcQaN6LbW4NkRjDP0jw8RgHgAQatYRfSkyTC8ylKz60dLZxrsRfCaRnKkt4U6OTKveUdhijyL5vdR2m6J3EFriItYsQCCdzUvZmaqBql1bI9beXCc=
2ebe22e4-05a5-479d-90e6-bfebcaf2fbc8	02627b05-7da7-4ffb-848e-6efc77dbb0a1	privateKey	MIIEowIBAAKCAQEAkPZzxf8I0rka7yJybbP7hLOgQcG3VMau7RGK61zmBILzGaMLNOuCNvuGSfV9blhXxbR0LXAul7UWhZOT7Jv7Ef6swFDTG36qV9Cn0PY9XBnmFgJjySxqcDURvVaJ8b0r+hNbaeHD53ttsBzSbHeq0aI4xrZnnoj9eRklhdfzx+74D0LZjmofRhKn4QLWQn1n5M45Uycq/G1hKVTSrMjegc+O7HGMDH1Dn1cJh6zndinjwiYUfCc5Tvhbyn9kIRdMB3ssyA2CcCSP6TTf8LowuV9SbKZXio10KzjqFWctIEOOecNx1UM1YdGfWG2EUYtImRGuAjXYTe7jZJWAZjTzoQIDAQABAoIBAACTtYxibmxfIPOrl5NhlR5EftkHfTbW0LHi08KUm3mwPykr26bKVZm+zKxuervvJArLuVm9XaxxiQ6vLUvIB2gyqH5TuAe5jGemSJu29jGvwfQLmS50Xn2ruBJLYKf5WqOPkwnNP0PkgIWpXgpL2+PYQqP3rFqz1S1Hp7KZnw0YOtm8IA0dEWdheZT68PWylWXD4pmWDPUicvh39+Ehwd70elbLgKj5zHpua0KY2a4pWaQflIWh+lQwDrcZeXbGCHdte194vjhhg22QCxl+T6OEK6b6vCtr4iPO66TRDIkzAvgXt+7Pfhk4/QxTl+A04hfF1J+nFGimcFG55Q+WAYECgYEAxmPo96Bd5bHGVu9CU2uKgWNIzvmacUG+9Bz9NQQOGQ0CfHYQO+vJkBdsIdSfQ+VSCuMT8bls60XZw4PxVKvnMA4/ebZkGg2Ib9jxm8wKhxAEhr6ZFyffCjd/9T0PiEzlmS07DBf0PEwaHmdtoH5GTaJE59hFVYjB+dBHZ6nK38ECgYEAuw7NWDgREu0MiroTf17pKB8QT/uOcOI2bfJf+/AdQVpevrxLzrUjDXM0bHppo08PXeV1J4+X5EA61/5malH2hgsSTwh4VXlXTwjJjrveAYr0hk3C2LxtNsCHV0h7SD/dyGE5RKaAxABOfrCe3FrGQCRoUvLX5THkN59CI/WJC+ECgYEAmxxygWl5AKXGFSJsERz75b3ipzCwd+yXh/VCY7kP7LYnQ3hrqO3pYidt++VpwIQDaU+xwEThy/GJGTyH61OcJg59woPAMD50dj6AaPdXI9J6N3+94kTiNfK+sNdU1ZSJzwF2MTZpVtuJcEwdgmY4QWqlxT9qtj1+q/sUWRB/9gECgYAQLYOM8axoWqAPD3DIP0ki8yzR/gufr7DNaXzrqSSellZDYL2drwTNEP2jtCKWwSuvDz1GoqCcWQG91H6/Cz+q8CIxO6ZMniXy6+uisJTOxVnIk8kaPZGkfpo17krbQMrJnb76NPxF91DSnCvhGuiye3OaWO5bICmAtgFeYsnrgQKBgEbXjaf3YbGHPW3siT64ptMSvXqz47CkhNjDiS+FRhCWxEhqPsioBxlCydPmmFlUFrOc7YWWL89uESZ0qlQd9kJbk2MEURYtcTbxbKOV6hzyLmRFDi4B2lXKIqK8Om7mSBDzit60u04450D9Kblpkdph0m8q7nmnCBSFMqqrZigA
347ac5be-3fc6-41e8-9211-b0467bb5969b	02627b05-7da7-4ffb-848e-6efc77dbb0a1	algorithm	RSA-OAEP
ebb41f27-23fc-43f3-83d0-d0fdd7858dd2	02627b05-7da7-4ffb-848e-6efc77dbb0a1	priority	100
14bffca4-0890-441f-93b4-5dc2841b12f7	00d22ba7-eb79-4413-8399-26583807d15f	kc.user.profile.config	{"attributes":[{"name":"username","displayName":"${username}","validations":{"length":{"min":3,"max":255},"username-prohibited-characters":{},"up-username-not-idn-homograph":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"email","displayName":"${email}","validations":{"email":{},"length":{"max":255}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"firstName","displayName":"${firstName}","validations":{"length":{"max":255},"person-name-prohibited-characters":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false},{"name":"lastName","displayName":"${lastName}","validations":{"length":{"max":255},"person-name-prohibited-characters":{}},"permissions":{"view":["admin","user"],"edit":["admin","user"]},"multivalued":false}],"groups":[{"name":"user-metadata","displayHeader":"User metadata","displayDescription":"Attributes, which refer to user metadata"}]}
3a95f79a-a341-4fd5-84e8-49b14fa89c85	3805c713-5ed8-4114-881e-20e7de84c5d1	priority	100
5cb0124b-4e5c-4fb2-abb1-37d1d344a125	3805c713-5ed8-4114-881e-20e7de84c5d1	secret	anZzYv8WmJ5N-IOhBu1A8A
eb6e6ca0-f215-4f88-9f9e-b260f76bc823	3805c713-5ed8-4114-881e-20e7de84c5d1	kid	b455c5a0-81f5-44bb-b1c9-1731a1947332
8f5cbf28-5127-4f97-aec3-61d252d96d86	323ae9f9-2e00-419f-baf1-9537426050c6	secret	EjsHc1PZFxVm_mG4jX6Quyoxu01AloFpmh8mDRIOQKkcWj9aYmwBhsIzDNrf5RPREX9nPHYwf70ZxCDsPXIwh0hYAAiHZC2I0d8-pwMk_MPOiuiMfN8lYl98MudZYz0iZqipjBZHNgWSz6qlQRvRz1de8YaJKmpJGksP_J1vvFA
6b075e4a-2179-4d9b-b35b-f020dd0034bf	323ae9f9-2e00-419f-baf1-9537426050c6	algorithm	HS512
98619d43-3698-4929-8a09-a82455c191ef	323ae9f9-2e00-419f-baf1-9537426050c6	kid	1b329bb0-e89e-49e6-94c6-15d2e965c030
9a9fe482-7113-424e-a9e2-94795cca2f9d	323ae9f9-2e00-419f-baf1-9537426050c6	priority	100
13654399-e949-406a-848c-e55d14193d66	64e241d9-40a9-40bd-9fee-3efb365f5744	privateKey	MIIEowIBAAKCAQEArmqyvhHVlf0hvJvdTJfLC8J7ahZhXeh0e3enONMxVINl5/OChqX0jcVDZ0h5geYiYZ/Ap4HIMvhA8VTLib4qhpbwqBNpQhnh5A+QCYOsJMyIwPEMTNEeq2jIcFe9D/TseTswDFYOU3+HgCveFwemOHZIhjB+Xhb3PcZEuGx6M5FvzQhvN+zwUYAR+bFE09kLvRiv352A3CQvk3egFDLPbhiRcvB1Z3a6gAEx4fh9iLLFAFWZA+2pza5h72KrKrDzqJXZQJYdglucceApLiCHhZ2eBDv6GtWzmPZpiR73V+BYWEVNO3PSQH6TZGN8bJp911YA55o5KLaxs5pmu9Q2GQIDAQABAoIBADeCqeSoVGvqJmSazrHj1bGmchTvjomOxBPPnx8MyDR3pWVPMQmdo9nDIJKslE9taR/c8jndqlPegvzL2gO6zFoNjAZSNzvcdPJaqaL9jzofBp8xmJKSM8qmDLUEl52Oe/yRg9dJREH64qs+Su7Vdmed7bMXmABmGsZEZfa0P6hNZ/+WwfJmn2UqrX14KGczq8sz/5OhMcxmKh+n/3JWsZNvCbZgbQZd4J0frpQdWIkIWHflw58b45pEzo+JQM9W5GHFnQ66qSV9f6R+Un3QvVQVvrdsxFgUZl6o6nS6f2CncY0rfwyh/grqfVcvPa3+m9Mjgu7bT9T1L4zfW81XYskCgYEA7OJHrwNDD5qhseVGGFeq77foAaykYixbIh8W90okU5za4PdDxDC1ka8+vEz3yC3nI4GCyscYbkHQSAywp5zgR1YWF6hnfi9+KlwaoDo0oi9k1IPSM7PM0xQiPEd1Qe3yFdTnlN0geFozeeNCt+yW+EyHGeAGwsV5cvnn/rh2E0cCgYEAvH3tVW/W2awEnIM0CvyCteTwIxJXPWZdrYcB2HSO0OuF8QYw9V7504bxfrEDAgKWZQiHZ0CkyvKXa5kbHp84+fsJ0pOk9vRTrKEskif+tZU4e5NFhaMkGBSCw/RaWNuSrDRpCJxeEeRr15NJHLTiYrBMrhnJbsZY5zb/c2s8W58CgYAIUDirz7V+yrJ6B83Z9Nmu6AlgZaqvN1dLb0PjEdsMhCi6VHMwY3U706aj/R+FCvddq6Hnc+1LkUu5+5gHid3lIwRLeEGJkCkhW3IjxWcrefZT7vxljB3YGpDJBMj8s1kXow0tkEUfdCryUCN7SPZTaHwlUFNsannEqziVG+wo6QKBgQCeeJTf3r5YlUnvOFO55OAUAx1trw7PnU+nA7mmfSBRP6KFqDnjIW2SzIIejL3Fo91Dpi8IvQ2PXvO1T6zASwdBDDEO7Hil83ahzYPGgX+gtIsfQgsSNr2yzRO/oaGP0VL4GrwvtB9WlZ+hR8ARNXabmDNvsFhtHK9D/TY5mG/PawKBgE0B9x92SYbjdkNWUzbVfsnWQ4qz47V6YGE3KjsPcrK1fkPpRq057d7GN6DUEiMTxjUxXd1AKO9/NPI1qlpsJ38zPp0g64NPIg9+YflMlztCcoUMkvQupU0JsZFGoQrgK7CklY3XaMsuPiGW+f+7uL4kvHr7RmlxnVo4yhNP2Y1b
5d597b5a-aeea-4009-a452-08380140ad74	64e241d9-40a9-40bd-9fee-3efb365f5744	priority	100
a17b0c32-bd7b-4ff4-ae73-6f977c98ff81	64e241d9-40a9-40bd-9fee-3efb365f5744	keyUse	SIG
7933c8f9-b41b-4a17-bff8-566a317b555c	64e241d9-40a9-40bd-9fee-3efb365f5744	certificate	MIICmzCCAYMCBgGfOgOGmTANBgkqhkiG9w0BAQsFADARMQ8wDQYDVQQDDAZtYXN0ZXIwHhcNMjYwNzA3MDAzNzE3WhcNMzYwNzA3MDAzODU3WjARMQ8wDQYDVQQDDAZtYXN0ZXIwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCuarK+EdWV/SG8m91Ml8sLwntqFmFd6HR7d6c40zFUg2Xn84KGpfSNxUNnSHmB5iJhn8Cngcgy+EDxVMuJviqGlvCoE2lCGeHkD5AJg6wkzIjA8QxM0R6raMhwV70P9Ox5OzAMVg5Tf4eAK94XB6Y4dkiGMH5eFvc9xkS4bHozkW/NCG837PBRgBH5sUTT2Qu9GK/fnYDcJC+Td6AUMs9uGJFy8HVndrqAATHh+H2IssUAVZkD7anNrmHvYqsqsPOoldlAlh2CW5xx4CkuIIeFnZ4EO/oa1bOY9mmJHvdX4FhYRU07c9JAfpNkY3xsmn3XVgDnmjkotrGzmma71DYZAgMBAAEwDQYJKoZIhvcNAQELBQADggEBADj10k0cYNhRjCRLK0Epdd7LvuUvvHxo2ZJrWlQxnbWEOCddK1/B0TbRGLx5hBwJRYeaowh+AeI4NpjVOBLQmHmfuydmMrHDDTrCIt9Sw/NvFw2m05LHIfRh998BG6VRCFlfh/3SZvDGNQtIxRB+GciF38qooAM082lwdvrMbfvL8W0uUY1xduPCdshryteHuXU7VQkCxfWaPOdbGiqBUCjwp5wkIngZ55TITldJIMcTNN8yXbvrB4XVDhXZqp1U4qp8K8p14QF29yiUzCXOhr25bZJ5u8e5UbwoKko6QXT3lqokHVed5DeLqPIq4CKU94SnUtZ0Rsn4ClCUv/gbgfE=
f5127919-e33c-4b8f-808c-fb4519119517	aac5cc4c-17ef-4157-a8ca-f97da55f636e	kid	615f4448-d7e4-44b3-929f-48ca93c0fd0c
dd923318-1897-4bb7-9bca-e422a4f15923	aac5cc4c-17ef-4157-a8ca-f97da55f636e	secret	io10A4wCKXPlAVVW7FDmLg
a896fa1f-0ba6-4dd5-a8de-4d2199e1dc14	aac5cc4c-17ef-4157-a8ca-f97da55f636e	priority	100
515fa3e0-e45d-4422-8962-7cbbf317185e	ccb1d3e7-339b-45f2-a63a-ebb85af99a21	certificate	MIICpTCCAY0CBgGfOgPQKzANBgkqhkiG9w0BAQsFADAWMRQwEgYDVQQDDAthZ2VudHNoaWVsZDAeFw0yNjA3MDcwMDM3MzZaFw0zNjA3MDcwMDM5MTZaMBYxFDASBgNVBAMMC2FnZW50c2hpZWxkMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAmeTAMluYbo0F/D4LOc4gs8idW+hBwfdxXFBMdk2Ev1z/HK1EeSGZjZifX5SLSnnsibOAJW8hJKqBlsbu2380nqrnVbdUeAl0M1fBzqhOnu+MJo7pWE2qrW7pWwKgEHF6WpiCE8kWIDaRd1VWQQrf60pKU3d4GTSop+JufmP4IwtJIip9qy9MXuOodO5Yn2dniM9gEwI8ooLKYxqMEVPrDvnCaRYGyA1aITJBJUh3HO5vBSn7vnoMyQJt4fYlClAyGuvsTxOYJl+WI4iCbfMZVN/PWC/ZrWSKDaZIWA4FS8yQgA2fNAKr8qayKMmmA7stoYgBGtxxk/MhneedXHFtgQIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQBBk3NzAkupzqNzH+MXcBFqnJz/KDIlsiRQ4hWk1aCTfR+/h5dzwORy2MgJs2Uu33FIICLX95rW3LSAqLU7+UvaOwbxJrkjVklc9YITFU9WnsoNBhHqWsK8XS93Na1AY+C/NBrUK0YUGkhEwLuIb2V5kg8Rr8zVbC/n9+rCioazreC0kcBcG1BcXOvy72jA7ozHZfOzURGjVg3tBkyqBdsfQ1y47lzi+nSfd2Jd3qWQTp2K7LJQalXCaGx5RsN6vP0whWzPDe4/x9mBvhzf1SSoQYHkeHDhU+ZXfn2mhrLzbMuAbG0BwRGUdNPTIPMp8hGy4o6/6KRkpe0i6deDPiKW
1c4774e9-183d-406f-a0ae-f6c208f1c3f6	ccb1d3e7-339b-45f2-a63a-ebb85af99a21	algorithm	RSA-OAEP
27cf8fde-15a7-4b08-891b-01c11fbb315b	ccb1d3e7-339b-45f2-a63a-ebb85af99a21	privateKey	MIIEogIBAAKCAQEAmeTAMluYbo0F/D4LOc4gs8idW+hBwfdxXFBMdk2Ev1z/HK1EeSGZjZifX5SLSnnsibOAJW8hJKqBlsbu2380nqrnVbdUeAl0M1fBzqhOnu+MJo7pWE2qrW7pWwKgEHF6WpiCE8kWIDaRd1VWQQrf60pKU3d4GTSop+JufmP4IwtJIip9qy9MXuOodO5Yn2dniM9gEwI8ooLKYxqMEVPrDvnCaRYGyA1aITJBJUh3HO5vBSn7vnoMyQJt4fYlClAyGuvsTxOYJl+WI4iCbfMZVN/PWC/ZrWSKDaZIWA4FS8yQgA2fNAKr8qayKMmmA7stoYgBGtxxk/MhneedXHFtgQIDAQABAoIBAAIJ3M5l9nZTbaZ+W2d1/qqnAAefQ1y6hoDEqwifpQAkbxguBuPMYUR2BrltRi2TwSF/VFWam9+olwwcYT5c2GF4LdWNtsOay3RhJ5bxVY5HKc36c2aZK8c9mn97QMvK9wYTclio/58oXeOs6JY2usna+3JQ2TFLSGcl6ZUIxbkQGFAtbiFs0u+7er5Ko34Wll3r6DCy2u/g/Q2IP+bZH99OjQJTGC/mg5U8Aoq1avC5rWxTiH7bSIPzfE+CgxeuUBQYJETimv4RLz8n7EQcDWYtPMw+sbK3CknByLKQtAphCFOMu0HYa3BdRuA+xzCeX5dvjmq6dNHSwhRE4HrChOECgYEA1ARh93JE8ld2VBDHSCQKbniRaXanFYrsSoDsdTZ9aPjYRlN7dCZsR3lJqtQPBOjVKjIjuiAOdopjQu1aj1rT9dBY8XG+NjuW3KAgbboN83WJqwDEkcOm44X+LzANwcss7SUad/rVgMmWe1MWydzGhS3TJKO1DR4tzNX6pOUkKXECgYEAudGX7KDNpBD2Ro/nlGCm911+6pmKjYigNtGdK8zJPzQx+qDVlXieBK+fOdeYSFL0GyIkISPP2Y64c3ZpM8yiKarA4Bh1c2l/PeQ6NjyXs0cPYFHRjN65Cr2/VYrRYdCXLFfyb6H1BON60bfoCGEHsKeQMOdlc8kXOnRDmC52/RECgYAhHGocVek0m7osGM62koJajFPRT6l6cM7EN+w1xgPB8BL+sKz4D8QbSXLazfFmh+I6i8gOmlEH7EbiPeVFvB6cJiSt2GCnYZkG7a8C0+q32eRdI2qPhSm8IMH4pp2PZWanxoKiuDa9vT3WFrzZW7RZOjXeY/6zhMIMWmKhe/Ow0QKBgEQMPVaqjKRIkefFS0lLG9n6oz/GerbaEdIBcU1Y8Vn0A1mFDLJwOW394pGMInhZ6IsHNbPtKXDCk0m1U1Fk3v3jSj7GtjxNpgtESQ0To3pDy526WML9zUXhtu/cplDr0nCqxF2dMd1YcOHcN1zaK7bFpkhCdSSxv4/og9h3K5wBAoGAe0RAjOCwaRZ1Tx4hYWX4YkVj64I4XTx4XbKVoCbl6m9+uksk+Ryn3I0DJrufyEcrJwajzKqenH8SqY4TW30MWMMZgZZUlB5yfjoZSFxb6SIsj4MZEOjAsO8Ban+vF+uZ2wsiUYpHIhMp6Gz6D7ZkTRlzPRSzfrYcb5v4FqeYszY=
4400f40b-5a3f-4832-bdf5-6fdd9cce4ddb	ccb1d3e7-339b-45f2-a63a-ebb85af99a21	keyUse	ENC
d7ec0503-f054-4516-ac0a-6e0b5628509c	ccb1d3e7-339b-45f2-a63a-ebb85af99a21	priority	100
ff91e7fb-613e-475f-853b-ebd2416989a4	841b4483-a26c-4e15-be3a-3419dd4b921c	certificate	MIICpTCCAY0CBgGfOgPP3TANBgkqhkiG9w0BAQsFADAWMRQwEgYDVQQDDAthZ2VudHNoaWVsZDAeFw0yNjA3MDcwMDM3MzZaFw0zNjA3MDcwMDM5MTZaMBYxFDASBgNVBAMMC2FnZW50c2hpZWxkMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsMKD/0ryAhurJGZRtA5ZODzD2T8yid0GNkI49b/TXfMdgj12ThVsbo9oZbJtEPfQaDFtUDbhxybTbwfkJ8N6tk/eW+n/T8e6tmXxgQBzApONa19Xw5iChHwUjoCUuZuXPIlGtrMuEQuscVPFAEv1+GepeukCjVfzu6CyJMOQud7GgvjIEAL8myHz0hz1cuy4K660Sh76nQoC+HFjXftv6vsNr98rFzbxAkwvEO/ytoh+rqlA94aJ9Hyw0ajQrZeg3DSKDjbP1GbKmDNGimCKhE5IuyCeWcqGAo4JAntvaitJU8mGa40lVMJuNPyUS+qPHHGCGFlRmVRahtx7MHWRZQIDAQABMA0GCSqGSIb3DQEBCwUAA4IBAQBgftAtrkekiIMXEMAW3r2PbQqEk8XH38U+kg3OG2aHJcJ5HPmjMsKiL7yb2A11v0NmSjPeejvRrjR8+33iaBR0DIg5grA0MXpMuU63DelqrItZXpFlSdcivvLOrm2l9PzqzzOIV19VJdFtdj2/tGE5fA6W0FiW5mgt2k6+RnzPJAmL7xYMNsa61YE1g1CTSqdeBQMuI7tMQWavTEyKkchzf+vvgGHTxiLE+xyJ6OjIzZMG8asVWGAHiwDQuyp7LZkYUOUul8uYWQVIIHHqX8GkREiZ6TF0AREn4hm8zG1LLk2GnfiQhMp4ent+uuoxqf3ed0p5oQ6DXDPCD/gYzlDf
80a02e71-54fb-4da8-8d81-07c3b07dda12	841b4483-a26c-4e15-be3a-3419dd4b921c	priority	100
bd1fb5d6-b167-42f7-b21a-93157a46672a	841b4483-a26c-4e15-be3a-3419dd4b921c	keyUse	SIG
37d86cf2-81cf-4043-b7e9-aafa2107fe71	841b4483-a26c-4e15-be3a-3419dd4b921c	privateKey	MIIEowIBAAKCAQEAsMKD/0ryAhurJGZRtA5ZODzD2T8yid0GNkI49b/TXfMdgj12ThVsbo9oZbJtEPfQaDFtUDbhxybTbwfkJ8N6tk/eW+n/T8e6tmXxgQBzApONa19Xw5iChHwUjoCUuZuXPIlGtrMuEQuscVPFAEv1+GepeukCjVfzu6CyJMOQud7GgvjIEAL8myHz0hz1cuy4K660Sh76nQoC+HFjXftv6vsNr98rFzbxAkwvEO/ytoh+rqlA94aJ9Hyw0ajQrZeg3DSKDjbP1GbKmDNGimCKhE5IuyCeWcqGAo4JAntvaitJU8mGa40lVMJuNPyUS+qPHHGCGFlRmVRahtx7MHWRZQIDAQABAoIBADRPFCYARVc3XfHTL9mjp2aboO/RIoEm/hgfh+C+CGyUrkZlLvYTo/eiC+iQoXM0iyHSgsGKxE0d4dNJWA0mbdG3GBxGRs6S0l/5Eju1aNO528+LMxtIrlNLrv+u8JRvBZYeH+WgaAEWXc1Z14JreFqvProHa8BtZ00+1IlJsLI4S8AsayWIWond7Ip9zrbAo0xD0ATgYur8Jxdd1ZC/UPHguonK5sssDNO7/kzOblig6hqCUw1ajeBtrKIndMC05zYMHLgQcoUGsT5qlkWfUIkF6N+PaBYd4+d25g0uXuZFuELBRXM1mH3z51q7hNTLUhc/DKOxQTl2PTjCCetvCs8CgYEA2iZpTvypakm7UADckNrNbLjCgxpL19YMRnpKaZMrFy9Swrb20x2IQMLyMjVVzZUfMnG4t14P+v9vanPcdxBhrS8UksWpGV9ZQ2nBxjgu6ONeaaUyqiSVrxm840fQ/zVFygtRAYuYmEJ0K6g0GTJ+2gDarrAnqSGlIudQ9WwEYDcCgYEAz22r6EUSpiki0JyFZChow1y0yiKIswZBiP6E/141fiURN7171BVxd/lG8LJvojdF5mQLXxuH34+ZUm7gmylIdXSgUMZFaSQM80c8BvDzffjXMIO2sRnFdEinyUIYSoNi7RdO8bMHnzGmSm9WIbh1/4GsVFnT3Njrf1z51FNDNUMCgYBxSZVSsZ+BVPzzVR82EoqvtVs+Hj/YvI3vY76VCRpNlgPSnpWbmTCTASoprMz8UD69QZV9lFmULWa8z6JkKpuvBk4W0pM4W+3NNnSs7axewQTctC+VcB5TqngPR9JfVlkBzdKpjMcX+xq9OUKk+zYpHFx0b4KJMLHDaIEAkrHLDQKBgH4pkXablIU13fQOT1+k6Fty5o9PQ9/HfVLKo7AC5/xKpVdGy6sqQ7KaDpjVnuqGPeCslvII97J1T+cAg2I8UNMH1X5rqcoSYEIT4KHEKgVDtfbPFe5P43YfvtW9erLPiPr1w1Fk98zO0PrTDwtBe5uljmBbpm3cDhiQP2/yGJ2rAoGBAIBtqNVgnhcxtg/vOWndhS/kzg/Ofjy0973eVAroy8QRhlzCt5WZe6ByfiD8Jr5AgM8z3Pqkfj1MCuciWViFR/ANGySqRsdqxgiR2AF6hBSjyaODvJWK6qg/L1c6VzZRsB774AnBKvV13Yqu9uoGwbvWTruY8lVf67S2PyGWDd8n
aecbdf51-d952-4cbf-93ae-6b87356f4a63	fd4edd93-7c52-4fe4-bf49-702ed97ccc98	priority	100
b847b6b5-440a-4bce-a2b7-af8c5a8eed00	fd4edd93-7c52-4fe4-bf49-702ed97ccc98	kid	7f6e65ba-efda-4deb-a96c-d70cfffdad09
2a64b022-2196-4a28-a308-2283009a1f8f	fd4edd93-7c52-4fe4-bf49-702ed97ccc98	algorithm	HS512
972f9064-fc14-4d48-82c8-c62bca1549c9	fd4edd93-7c52-4fe4-bf49-702ed97ccc98	secret	AqN1fskZrgJV5lpymdnOcLxfs5GbFuWn6IDvu8Zten0t8uY3yuu8DF0d4bfnEb0jVfY2BpsEk1_91TaOo2OeU6H6XmMA7Xfels7L3dtmQYixBjh44QEYkJDZpTPh6piI0Y9fbzYH8Oj7TKHQdp5KpM9GWA-2e6L3j9uKCYBk2MU
daff5c54-92a2-43df-9d5f-433911f0564e	4a2d6ece-3093-4736-ab69-b98696c54bcf	allow-default-scopes	true
730e36fc-85e1-4dfc-bd07-0dfe757f810e	fccd0ee0-12e5-4ffe-9649-cfa3d12ac744	allow-default-scopes	true
dbc99413-097f-41a7-96e0-6ac9253a0f43	7669bee9-164e-40cc-981c-466cd17c62da	allowed-protocol-mapper-types	saml-user-attribute-mapper
f2f62916-0dd3-46c7-8d39-761404eaedf3	7669bee9-164e-40cc-981c-466cd17c62da	allowed-protocol-mapper-types	saml-role-list-mapper
0233b218-ba96-47d8-ac74-dd1a2e81049b	7669bee9-164e-40cc-981c-466cd17c62da	allowed-protocol-mapper-types	saml-user-property-mapper
f867947d-e600-4b2b-b893-c72acad76ed5	7669bee9-164e-40cc-981c-466cd17c62da	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
2772db76-bbc1-4bf0-a613-14572e30f975	7669bee9-164e-40cc-981c-466cd17c62da	allowed-protocol-mapper-types	oidc-address-mapper
27620d9a-65b0-49fd-8e12-5365fc95991b	7669bee9-164e-40cc-981c-466cd17c62da	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
cf61794a-2bcf-4af3-9e9d-ae218d9037f7	7669bee9-164e-40cc-981c-466cd17c62da	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
7699e5e5-f538-4501-ab75-133e68b1070d	7669bee9-164e-40cc-981c-466cd17c62da	allowed-protocol-mapper-types	oidc-full-name-mapper
935281ad-c445-4235-aa5c-4148964b3523	ba1fdbf3-f5c0-4841-83b0-2dc11b0fbfd8	max-clients	200
7343c94c-e145-4319-a6c5-b6018ec40cf9	b16ae371-72cc-4f3d-83ad-12f51d052e3c	allowed-protocol-mapper-types	oidc-usermodel-property-mapper
12a02879-001c-4792-9d86-e581d65c3065	b16ae371-72cc-4f3d-83ad-12f51d052e3c	allowed-protocol-mapper-types	oidc-address-mapper
516bef31-a483-4492-aab5-a6bfe19907e0	b16ae371-72cc-4f3d-83ad-12f51d052e3c	allowed-protocol-mapper-types	saml-user-property-mapper
85028699-04ae-426d-ac51-77ef60cc7be8	b16ae371-72cc-4f3d-83ad-12f51d052e3c	allowed-protocol-mapper-types	oidc-full-name-mapper
185849df-c9b9-4b4a-9f74-72fda2aa998e	b16ae371-72cc-4f3d-83ad-12f51d052e3c	allowed-protocol-mapper-types	saml-user-attribute-mapper
3eaf899a-aed2-4c13-be51-b66d35a63155	b16ae371-72cc-4f3d-83ad-12f51d052e3c	allowed-protocol-mapper-types	oidc-sha256-pairwise-sub-mapper
e37ae07f-5529-4f62-a465-3c764ebbfd8a	b16ae371-72cc-4f3d-83ad-12f51d052e3c	allowed-protocol-mapper-types	oidc-usermodel-attribute-mapper
0a7fe171-4ef9-47e3-b83a-9c7e1ca64f48	b16ae371-72cc-4f3d-83ad-12f51d052e3c	allowed-protocol-mapper-types	saml-role-list-mapper
a8a52e33-0da6-47c9-940a-1f7b0a829e36	0765ab68-6749-4872-ab2b-8ab29df7211b	client-uris-must-match	true
891655d2-bff7-49bb-ac39-448ea2158add	0765ab68-6749-4872-ab2b-8ab29df7211b	host-sending-registration-request-must-match	true
\.


--
-- Data for Name: composite_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.composite_role (composite, child_role) FROM stdin;
54d75e83-bbab-4e17-bd53-dd86138a07cb	817d7506-f76e-4202-951f-4741ad2d9262
54d75e83-bbab-4e17-bd53-dd86138a07cb	6bf33d56-52c7-4c82-90b2-dd14f3f9b4bc
54d75e83-bbab-4e17-bd53-dd86138a07cb	e83a3d8a-5392-4ef6-a592-139c62e8bda7
54d75e83-bbab-4e17-bd53-dd86138a07cb	a0c351be-4685-44d7-b172-552c85d8a4ea
54d75e83-bbab-4e17-bd53-dd86138a07cb	c198a99d-fc05-4d6b-bff9-f039a0be0714
54d75e83-bbab-4e17-bd53-dd86138a07cb	8bcbde4f-35c6-4606-98b4-b7aedb161048
54d75e83-bbab-4e17-bd53-dd86138a07cb	73f22d19-8452-49fb-9c70-062246ba3ef2
54d75e83-bbab-4e17-bd53-dd86138a07cb	f61b739f-46dd-4279-b2eb-2404e5c64c0c
54d75e83-bbab-4e17-bd53-dd86138a07cb	b148002c-8efb-4127-acdb-ff0c180aaa89
54d75e83-bbab-4e17-bd53-dd86138a07cb	e53a7e81-3e03-4a7d-b717-ed3304e164f7
54d75e83-bbab-4e17-bd53-dd86138a07cb	0ad3d05a-6593-46ff-9b4e-c61cfa897277
54d75e83-bbab-4e17-bd53-dd86138a07cb	5bfc0a5a-ae71-4834-9b47-fc347fd991c2
54d75e83-bbab-4e17-bd53-dd86138a07cb	4bf2a8cd-9868-40f6-9ae2-90db0a14ea6b
54d75e83-bbab-4e17-bd53-dd86138a07cb	7b07d3ed-8641-4e3c-af1a-93cd691a577d
54d75e83-bbab-4e17-bd53-dd86138a07cb	8265f4cb-e7f0-4d16-91f3-d0050e65b48a
54d75e83-bbab-4e17-bd53-dd86138a07cb	e34c35aa-168b-4876-808a-63e093b81eec
54d75e83-bbab-4e17-bd53-dd86138a07cb	4e683c6b-0173-4d12-9fa0-9c23bdd5e7c3
54d75e83-bbab-4e17-bd53-dd86138a07cb	2964435c-6cfa-4b87-b189-b02f97af681b
a0c351be-4685-44d7-b172-552c85d8a4ea	8265f4cb-e7f0-4d16-91f3-d0050e65b48a
a0c351be-4685-44d7-b172-552c85d8a4ea	2964435c-6cfa-4b87-b189-b02f97af681b
bfb26ed5-54a0-4f24-8a6a-9c7402b830a7	f9a7385d-8061-442d-a816-a41257a1a137
c198a99d-fc05-4d6b-bff9-f039a0be0714	e34c35aa-168b-4876-808a-63e093b81eec
bfb26ed5-54a0-4f24-8a6a-9c7402b830a7	cf252c9e-b3ca-4ac4-973f-abe83d70c192
cf252c9e-b3ca-4ac4-973f-abe83d70c192	f4982fca-525a-4ca8-947f-e83989ffe7ff
a6760797-1e18-470a-bd34-7f478b63f9f1	65f458d0-0054-459e-98b7-7eef2c119f28
54d75e83-bbab-4e17-bd53-dd86138a07cb	191233e9-5cc2-4d87-baee-5615fd674329
bfb26ed5-54a0-4f24-8a6a-9c7402b830a7	1c0b5c7d-bfb4-4eb5-bd0f-16b4c4fa8d35
bfb26ed5-54a0-4f24-8a6a-9c7402b830a7	de3339e9-03a4-4696-87d9-e42a3313a1d6
54d75e83-bbab-4e17-bd53-dd86138a07cb	222e2432-5659-40de-995f-9c0550e5a2d8
54d75e83-bbab-4e17-bd53-dd86138a07cb	b9632cc9-f602-4733-b3f8-083c0c0fd915
54d75e83-bbab-4e17-bd53-dd86138a07cb	3c3ac68b-2468-4d77-9cab-18dbd6dd1009
54d75e83-bbab-4e17-bd53-dd86138a07cb	ef9fbc05-8727-46ed-bfae-673c95a8cd77
54d75e83-bbab-4e17-bd53-dd86138a07cb	6c6e053f-0a59-4f98-9389-f55885499569
54d75e83-bbab-4e17-bd53-dd86138a07cb	10d8379b-25bd-418a-b7d4-29ad3a240686
54d75e83-bbab-4e17-bd53-dd86138a07cb	0251b6d7-85e6-4a73-8334-07d98f09a189
54d75e83-bbab-4e17-bd53-dd86138a07cb	613c574f-a7ca-4388-97d8-50794494f162
54d75e83-bbab-4e17-bd53-dd86138a07cb	b9ff9490-dd0d-4395-b5e0-e36f09975a65
54d75e83-bbab-4e17-bd53-dd86138a07cb	8709b40d-fc99-4675-bcd8-b1c68a5823ff
54d75e83-bbab-4e17-bd53-dd86138a07cb	f10d1ab4-3ad0-4d92-8c1d-ec7a22ae56f8
54d75e83-bbab-4e17-bd53-dd86138a07cb	59889728-5328-4806-ba2a-3f7debf710e9
54d75e83-bbab-4e17-bd53-dd86138a07cb	ebb09c94-2a3b-420f-9b6d-5eda643fcbc3
54d75e83-bbab-4e17-bd53-dd86138a07cb	c72a00e7-c357-4fb6-be34-0ad38fa7df97
54d75e83-bbab-4e17-bd53-dd86138a07cb	d30da5b4-870b-4c0c-aab1-cb0d8c9721fd
54d75e83-bbab-4e17-bd53-dd86138a07cb	faf9a9a6-7f9e-4cac-94d8-f11e82758ad2
54d75e83-bbab-4e17-bd53-dd86138a07cb	0ef4014d-c0f5-4865-bd43-6f2deb8bc6fc
3c3ac68b-2468-4d77-9cab-18dbd6dd1009	c72a00e7-c357-4fb6-be34-0ad38fa7df97
3c3ac68b-2468-4d77-9cab-18dbd6dd1009	0ef4014d-c0f5-4865-bd43-6f2deb8bc6fc
ef9fbc05-8727-46ed-bfae-673c95a8cd77	d30da5b4-870b-4c0c-aab1-cb0d8c9721fd
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	7cfc0eaa-b340-4db4-8459-9dd9dae94344
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	5d67bc96-e989-4782-8cb1-a052d011b1e4
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	e65d6f22-b554-4cb6-9e95-35a9e04285d5
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	4259de44-f644-4d7b-869c-58b78d9eea71
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	5af6afc9-9e47-49da-89d0-2fcdb8fa7a68
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	9654281d-737f-4f75-8d87-16d51f8d2904
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	8ecd70e1-52aa-4109-b8c6-abd7165c3a90
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	938db672-1e25-4307-adca-10b656f6ac1d
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	64213e77-129b-4e99-a383-79c06c9b5ad4
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	e6c32325-c2dd-46cf-b44e-b54d79695dfe
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	f155572c-2a99-4917-a499-6117c846d99b
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	c9e0249b-1ae5-48a3-b7b9-d9548a7d35bf
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	6f17e2db-2115-496d-9b86-f235c58e9edd
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	179a97e3-9070-4136-94be-ca3be76098e3
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	01d9bf7b-fb66-48fe-9af4-0486e962e4bd
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	403cea89-1aad-45ed-8629-2dff2549fa26
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	67f58a8e-be92-4087-808a-ee9308bdaedd
4259de44-f644-4d7b-869c-58b78d9eea71	01d9bf7b-fb66-48fe-9af4-0486e962e4bd
bd09041d-0741-445f-9d89-b73a04dcb1f7	d22cf518-769b-450e-bc9c-6cf4f7748db8
e65d6f22-b554-4cb6-9e95-35a9e04285d5	67f58a8e-be92-4087-808a-ee9308bdaedd
e65d6f22-b554-4cb6-9e95-35a9e04285d5	179a97e3-9070-4136-94be-ca3be76098e3
bd09041d-0741-445f-9d89-b73a04dcb1f7	e2d67d67-d4a9-4b08-bc1c-8fc06bbc4217
e2d67d67-d4a9-4b08-bc1c-8fc06bbc4217	5611a172-ebd3-42c2-8f48-33c5f9f3292e
4c27cc8e-dffc-47f0-b24b-df3210e11eac	c782fcc6-8aa3-4a24-bd32-9d886849de2e
54d75e83-bbab-4e17-bd53-dd86138a07cb	7c1cfe30-15c8-4af4-9c4f-eb738eef7579
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	9e9d8ec4-ccb0-4f59-8996-b834b9fb5118
bd09041d-0741-445f-9d89-b73a04dcb1f7	c597fc37-a767-412a-ac88-bbeba571cdb4
bd09041d-0741-445f-9d89-b73a04dcb1f7	ba9a9162-3ea3-41f2-996c-033b64512b2c
\.


--
-- Data for Name: credential; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.credential (id, salt, type, user_id, created_date, user_label, secret_data, credential_data, priority) FROM stdin;
46a5520f-784f-4549-a7c7-6d2a32d885c7	\N	password	1eaa3f8c-721b-4120-8559-03892bf71cab	1783384738138	\N	{"value":"tn72RALrTIV+zFVTYB6ftksovQPLyjKsgfkU4z4eyg0=","salt":"C1DrtTjG2i8/I4jloD32XQ==","additionalParameters":{}}	{"hashIterations":5,"algorithm":"argon2","additionalParameters":{"hashLength":["32"],"memory":["7168"],"type":["id"],"version":["1.3"],"parallelism":["1"]}}	10
ffdcd052-d2d2-4d05-b0f1-e9848f8f58e8	\N	password	75c7c8b3-7d2d-46e1-8a7b-938dd3c157c6	1783384777635	\N	{"value":"ozg/KLhdC2cb2gosbmGpZ9J6FLQsHqFT4treWC/OCMo=","salt":"bdL9D211CQX/YmxXgbtYJA==","additionalParameters":{}}	{"hashIterations":5,"algorithm":"argon2","additionalParameters":{"hashLength":["32"],"memory":["7168"],"type":["id"],"version":["1.3"],"parallelism":["1"]}}	10
9fb0c800-b638-460f-91b5-5e0e8844de5e	\N	password	77afa81a-8073-4962-8e61-a1e942e52570	1783384784634	\N	{"value":"abfD0M9HvQBJVsIpOXb93ZZEVMg37TgFYvyNvKQYGLM=","salt":"/6PLKtfAZ5JBFc+vfXBa+g==","additionalParameters":{}}	{"hashIterations":5,"algorithm":"argon2","additionalParameters":{"hashLength":["32"],"memory":["7168"],"type":["id"],"version":["1.3"],"parallelism":["1"]}}	10
f4dbeb58-0fa9-4faa-b3c4-20125c628ebc	\N	password	643b0e62-b437-40f8-8104-57c34203624b	1783386680232	\N	{"value":"YcrHN8ZlyoqyHecbqC0lUeKlWPmKteXbX7boSSLHxpg=","salt":"b7nsnJlX1qCBrf7In3EETw==","additionalParameters":{}}	{"hashIterations":5,"algorithm":"argon2","additionalParameters":{"hashLength":["32"],"memory":["7168"],"type":["id"],"version":["1.3"],"parallelism":["1"]}}	10
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/jpa-changelog-1.0.0.Final.xml	2026-07-07 00:38:46.531679	1	EXECUTED	9:6f1016664e21e16d26517a4418f5e3df	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.29.1	\N	\N	3384726038
1.0.0.Final-KEYCLOAK-5461	sthorger@redhat.com	META-INF/db2-jpa-changelog-1.0.0.Final.xml	2026-07-07 00:38:46.542852	2	MARK_RAN	9:828775b1596a07d1200ba1d49e5e3941	createTable tableName=APPLICATION_DEFAULT_ROLES; createTable tableName=CLIENT; createTable tableName=CLIENT_SESSION; createTable tableName=CLIENT_SESSION_ROLE; createTable tableName=COMPOSITE_ROLE; createTable tableName=CREDENTIAL; createTable tab...		\N	4.29.1	\N	\N	3384726038
1.1.0.Beta1	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Beta1.xml	2026-07-07 00:38:46.562885	3	EXECUTED	9:5f090e44a7d595883c1fb61f4b41fd38	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=CLIENT_ATTRIBUTES; createTable tableName=CLIENT_SESSION_NOTE; createTable tableName=APP_NODE_REGISTRATIONS; addColumn table...		\N	4.29.1	\N	\N	3384726038
1.1.0.Final	sthorger@redhat.com	META-INF/jpa-changelog-1.1.0.Final.xml	2026-07-07 00:38:46.565077	4	EXECUTED	9:c07e577387a3d2c04d1adc9aaad8730e	renameColumn newColumnName=EVENT_TIME, oldColumnName=TIME, tableName=EVENT_ENTITY		\N	4.29.1	\N	\N	3384726038
1.2.0.Beta1	psilva@redhat.com	META-INF/jpa-changelog-1.2.0.Beta1.xml	2026-07-07 00:38:46.651465	5	EXECUTED	9:b68ce996c655922dbcd2fe6b6ae72686	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.29.1	\N	\N	3384726038
1.2.0.Beta1	psilva@redhat.com	META-INF/db2-jpa-changelog-1.2.0.Beta1.xml	2026-07-07 00:38:46.655585	6	MARK_RAN	9:543b5c9989f024fe35c6f6c5a97de88e	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION; createTable tableName=PROTOCOL_MAPPER; createTable tableName=PROTOCOL_MAPPER_CONFIG; createTable tableName=...		\N	4.29.1	\N	\N	3384726038
1.2.0.RC1	bburke@redhat.com	META-INF/jpa-changelog-1.2.0.CR1.xml	2026-07-07 00:38:46.748096	7	EXECUTED	9:765afebbe21cf5bbca048e632df38336	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.29.1	\N	\N	3384726038
1.2.0.RC1	bburke@redhat.com	META-INF/db2-jpa-changelog-1.2.0.CR1.xml	2026-07-07 00:38:46.751907	8	MARK_RAN	9:db4a145ba11a6fdaefb397f6dbf829a1	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=MIGRATION_MODEL; createTable tableName=IDENTITY_P...		\N	4.29.1	\N	\N	3384726038
1.2.0.Final	keycloak	META-INF/jpa-changelog-1.2.0.Final.xml	2026-07-07 00:38:46.755658	9	EXECUTED	9:9d05c7be10cdb873f8bcb41bc3a8ab23	update tableName=CLIENT; update tableName=CLIENT; update tableName=CLIENT		\N	4.29.1	\N	\N	3384726038
1.3.0	bburke@redhat.com	META-INF/jpa-changelog-1.3.0.xml	2026-07-07 00:38:46.835289	10	EXECUTED	9:18593702353128d53111f9b1ff0b82b8	delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete tableName=USER_SESSION; createTable tableName=ADMI...		\N	4.29.1	\N	\N	3384726038
1.4.0	bburke@redhat.com	META-INF/jpa-changelog-1.4.0.xml	2026-07-07 00:38:46.856556	11	EXECUTED	9:6122efe5f090e41a85c0f1c9e52cbb62	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.29.1	\N	\N	3384726038
1.4.0	bburke@redhat.com	META-INF/db2-jpa-changelog-1.4.0.xml	2026-07-07 00:38:46.860001	12	MARK_RAN	9:e1ff28bf7568451453f844c5d54bb0b5	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.29.1	\N	\N	3384726038
1.5.0	bburke@redhat.com	META-INF/jpa-changelog-1.5.0.xml	2026-07-07 00:38:46.871047	13	EXECUTED	9:7af32cd8957fbc069f796b61217483fd	delete tableName=CLIENT_SESSION_AUTH_STATUS; delete tableName=CLIENT_SESSION_ROLE; delete tableName=CLIENT_SESSION_PROT_MAPPER; delete tableName=CLIENT_SESSION_NOTE; delete tableName=CLIENT_SESSION; delete tableName=USER_SESSION_NOTE; delete table...		\N	4.29.1	\N	\N	3384726038
1.6.1_from15	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2026-07-07 00:38:46.92906	14	EXECUTED	9:6005e15e84714cd83226bf7879f54190	addColumn tableName=REALM; addColumn tableName=KEYCLOAK_ROLE; addColumn tableName=CLIENT; createTable tableName=OFFLINE_USER_SESSION; createTable tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_US_SES_PK2, tableName=...		\N	4.29.1	\N	\N	3384726038
1.6.1_from16-pre	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2026-07-07 00:38:46.929891	15	MARK_RAN	9:bf656f5a2b055d07f314431cae76f06c	delete tableName=OFFLINE_CLIENT_SESSION; delete tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	3384726038
1.6.1_from16	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2026-07-07 00:38:46.931288	16	MARK_RAN	9:f8dadc9284440469dcf71e25ca6ab99b	dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_US_SES_PK, tableName=OFFLINE_USER_SESSION; dropPrimaryKey constraintName=CONSTRAINT_OFFLINE_CL_SES_PK, tableName=OFFLINE_CLIENT_SESSION; addColumn tableName=OFFLINE_USER_SESSION; update tableName=OF...		\N	4.29.1	\N	\N	3384726038
1.6.1	mposolda@redhat.com	META-INF/jpa-changelog-1.6.1.xml	2026-07-07 00:38:46.932634	17	EXECUTED	9:d41d8cd98f00b204e9800998ecf8427e	empty		\N	4.29.1	\N	\N	3384726038
1.7.0	bburke@redhat.com	META-INF/jpa-changelog-1.7.0.xml	2026-07-07 00:38:46.949154	18	EXECUTED	9:3368ff0be4c2855ee2dd9ca813b38d8e	createTable tableName=KEYCLOAK_GROUP; createTable tableName=GROUP_ROLE_MAPPING; createTable tableName=GROUP_ATTRIBUTE; createTable tableName=USER_GROUP_MEMBERSHIP; createTable tableName=REALM_DEFAULT_GROUPS; addColumn tableName=IDENTITY_PROVIDER; ...		\N	4.29.1	\N	\N	3384726038
1.8.0	mposolda@redhat.com	META-INF/jpa-changelog-1.8.0.xml	2026-07-07 00:38:46.966428	19	EXECUTED	9:8ac2fb5dd030b24c0570a763ed75ed20	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.29.1	\N	\N	3384726038
1.8.0-2	keycloak	META-INF/jpa-changelog-1.8.0.xml	2026-07-07 00:38:47.014475	20	EXECUTED	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.29.1	\N	\N	3384726038
1.8.0	mposolda@redhat.com	META-INF/db2-jpa-changelog-1.8.0.xml	2026-07-07 00:38:47.024237	21	MARK_RAN	9:831e82914316dc8a57dc09d755f23c51	addColumn tableName=IDENTITY_PROVIDER; createTable tableName=CLIENT_TEMPLATE; createTable tableName=CLIENT_TEMPLATE_ATTRIBUTES; createTable tableName=TEMPLATE_SCOPE_MAPPING; dropNotNullConstraint columnName=CLIENT_ID, tableName=PROTOCOL_MAPPER; ad...		\N	4.29.1	\N	\N	3384726038
1.8.0-2	keycloak	META-INF/db2-jpa-changelog-1.8.0.xml	2026-07-07 00:38:47.026362	22	MARK_RAN	9:f91ddca9b19743db60e3057679810e6c	dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; update tableName=CREDENTIAL		\N	4.29.1	\N	\N	3384726038
1.9.0	mposolda@redhat.com	META-INF/jpa-changelog-1.9.0.xml	2026-07-07 00:38:47.124077	23	EXECUTED	9:bc3d0f9e823a69dc21e23e94c7a94bb1	update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=REALM; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=REALM; update tableName=REALM; customChange; dr...		\N	4.29.1	\N	\N	3384726038
1.9.1	keycloak	META-INF/jpa-changelog-1.9.1.xml	2026-07-07 00:38:47.127479	24	EXECUTED	9:c9999da42f543575ab790e76439a2679	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=PUBLIC_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.29.1	\N	\N	3384726038
1.9.1	keycloak	META-INF/db2-jpa-changelog-1.9.1.xml	2026-07-07 00:38:47.128196	25	MARK_RAN	9:0d6c65c6f58732d81569e77b10ba301d	modifyDataType columnName=PRIVATE_KEY, tableName=REALM; modifyDataType columnName=CERTIFICATE, tableName=REALM		\N	4.29.1	\N	\N	3384726038
1.9.2	keycloak	META-INF/jpa-changelog-1.9.2.xml	2026-07-07 00:38:47.631463	26	EXECUTED	9:fc576660fc016ae53d2d4778d84d86d0	createIndex indexName=IDX_USER_EMAIL, tableName=USER_ENTITY; createIndex indexName=IDX_USER_ROLE_MAPPING, tableName=USER_ROLE_MAPPING; createIndex indexName=IDX_USER_GROUP_MAPPING, tableName=USER_GROUP_MEMBERSHIP; createIndex indexName=IDX_USER_CO...		\N	4.29.1	\N	\N	3384726038
authz-2.0.0	psilva@redhat.com	META-INF/jpa-changelog-authz-2.0.0.xml	2026-07-07 00:38:47.649285	27	EXECUTED	9:43ed6b0da89ff77206289e87eaa9c024	createTable tableName=RESOURCE_SERVER; addPrimaryKey constraintName=CONSTRAINT_FARS, tableName=RESOURCE_SERVER; addUniqueConstraint constraintName=UK_AU8TT6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER; createTable tableName=RESOURCE_SERVER_RESOU...		\N	4.29.1	\N	\N	3384726038
authz-2.5.1	psilva@redhat.com	META-INF/jpa-changelog-authz-2.5.1.xml	2026-07-07 00:38:47.650981	28	EXECUTED	9:44bae577f551b3738740281eceb4ea70	update tableName=RESOURCE_SERVER_POLICY		\N	4.29.1	\N	\N	3384726038
2.1.0-KEYCLOAK-5461	bburke@redhat.com	META-INF/jpa-changelog-2.1.0.xml	2026-07-07 00:38:47.664664	29	EXECUTED	9:bd88e1f833df0420b01e114533aee5e8	createTable tableName=BROKER_LINK; createTable tableName=FED_USER_ATTRIBUTE; createTable tableName=FED_USER_CONSENT; createTable tableName=FED_USER_CONSENT_ROLE; createTable tableName=FED_USER_CONSENT_PROT_MAPPER; createTable tableName=FED_USER_CR...		\N	4.29.1	\N	\N	3384726038
2.2.0	bburke@redhat.com	META-INF/jpa-changelog-2.2.0.xml	2026-07-07 00:38:47.717387	30	EXECUTED	9:a7022af5267f019d020edfe316ef4371	addColumn tableName=ADMIN_EVENT_ENTITY; createTable tableName=CREDENTIAL_ATTRIBUTE; createTable tableName=FED_CREDENTIAL_ATTRIBUTE; modifyDataType columnName=VALUE, tableName=CREDENTIAL; addForeignKeyConstraint baseTableName=FED_CREDENTIAL_ATTRIBU...		\N	4.29.1	\N	\N	3384726038
2.3.0	bburke@redhat.com	META-INF/jpa-changelog-2.3.0.xml	2026-07-07 00:38:47.7305	31	EXECUTED	9:fc155c394040654d6a79227e56f5e25a	createTable tableName=FEDERATED_USER; addPrimaryKey constraintName=CONSTR_FEDERATED_USER, tableName=FEDERATED_USER; dropDefaultValue columnName=TOTP, tableName=USER_ENTITY; dropColumn columnName=TOTP, tableName=USER_ENTITY; addColumn tableName=IDE...		\N	4.29.1	\N	\N	3384726038
2.4.0	bburke@redhat.com	META-INF/jpa-changelog-2.4.0.xml	2026-07-07 00:38:47.732306	32	EXECUTED	9:eac4ffb2a14795e5dc7b426063e54d88	customChange		\N	4.29.1	\N	\N	3384726038
2.5.0	bburke@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2026-07-07 00:38:47.734945	33	EXECUTED	9:54937c05672568c4c64fc9524c1e9462	customChange; modifyDataType columnName=USER_ID, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	3384726038
2.5.0-unicode-oracle	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2026-07-07 00:38:47.736119	34	MARK_RAN	9:3a32bace77c84d7678d035a7f5a8084e	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.29.1	\N	\N	3384726038
2.5.0-unicode-other-dbs	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2026-07-07 00:38:47.745226	35	EXECUTED	9:33d72168746f81f98ae3a1e8e0ca3554	modifyDataType columnName=DESCRIPTION, tableName=AUTHENTICATION_FLOW; modifyDataType columnName=DESCRIPTION, tableName=CLIENT_TEMPLATE; modifyDataType columnName=DESCRIPTION, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=DESCRIPTION,...		\N	4.29.1	\N	\N	3384726038
2.5.0-duplicate-email-support	slawomir@dabek.name	META-INF/jpa-changelog-2.5.0.xml	2026-07-07 00:38:47.747667	36	EXECUTED	9:61b6d3d7a4c0e0024b0c839da283da0c	addColumn tableName=REALM		\N	4.29.1	\N	\N	3384726038
2.5.0-unique-group-names	hmlnarik@redhat.com	META-INF/jpa-changelog-2.5.0.xml	2026-07-07 00:38:47.749058	37	EXECUTED	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.29.1	\N	\N	3384726038
2.5.1	bburke@redhat.com	META-INF/jpa-changelog-2.5.1.xml	2026-07-07 00:38:47.751122	38	EXECUTED	9:a2b870802540cb3faa72098db5388af3	addColumn tableName=FED_USER_CONSENT		\N	4.29.1	\N	\N	3384726038
3.0.0	bburke@redhat.com	META-INF/jpa-changelog-3.0.0.xml	2026-07-07 00:38:47.752595	39	EXECUTED	9:132a67499ba24bcc54fb5cbdcfe7e4c0	addColumn tableName=IDENTITY_PROVIDER		\N	4.29.1	\N	\N	3384726038
3.2.0-fix	keycloak	META-INF/jpa-changelog-3.2.0.xml	2026-07-07 00:38:47.75309	40	MARK_RAN	9:938f894c032f5430f2b0fafb1a243462	addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS		\N	4.29.1	\N	\N	3384726038
3.2.0-fix-with-keycloak-5416	keycloak	META-INF/jpa-changelog-3.2.0.xml	2026-07-07 00:38:47.753941	41	MARK_RAN	9:845c332ff1874dc5d35974b0babf3006	dropIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS; addNotNullConstraint columnName=REALM_ID, tableName=CLIENT_INITIAL_ACCESS; createIndex indexName=IDX_CLIENT_INIT_ACC_REALM, tableName=CLIENT_INITIAL_ACCESS		\N	4.29.1	\N	\N	3384726038
3.2.0-fix-offline-sessions	hmlnarik	META-INF/jpa-changelog-3.2.0.xml	2026-07-07 00:38:47.75586	42	EXECUTED	9:fc86359c079781adc577c5a217e4d04c	customChange		\N	4.29.1	\N	\N	3384726038
3.2.0-fixed	keycloak	META-INF/jpa-changelog-3.2.0.xml	2026-07-07 00:38:49.552242	43	EXECUTED	9:59a64800e3c0d09b825f8a3b444fa8f4	addColumn tableName=REALM; dropPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_PK2, tableName=OFFLINE_CLIENT_SESSION; dropColumn columnName=CLIENT_SESSION_ID, tableName=OFFLINE_CLIENT_SESSION; addPrimaryKey constraintName=CONSTRAINT_OFFL_CL_SES_P...		\N	4.29.1	\N	\N	3384726038
3.3.0	keycloak	META-INF/jpa-changelog-3.3.0.xml	2026-07-07 00:38:49.554462	44	EXECUTED	9:d48d6da5c6ccf667807f633fe489ce88	addColumn tableName=USER_ENTITY		\N	4.29.1	\N	\N	3384726038
authz-3.4.0.CR1-resource-server-pk-change-part1	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-07-07 00:38:49.556426	45	EXECUTED	9:dde36f7973e80d71fceee683bc5d2951	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_RESOURCE; addColumn tableName=RESOURCE_SERVER_SCOPE		\N	4.29.1	\N	\N	3384726038
authz-3.4.0.CR1-resource-server-pk-change-part2-KEYCLOAK-6095	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-07-07 00:38:49.558999	46	EXECUTED	9:b855e9b0a406b34fa323235a0cf4f640	customChange		\N	4.29.1	\N	\N	3384726038
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-07-07 00:38:49.560124	47	MARK_RAN	9:51abbacd7b416c50c4421a8cabf7927e	dropIndex indexName=IDX_RES_SERV_POL_RES_SERV, tableName=RESOURCE_SERVER_POLICY; dropIndex indexName=IDX_RES_SRV_RES_RES_SRV, tableName=RESOURCE_SERVER_RESOURCE; dropIndex indexName=IDX_RES_SRV_SCOPE_RES_SRV, tableName=RESOURCE_SERVER_SCOPE		\N	4.29.1	\N	\N	3384726038
authz-3.4.0.CR1-resource-server-pk-change-part3-fixed-nodropindex	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-07-07 00:38:49.664303	48	EXECUTED	9:bdc99e567b3398bac83263d375aad143	addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_POLICY; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, tableName=RESOURCE_SERVER_RESOURCE; addNotNullConstraint columnName=RESOURCE_SERVER_CLIENT_ID, ...		\N	4.29.1	\N	\N	3384726038
authn-3.4.0.CR1-refresh-token-max-reuse	glavoie@gmail.com	META-INF/jpa-changelog-authz-3.4.0.CR1.xml	2026-07-07 00:38:49.666586	49	EXECUTED	9:d198654156881c46bfba39abd7769e69	addColumn tableName=REALM		\N	4.29.1	\N	\N	3384726038
3.4.0	keycloak	META-INF/jpa-changelog-3.4.0.xml	2026-07-07 00:38:49.726505	50	EXECUTED	9:cfdd8736332ccdd72c5256ccb42335db	addPrimaryKey constraintName=CONSTRAINT_REALM_DEFAULT_ROLES, tableName=REALM_DEFAULT_ROLES; addPrimaryKey constraintName=CONSTRAINT_COMPOSITE_ROLE, tableName=COMPOSITE_ROLE; addPrimaryKey constraintName=CONSTR_REALM_DEFAULT_GROUPS, tableName=REALM...		\N	4.29.1	\N	\N	3384726038
3.4.0-KEYCLOAK-5230	hmlnarik@redhat.com	META-INF/jpa-changelog-3.4.0.xml	2026-07-07 00:38:50.081744	51	EXECUTED	9:7c84de3d9bd84d7f077607c1a4dcb714	createIndex indexName=IDX_FU_ATTRIBUTE, tableName=FED_USER_ATTRIBUTE; createIndex indexName=IDX_FU_CONSENT, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CONSENT_RU, tableName=FED_USER_CONSENT; createIndex indexName=IDX_FU_CREDENTIAL, t...		\N	4.29.1	\N	\N	3384726038
3.4.1	psilva@redhat.com	META-INF/jpa-changelog-3.4.1.xml	2026-07-07 00:38:50.083889	52	EXECUTED	9:5a6bb36cbefb6a9d6928452c0852af2d	modifyDataType columnName=VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	3384726038
3.4.2	keycloak	META-INF/jpa-changelog-3.4.2.xml	2026-07-07 00:38:50.085886	53	EXECUTED	9:8f23e334dbc59f82e0a328373ca6ced0	update tableName=REALM		\N	4.29.1	\N	\N	3384726038
3.4.2-KEYCLOAK-5172	mkanis@redhat.com	META-INF/jpa-changelog-3.4.2.xml	2026-07-07 00:38:50.087666	54	EXECUTED	9:9156214268f09d970cdf0e1564d866af	update tableName=CLIENT		\N	4.29.1	\N	\N	3384726038
4.0.0-KEYCLOAK-6335	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2026-07-07 00:38:50.089927	55	EXECUTED	9:db806613b1ed154826c02610b7dbdf74	createTable tableName=CLIENT_AUTH_FLOW_BINDINGS; addPrimaryKey constraintName=C_CLI_FLOW_BIND, tableName=CLIENT_AUTH_FLOW_BINDINGS		\N	4.29.1	\N	\N	3384726038
4.0.0-CLEANUP-UNUSED-TABLE	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2026-07-07 00:38:50.110914	56	EXECUTED	9:229a041fb72d5beac76bb94a5fa709de	dropTable tableName=CLIENT_IDENTITY_PROV_MAPPING		\N	4.29.1	\N	\N	3384726038
4.0.0-KEYCLOAK-6228	bburke@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2026-07-07 00:38:50.153305	57	EXECUTED	9:079899dade9c1e683f26b2aa9ca6ff04	dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; dropNotNullConstraint columnName=CLIENT_ID, tableName=USER_CONSENT; addColumn tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHO...		\N	4.29.1	\N	\N	3384726038
4.0.0-KEYCLOAK-5579-fixed	mposolda@redhat.com	META-INF/jpa-changelog-4.0.0.xml	2026-07-07 00:38:50.764722	58	EXECUTED	9:139b79bcbbfe903bb1c2d2a4dbf001d9	dropForeignKeyConstraint baseTableName=CLIENT_TEMPLATE_ATTRIBUTES, constraintName=FK_CL_TEMPL_ATTR_TEMPL; renameTable newTableName=CLIENT_SCOPE_ATTRIBUTES, oldTableName=CLIENT_TEMPLATE_ATTRIBUTES; renameColumn newColumnName=SCOPE_ID, oldColumnName...		\N	4.29.1	\N	\N	3384726038
authz-4.0.0.CR1	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.CR1.xml	2026-07-07 00:38:50.773481	59	EXECUTED	9:b55738ad889860c625ba2bf483495a04	createTable tableName=RESOURCE_SERVER_PERM_TICKET; addPrimaryKey constraintName=CONSTRAINT_FAPMT, tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRHO213XCX4WNKOG82SSPMT...		\N	4.29.1	\N	\N	3384726038
authz-4.0.0.Beta3	psilva@redhat.com	META-INF/jpa-changelog-authz-4.0.0.Beta3.xml	2026-07-07 00:38:50.776911	60	EXECUTED	9:e0057eac39aa8fc8e09ac6cfa4ae15fe	addColumn tableName=RESOURCE_SERVER_POLICY; addColumn tableName=RESOURCE_SERVER_PERM_TICKET; addForeignKeyConstraint baseTableName=RESOURCE_SERVER_PERM_TICKET, constraintName=FK_FRSRPO2128CX4WNKOG82SSRFY, referencedTableName=RESOURCE_SERVER_POLICY		\N	4.29.1	\N	\N	3384726038
authz-4.2.0.Final	mhajas@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2026-07-07 00:38:50.812862	61	EXECUTED	9:42a33806f3a0443fe0e7feeec821326c	createTable tableName=RESOURCE_URIS; addForeignKeyConstraint baseTableName=RESOURCE_URIS, constraintName=FK_RESOURCE_SERVER_URIS, referencedTableName=RESOURCE_SERVER_RESOURCE; customChange; dropColumn columnName=URI, tableName=RESOURCE_SERVER_RESO...		\N	4.29.1	\N	\N	3384726038
authz-4.2.0.Final-KEYCLOAK-9944	hmlnarik@redhat.com	META-INF/jpa-changelog-authz-4.2.0.Final.xml	2026-07-07 00:38:50.814848	62	EXECUTED	9:9968206fca46eecc1f51db9c024bfe56	addPrimaryKey constraintName=CONSTRAINT_RESOUR_URIS_PK, tableName=RESOURCE_URIS		\N	4.29.1	\N	\N	3384726038
4.2.0-KEYCLOAK-6313	wadahiro@gmail.com	META-INF/jpa-changelog-4.2.0.xml	2026-07-07 00:38:50.816658	63	EXECUTED	9:92143a6daea0a3f3b8f598c97ce55c3d	addColumn tableName=REQUIRED_ACTION_PROVIDER		\N	4.29.1	\N	\N	3384726038
4.3.0-KEYCLOAK-7984	wadahiro@gmail.com	META-INF/jpa-changelog-4.3.0.xml	2026-07-07 00:38:50.818232	64	EXECUTED	9:82bab26a27195d889fb0429003b18f40	update tableName=REQUIRED_ACTION_PROVIDER		\N	4.29.1	\N	\N	3384726038
4.6.0-KEYCLOAK-7950	psilva@redhat.com	META-INF/jpa-changelog-4.6.0.xml	2026-07-07 00:38:50.820052	65	EXECUTED	9:e590c88ddc0b38b0ae4249bbfcb5abc3	update tableName=RESOURCE_SERVER_RESOURCE		\N	4.29.1	\N	\N	3384726038
4.6.0-KEYCLOAK-8377	keycloak	META-INF/jpa-changelog-4.6.0.xml	2026-07-07 00:38:50.852098	66	EXECUTED	9:5c1f475536118dbdc38d5d7977950cc0	createTable tableName=ROLE_ATTRIBUTE; addPrimaryKey constraintName=CONSTRAINT_ROLE_ATTRIBUTE_PK, tableName=ROLE_ATTRIBUTE; addForeignKeyConstraint baseTableName=ROLE_ATTRIBUTE, constraintName=FK_ROLE_ATTRIBUTE_ID, referencedTableName=KEYCLOAK_ROLE...		\N	4.29.1	\N	\N	3384726038
4.6.0-KEYCLOAK-8555	gideonray@gmail.com	META-INF/jpa-changelog-4.6.0.xml	2026-07-07 00:38:50.875688	67	EXECUTED	9:e7c9f5f9c4d67ccbbcc215440c718a17	createIndex indexName=IDX_COMPONENT_PROVIDER_TYPE, tableName=COMPONENT		\N	4.29.1	\N	\N	3384726038
4.7.0-KEYCLOAK-1267	sguilhen@redhat.com	META-INF/jpa-changelog-4.7.0.xml	2026-07-07 00:38:50.878491	68	EXECUTED	9:88e0bfdda924690d6f4e430c53447dd5	addColumn tableName=REALM		\N	4.29.1	\N	\N	3384726038
4.7.0-KEYCLOAK-7275	keycloak	META-INF/jpa-changelog-4.7.0.xml	2026-07-07 00:38:50.92649	69	EXECUTED	9:f53177f137e1c46b6a88c59ec1cb5218	renameColumn newColumnName=CREATED_ON, oldColumnName=LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION; addNotNullConstraint columnName=CREATED_ON, tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_USER_SESSION; customChange; createIn...		\N	4.29.1	\N	\N	3384726038
4.8.0-KEYCLOAK-8835	sguilhen@redhat.com	META-INF/jpa-changelog-4.8.0.xml	2026-07-07 00:38:50.930569	70	EXECUTED	9:a74d33da4dc42a37ec27121580d1459f	addNotNullConstraint columnName=SSO_MAX_LIFESPAN_REMEMBER_ME, tableName=REALM; addNotNullConstraint columnName=SSO_IDLE_TIMEOUT_REMEMBER_ME, tableName=REALM		\N	4.29.1	\N	\N	3384726038
authz-7.0.0-KEYCLOAK-10443	psilva@redhat.com	META-INF/jpa-changelog-authz-7.0.0.xml	2026-07-07 00:38:50.932575	71	EXECUTED	9:fd4ade7b90c3b67fae0bfcfcb42dfb5f	addColumn tableName=RESOURCE_SERVER		\N	4.29.1	\N	\N	3384726038
8.0.0-adding-credential-columns	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-07-07 00:38:50.936583	72	EXECUTED	9:aa072ad090bbba210d8f18781b8cebf4	addColumn tableName=CREDENTIAL; addColumn tableName=FED_USER_CREDENTIAL		\N	4.29.1	\N	\N	3384726038
8.0.0-updating-credential-data-not-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-07-07 00:38:50.940146	73	EXECUTED	9:1ae6be29bab7c2aa376f6983b932be37	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.29.1	\N	\N	3384726038
8.0.0-updating-credential-data-oracle-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-07-07 00:38:50.941296	74	MARK_RAN	9:14706f286953fc9a25286dbd8fb30d97	update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL; update tableName=FED_USER_CREDENTIAL		\N	4.29.1	\N	\N	3384726038
8.0.0-credential-cleanup-fixed	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-07-07 00:38:50.951454	75	EXECUTED	9:2b9cc12779be32c5b40e2e67711a218b	dropDefaultValue columnName=COUNTER, tableName=CREDENTIAL; dropDefaultValue columnName=DIGITS, tableName=CREDENTIAL; dropDefaultValue columnName=PERIOD, tableName=CREDENTIAL; dropDefaultValue columnName=ALGORITHM, tableName=CREDENTIAL; dropColumn ...		\N	4.29.1	\N	\N	3384726038
8.0.0-resource-tag-support	keycloak	META-INF/jpa-changelog-8.0.0.xml	2026-07-07 00:38:51.018393	76	EXECUTED	9:91fa186ce7a5af127a2d7a91ee083cc5	addColumn tableName=MIGRATION_MODEL; createIndex indexName=IDX_UPDATE_TIME, tableName=MIGRATION_MODEL		\N	4.29.1	\N	\N	3384726038
9.0.0-always-display-client	keycloak	META-INF/jpa-changelog-9.0.0.xml	2026-07-07 00:38:51.020611	77	EXECUTED	9:6335e5c94e83a2639ccd68dd24e2e5ad	addColumn tableName=CLIENT		\N	4.29.1	\N	\N	3384726038
9.0.0-drop-constraints-for-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2026-07-07 00:38:51.021238	78	MARK_RAN	9:6bdb5658951e028bfe16fa0a8228b530	dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5PMT, tableName=RESOURCE_SERVER_PERM_TICKET; dropUniqueConstraint constraintName=UK_FRSR6T700S9V50BU18WS5HA6, tableName=RESOURCE_SERVER_RESOURCE; dropPrimaryKey constraintName=CONSTRAINT_O...		\N	4.29.1	\N	\N	3384726038
9.0.0-increase-column-size-federated-fk	keycloak	META-INF/jpa-changelog-9.0.0.xml	2026-07-07 00:38:51.030738	79	EXECUTED	9:d5bc15a64117ccad481ce8792d4c608f	modifyDataType columnName=CLIENT_ID, tableName=FED_USER_CONSENT; modifyDataType columnName=CLIENT_REALM_CONSTRAINT, tableName=KEYCLOAK_ROLE; modifyDataType columnName=OWNER, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=CLIENT_ID, ta...		\N	4.29.1	\N	\N	3384726038
9.0.0-recreate-constraints-after-column-increase	keycloak	META-INF/jpa-changelog-9.0.0.xml	2026-07-07 00:38:51.031956	80	MARK_RAN	9:077cba51999515f4d3e7ad5619ab592c	addNotNullConstraint columnName=CLIENT_ID, tableName=OFFLINE_CLIENT_SESSION; addNotNullConstraint columnName=OWNER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNullConstraint columnName=REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; addNotNull...		\N	4.29.1	\N	\N	3384726038
9.0.1-add-index-to-client.client_id	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-07-07 00:38:51.057211	81	EXECUTED	9:be969f08a163bf47c6b9e9ead8ac2afb	createIndex indexName=IDX_CLIENT_ID, tableName=CLIENT		\N	4.29.1	\N	\N	3384726038
9.0.1-KEYCLOAK-12579-drop-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-07-07 00:38:51.05893	82	MARK_RAN	9:6d3bb4408ba5a72f39bd8a0b301ec6e3	dropUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.29.1	\N	\N	3384726038
9.0.1-KEYCLOAK-12579-add-not-null-constraint	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-07-07 00:38:51.063793	83	EXECUTED	9:966bda61e46bebf3cc39518fbed52fa7	addNotNullConstraint columnName=PARENT_GROUP, tableName=KEYCLOAK_GROUP		\N	4.29.1	\N	\N	3384726038
9.0.1-KEYCLOAK-12579-recreate-constraints	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-07-07 00:38:51.065004	84	MARK_RAN	9:8dcac7bdf7378e7d823cdfddebf72fda	addUniqueConstraint constraintName=SIBLING_NAMES, tableName=KEYCLOAK_GROUP		\N	4.29.1	\N	\N	3384726038
9.0.1-add-index-to-events	keycloak	META-INF/jpa-changelog-9.0.1.xml	2026-07-07 00:38:51.138801	85	EXECUTED	9:7d93d602352a30c0c317e6a609b56599	createIndex indexName=IDX_EVENT_TIME, tableName=EVENT_ENTITY		\N	4.29.1	\N	\N	3384726038
map-remove-ri	keycloak	META-INF/jpa-changelog-11.0.0.xml	2026-07-07 00:38:51.140736	86	EXECUTED	9:71c5969e6cdd8d7b6f47cebc86d37627	dropForeignKeyConstraint baseTableName=REALM, constraintName=FK_TRAF444KK6QRKMS7N56AIWQ5Y; dropForeignKeyConstraint baseTableName=KEYCLOAK_ROLE, constraintName=FK_KJHO5LE2C0RAL09FL8CM9WFW9		\N	4.29.1	\N	\N	3384726038
map-remove-ri	keycloak	META-INF/jpa-changelog-12.0.0.xml	2026-07-07 00:38:51.148488	87	EXECUTED	9:a9ba7d47f065f041b7da856a81762021	dropForeignKeyConstraint baseTableName=REALM_DEFAULT_GROUPS, constraintName=FK_DEF_GROUPS_GROUP; dropForeignKeyConstraint baseTableName=REALM_DEFAULT_ROLES, constraintName=FK_H4WPD7W4HSOOLNI3H0SW7BTJE; dropForeignKeyConstraint baseTableName=CLIENT...		\N	4.29.1	\N	\N	3384726038
12.1.0-add-realm-localization-table	keycloak	META-INF/jpa-changelog-12.0.0.xml	2026-07-07 00:38:51.1529	88	EXECUTED	9:fffabce2bc01e1a8f5110d5278500065	createTable tableName=REALM_LOCALIZATIONS; addPrimaryKey tableName=REALM_LOCALIZATIONS		\N	4.29.1	\N	\N	3384726038
default-roles	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-07-07 00:38:51.155865	89	EXECUTED	9:fa8a5b5445e3857f4b010bafb5009957	addColumn tableName=REALM; customChange		\N	4.29.1	\N	\N	3384726038
default-roles-cleanup	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-07-07 00:38:51.212395	90	EXECUTED	9:67ac3241df9a8582d591c5ed87125f39	dropTable tableName=REALM_DEFAULT_ROLES; dropTable tableName=CLIENT_DEFAULT_ROLES		\N	4.29.1	\N	\N	3384726038
13.0.0-KEYCLOAK-16844	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-07-07 00:38:51.237236	91	EXECUTED	9:ad1194d66c937e3ffc82386c050ba089	createIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	3384726038
map-remove-ri-13.0.0	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-07-07 00:38:51.240242	92	EXECUTED	9:d9be619d94af5a2f5d07b9f003543b91	dropForeignKeyConstraint baseTableName=DEFAULT_CLIENT_SCOPE, constraintName=FK_R_DEF_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SCOPE_CLIENT, constraintName=FK_C_CLI_SCOPE_SCOPE; dropForeignKeyConstraint baseTableName=CLIENT_SC...		\N	4.29.1	\N	\N	3384726038
13.0.0-KEYCLOAK-17992-drop-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-07-07 00:38:51.241055	93	MARK_RAN	9:544d201116a0fcc5a5da0925fbbc3bde	dropPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CLSCOPE_CL, tableName=CLIENT_SCOPE_CLIENT; dropIndex indexName=IDX_CL_CLSCOPE, tableName=CLIENT_SCOPE_CLIENT		\N	4.29.1	\N	\N	3384726038
13.0.0-increase-column-size-federated	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-07-07 00:38:51.244619	94	EXECUTED	9:43c0c1055b6761b4b3e89de76d612ccf	modifyDataType columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; modifyDataType columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT		\N	4.29.1	\N	\N	3384726038
13.0.0-KEYCLOAK-17992-recreate-constraints	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-07-07 00:38:51.245578	95	MARK_RAN	9:8bd711fd0330f4fe980494ca43ab1139	addNotNullConstraint columnName=CLIENT_ID, tableName=CLIENT_SCOPE_CLIENT; addNotNullConstraint columnName=SCOPE_ID, tableName=CLIENT_SCOPE_CLIENT; addPrimaryKey constraintName=C_CLI_SCOPE_BIND, tableName=CLIENT_SCOPE_CLIENT; createIndex indexName=...		\N	4.29.1	\N	\N	3384726038
json-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-13.0.0.xml	2026-07-07 00:38:51.248348	96	EXECUTED	9:e07d2bc0970c348bb06fb63b1f82ddbf	addColumn tableName=REALM_ATTRIBUTE; update tableName=REALM_ATTRIBUTE; dropColumn columnName=VALUE, tableName=REALM_ATTRIBUTE; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=REALM_ATTRIBUTE		\N	4.29.1	\N	\N	3384726038
14.0.0-KEYCLOAK-11019	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-07-07 00:38:51.341909	97	EXECUTED	9:24fb8611e97f29989bea412aa38d12b7	createIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USER, tableName=OFFLINE_USER_SESSION; createIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	3384726038
14.0.0-KEYCLOAK-18286	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-07-07 00:38:51.34298	98	MARK_RAN	9:259f89014ce2506ee84740cbf7163aa7	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	3384726038
14.0.0-KEYCLOAK-18286-revert	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-07-07 00:38:51.352219	99	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	3384726038
14.0.0-KEYCLOAK-18286-supported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-07-07 00:38:51.520452	100	EXECUTED	9:60ca84a0f8c94ec8c3504a5a3bc88ee8	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	3384726038
14.0.0-KEYCLOAK-18286-unsupported-dbs	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-07-07 00:38:51.521411	101	MARK_RAN	9:d3d977031d431db16e2c181ce49d73e9	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	3384726038
KEYCLOAK-17267-add-index-to-user-attributes	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-07-07 00:38:51.626937	102	EXECUTED	9:0b305d8d1277f3a89a0a53a659ad274c	createIndex indexName=IDX_USER_ATTRIBUTE_NAME, tableName=USER_ATTRIBUTE		\N	4.29.1	\N	\N	3384726038
KEYCLOAK-18146-add-saml-art-binding-identifier	keycloak	META-INF/jpa-changelog-14.0.0.xml	2026-07-07 00:38:51.629257	103	EXECUTED	9:2c374ad2cdfe20e2905a84c8fac48460	customChange		\N	4.29.1	\N	\N	3384726038
15.0.0-KEYCLOAK-18467	keycloak	META-INF/jpa-changelog-15.0.0.xml	2026-07-07 00:38:51.632738	104	EXECUTED	9:47a760639ac597360a8219f5b768b4de	addColumn tableName=REALM_LOCALIZATIONS; update tableName=REALM_LOCALIZATIONS; dropColumn columnName=TEXTS, tableName=REALM_LOCALIZATIONS; renameColumn newColumnName=TEXTS, oldColumnName=TEXTS_NEW, tableName=REALM_LOCALIZATIONS; addNotNullConstrai...		\N	4.29.1	\N	\N	3384726038
17.0.0-9562	keycloak	META-INF/jpa-changelog-17.0.0.xml	2026-07-07 00:38:51.812128	105	EXECUTED	9:a6272f0576727dd8cad2522335f5d99e	createIndex indexName=IDX_USER_SERVICE_ACCOUNT, tableName=USER_ENTITY		\N	4.29.1	\N	\N	3384726038
18.0.0-10625-IDX_ADMIN_EVENT_TIME	keycloak	META-INF/jpa-changelog-18.0.0.xml	2026-07-07 00:38:51.912524	106	EXECUTED	9:015479dbd691d9cc8669282f4828c41d	createIndex indexName=IDX_ADMIN_EVENT_TIME, tableName=ADMIN_EVENT_ENTITY		\N	4.29.1	\N	\N	3384726038
18.0.15-30992-index-consent	keycloak	META-INF/jpa-changelog-18.0.15.xml	2026-07-07 00:38:52.020691	107	EXECUTED	9:80071ede7a05604b1f4906f3bf3b00f0	createIndex indexName=IDX_USCONSENT_SCOPE_ID, tableName=USER_CONSENT_CLIENT_SCOPE		\N	4.29.1	\N	\N	3384726038
19.0.0-10135	keycloak	META-INF/jpa-changelog-19.0.0.xml	2026-07-07 00:38:52.022817	108	EXECUTED	9:9518e495fdd22f78ad6425cc30630221	customChange		\N	4.29.1	\N	\N	3384726038
20.0.0-12964-supported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2026-07-07 00:38:52.119677	109	EXECUTED	9:e5f243877199fd96bcc842f27a1656ac	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.29.1	\N	\N	3384726038
20.0.0-12964-unsupported-dbs	keycloak	META-INF/jpa-changelog-20.0.0.xml	2026-07-07 00:38:52.120605	110	MARK_RAN	9:1a6fcaa85e20bdeae0a9ce49b41946a5	createIndex indexName=IDX_GROUP_ATT_BY_NAME_VALUE, tableName=GROUP_ATTRIBUTE		\N	4.29.1	\N	\N	3384726038
client-attributes-string-accomodation-fixed	keycloak	META-INF/jpa-changelog-20.0.0.xml	2026-07-07 00:38:52.123796	111	EXECUTED	9:3f332e13e90739ed0c35b0b25b7822ca	addColumn tableName=CLIENT_ATTRIBUTES; update tableName=CLIENT_ATTRIBUTES; dropColumn columnName=VALUE, tableName=CLIENT_ATTRIBUTES; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	3384726038
21.0.2-17277	keycloak	META-INF/jpa-changelog-21.0.2.xml	2026-07-07 00:38:52.212219	112	EXECUTED	9:7ee1f7a3fb8f5588f171fb9a6ab623c0	customChange		\N	4.29.1	\N	\N	3384726038
21.1.0-19404	keycloak	META-INF/jpa-changelog-21.1.0.xml	2026-07-07 00:38:52.217574	113	EXECUTED	9:3d7e830b52f33676b9d64f7f2b2ea634	modifyDataType columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=LOGIC, tableName=RESOURCE_SERVER_POLICY; modifyDataType columnName=POLICY_ENFORCE_MODE, tableName=RESOURCE_SERVER		\N	4.29.1	\N	\N	3384726038
21.1.0-19404-2	keycloak	META-INF/jpa-changelog-21.1.0.xml	2026-07-07 00:38:52.219079	114	MARK_RAN	9:627d032e3ef2c06c0e1f73d2ae25c26c	addColumn tableName=RESOURCE_SERVER_POLICY; update tableName=RESOURCE_SERVER_POLICY; dropColumn columnName=DECISION_STRATEGY, tableName=RESOURCE_SERVER_POLICY; renameColumn newColumnName=DECISION_STRATEGY, oldColumnName=DECISION_STRATEGY_NEW, tabl...		\N	4.29.1	\N	\N	3384726038
22.0.0-17484-updated	keycloak	META-INF/jpa-changelog-22.0.0.xml	2026-07-07 00:38:52.221656	115	EXECUTED	9:90af0bfd30cafc17b9f4d6eccd92b8b3	customChange		\N	4.29.1	\N	\N	3384726038
22.0.5-24031	keycloak	META-INF/jpa-changelog-22.0.0.xml	2026-07-07 00:38:52.222211	116	MARK_RAN	9:a60d2d7b315ec2d3eba9e2f145f9df28	customChange		\N	4.29.1	\N	\N	3384726038
23.0.0-12062	keycloak	META-INF/jpa-changelog-23.0.0.xml	2026-07-07 00:38:52.225131	117	EXECUTED	9:2168fbe728fec46ae9baf15bf80927b8	addColumn tableName=COMPONENT_CONFIG; update tableName=COMPONENT_CONFIG; dropColumn columnName=VALUE, tableName=COMPONENT_CONFIG; renameColumn newColumnName=VALUE, oldColumnName=VALUE_NEW, tableName=COMPONENT_CONFIG		\N	4.29.1	\N	\N	3384726038
23.0.0-17258	keycloak	META-INF/jpa-changelog-23.0.0.xml	2026-07-07 00:38:52.226868	118	EXECUTED	9:36506d679a83bbfda85a27ea1864dca8	addColumn tableName=EVENT_ENTITY		\N	4.29.1	\N	\N	3384726038
24.0.0-9758	keycloak	META-INF/jpa-changelog-24.0.0.xml	2026-07-07 00:38:52.620425	119	EXECUTED	9:502c557a5189f600f0f445a9b49ebbce	addColumn tableName=USER_ATTRIBUTE; addColumn tableName=FED_USER_ATTRIBUTE; createIndex indexName=USER_ATTR_LONG_VALUES, tableName=USER_ATTRIBUTE; createIndex indexName=FED_USER_ATTR_LONG_VALUES, tableName=FED_USER_ATTRIBUTE; createIndex indexName...		\N	4.29.1	\N	\N	3384726038
24.0.0-9758-2	keycloak	META-INF/jpa-changelog-24.0.0.xml	2026-07-07 00:38:52.622425	120	EXECUTED	9:bf0fdee10afdf597a987adbf291db7b2	customChange		\N	4.29.1	\N	\N	3384726038
24.0.0-26618-drop-index-if-present	keycloak	META-INF/jpa-changelog-24.0.0.xml	2026-07-07 00:38:52.624899	121	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	3384726038
24.0.0-26618-reindex	keycloak	META-INF/jpa-changelog-24.0.0.xml	2026-07-07 00:38:52.719924	122	EXECUTED	9:08707c0f0db1cef6b352db03a60edc7f	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	3384726038
24.0.2-27228	keycloak	META-INF/jpa-changelog-24.0.2.xml	2026-07-07 00:38:52.722126	123	EXECUTED	9:eaee11f6b8aa25d2cc6a84fb86fc6238	customChange		\N	4.29.1	\N	\N	3384726038
24.0.2-27967-drop-index-if-present	keycloak	META-INF/jpa-changelog-24.0.2.xml	2026-07-07 00:38:52.722739	124	MARK_RAN	9:04baaf56c116ed19951cbc2cca584022	dropIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	3384726038
24.0.2-27967-reindex	keycloak	META-INF/jpa-changelog-24.0.2.xml	2026-07-07 00:38:52.724015	125	MARK_RAN	9:d3d977031d431db16e2c181ce49d73e9	createIndex indexName=IDX_CLIENT_ATT_BY_NAME_VALUE, tableName=CLIENT_ATTRIBUTES		\N	4.29.1	\N	\N	3384726038
25.0.0-28265-tables	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-07-07 00:38:52.726518	126	EXECUTED	9:deda2df035df23388af95bbd36c17cef	addColumn tableName=OFFLINE_USER_SESSION; addColumn tableName=OFFLINE_CLIENT_SESSION		\N	4.29.1	\N	\N	3384726038
25.0.0-28265-index-creation	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-07-07 00:38:52.827292	127	EXECUTED	9:3e96709818458ae49f3c679ae58d263a	createIndex indexName=IDX_OFFLINE_USS_BY_LAST_SESSION_REFRESH, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	3384726038
25.0.0-28265-index-cleanup-uss-createdon	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-07-07 00:38:53.014405	128	EXECUTED	9:78ab4fc129ed5e8265dbcc3485fba92f	dropIndex indexName=IDX_OFFLINE_USS_CREATEDON, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	3384726038
25.0.0-28265-index-cleanup-uss-preload	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-07-07 00:38:53.116643	129	EXECUTED	9:de5f7c1f7e10994ed8b62e621d20eaab	dropIndex indexName=IDX_OFFLINE_USS_PRELOAD, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	3384726038
25.0.0-28265-index-cleanup-uss-by-usersess	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-07-07 00:38:53.21557	130	EXECUTED	9:6eee220d024e38e89c799417ec33667f	dropIndex indexName=IDX_OFFLINE_USS_BY_USERSESS, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	3384726038
25.0.0-28265-index-cleanup-css-preload	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-07-07 00:38:53.318488	131	EXECUTED	9:5411d2fb2891d3e8d63ddb55dfa3c0c9	dropIndex indexName=IDX_OFFLINE_CSS_PRELOAD, tableName=OFFLINE_CLIENT_SESSION		\N	4.29.1	\N	\N	3384726038
25.0.0-28265-index-2-mysql	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-07-07 00:38:53.3195	132	MARK_RAN	9:b7ef76036d3126bb83c2423bf4d449d6	createIndex indexName=IDX_OFFLINE_USS_BY_BROKER_SESSION_ID, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	3384726038
25.0.0-28265-index-2-not-mysql	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-07-07 00:38:53.429998	133	EXECUTED	9:23396cf51ab8bc1ae6f0cac7f9f6fcf7	createIndex indexName=IDX_OFFLINE_USS_BY_BROKER_SESSION_ID, tableName=OFFLINE_USER_SESSION		\N	4.29.1	\N	\N	3384726038
25.0.0-org	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-07-07 00:38:53.435415	134	EXECUTED	9:5c859965c2c9b9c72136c360649af157	createTable tableName=ORG; addUniqueConstraint constraintName=UK_ORG_NAME, tableName=ORG; addUniqueConstraint constraintName=UK_ORG_GROUP, tableName=ORG; createTable tableName=ORG_DOMAIN		\N	4.29.1	\N	\N	3384726038
unique-consentuser	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-07-07 00:38:53.514159	135	EXECUTED	9:5857626a2ea8767e9a6c66bf3a2cb32f	customChange; dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_LOCAL_CONSENT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_EXTERNAL_CONSENT, tableName=...		\N	4.29.1	\N	\N	3384726038
unique-consentuser-mysql	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-07-07 00:38:53.51495	136	MARK_RAN	9:b79478aad5adaa1bc428e31563f55e8e	customChange; dropUniqueConstraint constraintName=UK_JKUWUVD56ONTGSUHOGM8UEWRT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_LOCAL_CONSENT, tableName=USER_CONSENT; addUniqueConstraint constraintName=UK_EXTERNAL_CONSENT, tableName=...		\N	4.29.1	\N	\N	3384726038
25.0.0-28861-index-creation	keycloak	META-INF/jpa-changelog-25.0.0.xml	2026-07-07 00:38:53.712709	137	EXECUTED	9:b9acb58ac958d9ada0fe12a5d4794ab1	createIndex indexName=IDX_PERM_TICKET_REQUESTER, tableName=RESOURCE_SERVER_PERM_TICKET; createIndex indexName=IDX_PERM_TICKET_OWNER, tableName=RESOURCE_SERVER_PERM_TICKET		\N	4.29.1	\N	\N	3384726038
26.0.0-org-alias	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-07-07 00:38:53.716594	138	EXECUTED	9:6ef7d63e4412b3c2d66ed179159886a4	addColumn tableName=ORG; update tableName=ORG; addNotNullConstraint columnName=ALIAS, tableName=ORG; addUniqueConstraint constraintName=UK_ORG_ALIAS, tableName=ORG		\N	4.29.1	\N	\N	3384726038
26.0.0-org-group	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-07-07 00:38:53.719844	139	EXECUTED	9:da8e8087d80ef2ace4f89d8c5b9ca223	addColumn tableName=KEYCLOAK_GROUP; update tableName=KEYCLOAK_GROUP; addNotNullConstraint columnName=TYPE, tableName=KEYCLOAK_GROUP; customChange		\N	4.29.1	\N	\N	3384726038
26.0.0-org-indexes	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-07-07 00:38:53.820614	140	EXECUTED	9:79b05dcd610a8c7f25ec05135eec0857	createIndex indexName=IDX_ORG_DOMAIN_ORG_ID, tableName=ORG_DOMAIN		\N	4.29.1	\N	\N	3384726038
26.0.0-org-group-membership	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-07-07 00:38:53.822984	141	EXECUTED	9:a6ace2ce583a421d89b01ba2a28dc2d4	addColumn tableName=USER_GROUP_MEMBERSHIP; update tableName=USER_GROUP_MEMBERSHIP; addNotNullConstraint columnName=MEMBERSHIP_TYPE, tableName=USER_GROUP_MEMBERSHIP		\N	4.29.1	\N	\N	3384726038
31296-persist-revoked-access-tokens	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-07-07 00:38:53.825276	142	EXECUTED	9:64ef94489d42a358e8304b0e245f0ed4	createTable tableName=REVOKED_TOKEN; addPrimaryKey constraintName=CONSTRAINT_RT, tableName=REVOKED_TOKEN		\N	4.29.1	\N	\N	3384726038
31725-index-persist-revoked-access-tokens	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-07-07 00:38:53.929229	143	EXECUTED	9:b994246ec2bf7c94da881e1d28782c7b	createIndex indexName=IDX_REV_TOKEN_ON_EXPIRE, tableName=REVOKED_TOKEN		\N	4.29.1	\N	\N	3384726038
26.0.0-idps-for-login	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-07-07 00:38:54.130426	144	EXECUTED	9:51f5fffadf986983d4bd59582c6c1604	addColumn tableName=IDENTITY_PROVIDER; createIndex indexName=IDX_IDP_REALM_ORG, tableName=IDENTITY_PROVIDER; createIndex indexName=IDX_IDP_FOR_LOGIN, tableName=IDENTITY_PROVIDER; customChange		\N	4.29.1	\N	\N	3384726038
26.0.0-32583-drop-redundant-index-on-client-session	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-07-07 00:38:54.223819	145	EXECUTED	9:24972d83bf27317a055d234187bb4af9	dropIndex indexName=IDX_US_SESS_ID_ON_CL_SESS, tableName=OFFLINE_CLIENT_SESSION		\N	4.29.1	\N	\N	3384726038
26.0.0.32582-remove-tables-user-session-user-session-note-and-client-session	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-07-07 00:38:54.316233	146	EXECUTED	9:febdc0f47f2ed241c59e60f58c3ceea5	dropTable tableName=CLIENT_SESSION_ROLE; dropTable tableName=CLIENT_SESSION_NOTE; dropTable tableName=CLIENT_SESSION_PROT_MAPPER; dropTable tableName=CLIENT_SESSION_AUTH_STATUS; dropTable tableName=CLIENT_USER_SESSION_NOTE; dropTable tableName=CLI...		\N	4.29.1	\N	\N	3384726038
26.0.0-33201-org-redirect-url	keycloak	META-INF/jpa-changelog-26.0.0.xml	2026-07-07 00:38:54.31859	147	EXECUTED	9:4d0e22b0ac68ebe9794fa9cb752ea660	addColumn tableName=ORG		\N	4.29.1	\N	\N	3384726038
26.0.6-34013	keycloak	META-INF/jpa-changelog-26.0.6.xml	2026-07-07 00:38:54.324254	148	EXECUTED	9:e6b686a15759aef99a6d758a5c4c6a26	addColumn tableName=ADMIN_EVENT_ENTITY		\N	4.29.1	\N	\N	3384726038
\.


--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
1	f	\N	\N
1000	f	\N	\N
\.


--
-- Data for Name: default_client_scope; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.default_client_scope (realm_id, scope_id, default_scope) FROM stdin;
29bb8813-da75-41e0-b440-8ab491e3ec8a	44b67136-7503-4a50-8032-654238f1597e	f
29bb8813-da75-41e0-b440-8ab491e3ec8a	c77e4009-b62f-4686-911d-9074d5a908eb	t
29bb8813-da75-41e0-b440-8ab491e3ec8a	047b7ff2-a372-4226-a419-614a93042ca7	t
29bb8813-da75-41e0-b440-8ab491e3ec8a	15f84608-cfee-4646-8bd3-0790ce935bb3	t
29bb8813-da75-41e0-b440-8ab491e3ec8a	d07f80b4-9492-4626-9ba4-6546c97024d5	t
29bb8813-da75-41e0-b440-8ab491e3ec8a	37847a84-3ab5-43da-9fcc-0ac309abbc86	f
29bb8813-da75-41e0-b440-8ab491e3ec8a	edbd3382-c73e-407b-ad90-4a80a863a3dd	f
29bb8813-da75-41e0-b440-8ab491e3ec8a	609d4ae5-bf8a-48e2-b2a9-d81b42096dfd	t
29bb8813-da75-41e0-b440-8ab491e3ec8a	148b4ece-21c1-49ec-89ea-b9137b5500f8	t
29bb8813-da75-41e0-b440-8ab491e3ec8a	acc3bdbb-18a3-4cf5-8ea2-0264f7c5fa36	f
29bb8813-da75-41e0-b440-8ab491e3ec8a	d3e92e3f-8e46-4b7d-9c8e-38d7281a1928	t
29bb8813-da75-41e0-b440-8ab491e3ec8a	055dd76c-fd10-4e37-8c97-947d04648d0b	t
29bb8813-da75-41e0-b440-8ab491e3ec8a	030d798b-c28b-481f-929a-3ec2c6e92e8d	f
29105d11-1bed-40a5-9927-60d87c4deff3	fe5a66e2-8ad9-4c9f-b17c-13ddb93d328f	f
29105d11-1bed-40a5-9927-60d87c4deff3	b04f828c-43f0-4aa6-a6ec-e7e2e0f0578d	t
29105d11-1bed-40a5-9927-60d87c4deff3	dd0215c5-7711-47b3-801c-2226122f3bc7	t
29105d11-1bed-40a5-9927-60d87c4deff3	bc0416cc-4e82-4346-85fa-1d4fe837ecf2	t
29105d11-1bed-40a5-9927-60d87c4deff3	c796e839-148a-4f01-ba5c-2e38fbf1eeb6	t
29105d11-1bed-40a5-9927-60d87c4deff3	4dd3b68c-89e1-4748-9a1d-bfc573a54bee	f
29105d11-1bed-40a5-9927-60d87c4deff3	f7b2f01c-d622-435c-8bc8-33a21311e25b	f
29105d11-1bed-40a5-9927-60d87c4deff3	5a0bd71b-5a3c-4cd8-a0da-81f64dc46ebe	t
29105d11-1bed-40a5-9927-60d87c4deff3	905f36f2-5b46-4f08-8d1d-ff48fd0abc87	t
29105d11-1bed-40a5-9927-60d87c4deff3	3e92e7c3-ca3a-4b28-a741-da0850a79426	f
29105d11-1bed-40a5-9927-60d87c4deff3	c99d871b-9dfe-4e84-81bc-eb0759ef065e	t
29105d11-1bed-40a5-9927-60d87c4deff3	291c177f-c12f-4341-be6a-7fa3d2faabb4	t
29105d11-1bed-40a5-9927-60d87c4deff3	c26deb71-24b8-4715-be45-3baa4c818026	f
\.


--
-- Data for Name: event_entity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event_entity (id, client_id, details_json, error, ip_address, realm_id, session_id, event_time, type, user_id, details_json_long_value) FROM stdin;
\.


--
-- Data for Name: fed_user_attribute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fed_user_attribute (id, name, user_id, realm_id, storage_provider_id, value, long_value_hash, long_value_hash_lower_case, long_value) FROM stdin;
\.


--
-- Data for Name: fed_user_consent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fed_user_consent (id, client_id, user_id, realm_id, storage_provider_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: fed_user_consent_cl_scope; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fed_user_consent_cl_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: fed_user_credential; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fed_user_credential (id, salt, type, created_date, user_id, realm_id, storage_provider_id, user_label, secret_data, credential_data, priority) FROM stdin;
\.


--
-- Data for Name: fed_user_group_membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fed_user_group_membership (group_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_required_action; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fed_user_required_action (required_action, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: fed_user_role_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fed_user_role_mapping (role_id, user_id, realm_id, storage_provider_id) FROM stdin;
\.


--
-- Data for Name: federated_identity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.federated_identity (identity_provider, realm_id, federated_user_id, federated_username, token, user_id) FROM stdin;
\.


--
-- Data for Name: federated_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.federated_user (id, storage_provider_id, realm_id) FROM stdin;
\.


--
-- Data for Name: group_attribute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.group_attribute (id, name, value, group_id) FROM stdin;
\.


--
-- Data for Name: group_role_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.group_role_mapping (role_id, group_id) FROM stdin;
\.


--
-- Data for Name: identity_provider; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.identity_provider (internal_id, enabled, provider_alias, provider_id, store_token, authenticate_by_default, realm_id, add_token_role, trust_email, first_broker_login_flow_id, post_broker_login_flow_id, provider_display_name, link_only, organization_id, hide_on_login) FROM stdin;
\.


--
-- Data for Name: identity_provider_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.identity_provider_config (identity_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: identity_provider_mapper; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.identity_provider_mapper (id, name, idp_alias, idp_mapper_name, realm_id) FROM stdin;
\.


--
-- Data for Name: idp_mapper_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.idp_mapper_config (idp_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: keycloak_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.keycloak_group (id, name, parent_group, realm_id, type) FROM stdin;
\.


--
-- Data for Name: keycloak_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.keycloak_role (id, client_realm_constraint, client_role, description, name, realm_id, client, realm) FROM stdin;
bfb26ed5-54a0-4f24-8a6a-9c7402b830a7	29bb8813-da75-41e0-b440-8ab491e3ec8a	f	${role_default-roles}	default-roles-master	29bb8813-da75-41e0-b440-8ab491e3ec8a	\N	\N
54d75e83-bbab-4e17-bd53-dd86138a07cb	29bb8813-da75-41e0-b440-8ab491e3ec8a	f	${role_admin}	admin	29bb8813-da75-41e0-b440-8ab491e3ec8a	\N	\N
817d7506-f76e-4202-951f-4741ad2d9262	29bb8813-da75-41e0-b440-8ab491e3ec8a	f	${role_create-realm}	create-realm	29bb8813-da75-41e0-b440-8ab491e3ec8a	\N	\N
6bf33d56-52c7-4c82-90b2-dd14f3f9b4bc	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_create-client}	create-client	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
e83a3d8a-5392-4ef6-a592-139c62e8bda7	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_view-realm}	view-realm	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
a0c351be-4685-44d7-b172-552c85d8a4ea	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_view-users}	view-users	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
c198a99d-fc05-4d6b-bff9-f039a0be0714	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_view-clients}	view-clients	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
8bcbde4f-35c6-4606-98b4-b7aedb161048	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_view-events}	view-events	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
73f22d19-8452-49fb-9c70-062246ba3ef2	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_view-identity-providers}	view-identity-providers	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
f61b739f-46dd-4279-b2eb-2404e5c64c0c	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_view-authorization}	view-authorization	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
b148002c-8efb-4127-acdb-ff0c180aaa89	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_manage-realm}	manage-realm	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
e53a7e81-3e03-4a7d-b717-ed3304e164f7	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_manage-users}	manage-users	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
0ad3d05a-6593-46ff-9b4e-c61cfa897277	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_manage-clients}	manage-clients	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
5bfc0a5a-ae71-4834-9b47-fc347fd991c2	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_manage-events}	manage-events	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
4bf2a8cd-9868-40f6-9ae2-90db0a14ea6b	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_manage-identity-providers}	manage-identity-providers	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
7b07d3ed-8641-4e3c-af1a-93cd691a577d	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_manage-authorization}	manage-authorization	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
8265f4cb-e7f0-4d16-91f3-d0050e65b48a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_query-users}	query-users	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
e34c35aa-168b-4876-808a-63e093b81eec	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_query-clients}	query-clients	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
4e683c6b-0173-4d12-9fa0-9c23bdd5e7c3	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_query-realms}	query-realms	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
2964435c-6cfa-4b87-b189-b02f97af681b	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_query-groups}	query-groups	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
f9a7385d-8061-442d-a816-a41257a1a137	d6fae655-39e6-4ff5-b705-e23facd2ef68	t	${role_view-profile}	view-profile	29bb8813-da75-41e0-b440-8ab491e3ec8a	d6fae655-39e6-4ff5-b705-e23facd2ef68	\N
cf252c9e-b3ca-4ac4-973f-abe83d70c192	d6fae655-39e6-4ff5-b705-e23facd2ef68	t	${role_manage-account}	manage-account	29bb8813-da75-41e0-b440-8ab491e3ec8a	d6fae655-39e6-4ff5-b705-e23facd2ef68	\N
f4982fca-525a-4ca8-947f-e83989ffe7ff	d6fae655-39e6-4ff5-b705-e23facd2ef68	t	${role_manage-account-links}	manage-account-links	29bb8813-da75-41e0-b440-8ab491e3ec8a	d6fae655-39e6-4ff5-b705-e23facd2ef68	\N
074ebfd0-c006-4060-8bfb-c97d144b4d69	d6fae655-39e6-4ff5-b705-e23facd2ef68	t	${role_view-applications}	view-applications	29bb8813-da75-41e0-b440-8ab491e3ec8a	d6fae655-39e6-4ff5-b705-e23facd2ef68	\N
65f458d0-0054-459e-98b7-7eef2c119f28	d6fae655-39e6-4ff5-b705-e23facd2ef68	t	${role_view-consent}	view-consent	29bb8813-da75-41e0-b440-8ab491e3ec8a	d6fae655-39e6-4ff5-b705-e23facd2ef68	\N
a6760797-1e18-470a-bd34-7f478b63f9f1	d6fae655-39e6-4ff5-b705-e23facd2ef68	t	${role_manage-consent}	manage-consent	29bb8813-da75-41e0-b440-8ab491e3ec8a	d6fae655-39e6-4ff5-b705-e23facd2ef68	\N
cd8c1091-70ba-4947-b59a-8e57dc283b36	d6fae655-39e6-4ff5-b705-e23facd2ef68	t	${role_view-groups}	view-groups	29bb8813-da75-41e0-b440-8ab491e3ec8a	d6fae655-39e6-4ff5-b705-e23facd2ef68	\N
6b02b103-8f2a-43db-bc5e-2ce6b918eba0	d6fae655-39e6-4ff5-b705-e23facd2ef68	t	${role_delete-account}	delete-account	29bb8813-da75-41e0-b440-8ab491e3ec8a	d6fae655-39e6-4ff5-b705-e23facd2ef68	\N
b5bff3ea-9d5c-4deb-b3e2-2d8bab1f5e4f	58d2d4eb-cf03-4960-9972-cfbc1e823c5f	t	${role_read-token}	read-token	29bb8813-da75-41e0-b440-8ab491e3ec8a	58d2d4eb-cf03-4960-9972-cfbc1e823c5f	\N
191233e9-5cc2-4d87-baee-5615fd674329	0c385d9c-72ee-44a8-a993-aa8fc3317a70	t	${role_impersonation}	impersonation	29bb8813-da75-41e0-b440-8ab491e3ec8a	0c385d9c-72ee-44a8-a993-aa8fc3317a70	\N
1c0b5c7d-bfb4-4eb5-bd0f-16b4c4fa8d35	29bb8813-da75-41e0-b440-8ab491e3ec8a	f	${role_offline-access}	offline_access	29bb8813-da75-41e0-b440-8ab491e3ec8a	\N	\N
de3339e9-03a4-4696-87d9-e42a3313a1d6	29bb8813-da75-41e0-b440-8ab491e3ec8a	f	${role_uma_authorization}	uma_authorization	29bb8813-da75-41e0-b440-8ab491e3ec8a	\N	\N
bd09041d-0741-445f-9d89-b73a04dcb1f7	29105d11-1bed-40a5-9927-60d87c4deff3	f	${role_default-roles}	default-roles-agentshield	29105d11-1bed-40a5-9927-60d87c4deff3	\N	\N
222e2432-5659-40de-995f-9c0550e5a2d8	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_create-client}	create-client	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
b9632cc9-f602-4733-b3f8-083c0c0fd915	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_view-realm}	view-realm	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
3c3ac68b-2468-4d77-9cab-18dbd6dd1009	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_view-users}	view-users	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
ef9fbc05-8727-46ed-bfae-673c95a8cd77	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_view-clients}	view-clients	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
6c6e053f-0a59-4f98-9389-f55885499569	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_view-events}	view-events	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
10d8379b-25bd-418a-b7d4-29ad3a240686	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_view-identity-providers}	view-identity-providers	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
0251b6d7-85e6-4a73-8334-07d98f09a189	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_view-authorization}	view-authorization	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
613c574f-a7ca-4388-97d8-50794494f162	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_manage-realm}	manage-realm	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
b9ff9490-dd0d-4395-b5e0-e36f09975a65	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_manage-users}	manage-users	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
8709b40d-fc99-4675-bcd8-b1c68a5823ff	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_manage-clients}	manage-clients	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
f10d1ab4-3ad0-4d92-8c1d-ec7a22ae56f8	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_manage-events}	manage-events	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
59889728-5328-4806-ba2a-3f7debf710e9	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_manage-identity-providers}	manage-identity-providers	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
ebb09c94-2a3b-420f-9b6d-5eda643fcbc3	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_manage-authorization}	manage-authorization	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
c72a00e7-c357-4fb6-be34-0ad38fa7df97	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_query-users}	query-users	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
d30da5b4-870b-4c0c-aab1-cb0d8c9721fd	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_query-clients}	query-clients	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
faf9a9a6-7f9e-4cac-94d8-f11e82758ad2	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_query-realms}	query-realms	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
0ef4014d-c0f5-4865-bd43-6f2deb8bc6fc	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_query-groups}	query-groups	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
4b04ac3d-76a9-41b3-9e9d-fd7e8319840e	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_realm-admin}	realm-admin	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
7cfc0eaa-b340-4db4-8459-9dd9dae94344	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_create-client}	create-client	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
5d67bc96-e989-4782-8cb1-a052d011b1e4	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_view-realm}	view-realm	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
e65d6f22-b554-4cb6-9e95-35a9e04285d5	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_view-users}	view-users	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
4259de44-f644-4d7b-869c-58b78d9eea71	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_view-clients}	view-clients	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
5af6afc9-9e47-49da-89d0-2fcdb8fa7a68	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_view-events}	view-events	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
9654281d-737f-4f75-8d87-16d51f8d2904	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_view-identity-providers}	view-identity-providers	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
8ecd70e1-52aa-4109-b8c6-abd7165c3a90	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_view-authorization}	view-authorization	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
938db672-1e25-4307-adca-10b656f6ac1d	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_manage-realm}	manage-realm	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
64213e77-129b-4e99-a383-79c06c9b5ad4	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_manage-users}	manage-users	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
e6c32325-c2dd-46cf-b44e-b54d79695dfe	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_manage-clients}	manage-clients	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
f155572c-2a99-4917-a499-6117c846d99b	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_manage-events}	manage-events	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
c9e0249b-1ae5-48a3-b7b9-d9548a7d35bf	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_manage-identity-providers}	manage-identity-providers	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
6f17e2db-2115-496d-9b86-f235c58e9edd	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_manage-authorization}	manage-authorization	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
179a97e3-9070-4136-94be-ca3be76098e3	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_query-users}	query-users	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
01d9bf7b-fb66-48fe-9af4-0486e962e4bd	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_query-clients}	query-clients	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
403cea89-1aad-45ed-8629-2dff2549fa26	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_query-realms}	query-realms	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
67f58a8e-be92-4087-808a-ee9308bdaedd	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_query-groups}	query-groups	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
d22cf518-769b-450e-bc9c-6cf4f7748db8	121642cc-8d33-4fbc-b80d-39f4e1f8b22c	t	${role_view-profile}	view-profile	29105d11-1bed-40a5-9927-60d87c4deff3	121642cc-8d33-4fbc-b80d-39f4e1f8b22c	\N
e2d67d67-d4a9-4b08-bc1c-8fc06bbc4217	121642cc-8d33-4fbc-b80d-39f4e1f8b22c	t	${role_manage-account}	manage-account	29105d11-1bed-40a5-9927-60d87c4deff3	121642cc-8d33-4fbc-b80d-39f4e1f8b22c	\N
5611a172-ebd3-42c2-8f48-33c5f9f3292e	121642cc-8d33-4fbc-b80d-39f4e1f8b22c	t	${role_manage-account-links}	manage-account-links	29105d11-1bed-40a5-9927-60d87c4deff3	121642cc-8d33-4fbc-b80d-39f4e1f8b22c	\N
9d47bcac-913d-4adf-96ae-340f9bf88786	121642cc-8d33-4fbc-b80d-39f4e1f8b22c	t	${role_view-applications}	view-applications	29105d11-1bed-40a5-9927-60d87c4deff3	121642cc-8d33-4fbc-b80d-39f4e1f8b22c	\N
c782fcc6-8aa3-4a24-bd32-9d886849de2e	121642cc-8d33-4fbc-b80d-39f4e1f8b22c	t	${role_view-consent}	view-consent	29105d11-1bed-40a5-9927-60d87c4deff3	121642cc-8d33-4fbc-b80d-39f4e1f8b22c	\N
4c27cc8e-dffc-47f0-b24b-df3210e11eac	121642cc-8d33-4fbc-b80d-39f4e1f8b22c	t	${role_manage-consent}	manage-consent	29105d11-1bed-40a5-9927-60d87c4deff3	121642cc-8d33-4fbc-b80d-39f4e1f8b22c	\N
85d650c3-5138-46b7-8e9d-00ad35d686dd	121642cc-8d33-4fbc-b80d-39f4e1f8b22c	t	${role_view-groups}	view-groups	29105d11-1bed-40a5-9927-60d87c4deff3	121642cc-8d33-4fbc-b80d-39f4e1f8b22c	\N
c6563e50-5ce9-49cd-97f6-7e3149859f1c	121642cc-8d33-4fbc-b80d-39f4e1f8b22c	t	${role_delete-account}	delete-account	29105d11-1bed-40a5-9927-60d87c4deff3	121642cc-8d33-4fbc-b80d-39f4e1f8b22c	\N
7c1cfe30-15c8-4af4-9c4f-eb738eef7579	da88d06b-e956-42e8-a610-ba048d70e217	t	${role_impersonation}	impersonation	29bb8813-da75-41e0-b440-8ab491e3ec8a	da88d06b-e956-42e8-a610-ba048d70e217	\N
9e9d8ec4-ccb0-4f59-8996-b834b9fb5118	012c8e1e-7ab8-47be-bb58-34d958059506	t	${role_impersonation}	impersonation	29105d11-1bed-40a5-9927-60d87c4deff3	012c8e1e-7ab8-47be-bb58-34d958059506	\N
8ecbd377-ea6f-4b93-9179-e84f2d8ef72d	29032148-f6b3-467c-bfea-bad134dfcf6d	t	${role_read-token}	read-token	29105d11-1bed-40a5-9927-60d87c4deff3	29032148-f6b3-467c-bfea-bad134dfcf6d	\N
c597fc37-a767-412a-ac88-bbeba571cdb4	29105d11-1bed-40a5-9927-60d87c4deff3	f	${role_offline-access}	offline_access	29105d11-1bed-40a5-9927-60d87c4deff3	\N	\N
ba9a9162-3ea3-41f2-996c-033b64512b2c	29105d11-1bed-40a5-9927-60d87c4deff3	f	${role_uma_authorization}	uma_authorization	29105d11-1bed-40a5-9927-60d87c4deff3	\N	\N
\.


--
-- Data for Name: migration_model; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migration_model (id, version, update_time) FROM stdin;
xtfef	26.0.8	1783384734
\.


--
-- Data for Name: offline_client_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.offline_client_session (user_session_id, client_id, offline_flag, "timestamp", data, client_storage_provider, external_client_id, version) FROM stdin;
a824d33c-403f-4a7c-a708-0e1886c597f6	78fd174d-495c-4a9c-88ca-271608bc4f5f	0	1783390172	{"authMethod":"openid-connect","redirectUri":"http://localhost:5173/providers","notes":{"clientId":"78fd174d-495c-4a9c-88ca-271608bc4f5f","iss":"http://localhost:5173/realms/agentshield","startedAt":"1783386680","response_type":"code","level-of-authentication":"-1","code_challenge_method":"S256","nonce":"46f9b172-e870-440f-973c-a48c962f6c73","response_mode":"fragment","scope":"openid","userSessionStartedAt":"1783386680","redirect_uri":"http://localhost:5173/providers","state":"1e90c4c7-2dad-480b-b87a-480dc0154b25","code_challenge":"UiLPU0mD4xDjMRkhzsamz8RvWSCeMHC1ob5Fo5aEY9w","SSO_AUTH":"true"}}	local	local	13
\.


--
-- Data for Name: offline_user_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.offline_user_session (user_session_id, user_id, realm_id, created_on, offline_flag, data, last_session_refresh, broker_session_id, version) FROM stdin;
a824d33c-403f-4a7c-a708-0e1886c597f6	643b0e62-b437-40f8-8104-57c34203624b	29105d11-1bed-40a5-9927-60d87c4deff3	1783386680	0	{"ipAddress":"10.244.1.8","authMethod":"openid-connect","rememberMe":false,"started":0,"notes":{"KC_DEVICE_NOTE":"eyJpcEFkZHJlc3MiOiIxMC4yNDQuMS44Iiwib3MiOiJNYWMgT1MgWCIsIm9zVmVyc2lvbiI6IjEwLjE1LjciLCJicm93c2VyIjoiQ2hyb21lLzE1MC4wLjAiLCJkZXZpY2UiOiJNYWMiLCJsYXN0QWNjZXNzIjowLCJtb2JpbGUiOmZhbHNlfQ==","AUTH_TIME":"1783386680","authenticators-completed":"{\\"994230f6-3bf8-488b-92e2-ded0e0f5bf83\\":1783386672,\\"54ef8cf4-9017-4231-8d7d-c4cb760d2a69\\":1783387764}"},"state":"LOGGED_IN"}	1783390172	\N	13
\.


--
-- Data for Name: org; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.org (id, enabled, realm_id, group_id, name, description, alias, redirect_url) FROM stdin;
\.


--
-- Data for Name: org_domain; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.org_domain (id, name, verified, org_id) FROM stdin;
\.


--
-- Data for Name: policy_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.policy_config (policy_id, name, value) FROM stdin;
\.


--
-- Data for Name: protocol_mapper; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.protocol_mapper (id, name, protocol, protocol_mapper_name, client_id, client_scope_id) FROM stdin;
aa716809-6c4f-4ff8-a7c7-02b316173e1b	audience resolve	openid-connect	oidc-audience-resolve-mapper	3178bb2f-9cbe-425d-a613-e8ffea66389e	\N
b9e7a49b-b032-4597-9a04-cef4e49476f9	locale	openid-connect	oidc-usermodel-attribute-mapper	39a33722-8fc5-45a0-b730-61e79cde444e	\N
ebe8b0bc-57c8-4a8d-ad8b-58af524ec1b9	role list	saml	saml-role-list-mapper	\N	c77e4009-b62f-4686-911d-9074d5a908eb
b4d28b09-9c25-46e8-95a3-2669c527c811	organization	saml	saml-organization-membership-mapper	\N	047b7ff2-a372-4226-a419-614a93042ca7
a8875d84-2ac3-4374-95b2-d52024cbef82	full name	openid-connect	oidc-full-name-mapper	\N	15f84608-cfee-4646-8bd3-0790ce935bb3
06fa46dc-2ba3-4d0b-ac2a-205b4a97f576	family name	openid-connect	oidc-usermodel-attribute-mapper	\N	15f84608-cfee-4646-8bd3-0790ce935bb3
9a5cf12c-2cac-4893-bebd-6f67b506bf9f	given name	openid-connect	oidc-usermodel-attribute-mapper	\N	15f84608-cfee-4646-8bd3-0790ce935bb3
52611912-28ab-422b-8bd2-e879a9aa61cb	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	15f84608-cfee-4646-8bd3-0790ce935bb3
b08fd8e5-c5fa-4c6e-aa06-a800b9ddc3be	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	15f84608-cfee-4646-8bd3-0790ce935bb3
4d5fba88-957f-4218-8589-5c969013f738	username	openid-connect	oidc-usermodel-attribute-mapper	\N	15f84608-cfee-4646-8bd3-0790ce935bb3
b5a3f7fd-fb51-47ff-8dc1-0c3c69440d6f	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	15f84608-cfee-4646-8bd3-0790ce935bb3
ec208160-87db-4ccd-b89b-5e39c11d0be6	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	15f84608-cfee-4646-8bd3-0790ce935bb3
c0416085-3202-42d2-9c5e-5418e14f1198	website	openid-connect	oidc-usermodel-attribute-mapper	\N	15f84608-cfee-4646-8bd3-0790ce935bb3
c70e9306-ad0b-49eb-b7fe-f2736cd3ea88	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	15f84608-cfee-4646-8bd3-0790ce935bb3
ddd22944-9e8a-463b-98de-541c3a07c489	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	15f84608-cfee-4646-8bd3-0790ce935bb3
18a3083e-abee-45d6-a20e-6d9b988d3ef9	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	15f84608-cfee-4646-8bd3-0790ce935bb3
b0a0911e-1fde-434d-9055-1b3d37114797	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	15f84608-cfee-4646-8bd3-0790ce935bb3
a9afc488-67dd-4f28-9bfa-3825a5e5a21b	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	15f84608-cfee-4646-8bd3-0790ce935bb3
3516706c-f92e-43ad-ae4a-e49e8be1abdb	email	openid-connect	oidc-usermodel-attribute-mapper	\N	d07f80b4-9492-4626-9ba4-6546c97024d5
b1b6c1dd-6d7c-4d34-937c-cb91dcf05799	email verified	openid-connect	oidc-usermodel-property-mapper	\N	d07f80b4-9492-4626-9ba4-6546c97024d5
49c95f8f-a54b-4b23-b0e6-cc3455b7e6a1	address	openid-connect	oidc-address-mapper	\N	37847a84-3ab5-43da-9fcc-0ac309abbc86
91a9bbb2-8cea-4fa5-8843-287d70147149	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	edbd3382-c73e-407b-ad90-4a80a863a3dd
1cd68426-2393-4899-a2e2-cfa3cd5306c9	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	edbd3382-c73e-407b-ad90-4a80a863a3dd
5cec3c48-b0c9-4eb2-89c5-e27dbba2a2a6	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	609d4ae5-bf8a-48e2-b2a9-d81b42096dfd
8b256136-f346-4ad4-b2f6-88788bd0b1bc	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	609d4ae5-bf8a-48e2-b2a9-d81b42096dfd
10e14578-2d1f-4f38-8151-5f85d4431da0	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	609d4ae5-bf8a-48e2-b2a9-d81b42096dfd
41873786-0eeb-4663-adbf-0b517b144fc3	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	148b4ece-21c1-49ec-89ea-b9137b5500f8
918488ee-9170-41f1-af8b-f264b38a48b2	upn	openid-connect	oidc-usermodel-attribute-mapper	\N	acc3bdbb-18a3-4cf5-8ea2-0264f7c5fa36
917dcfdb-38ea-49c8-b340-6a2b2736d85d	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	acc3bdbb-18a3-4cf5-8ea2-0264f7c5fa36
42401434-f1c8-43e9-99ce-d54e17037901	acr loa level	openid-connect	oidc-acr-mapper	\N	d3e92e3f-8e46-4b7d-9c8e-38d7281a1928
b238b53b-6d22-45be-8014-7942022fb08f	auth_time	openid-connect	oidc-usersessionmodel-note-mapper	\N	055dd76c-fd10-4e37-8c97-947d04648d0b
0c41153b-66c1-4c6a-9dbc-98e5313f9e0e	sub	openid-connect	oidc-sub-mapper	\N	055dd76c-fd10-4e37-8c97-947d04648d0b
645c4981-19c7-40bf-9326-64d53bb9aa1c	organization	openid-connect	oidc-organization-membership-mapper	\N	030d798b-c28b-481f-929a-3ec2c6e92e8d
3aa3893a-3798-46c3-a894-82c961e23d8c	audience resolve	openid-connect	oidc-audience-resolve-mapper	db01877c-dcdc-4373-8120-6e7b48e26bab	\N
1d7c47d7-8f38-4b6c-b6f7-a366976e7c7e	role list	saml	saml-role-list-mapper	\N	b04f828c-43f0-4aa6-a6ec-e7e2e0f0578d
b61633f3-5541-4be7-801e-0dff77fd0f49	organization	saml	saml-organization-membership-mapper	\N	dd0215c5-7711-47b3-801c-2226122f3bc7
0c68ee56-b85d-4ac1-a851-9721220a8aff	full name	openid-connect	oidc-full-name-mapper	\N	bc0416cc-4e82-4346-85fa-1d4fe837ecf2
21736b90-f4a5-45b0-b45a-7b122e92c365	family name	openid-connect	oidc-usermodel-attribute-mapper	\N	bc0416cc-4e82-4346-85fa-1d4fe837ecf2
bdcfbc6c-4a9e-41cd-be0e-7f3f8f2b0a78	given name	openid-connect	oidc-usermodel-attribute-mapper	\N	bc0416cc-4e82-4346-85fa-1d4fe837ecf2
689faee0-d64d-40e0-ac3d-1f6ac70c3a9a	middle name	openid-connect	oidc-usermodel-attribute-mapper	\N	bc0416cc-4e82-4346-85fa-1d4fe837ecf2
fc0b6a60-f19f-440c-a421-133fd5fd70f9	nickname	openid-connect	oidc-usermodel-attribute-mapper	\N	bc0416cc-4e82-4346-85fa-1d4fe837ecf2
5ae23742-d2c7-4cd3-8f14-99bd18d02b88	username	openid-connect	oidc-usermodel-attribute-mapper	\N	bc0416cc-4e82-4346-85fa-1d4fe837ecf2
49c58178-4841-409c-9902-cfdc9055926c	profile	openid-connect	oidc-usermodel-attribute-mapper	\N	bc0416cc-4e82-4346-85fa-1d4fe837ecf2
c28caa54-b00c-417b-a8e0-b4193dbe1f5f	picture	openid-connect	oidc-usermodel-attribute-mapper	\N	bc0416cc-4e82-4346-85fa-1d4fe837ecf2
def21bf2-4c98-4c58-8c90-418406c67ffc	website	openid-connect	oidc-usermodel-attribute-mapper	\N	bc0416cc-4e82-4346-85fa-1d4fe837ecf2
12750155-f463-4747-9a3e-2df98f29da71	gender	openid-connect	oidc-usermodel-attribute-mapper	\N	bc0416cc-4e82-4346-85fa-1d4fe837ecf2
3e4eb6f7-2d7f-4f93-b8e8-f7b186643ce6	birthdate	openid-connect	oidc-usermodel-attribute-mapper	\N	bc0416cc-4e82-4346-85fa-1d4fe837ecf2
bf551602-9605-412b-9d16-09e8d76a4932	zoneinfo	openid-connect	oidc-usermodel-attribute-mapper	\N	bc0416cc-4e82-4346-85fa-1d4fe837ecf2
5a9d27d9-135c-4226-bd78-ab6576e63396	locale	openid-connect	oidc-usermodel-attribute-mapper	\N	bc0416cc-4e82-4346-85fa-1d4fe837ecf2
cdb3fad6-9bc7-49be-81c9-f3b26343b6ad	updated at	openid-connect	oidc-usermodel-attribute-mapper	\N	bc0416cc-4e82-4346-85fa-1d4fe837ecf2
ac88e056-9bdd-48c3-b563-5c1ed6d79f47	email	openid-connect	oidc-usermodel-attribute-mapper	\N	c796e839-148a-4f01-ba5c-2e38fbf1eeb6
065bc919-2fe1-4027-954e-bf498e338b31	email verified	openid-connect	oidc-usermodel-property-mapper	\N	c796e839-148a-4f01-ba5c-2e38fbf1eeb6
3a7197e0-7da4-45b3-9164-1f5029921332	address	openid-connect	oidc-address-mapper	\N	4dd3b68c-89e1-4748-9a1d-bfc573a54bee
bab36fb7-ab6c-4156-92f6-42ffedbaef78	phone number	openid-connect	oidc-usermodel-attribute-mapper	\N	f7b2f01c-d622-435c-8bc8-33a21311e25b
69cef575-065e-4613-b5b4-4002117c1f21	phone number verified	openid-connect	oidc-usermodel-attribute-mapper	\N	f7b2f01c-d622-435c-8bc8-33a21311e25b
91c1cb39-26ea-4d48-9cd7-6c39da8aec54	realm roles	openid-connect	oidc-usermodel-realm-role-mapper	\N	5a0bd71b-5a3c-4cd8-a0da-81f64dc46ebe
9b4187e2-62ca-420f-a0c4-63aeb3fbc0b5	client roles	openid-connect	oidc-usermodel-client-role-mapper	\N	5a0bd71b-5a3c-4cd8-a0da-81f64dc46ebe
d6875042-0fdb-4f98-86b1-31ad843cd7d3	audience resolve	openid-connect	oidc-audience-resolve-mapper	\N	5a0bd71b-5a3c-4cd8-a0da-81f64dc46ebe
4f78308b-c334-432e-8471-5cee0ff3a120	allowed web origins	openid-connect	oidc-allowed-origins-mapper	\N	905f36f2-5b46-4f08-8d1d-ff48fd0abc87
29070550-b137-415e-af74-60362c066742	upn	openid-connect	oidc-usermodel-attribute-mapper	\N	3e92e7c3-ca3a-4b28-a741-da0850a79426
f999a491-b48e-4eaa-9e14-9516bc61f2a5	groups	openid-connect	oidc-usermodel-realm-role-mapper	\N	3e92e7c3-ca3a-4b28-a741-da0850a79426
8f662e05-788a-4634-ad24-b573298847e3	acr loa level	openid-connect	oidc-acr-mapper	\N	c99d871b-9dfe-4e84-81bc-eb0759ef065e
ee05a34a-243b-488f-af21-d706add1e709	auth_time	openid-connect	oidc-usersessionmodel-note-mapper	\N	291c177f-c12f-4341-be6a-7fa3d2faabb4
3620e8bd-2393-4430-b6b3-cfd8ab595234	sub	openid-connect	oidc-sub-mapper	\N	291c177f-c12f-4341-be6a-7fa3d2faabb4
a548fced-767b-4d01-a040-f8268d9add63	organization	openid-connect	oidc-organization-membership-mapper	\N	c26deb71-24b8-4715-be45-3baa4c818026
505e3a9b-281c-447e-8de7-712c60dd4e54	locale	openid-connect	oidc-usermodel-attribute-mapper	7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	\N
8e6d9897-b52b-4c10-9e22-5c8a5d004637	Client ID	openid-connect	oidc-usersessionmodel-note-mapper	bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	\N
8d3feec2-838e-4b96-88fb-7cf20bcee966	Client Host	openid-connect	oidc-usersessionmodel-note-mapper	bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	\N
b50388c5-c7ef-450e-84a2-044fe7eca7ca	Client IP Address	openid-connect	oidc-usersessionmodel-note-mapper	bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	\N
\.


--
-- Data for Name: protocol_mapper_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.protocol_mapper_config (protocol_mapper_id, value, name) FROM stdin;
b9e7a49b-b032-4597-9a04-cef4e49476f9	true	introspection.token.claim
b9e7a49b-b032-4597-9a04-cef4e49476f9	true	userinfo.token.claim
b9e7a49b-b032-4597-9a04-cef4e49476f9	locale	user.attribute
b9e7a49b-b032-4597-9a04-cef4e49476f9	true	id.token.claim
b9e7a49b-b032-4597-9a04-cef4e49476f9	true	access.token.claim
b9e7a49b-b032-4597-9a04-cef4e49476f9	locale	claim.name
b9e7a49b-b032-4597-9a04-cef4e49476f9	String	jsonType.label
ebe8b0bc-57c8-4a8d-ad8b-58af524ec1b9	false	single
ebe8b0bc-57c8-4a8d-ad8b-58af524ec1b9	Basic	attribute.nameformat
ebe8b0bc-57c8-4a8d-ad8b-58af524ec1b9	Role	attribute.name
06fa46dc-2ba3-4d0b-ac2a-205b4a97f576	true	introspection.token.claim
06fa46dc-2ba3-4d0b-ac2a-205b4a97f576	true	userinfo.token.claim
06fa46dc-2ba3-4d0b-ac2a-205b4a97f576	lastName	user.attribute
06fa46dc-2ba3-4d0b-ac2a-205b4a97f576	true	id.token.claim
06fa46dc-2ba3-4d0b-ac2a-205b4a97f576	true	access.token.claim
06fa46dc-2ba3-4d0b-ac2a-205b4a97f576	family_name	claim.name
06fa46dc-2ba3-4d0b-ac2a-205b4a97f576	String	jsonType.label
18a3083e-abee-45d6-a20e-6d9b988d3ef9	true	introspection.token.claim
18a3083e-abee-45d6-a20e-6d9b988d3ef9	true	userinfo.token.claim
18a3083e-abee-45d6-a20e-6d9b988d3ef9	zoneinfo	user.attribute
18a3083e-abee-45d6-a20e-6d9b988d3ef9	true	id.token.claim
18a3083e-abee-45d6-a20e-6d9b988d3ef9	true	access.token.claim
18a3083e-abee-45d6-a20e-6d9b988d3ef9	zoneinfo	claim.name
18a3083e-abee-45d6-a20e-6d9b988d3ef9	String	jsonType.label
4d5fba88-957f-4218-8589-5c969013f738	true	introspection.token.claim
4d5fba88-957f-4218-8589-5c969013f738	true	userinfo.token.claim
4d5fba88-957f-4218-8589-5c969013f738	username	user.attribute
4d5fba88-957f-4218-8589-5c969013f738	true	id.token.claim
4d5fba88-957f-4218-8589-5c969013f738	true	access.token.claim
4d5fba88-957f-4218-8589-5c969013f738	preferred_username	claim.name
4d5fba88-957f-4218-8589-5c969013f738	String	jsonType.label
52611912-28ab-422b-8bd2-e879a9aa61cb	true	introspection.token.claim
52611912-28ab-422b-8bd2-e879a9aa61cb	true	userinfo.token.claim
52611912-28ab-422b-8bd2-e879a9aa61cb	middleName	user.attribute
52611912-28ab-422b-8bd2-e879a9aa61cb	true	id.token.claim
52611912-28ab-422b-8bd2-e879a9aa61cb	true	access.token.claim
52611912-28ab-422b-8bd2-e879a9aa61cb	middle_name	claim.name
52611912-28ab-422b-8bd2-e879a9aa61cb	String	jsonType.label
9a5cf12c-2cac-4893-bebd-6f67b506bf9f	true	introspection.token.claim
9a5cf12c-2cac-4893-bebd-6f67b506bf9f	true	userinfo.token.claim
9a5cf12c-2cac-4893-bebd-6f67b506bf9f	firstName	user.attribute
9a5cf12c-2cac-4893-bebd-6f67b506bf9f	true	id.token.claim
9a5cf12c-2cac-4893-bebd-6f67b506bf9f	true	access.token.claim
9a5cf12c-2cac-4893-bebd-6f67b506bf9f	given_name	claim.name
9a5cf12c-2cac-4893-bebd-6f67b506bf9f	String	jsonType.label
a8875d84-2ac3-4374-95b2-d52024cbef82	true	introspection.token.claim
a8875d84-2ac3-4374-95b2-d52024cbef82	true	userinfo.token.claim
a8875d84-2ac3-4374-95b2-d52024cbef82	true	id.token.claim
a8875d84-2ac3-4374-95b2-d52024cbef82	true	access.token.claim
a9afc488-67dd-4f28-9bfa-3825a5e5a21b	true	introspection.token.claim
a9afc488-67dd-4f28-9bfa-3825a5e5a21b	true	userinfo.token.claim
a9afc488-67dd-4f28-9bfa-3825a5e5a21b	updatedAt	user.attribute
a9afc488-67dd-4f28-9bfa-3825a5e5a21b	true	id.token.claim
a9afc488-67dd-4f28-9bfa-3825a5e5a21b	true	access.token.claim
a9afc488-67dd-4f28-9bfa-3825a5e5a21b	updated_at	claim.name
a9afc488-67dd-4f28-9bfa-3825a5e5a21b	long	jsonType.label
b08fd8e5-c5fa-4c6e-aa06-a800b9ddc3be	true	introspection.token.claim
b08fd8e5-c5fa-4c6e-aa06-a800b9ddc3be	true	userinfo.token.claim
b08fd8e5-c5fa-4c6e-aa06-a800b9ddc3be	nickname	user.attribute
b08fd8e5-c5fa-4c6e-aa06-a800b9ddc3be	true	id.token.claim
b08fd8e5-c5fa-4c6e-aa06-a800b9ddc3be	true	access.token.claim
b08fd8e5-c5fa-4c6e-aa06-a800b9ddc3be	nickname	claim.name
b08fd8e5-c5fa-4c6e-aa06-a800b9ddc3be	String	jsonType.label
b0a0911e-1fde-434d-9055-1b3d37114797	true	introspection.token.claim
b0a0911e-1fde-434d-9055-1b3d37114797	true	userinfo.token.claim
b0a0911e-1fde-434d-9055-1b3d37114797	locale	user.attribute
b0a0911e-1fde-434d-9055-1b3d37114797	true	id.token.claim
b0a0911e-1fde-434d-9055-1b3d37114797	true	access.token.claim
b0a0911e-1fde-434d-9055-1b3d37114797	locale	claim.name
b0a0911e-1fde-434d-9055-1b3d37114797	String	jsonType.label
b5a3f7fd-fb51-47ff-8dc1-0c3c69440d6f	true	introspection.token.claim
b5a3f7fd-fb51-47ff-8dc1-0c3c69440d6f	true	userinfo.token.claim
b5a3f7fd-fb51-47ff-8dc1-0c3c69440d6f	profile	user.attribute
b5a3f7fd-fb51-47ff-8dc1-0c3c69440d6f	true	id.token.claim
b5a3f7fd-fb51-47ff-8dc1-0c3c69440d6f	true	access.token.claim
b5a3f7fd-fb51-47ff-8dc1-0c3c69440d6f	profile	claim.name
b5a3f7fd-fb51-47ff-8dc1-0c3c69440d6f	String	jsonType.label
c0416085-3202-42d2-9c5e-5418e14f1198	true	introspection.token.claim
c0416085-3202-42d2-9c5e-5418e14f1198	true	userinfo.token.claim
c0416085-3202-42d2-9c5e-5418e14f1198	website	user.attribute
c0416085-3202-42d2-9c5e-5418e14f1198	true	id.token.claim
c0416085-3202-42d2-9c5e-5418e14f1198	true	access.token.claim
c0416085-3202-42d2-9c5e-5418e14f1198	website	claim.name
c0416085-3202-42d2-9c5e-5418e14f1198	String	jsonType.label
c70e9306-ad0b-49eb-b7fe-f2736cd3ea88	true	introspection.token.claim
c70e9306-ad0b-49eb-b7fe-f2736cd3ea88	true	userinfo.token.claim
c70e9306-ad0b-49eb-b7fe-f2736cd3ea88	gender	user.attribute
c70e9306-ad0b-49eb-b7fe-f2736cd3ea88	true	id.token.claim
c70e9306-ad0b-49eb-b7fe-f2736cd3ea88	true	access.token.claim
c70e9306-ad0b-49eb-b7fe-f2736cd3ea88	gender	claim.name
c70e9306-ad0b-49eb-b7fe-f2736cd3ea88	String	jsonType.label
ddd22944-9e8a-463b-98de-541c3a07c489	true	introspection.token.claim
ddd22944-9e8a-463b-98de-541c3a07c489	true	userinfo.token.claim
ddd22944-9e8a-463b-98de-541c3a07c489	birthdate	user.attribute
ddd22944-9e8a-463b-98de-541c3a07c489	true	id.token.claim
ddd22944-9e8a-463b-98de-541c3a07c489	true	access.token.claim
ddd22944-9e8a-463b-98de-541c3a07c489	birthdate	claim.name
ddd22944-9e8a-463b-98de-541c3a07c489	String	jsonType.label
ec208160-87db-4ccd-b89b-5e39c11d0be6	true	introspection.token.claim
ec208160-87db-4ccd-b89b-5e39c11d0be6	true	userinfo.token.claim
ec208160-87db-4ccd-b89b-5e39c11d0be6	picture	user.attribute
ec208160-87db-4ccd-b89b-5e39c11d0be6	true	id.token.claim
ec208160-87db-4ccd-b89b-5e39c11d0be6	true	access.token.claim
ec208160-87db-4ccd-b89b-5e39c11d0be6	picture	claim.name
ec208160-87db-4ccd-b89b-5e39c11d0be6	String	jsonType.label
3516706c-f92e-43ad-ae4a-e49e8be1abdb	true	introspection.token.claim
3516706c-f92e-43ad-ae4a-e49e8be1abdb	true	userinfo.token.claim
3516706c-f92e-43ad-ae4a-e49e8be1abdb	email	user.attribute
3516706c-f92e-43ad-ae4a-e49e8be1abdb	true	id.token.claim
3516706c-f92e-43ad-ae4a-e49e8be1abdb	true	access.token.claim
3516706c-f92e-43ad-ae4a-e49e8be1abdb	email	claim.name
3516706c-f92e-43ad-ae4a-e49e8be1abdb	String	jsonType.label
b1b6c1dd-6d7c-4d34-937c-cb91dcf05799	true	introspection.token.claim
b1b6c1dd-6d7c-4d34-937c-cb91dcf05799	true	userinfo.token.claim
b1b6c1dd-6d7c-4d34-937c-cb91dcf05799	emailVerified	user.attribute
b1b6c1dd-6d7c-4d34-937c-cb91dcf05799	true	id.token.claim
b1b6c1dd-6d7c-4d34-937c-cb91dcf05799	true	access.token.claim
b1b6c1dd-6d7c-4d34-937c-cb91dcf05799	email_verified	claim.name
b1b6c1dd-6d7c-4d34-937c-cb91dcf05799	boolean	jsonType.label
49c95f8f-a54b-4b23-b0e6-cc3455b7e6a1	formatted	user.attribute.formatted
49c95f8f-a54b-4b23-b0e6-cc3455b7e6a1	country	user.attribute.country
49c95f8f-a54b-4b23-b0e6-cc3455b7e6a1	true	introspection.token.claim
49c95f8f-a54b-4b23-b0e6-cc3455b7e6a1	postal_code	user.attribute.postal_code
49c95f8f-a54b-4b23-b0e6-cc3455b7e6a1	true	userinfo.token.claim
49c95f8f-a54b-4b23-b0e6-cc3455b7e6a1	street	user.attribute.street
49c95f8f-a54b-4b23-b0e6-cc3455b7e6a1	true	id.token.claim
49c95f8f-a54b-4b23-b0e6-cc3455b7e6a1	region	user.attribute.region
49c95f8f-a54b-4b23-b0e6-cc3455b7e6a1	true	access.token.claim
49c95f8f-a54b-4b23-b0e6-cc3455b7e6a1	locality	user.attribute.locality
1cd68426-2393-4899-a2e2-cfa3cd5306c9	true	introspection.token.claim
1cd68426-2393-4899-a2e2-cfa3cd5306c9	true	userinfo.token.claim
1cd68426-2393-4899-a2e2-cfa3cd5306c9	phoneNumberVerified	user.attribute
1cd68426-2393-4899-a2e2-cfa3cd5306c9	true	id.token.claim
1cd68426-2393-4899-a2e2-cfa3cd5306c9	true	access.token.claim
1cd68426-2393-4899-a2e2-cfa3cd5306c9	phone_number_verified	claim.name
1cd68426-2393-4899-a2e2-cfa3cd5306c9	boolean	jsonType.label
91a9bbb2-8cea-4fa5-8843-287d70147149	true	introspection.token.claim
91a9bbb2-8cea-4fa5-8843-287d70147149	true	userinfo.token.claim
91a9bbb2-8cea-4fa5-8843-287d70147149	phoneNumber	user.attribute
91a9bbb2-8cea-4fa5-8843-287d70147149	true	id.token.claim
91a9bbb2-8cea-4fa5-8843-287d70147149	true	access.token.claim
91a9bbb2-8cea-4fa5-8843-287d70147149	phone_number	claim.name
91a9bbb2-8cea-4fa5-8843-287d70147149	String	jsonType.label
10e14578-2d1f-4f38-8151-5f85d4431da0	true	introspection.token.claim
10e14578-2d1f-4f38-8151-5f85d4431da0	true	access.token.claim
5cec3c48-b0c9-4eb2-89c5-e27dbba2a2a6	true	introspection.token.claim
5cec3c48-b0c9-4eb2-89c5-e27dbba2a2a6	true	multivalued
5cec3c48-b0c9-4eb2-89c5-e27dbba2a2a6	foo	user.attribute
5cec3c48-b0c9-4eb2-89c5-e27dbba2a2a6	true	access.token.claim
5cec3c48-b0c9-4eb2-89c5-e27dbba2a2a6	realm_access.roles	claim.name
5cec3c48-b0c9-4eb2-89c5-e27dbba2a2a6	String	jsonType.label
8b256136-f346-4ad4-b2f6-88788bd0b1bc	true	introspection.token.claim
8b256136-f346-4ad4-b2f6-88788bd0b1bc	true	multivalued
8b256136-f346-4ad4-b2f6-88788bd0b1bc	foo	user.attribute
8b256136-f346-4ad4-b2f6-88788bd0b1bc	true	access.token.claim
8b256136-f346-4ad4-b2f6-88788bd0b1bc	resource_access.${client_id}.roles	claim.name
8b256136-f346-4ad4-b2f6-88788bd0b1bc	String	jsonType.label
41873786-0eeb-4663-adbf-0b517b144fc3	true	introspection.token.claim
41873786-0eeb-4663-adbf-0b517b144fc3	true	access.token.claim
917dcfdb-38ea-49c8-b340-6a2b2736d85d	true	introspection.token.claim
917dcfdb-38ea-49c8-b340-6a2b2736d85d	true	multivalued
917dcfdb-38ea-49c8-b340-6a2b2736d85d	foo	user.attribute
917dcfdb-38ea-49c8-b340-6a2b2736d85d	true	id.token.claim
917dcfdb-38ea-49c8-b340-6a2b2736d85d	true	access.token.claim
917dcfdb-38ea-49c8-b340-6a2b2736d85d	groups	claim.name
917dcfdb-38ea-49c8-b340-6a2b2736d85d	String	jsonType.label
918488ee-9170-41f1-af8b-f264b38a48b2	true	introspection.token.claim
918488ee-9170-41f1-af8b-f264b38a48b2	true	userinfo.token.claim
918488ee-9170-41f1-af8b-f264b38a48b2	username	user.attribute
918488ee-9170-41f1-af8b-f264b38a48b2	true	id.token.claim
918488ee-9170-41f1-af8b-f264b38a48b2	true	access.token.claim
918488ee-9170-41f1-af8b-f264b38a48b2	upn	claim.name
918488ee-9170-41f1-af8b-f264b38a48b2	String	jsonType.label
42401434-f1c8-43e9-99ce-d54e17037901	true	introspection.token.claim
42401434-f1c8-43e9-99ce-d54e17037901	true	id.token.claim
42401434-f1c8-43e9-99ce-d54e17037901	true	access.token.claim
0c41153b-66c1-4c6a-9dbc-98e5313f9e0e	true	introspection.token.claim
0c41153b-66c1-4c6a-9dbc-98e5313f9e0e	true	access.token.claim
b238b53b-6d22-45be-8014-7942022fb08f	AUTH_TIME	user.session.note
b238b53b-6d22-45be-8014-7942022fb08f	true	introspection.token.claim
b238b53b-6d22-45be-8014-7942022fb08f	true	id.token.claim
b238b53b-6d22-45be-8014-7942022fb08f	true	access.token.claim
b238b53b-6d22-45be-8014-7942022fb08f	auth_time	claim.name
b238b53b-6d22-45be-8014-7942022fb08f	long	jsonType.label
645c4981-19c7-40bf-9326-64d53bb9aa1c	true	introspection.token.claim
645c4981-19c7-40bf-9326-64d53bb9aa1c	true	multivalued
645c4981-19c7-40bf-9326-64d53bb9aa1c	true	id.token.claim
645c4981-19c7-40bf-9326-64d53bb9aa1c	true	access.token.claim
645c4981-19c7-40bf-9326-64d53bb9aa1c	organization	claim.name
645c4981-19c7-40bf-9326-64d53bb9aa1c	String	jsonType.label
1d7c47d7-8f38-4b6c-b6f7-a366976e7c7e	false	single
1d7c47d7-8f38-4b6c-b6f7-a366976e7c7e	Basic	attribute.nameformat
1d7c47d7-8f38-4b6c-b6f7-a366976e7c7e	Role	attribute.name
0c68ee56-b85d-4ac1-a851-9721220a8aff	true	introspection.token.claim
0c68ee56-b85d-4ac1-a851-9721220a8aff	true	userinfo.token.claim
0c68ee56-b85d-4ac1-a851-9721220a8aff	true	id.token.claim
0c68ee56-b85d-4ac1-a851-9721220a8aff	true	access.token.claim
12750155-f463-4747-9a3e-2df98f29da71	true	introspection.token.claim
12750155-f463-4747-9a3e-2df98f29da71	true	userinfo.token.claim
12750155-f463-4747-9a3e-2df98f29da71	gender	user.attribute
12750155-f463-4747-9a3e-2df98f29da71	true	id.token.claim
12750155-f463-4747-9a3e-2df98f29da71	true	access.token.claim
12750155-f463-4747-9a3e-2df98f29da71	gender	claim.name
12750155-f463-4747-9a3e-2df98f29da71	String	jsonType.label
21736b90-f4a5-45b0-b45a-7b122e92c365	true	introspection.token.claim
21736b90-f4a5-45b0-b45a-7b122e92c365	true	userinfo.token.claim
21736b90-f4a5-45b0-b45a-7b122e92c365	lastName	user.attribute
21736b90-f4a5-45b0-b45a-7b122e92c365	true	id.token.claim
21736b90-f4a5-45b0-b45a-7b122e92c365	true	access.token.claim
21736b90-f4a5-45b0-b45a-7b122e92c365	family_name	claim.name
21736b90-f4a5-45b0-b45a-7b122e92c365	String	jsonType.label
3e4eb6f7-2d7f-4f93-b8e8-f7b186643ce6	true	introspection.token.claim
3e4eb6f7-2d7f-4f93-b8e8-f7b186643ce6	true	userinfo.token.claim
3e4eb6f7-2d7f-4f93-b8e8-f7b186643ce6	birthdate	user.attribute
3e4eb6f7-2d7f-4f93-b8e8-f7b186643ce6	true	id.token.claim
3e4eb6f7-2d7f-4f93-b8e8-f7b186643ce6	true	access.token.claim
3e4eb6f7-2d7f-4f93-b8e8-f7b186643ce6	birthdate	claim.name
3e4eb6f7-2d7f-4f93-b8e8-f7b186643ce6	String	jsonType.label
49c58178-4841-409c-9902-cfdc9055926c	true	introspection.token.claim
49c58178-4841-409c-9902-cfdc9055926c	true	userinfo.token.claim
49c58178-4841-409c-9902-cfdc9055926c	profile	user.attribute
49c58178-4841-409c-9902-cfdc9055926c	true	id.token.claim
49c58178-4841-409c-9902-cfdc9055926c	true	access.token.claim
49c58178-4841-409c-9902-cfdc9055926c	profile	claim.name
49c58178-4841-409c-9902-cfdc9055926c	String	jsonType.label
5a9d27d9-135c-4226-bd78-ab6576e63396	true	introspection.token.claim
5a9d27d9-135c-4226-bd78-ab6576e63396	true	userinfo.token.claim
5a9d27d9-135c-4226-bd78-ab6576e63396	locale	user.attribute
5a9d27d9-135c-4226-bd78-ab6576e63396	true	id.token.claim
5a9d27d9-135c-4226-bd78-ab6576e63396	true	access.token.claim
5a9d27d9-135c-4226-bd78-ab6576e63396	locale	claim.name
5a9d27d9-135c-4226-bd78-ab6576e63396	String	jsonType.label
5ae23742-d2c7-4cd3-8f14-99bd18d02b88	true	introspection.token.claim
5ae23742-d2c7-4cd3-8f14-99bd18d02b88	true	userinfo.token.claim
5ae23742-d2c7-4cd3-8f14-99bd18d02b88	username	user.attribute
5ae23742-d2c7-4cd3-8f14-99bd18d02b88	true	id.token.claim
5ae23742-d2c7-4cd3-8f14-99bd18d02b88	true	access.token.claim
5ae23742-d2c7-4cd3-8f14-99bd18d02b88	preferred_username	claim.name
5ae23742-d2c7-4cd3-8f14-99bd18d02b88	String	jsonType.label
689faee0-d64d-40e0-ac3d-1f6ac70c3a9a	true	introspection.token.claim
689faee0-d64d-40e0-ac3d-1f6ac70c3a9a	true	userinfo.token.claim
689faee0-d64d-40e0-ac3d-1f6ac70c3a9a	middleName	user.attribute
689faee0-d64d-40e0-ac3d-1f6ac70c3a9a	true	id.token.claim
689faee0-d64d-40e0-ac3d-1f6ac70c3a9a	true	access.token.claim
689faee0-d64d-40e0-ac3d-1f6ac70c3a9a	middle_name	claim.name
689faee0-d64d-40e0-ac3d-1f6ac70c3a9a	String	jsonType.label
bdcfbc6c-4a9e-41cd-be0e-7f3f8f2b0a78	true	introspection.token.claim
bdcfbc6c-4a9e-41cd-be0e-7f3f8f2b0a78	true	userinfo.token.claim
bdcfbc6c-4a9e-41cd-be0e-7f3f8f2b0a78	firstName	user.attribute
bdcfbc6c-4a9e-41cd-be0e-7f3f8f2b0a78	true	id.token.claim
bdcfbc6c-4a9e-41cd-be0e-7f3f8f2b0a78	true	access.token.claim
bdcfbc6c-4a9e-41cd-be0e-7f3f8f2b0a78	given_name	claim.name
bdcfbc6c-4a9e-41cd-be0e-7f3f8f2b0a78	String	jsonType.label
bf551602-9605-412b-9d16-09e8d76a4932	true	introspection.token.claim
bf551602-9605-412b-9d16-09e8d76a4932	true	userinfo.token.claim
bf551602-9605-412b-9d16-09e8d76a4932	zoneinfo	user.attribute
bf551602-9605-412b-9d16-09e8d76a4932	true	id.token.claim
bf551602-9605-412b-9d16-09e8d76a4932	true	access.token.claim
bf551602-9605-412b-9d16-09e8d76a4932	zoneinfo	claim.name
bf551602-9605-412b-9d16-09e8d76a4932	String	jsonType.label
c28caa54-b00c-417b-a8e0-b4193dbe1f5f	true	introspection.token.claim
c28caa54-b00c-417b-a8e0-b4193dbe1f5f	true	userinfo.token.claim
c28caa54-b00c-417b-a8e0-b4193dbe1f5f	picture	user.attribute
c28caa54-b00c-417b-a8e0-b4193dbe1f5f	true	id.token.claim
c28caa54-b00c-417b-a8e0-b4193dbe1f5f	true	access.token.claim
c28caa54-b00c-417b-a8e0-b4193dbe1f5f	picture	claim.name
c28caa54-b00c-417b-a8e0-b4193dbe1f5f	String	jsonType.label
cdb3fad6-9bc7-49be-81c9-f3b26343b6ad	true	introspection.token.claim
cdb3fad6-9bc7-49be-81c9-f3b26343b6ad	true	userinfo.token.claim
cdb3fad6-9bc7-49be-81c9-f3b26343b6ad	updatedAt	user.attribute
cdb3fad6-9bc7-49be-81c9-f3b26343b6ad	true	id.token.claim
cdb3fad6-9bc7-49be-81c9-f3b26343b6ad	true	access.token.claim
cdb3fad6-9bc7-49be-81c9-f3b26343b6ad	updated_at	claim.name
cdb3fad6-9bc7-49be-81c9-f3b26343b6ad	long	jsonType.label
def21bf2-4c98-4c58-8c90-418406c67ffc	true	introspection.token.claim
def21bf2-4c98-4c58-8c90-418406c67ffc	true	userinfo.token.claim
def21bf2-4c98-4c58-8c90-418406c67ffc	website	user.attribute
def21bf2-4c98-4c58-8c90-418406c67ffc	true	id.token.claim
def21bf2-4c98-4c58-8c90-418406c67ffc	true	access.token.claim
def21bf2-4c98-4c58-8c90-418406c67ffc	website	claim.name
def21bf2-4c98-4c58-8c90-418406c67ffc	String	jsonType.label
fc0b6a60-f19f-440c-a421-133fd5fd70f9	true	introspection.token.claim
fc0b6a60-f19f-440c-a421-133fd5fd70f9	true	userinfo.token.claim
fc0b6a60-f19f-440c-a421-133fd5fd70f9	nickname	user.attribute
fc0b6a60-f19f-440c-a421-133fd5fd70f9	true	id.token.claim
fc0b6a60-f19f-440c-a421-133fd5fd70f9	true	access.token.claim
fc0b6a60-f19f-440c-a421-133fd5fd70f9	nickname	claim.name
fc0b6a60-f19f-440c-a421-133fd5fd70f9	String	jsonType.label
065bc919-2fe1-4027-954e-bf498e338b31	true	introspection.token.claim
065bc919-2fe1-4027-954e-bf498e338b31	true	userinfo.token.claim
065bc919-2fe1-4027-954e-bf498e338b31	emailVerified	user.attribute
065bc919-2fe1-4027-954e-bf498e338b31	true	id.token.claim
065bc919-2fe1-4027-954e-bf498e338b31	true	access.token.claim
065bc919-2fe1-4027-954e-bf498e338b31	email_verified	claim.name
065bc919-2fe1-4027-954e-bf498e338b31	boolean	jsonType.label
ac88e056-9bdd-48c3-b563-5c1ed6d79f47	true	introspection.token.claim
ac88e056-9bdd-48c3-b563-5c1ed6d79f47	true	userinfo.token.claim
ac88e056-9bdd-48c3-b563-5c1ed6d79f47	email	user.attribute
ac88e056-9bdd-48c3-b563-5c1ed6d79f47	true	id.token.claim
ac88e056-9bdd-48c3-b563-5c1ed6d79f47	true	access.token.claim
ac88e056-9bdd-48c3-b563-5c1ed6d79f47	email	claim.name
ac88e056-9bdd-48c3-b563-5c1ed6d79f47	String	jsonType.label
3a7197e0-7da4-45b3-9164-1f5029921332	formatted	user.attribute.formatted
3a7197e0-7da4-45b3-9164-1f5029921332	country	user.attribute.country
3a7197e0-7da4-45b3-9164-1f5029921332	true	introspection.token.claim
3a7197e0-7da4-45b3-9164-1f5029921332	postal_code	user.attribute.postal_code
3a7197e0-7da4-45b3-9164-1f5029921332	true	userinfo.token.claim
3a7197e0-7da4-45b3-9164-1f5029921332	street	user.attribute.street
3a7197e0-7da4-45b3-9164-1f5029921332	true	id.token.claim
3a7197e0-7da4-45b3-9164-1f5029921332	region	user.attribute.region
3a7197e0-7da4-45b3-9164-1f5029921332	true	access.token.claim
3a7197e0-7da4-45b3-9164-1f5029921332	locality	user.attribute.locality
69cef575-065e-4613-b5b4-4002117c1f21	true	introspection.token.claim
69cef575-065e-4613-b5b4-4002117c1f21	true	userinfo.token.claim
69cef575-065e-4613-b5b4-4002117c1f21	phoneNumberVerified	user.attribute
69cef575-065e-4613-b5b4-4002117c1f21	true	id.token.claim
69cef575-065e-4613-b5b4-4002117c1f21	true	access.token.claim
69cef575-065e-4613-b5b4-4002117c1f21	phone_number_verified	claim.name
69cef575-065e-4613-b5b4-4002117c1f21	boolean	jsonType.label
bab36fb7-ab6c-4156-92f6-42ffedbaef78	true	introspection.token.claim
bab36fb7-ab6c-4156-92f6-42ffedbaef78	true	userinfo.token.claim
bab36fb7-ab6c-4156-92f6-42ffedbaef78	phoneNumber	user.attribute
bab36fb7-ab6c-4156-92f6-42ffedbaef78	true	id.token.claim
bab36fb7-ab6c-4156-92f6-42ffedbaef78	true	access.token.claim
bab36fb7-ab6c-4156-92f6-42ffedbaef78	phone_number	claim.name
bab36fb7-ab6c-4156-92f6-42ffedbaef78	String	jsonType.label
91c1cb39-26ea-4d48-9cd7-6c39da8aec54	true	introspection.token.claim
91c1cb39-26ea-4d48-9cd7-6c39da8aec54	true	multivalued
91c1cb39-26ea-4d48-9cd7-6c39da8aec54	foo	user.attribute
91c1cb39-26ea-4d48-9cd7-6c39da8aec54	true	access.token.claim
91c1cb39-26ea-4d48-9cd7-6c39da8aec54	realm_access.roles	claim.name
91c1cb39-26ea-4d48-9cd7-6c39da8aec54	String	jsonType.label
9b4187e2-62ca-420f-a0c4-63aeb3fbc0b5	true	introspection.token.claim
9b4187e2-62ca-420f-a0c4-63aeb3fbc0b5	true	multivalued
9b4187e2-62ca-420f-a0c4-63aeb3fbc0b5	foo	user.attribute
9b4187e2-62ca-420f-a0c4-63aeb3fbc0b5	true	access.token.claim
9b4187e2-62ca-420f-a0c4-63aeb3fbc0b5	resource_access.${client_id}.roles	claim.name
9b4187e2-62ca-420f-a0c4-63aeb3fbc0b5	String	jsonType.label
d6875042-0fdb-4f98-86b1-31ad843cd7d3	true	introspection.token.claim
d6875042-0fdb-4f98-86b1-31ad843cd7d3	true	access.token.claim
4f78308b-c334-432e-8471-5cee0ff3a120	true	introspection.token.claim
4f78308b-c334-432e-8471-5cee0ff3a120	true	access.token.claim
29070550-b137-415e-af74-60362c066742	true	introspection.token.claim
29070550-b137-415e-af74-60362c066742	true	userinfo.token.claim
29070550-b137-415e-af74-60362c066742	username	user.attribute
29070550-b137-415e-af74-60362c066742	true	id.token.claim
29070550-b137-415e-af74-60362c066742	true	access.token.claim
29070550-b137-415e-af74-60362c066742	upn	claim.name
29070550-b137-415e-af74-60362c066742	String	jsonType.label
f999a491-b48e-4eaa-9e14-9516bc61f2a5	true	introspection.token.claim
f999a491-b48e-4eaa-9e14-9516bc61f2a5	true	multivalued
f999a491-b48e-4eaa-9e14-9516bc61f2a5	foo	user.attribute
f999a491-b48e-4eaa-9e14-9516bc61f2a5	true	id.token.claim
f999a491-b48e-4eaa-9e14-9516bc61f2a5	true	access.token.claim
f999a491-b48e-4eaa-9e14-9516bc61f2a5	groups	claim.name
f999a491-b48e-4eaa-9e14-9516bc61f2a5	String	jsonType.label
8f662e05-788a-4634-ad24-b573298847e3	true	introspection.token.claim
8f662e05-788a-4634-ad24-b573298847e3	true	id.token.claim
8f662e05-788a-4634-ad24-b573298847e3	true	access.token.claim
3620e8bd-2393-4430-b6b3-cfd8ab595234	true	introspection.token.claim
3620e8bd-2393-4430-b6b3-cfd8ab595234	true	access.token.claim
ee05a34a-243b-488f-af21-d706add1e709	AUTH_TIME	user.session.note
ee05a34a-243b-488f-af21-d706add1e709	true	introspection.token.claim
ee05a34a-243b-488f-af21-d706add1e709	true	id.token.claim
ee05a34a-243b-488f-af21-d706add1e709	true	access.token.claim
ee05a34a-243b-488f-af21-d706add1e709	auth_time	claim.name
ee05a34a-243b-488f-af21-d706add1e709	long	jsonType.label
a548fced-767b-4d01-a040-f8268d9add63	true	introspection.token.claim
a548fced-767b-4d01-a040-f8268d9add63	true	multivalued
a548fced-767b-4d01-a040-f8268d9add63	true	id.token.claim
a548fced-767b-4d01-a040-f8268d9add63	true	access.token.claim
a548fced-767b-4d01-a040-f8268d9add63	organization	claim.name
a548fced-767b-4d01-a040-f8268d9add63	String	jsonType.label
505e3a9b-281c-447e-8de7-712c60dd4e54	true	introspection.token.claim
505e3a9b-281c-447e-8de7-712c60dd4e54	true	userinfo.token.claim
505e3a9b-281c-447e-8de7-712c60dd4e54	locale	user.attribute
505e3a9b-281c-447e-8de7-712c60dd4e54	true	id.token.claim
505e3a9b-281c-447e-8de7-712c60dd4e54	true	access.token.claim
505e3a9b-281c-447e-8de7-712c60dd4e54	locale	claim.name
505e3a9b-281c-447e-8de7-712c60dd4e54	String	jsonType.label
8d3feec2-838e-4b96-88fb-7cf20bcee966	clientHost	user.session.note
8d3feec2-838e-4b96-88fb-7cf20bcee966	true	introspection.token.claim
8d3feec2-838e-4b96-88fb-7cf20bcee966	true	id.token.claim
8d3feec2-838e-4b96-88fb-7cf20bcee966	true	access.token.claim
8d3feec2-838e-4b96-88fb-7cf20bcee966	clientHost	claim.name
8d3feec2-838e-4b96-88fb-7cf20bcee966	String	jsonType.label
8e6d9897-b52b-4c10-9e22-5c8a5d004637	client_id	user.session.note
8e6d9897-b52b-4c10-9e22-5c8a5d004637	true	introspection.token.claim
8e6d9897-b52b-4c10-9e22-5c8a5d004637	true	id.token.claim
8e6d9897-b52b-4c10-9e22-5c8a5d004637	true	access.token.claim
8e6d9897-b52b-4c10-9e22-5c8a5d004637	client_id	claim.name
8e6d9897-b52b-4c10-9e22-5c8a5d004637	String	jsonType.label
b50388c5-c7ef-450e-84a2-044fe7eca7ca	clientAddress	user.session.note
b50388c5-c7ef-450e-84a2-044fe7eca7ca	true	introspection.token.claim
b50388c5-c7ef-450e-84a2-044fe7eca7ca	true	id.token.claim
b50388c5-c7ef-450e-84a2-044fe7eca7ca	true	access.token.claim
b50388c5-c7ef-450e-84a2-044fe7eca7ca	clientAddress	claim.name
b50388c5-c7ef-450e-84a2-044fe7eca7ca	String	jsonType.label
\.


--
-- Data for Name: realm; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.realm (id, access_code_lifespan, user_action_lifespan, access_token_lifespan, account_theme, admin_theme, email_theme, enabled, events_enabled, events_expiration, login_theme, name, not_before, password_policy, registration_allowed, remember_me, reset_password_allowed, social, ssl_required, sso_idle_timeout, sso_max_lifespan, update_profile_on_soc_login, verify_email, master_admin_client, login_lifespan, internationalization_enabled, default_locale, reg_email_as_username, admin_events_enabled, admin_events_details_enabled, edit_username_allowed, otp_policy_counter, otp_policy_window, otp_policy_period, otp_policy_digits, otp_policy_alg, otp_policy_type, browser_flow, registration_flow, direct_grant_flow, reset_credentials_flow, client_auth_flow, offline_session_idle_timeout, revoke_refresh_token, access_token_life_implicit, login_with_email_allowed, duplicate_emails_allowed, docker_auth_flow, refresh_token_max_reuse, allow_user_managed_access, sso_max_lifespan_remember_me, sso_idle_timeout_remember_me, default_role) FROM stdin;
29105d11-1bed-40a5-9927-60d87c4deff3	60	300	300	\N	\N	\N	t	f	0	\N	agentshield	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	da88d06b-e956-42e8-a610-ba048d70e217	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	ee672b99-bfea-4d79-abcd-dde94ecfec4c	d5ecf7dc-2fb0-43ac-a6b5-761c28efa605	fc780d10-589d-4f15-ba24-2e31e87e24fb	2bf59d35-f426-45d8-a3c7-ccbf2da5c626	556d147b-5125-4b16-95db-8afea7b350e5	2592000	f	900	t	f	4c26b482-314f-482a-8c2d-f4673ddd5394	0	f	0	0	bd09041d-0741-445f-9d89-b73a04dcb1f7
29bb8813-da75-41e0-b440-8ab491e3ec8a	60	300	60	\N	\N	\N	t	f	0	\N	master	0	\N	f	f	f	f	EXTERNAL	1800	36000	f	f	0c385d9c-72ee-44a8-a993-aa8fc3317a70	1800	f	\N	f	f	f	f	0	1	30	6	HmacSHA1	totp	63194eec-ce6b-4eeb-b81a-9f454ebcf9d1	b547a862-3a72-477a-9e64-cd3e379f17b0	72df32c4-c017-466f-9e98-43057989ceba	bae1abb4-6a83-4415-928c-2d5d5ae80d76	20ca09c0-f56b-4b21-9d47-82b9198685d9	2592000	f	900	t	f	9efb454a-1d67-464e-9779-fffe9c405efd	0	f	0	0	bfb26ed5-54a0-4f24-8a6a-9c7402b830a7
\.


--
-- Data for Name: realm_attribute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.realm_attribute (name, realm_id, value) FROM stdin;
_browser_header.contentSecurityPolicyReportOnly	29bb8813-da75-41e0-b440-8ab491e3ec8a	
_browser_header.xContentTypeOptions	29bb8813-da75-41e0-b440-8ab491e3ec8a	nosniff
_browser_header.referrerPolicy	29bb8813-da75-41e0-b440-8ab491e3ec8a	no-referrer
_browser_header.xRobotsTag	29bb8813-da75-41e0-b440-8ab491e3ec8a	none
_browser_header.xFrameOptions	29bb8813-da75-41e0-b440-8ab491e3ec8a	SAMEORIGIN
_browser_header.contentSecurityPolicy	29bb8813-da75-41e0-b440-8ab491e3ec8a	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	29bb8813-da75-41e0-b440-8ab491e3ec8a	1; mode=block
_browser_header.strictTransportSecurity	29bb8813-da75-41e0-b440-8ab491e3ec8a	max-age=31536000; includeSubDomains
bruteForceProtected	29bb8813-da75-41e0-b440-8ab491e3ec8a	false
permanentLockout	29bb8813-da75-41e0-b440-8ab491e3ec8a	false
maxTemporaryLockouts	29bb8813-da75-41e0-b440-8ab491e3ec8a	0
bruteForceStrategy	29bb8813-da75-41e0-b440-8ab491e3ec8a	MULTIPLE
maxFailureWaitSeconds	29bb8813-da75-41e0-b440-8ab491e3ec8a	900
minimumQuickLoginWaitSeconds	29bb8813-da75-41e0-b440-8ab491e3ec8a	60
waitIncrementSeconds	29bb8813-da75-41e0-b440-8ab491e3ec8a	60
quickLoginCheckMilliSeconds	29bb8813-da75-41e0-b440-8ab491e3ec8a	1000
maxDeltaTimeSeconds	29bb8813-da75-41e0-b440-8ab491e3ec8a	43200
failureFactor	29bb8813-da75-41e0-b440-8ab491e3ec8a	30
realmReusableOtpCode	29bb8813-da75-41e0-b440-8ab491e3ec8a	false
firstBrokerLoginFlowId	29bb8813-da75-41e0-b440-8ab491e3ec8a	c2ce6c00-2b94-4f8e-a1c9-96cb0650426f
displayName	29bb8813-da75-41e0-b440-8ab491e3ec8a	Keycloak
displayNameHtml	29bb8813-da75-41e0-b440-8ab491e3ec8a	<div class="kc-logo-text"><span>Keycloak</span></div>
defaultSignatureAlgorithm	29bb8813-da75-41e0-b440-8ab491e3ec8a	RS256
offlineSessionMaxLifespanEnabled	29bb8813-da75-41e0-b440-8ab491e3ec8a	false
offlineSessionMaxLifespan	29bb8813-da75-41e0-b440-8ab491e3ec8a	5184000
_browser_header.contentSecurityPolicyReportOnly	29105d11-1bed-40a5-9927-60d87c4deff3	
_browser_header.xContentTypeOptions	29105d11-1bed-40a5-9927-60d87c4deff3	nosniff
_browser_header.referrerPolicy	29105d11-1bed-40a5-9927-60d87c4deff3	no-referrer
_browser_header.xRobotsTag	29105d11-1bed-40a5-9927-60d87c4deff3	none
_browser_header.xFrameOptions	29105d11-1bed-40a5-9927-60d87c4deff3	SAMEORIGIN
_browser_header.contentSecurityPolicy	29105d11-1bed-40a5-9927-60d87c4deff3	frame-src 'self'; frame-ancestors 'self'; object-src 'none';
_browser_header.xXSSProtection	29105d11-1bed-40a5-9927-60d87c4deff3	1; mode=block
_browser_header.strictTransportSecurity	29105d11-1bed-40a5-9927-60d87c4deff3	max-age=31536000; includeSubDomains
bruteForceProtected	29105d11-1bed-40a5-9927-60d87c4deff3	false
permanentLockout	29105d11-1bed-40a5-9927-60d87c4deff3	false
maxTemporaryLockouts	29105d11-1bed-40a5-9927-60d87c4deff3	0
bruteForceStrategy	29105d11-1bed-40a5-9927-60d87c4deff3	MULTIPLE
maxFailureWaitSeconds	29105d11-1bed-40a5-9927-60d87c4deff3	900
minimumQuickLoginWaitSeconds	29105d11-1bed-40a5-9927-60d87c4deff3	60
waitIncrementSeconds	29105d11-1bed-40a5-9927-60d87c4deff3	60
quickLoginCheckMilliSeconds	29105d11-1bed-40a5-9927-60d87c4deff3	1000
maxDeltaTimeSeconds	29105d11-1bed-40a5-9927-60d87c4deff3	43200
failureFactor	29105d11-1bed-40a5-9927-60d87c4deff3	30
realmReusableOtpCode	29105d11-1bed-40a5-9927-60d87c4deff3	false
displayName	29105d11-1bed-40a5-9927-60d87c4deff3	AgentShield
defaultSignatureAlgorithm	29105d11-1bed-40a5-9927-60d87c4deff3	RS256
offlineSessionMaxLifespanEnabled	29105d11-1bed-40a5-9927-60d87c4deff3	false
offlineSessionMaxLifespan	29105d11-1bed-40a5-9927-60d87c4deff3	5184000
actionTokenGeneratedByAdminLifespan	29105d11-1bed-40a5-9927-60d87c4deff3	43200
actionTokenGeneratedByUserLifespan	29105d11-1bed-40a5-9927-60d87c4deff3	300
oauth2DeviceCodeLifespan	29105d11-1bed-40a5-9927-60d87c4deff3	600
oauth2DevicePollingInterval	29105d11-1bed-40a5-9927-60d87c4deff3	5
webAuthnPolicyRpEntityName	29105d11-1bed-40a5-9927-60d87c4deff3	keycloak
webAuthnPolicySignatureAlgorithms	29105d11-1bed-40a5-9927-60d87c4deff3	ES256,RS256
webAuthnPolicyRpId	29105d11-1bed-40a5-9927-60d87c4deff3	
webAuthnPolicyAttestationConveyancePreference	29105d11-1bed-40a5-9927-60d87c4deff3	not specified
webAuthnPolicyAuthenticatorAttachment	29105d11-1bed-40a5-9927-60d87c4deff3	not specified
webAuthnPolicyRequireResidentKey	29105d11-1bed-40a5-9927-60d87c4deff3	not specified
webAuthnPolicyUserVerificationRequirement	29105d11-1bed-40a5-9927-60d87c4deff3	not specified
webAuthnPolicyCreateTimeout	29105d11-1bed-40a5-9927-60d87c4deff3	0
webAuthnPolicyAvoidSameAuthenticatorRegister	29105d11-1bed-40a5-9927-60d87c4deff3	false
webAuthnPolicyRpEntityNamePasswordless	29105d11-1bed-40a5-9927-60d87c4deff3	keycloak
webAuthnPolicySignatureAlgorithmsPasswordless	29105d11-1bed-40a5-9927-60d87c4deff3	ES256,RS256
webAuthnPolicyRpIdPasswordless	29105d11-1bed-40a5-9927-60d87c4deff3	
webAuthnPolicyAttestationConveyancePreferencePasswordless	29105d11-1bed-40a5-9927-60d87c4deff3	not specified
webAuthnPolicyAuthenticatorAttachmentPasswordless	29105d11-1bed-40a5-9927-60d87c4deff3	not specified
webAuthnPolicyRequireResidentKeyPasswordless	29105d11-1bed-40a5-9927-60d87c4deff3	not specified
webAuthnPolicyUserVerificationRequirementPasswordless	29105d11-1bed-40a5-9927-60d87c4deff3	not specified
webAuthnPolicyCreateTimeoutPasswordless	29105d11-1bed-40a5-9927-60d87c4deff3	0
webAuthnPolicyAvoidSameAuthenticatorRegisterPasswordless	29105d11-1bed-40a5-9927-60d87c4deff3	false
cibaBackchannelTokenDeliveryMode	29105d11-1bed-40a5-9927-60d87c4deff3	poll
cibaExpiresIn	29105d11-1bed-40a5-9927-60d87c4deff3	120
cibaInterval	29105d11-1bed-40a5-9927-60d87c4deff3	5
cibaAuthRequestedUserHint	29105d11-1bed-40a5-9927-60d87c4deff3	login_hint
parRequestUriLifespan	29105d11-1bed-40a5-9927-60d87c4deff3	60
firstBrokerLoginFlowId	29105d11-1bed-40a5-9927-60d87c4deff3	40918f65-f3fd-4f7d-a839-1b665c6d3214
\.


--
-- Data for Name: realm_default_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.realm_default_groups (realm_id, group_id) FROM stdin;
\.


--
-- Data for Name: realm_enabled_event_types; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.realm_enabled_event_types (realm_id, value) FROM stdin;
\.


--
-- Data for Name: realm_events_listeners; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.realm_events_listeners (realm_id, value) FROM stdin;
29bb8813-da75-41e0-b440-8ab491e3ec8a	jboss-logging
29105d11-1bed-40a5-9927-60d87c4deff3	jboss-logging
\.


--
-- Data for Name: realm_localizations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.realm_localizations (realm_id, locale, texts) FROM stdin;
\.


--
-- Data for Name: realm_required_credential; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.realm_required_credential (type, form_label, input, secret, realm_id) FROM stdin;
password	password	t	t	29bb8813-da75-41e0-b440-8ab491e3ec8a
password	password	t	t	29105d11-1bed-40a5-9927-60d87c4deff3
\.


--
-- Data for Name: realm_smtp_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.realm_smtp_config (realm_id, value, name) FROM stdin;
\.


--
-- Data for Name: realm_supported_locales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.realm_supported_locales (realm_id, value) FROM stdin;
\.


--
-- Data for Name: redirect_uris; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.redirect_uris (client_id, value) FROM stdin;
d6fae655-39e6-4ff5-b705-e23facd2ef68	/realms/master/account/*
3178bb2f-9cbe-425d-a613-e8ffea66389e	/realms/master/account/*
39a33722-8fc5-45a0-b730-61e79cde444e	/admin/master/console/*
121642cc-8d33-4fbc-b80d-39f4e1f8b22c	/realms/agentshield/account/*
db01877c-dcdc-4373-8120-6e7b48e26bab	/realms/agentshield/account/*
7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	/admin/agentshield/console/*
bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	*
3863be94-a32c-41dd-80c6-a847175f3a96	*
78fd174d-495c-4a9c-88ca-271608bc4f5f	*
\.


--
-- Data for Name: required_action_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.required_action_config (required_action_id, value, name) FROM stdin;
\.


--
-- Data for Name: required_action_provider; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.required_action_provider (id, alias, name, realm_id, enabled, default_action, provider_id, priority) FROM stdin;
77411c07-3145-4273-b799-31f8e259b55c	VERIFY_EMAIL	Verify Email	29bb8813-da75-41e0-b440-8ab491e3ec8a	t	f	VERIFY_EMAIL	50
14a21ae9-373c-45b3-932e-3564b05cc08a	UPDATE_PROFILE	Update Profile	29bb8813-da75-41e0-b440-8ab491e3ec8a	t	f	UPDATE_PROFILE	40
b6f05634-600d-4212-8dfe-42a899766e1d	CONFIGURE_TOTP	Configure OTP	29bb8813-da75-41e0-b440-8ab491e3ec8a	t	f	CONFIGURE_TOTP	10
c8a1f811-4ee3-4e7e-a360-e60da943bf5f	UPDATE_PASSWORD	Update Password	29bb8813-da75-41e0-b440-8ab491e3ec8a	t	f	UPDATE_PASSWORD	30
f7bb41b1-5285-44ba-a19a-4dcdee29dc44	TERMS_AND_CONDITIONS	Terms and Conditions	29bb8813-da75-41e0-b440-8ab491e3ec8a	f	f	TERMS_AND_CONDITIONS	20
55d30e61-7647-4966-8eef-904fcf5a19a6	delete_account	Delete Account	29bb8813-da75-41e0-b440-8ab491e3ec8a	f	f	delete_account	60
a992b3ef-11a3-4a20-af3c-4584c8b06eba	delete_credential	Delete Credential	29bb8813-da75-41e0-b440-8ab491e3ec8a	t	f	delete_credential	100
94c03bbe-f9d8-40ec-b9a2-0df80879e51c	update_user_locale	Update User Locale	29bb8813-da75-41e0-b440-8ab491e3ec8a	t	f	update_user_locale	1000
6f080591-40f1-4a78-90ca-343decdef5ff	webauthn-register	Webauthn Register	29bb8813-da75-41e0-b440-8ab491e3ec8a	t	f	webauthn-register	70
55a4a629-66b6-4ccf-b602-bd0d23607ac7	webauthn-register-passwordless	Webauthn Register Passwordless	29bb8813-da75-41e0-b440-8ab491e3ec8a	t	f	webauthn-register-passwordless	80
a08b6101-53d9-4739-824b-401235b5e51a	VERIFY_PROFILE	Verify Profile	29bb8813-da75-41e0-b440-8ab491e3ec8a	t	f	VERIFY_PROFILE	90
6a762c1e-6720-453d-bbd4-4d92cfbfe071	VERIFY_EMAIL	Verify Email	29105d11-1bed-40a5-9927-60d87c4deff3	t	f	VERIFY_EMAIL	50
6d438aa0-74f7-4238-bcc9-401b902c15fc	UPDATE_PROFILE	Update Profile	29105d11-1bed-40a5-9927-60d87c4deff3	t	f	UPDATE_PROFILE	40
d29f4fee-2bcf-47a3-9cdf-8fed332f72b9	CONFIGURE_TOTP	Configure OTP	29105d11-1bed-40a5-9927-60d87c4deff3	t	f	CONFIGURE_TOTP	10
c77c54f6-1e0d-42f1-9d1a-c36071413678	UPDATE_PASSWORD	Update Password	29105d11-1bed-40a5-9927-60d87c4deff3	t	f	UPDATE_PASSWORD	30
55e5a3f5-ad0c-49c3-aa6e-8124369c0867	TERMS_AND_CONDITIONS	Terms and Conditions	29105d11-1bed-40a5-9927-60d87c4deff3	f	f	TERMS_AND_CONDITIONS	20
5ac76a16-4f75-419d-9db4-8b0005d30362	delete_account	Delete Account	29105d11-1bed-40a5-9927-60d87c4deff3	f	f	delete_account	60
d1438881-91f3-4d4e-85b6-d426889f1ee6	delete_credential	Delete Credential	29105d11-1bed-40a5-9927-60d87c4deff3	t	f	delete_credential	100
34dcfd02-cc0a-47aa-b2df-19fa0c0e7100	update_user_locale	Update User Locale	29105d11-1bed-40a5-9927-60d87c4deff3	t	f	update_user_locale	1000
33874ad8-4192-4458-a2c5-75aceb711537	webauthn-register	Webauthn Register	29105d11-1bed-40a5-9927-60d87c4deff3	t	f	webauthn-register	70
e912efe8-50a8-4fd8-aa7f-a30f90a52440	webauthn-register-passwordless	Webauthn Register Passwordless	29105d11-1bed-40a5-9927-60d87c4deff3	t	f	webauthn-register-passwordless	80
cee4d93c-f08a-4e56-a9c3-4d1cee7b6730	VERIFY_PROFILE	Verify Profile	29105d11-1bed-40a5-9927-60d87c4deff3	t	f	VERIFY_PROFILE	90
\.


--
-- Data for Name: resource_attribute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resource_attribute (id, name, value, resource_id) FROM stdin;
\.


--
-- Data for Name: resource_policy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resource_policy (resource_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_scope; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resource_scope (resource_id, scope_id) FROM stdin;
\.


--
-- Data for Name: resource_server; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resource_server (id, allow_rs_remote_mgmt, policy_enforce_mode, decision_strategy) FROM stdin;
\.


--
-- Data for Name: resource_server_perm_ticket; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resource_server_perm_ticket (id, owner, requester, created_timestamp, granted_timestamp, resource_id, scope_id, resource_server_id, policy_id) FROM stdin;
\.


--
-- Data for Name: resource_server_policy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resource_server_policy (id, name, description, type, decision_strategy, logic, resource_server_id, owner) FROM stdin;
\.


--
-- Data for Name: resource_server_resource; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resource_server_resource (id, name, type, icon_uri, owner, resource_server_id, owner_managed_access, display_name) FROM stdin;
\.


--
-- Data for Name: resource_server_scope; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resource_server_scope (id, name, icon_uri, resource_server_id, display_name) FROM stdin;
\.


--
-- Data for Name: resource_uris; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resource_uris (resource_id, value) FROM stdin;
\.


--
-- Data for Name: revoked_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.revoked_token (id, expire) FROM stdin;
\.


--
-- Data for Name: role_attribute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_attribute (id, role_id, name, value) FROM stdin;
\.


--
-- Data for Name: scope_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scope_mapping (client_id, role_id) FROM stdin;
3178bb2f-9cbe-425d-a613-e8ffea66389e	cf252c9e-b3ca-4ac4-973f-abe83d70c192
3178bb2f-9cbe-425d-a613-e8ffea66389e	cd8c1091-70ba-4947-b59a-8e57dc283b36
db01877c-dcdc-4373-8120-6e7b48e26bab	e2d67d67-d4a9-4b08-bc1c-8fc06bbc4217
db01877c-dcdc-4373-8120-6e7b48e26bab	85d650c3-5138-46b7-8e9d-00ad35d686dd
\.


--
-- Data for Name: scope_policy; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scope_policy (scope_id, policy_id) FROM stdin;
\.


--
-- Data for Name: user_attribute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_attribute (name, value, user_id, id, long_value_hash, long_value_hash_lower_case, long_value) FROM stdin;
is_temporary_admin	true	1eaa3f8c-721b-4120-8559-03892bf71cab	9e7a47fd-9810-4ce1-a344-13b34ba0da52	\N	\N	\N
\.


--
-- Data for Name: user_consent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_consent (id, client_id, user_id, created_date, last_updated_date, client_storage_provider, external_client_id) FROM stdin;
\.


--
-- Data for Name: user_consent_client_scope; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_consent_client_scope (user_consent_id, scope_id) FROM stdin;
\.


--
-- Data for Name: user_entity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_entity (id, email, email_constraint, email_verified, enabled, federation_link, first_name, last_name, realm_id, username, created_timestamp, service_account_client_link, not_before) FROM stdin;
1eaa3f8c-721b-4120-8559-03892bf71cab	\N	51832751-31bf-440a-8469-9c7827a443be	f	t	\N	\N	\N	29bb8813-da75-41e0-b440-8ab491e3ec8a	admin	1783384737823	\N	0
7f810329-29c0-4226-8625-7542a7cffd58	\N	7ce19184-be80-4a3b-bead-235a10b261b6	f	t	\N	\N	\N	29105d11-1bed-40a5-9927-60d87c4deff3	service-account-registry-api	1783384761151	bd97597a-9d6f-4748-8a6d-c5e9b45dfcbf	0
75c7c8b3-7d2d-46e1-8a7b-938dd3c157c6	platform-admin@agentshield.local	platform-admin@agentshield.local	t	t	\N	Platform	Admin	29105d11-1bed-40a5-9927-60d87c4deff3	platform-admin	1783384775157	\N	0
77afa81a-8073-4962-8e61-a1e942e52570	agent-reviewer@agentshield.local	agent-reviewer@agentshield.local	t	t	\N	Agent	Reviewer	29105d11-1bed-40a5-9927-60d87c4deff3	agent-reviewer	1783384782223	\N	0
643b0e62-b437-40f8-8104-57c34203624b	kalvagadda@hotmail.com	kalvagadda@hotmail.com	f	t	\N	kalyan kumar	kalvagadda	29105d11-1bed-40a5-9927-60d87c4deff3	kalyan	1783386659996	\N	0
\.


--
-- Data for Name: user_federation_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_federation_config (user_federation_provider_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_federation_mapper (id, name, federation_provider_id, federation_mapper_type, realm_id) FROM stdin;
\.


--
-- Data for Name: user_federation_mapper_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_federation_mapper_config (user_federation_mapper_id, value, name) FROM stdin;
\.


--
-- Data for Name: user_federation_provider; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_federation_provider (id, changed_sync_period, display_name, full_sync_period, last_sync, priority, provider_name, realm_id) FROM stdin;
\.


--
-- Data for Name: user_group_membership; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_group_membership (group_id, user_id, membership_type) FROM stdin;
\.


--
-- Data for Name: user_required_action; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_required_action (user_id, required_action) FROM stdin;
\.


--
-- Data for Name: user_role_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_role_mapping (role_id, user_id) FROM stdin;
bfb26ed5-54a0-4f24-8a6a-9c7402b830a7	1eaa3f8c-721b-4120-8559-03892bf71cab
54d75e83-bbab-4e17-bd53-dd86138a07cb	1eaa3f8c-721b-4120-8559-03892bf71cab
bd09041d-0741-445f-9d89-b73a04dcb1f7	7f810329-29c0-4226-8625-7542a7cffd58
bd09041d-0741-445f-9d89-b73a04dcb1f7	75c7c8b3-7d2d-46e1-8a7b-938dd3c157c6
bd09041d-0741-445f-9d89-b73a04dcb1f7	77afa81a-8073-4962-8e61-a1e942e52570
bd09041d-0741-445f-9d89-b73a04dcb1f7	643b0e62-b437-40f8-8104-57c34203624b
\.


--
-- Data for Name: username_login_failure; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.username_login_failure (realm_id, username, failed_login_not_before, last_failure, last_ip_failure, num_failures) FROM stdin;
\.


--
-- Data for Name: web_origins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.web_origins (client_id, value) FROM stdin;
39a33722-8fc5-45a0-b730-61e79cde444e	+
7c88bf75-cd83-4d4b-8ca9-79d9ac3a7009	+
78fd174d-495c-4a9c-88ca-271608bc4f5f	*
\.


--
-- Name: username_login_failure CONSTRAINT_17-2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.username_login_failure
    ADD CONSTRAINT "CONSTRAINT_17-2" PRIMARY KEY (realm_id, username);


--
-- Name: org_domain ORG_DOMAIN_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org_domain
    ADD CONSTRAINT "ORG_DOMAIN_pkey" PRIMARY KEY (id, name);


--
-- Name: org ORG_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT "ORG_pkey" PRIMARY KEY (id);


--
-- Name: keycloak_role UK_J3RWUVD56ONTGSUHOGM184WW2-2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT "UK_J3RWUVD56ONTGSUHOGM184WW2-2" UNIQUE (name, client_realm_constraint);


--
-- Name: client_auth_flow_bindings c_cli_flow_bind; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_auth_flow_bindings
    ADD CONSTRAINT c_cli_flow_bind PRIMARY KEY (client_id, binding_name);


--
-- Name: client_scope_client c_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_scope_client
    ADD CONSTRAINT c_cli_scope_bind PRIMARY KEY (client_id, scope_id);


--
-- Name: client_initial_access cnstr_client_init_acc_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT cnstr_client_init_acc_pk PRIMARY KEY (id);


--
-- Name: realm_default_groups con_group_id_def_groups; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT con_group_id_def_groups UNIQUE (group_id);


--
-- Name: broker_link constr_broker_link_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.broker_link
    ADD CONSTRAINT constr_broker_link_pk PRIMARY KEY (identity_provider, user_id);


--
-- Name: component_config constr_component_config_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT constr_component_config_pk PRIMARY KEY (id);


--
-- Name: component constr_component_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT constr_component_pk PRIMARY KEY (id);


--
-- Name: fed_user_required_action constr_fed_required_action; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fed_user_required_action
    ADD CONSTRAINT constr_fed_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: fed_user_attribute constr_fed_user_attr_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fed_user_attribute
    ADD CONSTRAINT constr_fed_user_attr_pk PRIMARY KEY (id);


--
-- Name: fed_user_consent constr_fed_user_consent_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fed_user_consent
    ADD CONSTRAINT constr_fed_user_consent_pk PRIMARY KEY (id);


--
-- Name: fed_user_credential constr_fed_user_cred_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fed_user_credential
    ADD CONSTRAINT constr_fed_user_cred_pk PRIMARY KEY (id);


--
-- Name: fed_user_group_membership constr_fed_user_group; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fed_user_group_membership
    ADD CONSTRAINT constr_fed_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: fed_user_role_mapping constr_fed_user_role; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fed_user_role_mapping
    ADD CONSTRAINT constr_fed_user_role PRIMARY KEY (role_id, user_id);


--
-- Name: federated_user constr_federated_user; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.federated_user
    ADD CONSTRAINT constr_federated_user PRIMARY KEY (id);


--
-- Name: realm_default_groups constr_realm_default_groups; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT constr_realm_default_groups PRIMARY KEY (realm_id, group_id);


--
-- Name: realm_enabled_event_types constr_realm_enabl_event_types; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT constr_realm_enabl_event_types PRIMARY KEY (realm_id, value);


--
-- Name: realm_events_listeners constr_realm_events_listeners; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT constr_realm_events_listeners PRIMARY KEY (realm_id, value);


--
-- Name: realm_supported_locales constr_realm_supported_locales; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT constr_realm_supported_locales PRIMARY KEY (realm_id, value);


--
-- Name: identity_provider constraint_2b; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT constraint_2b PRIMARY KEY (internal_id);


--
-- Name: client_attributes constraint_3c; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT constraint_3c PRIMARY KEY (client_id, name);


--
-- Name: event_entity constraint_4; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event_entity
    ADD CONSTRAINT constraint_4 PRIMARY KEY (id);


--
-- Name: federated_identity constraint_40; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT constraint_40 PRIMARY KEY (identity_provider, user_id);


--
-- Name: realm constraint_4a; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT constraint_4a PRIMARY KEY (id);


--
-- Name: user_federation_provider constraint_5c; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT constraint_5c PRIMARY KEY (id);


--
-- Name: client constraint_7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT constraint_7 PRIMARY KEY (id);


--
-- Name: scope_mapping constraint_81; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT constraint_81 PRIMARY KEY (client_id, role_id);


--
-- Name: client_node_registrations constraint_84; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT constraint_84 PRIMARY KEY (client_id, name);


--
-- Name: realm_attribute constraint_9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT constraint_9 PRIMARY KEY (name, realm_id);


--
-- Name: realm_required_credential constraint_92; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT constraint_92 PRIMARY KEY (realm_id, type);


--
-- Name: keycloak_role constraint_a; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT constraint_a PRIMARY KEY (id);


--
-- Name: admin_event_entity constraint_admin_event_entity; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin_event_entity
    ADD CONSTRAINT constraint_admin_event_entity PRIMARY KEY (id);


--
-- Name: authenticator_config_entry constraint_auth_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authenticator_config_entry
    ADD CONSTRAINT constraint_auth_cfg_pk PRIMARY KEY (authenticator_id, name);


--
-- Name: authentication_execution constraint_auth_exec_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT constraint_auth_exec_pk PRIMARY KEY (id);


--
-- Name: authentication_flow constraint_auth_flow_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT constraint_auth_flow_pk PRIMARY KEY (id);


--
-- Name: authenticator_config constraint_auth_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT constraint_auth_pk PRIMARY KEY (id);


--
-- Name: user_role_mapping constraint_c; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT constraint_c PRIMARY KEY (role_id, user_id);


--
-- Name: composite_role constraint_composite_role; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT constraint_composite_role PRIMARY KEY (composite, child_role);


--
-- Name: identity_provider_config constraint_d; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT constraint_d PRIMARY KEY (identity_provider_id, name);


--
-- Name: policy_config constraint_dpc; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT constraint_dpc PRIMARY KEY (policy_id, name);


--
-- Name: realm_smtp_config constraint_e; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT constraint_e PRIMARY KEY (realm_id, name);


--
-- Name: credential constraint_f; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT constraint_f PRIMARY KEY (id);


--
-- Name: user_federation_config constraint_f9; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT constraint_f9 PRIMARY KEY (user_federation_provider_id, name);


--
-- Name: resource_server_perm_ticket constraint_fapmt; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT constraint_fapmt PRIMARY KEY (id);


--
-- Name: resource_server_resource constraint_farsr; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT constraint_farsr PRIMARY KEY (id);


--
-- Name: resource_server_policy constraint_farsrp; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT constraint_farsrp PRIMARY KEY (id);


--
-- Name: associated_policy constraint_farsrpap; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT constraint_farsrpap PRIMARY KEY (policy_id, associated_policy_id);


--
-- Name: resource_policy constraint_farsrpp; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT constraint_farsrpp PRIMARY KEY (resource_id, policy_id);


--
-- Name: resource_server_scope constraint_farsrs; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT constraint_farsrs PRIMARY KEY (id);


--
-- Name: resource_scope constraint_farsrsp; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT constraint_farsrsp PRIMARY KEY (resource_id, scope_id);


--
-- Name: scope_policy constraint_farsrsps; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT constraint_farsrsps PRIMARY KEY (scope_id, policy_id);


--
-- Name: user_entity constraint_fb; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT constraint_fb PRIMARY KEY (id);


--
-- Name: user_federation_mapper_config constraint_fedmapper_cfg_pm; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT constraint_fedmapper_cfg_pm PRIMARY KEY (user_federation_mapper_id, name);


--
-- Name: user_federation_mapper constraint_fedmapperpm; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT constraint_fedmapperpm PRIMARY KEY (id);


--
-- Name: fed_user_consent_cl_scope constraint_fgrntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fed_user_consent_cl_scope
    ADD CONSTRAINT constraint_fgrntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent_client_scope constraint_grntcsnt_clsc_pm; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT constraint_grntcsnt_clsc_pm PRIMARY KEY (user_consent_id, scope_id);


--
-- Name: user_consent constraint_grntcsnt_pm; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT constraint_grntcsnt_pm PRIMARY KEY (id);


--
-- Name: keycloak_group constraint_group; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT constraint_group PRIMARY KEY (id);


--
-- Name: group_attribute constraint_group_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT constraint_group_attribute_pk PRIMARY KEY (id);


--
-- Name: group_role_mapping constraint_group_role; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT constraint_group_role PRIMARY KEY (role_id, group_id);


--
-- Name: identity_provider_mapper constraint_idpm; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT constraint_idpm PRIMARY KEY (id);


--
-- Name: idp_mapper_config constraint_idpmconfig; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT constraint_idpmconfig PRIMARY KEY (idp_mapper_id, name);


--
-- Name: migration_model constraint_migmod; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migration_model
    ADD CONSTRAINT constraint_migmod PRIMARY KEY (id);


--
-- Name: offline_client_session constraint_offl_cl_ses_pk3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offline_client_session
    ADD CONSTRAINT constraint_offl_cl_ses_pk3 PRIMARY KEY (user_session_id, client_id, client_storage_provider, external_client_id, offline_flag);


--
-- Name: offline_user_session constraint_offl_us_ses_pk2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.offline_user_session
    ADD CONSTRAINT constraint_offl_us_ses_pk2 PRIMARY KEY (user_session_id, offline_flag);


--
-- Name: protocol_mapper constraint_pcm; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT constraint_pcm PRIMARY KEY (id);


--
-- Name: protocol_mapper_config constraint_pmconfig; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT constraint_pmconfig PRIMARY KEY (protocol_mapper_id, name);


--
-- Name: redirect_uris constraint_redirect_uris; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT constraint_redirect_uris PRIMARY KEY (client_id, value);


--
-- Name: required_action_config constraint_req_act_cfg_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.required_action_config
    ADD CONSTRAINT constraint_req_act_cfg_pk PRIMARY KEY (required_action_id, name);


--
-- Name: required_action_provider constraint_req_act_prv_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT constraint_req_act_prv_pk PRIMARY KEY (id);


--
-- Name: user_required_action constraint_required_action; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT constraint_required_action PRIMARY KEY (required_action, user_id);


--
-- Name: resource_uris constraint_resour_uris_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT constraint_resour_uris_pk PRIMARY KEY (resource_id, value);


--
-- Name: role_attribute constraint_role_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT constraint_role_attribute_pk PRIMARY KEY (id);


--
-- Name: revoked_token constraint_rt; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.revoked_token
    ADD CONSTRAINT constraint_rt PRIMARY KEY (id);


--
-- Name: user_attribute constraint_user_attribute_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT constraint_user_attribute_pk PRIMARY KEY (id);


--
-- Name: user_group_membership constraint_user_group; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT constraint_user_group PRIMARY KEY (group_id, user_id);


--
-- Name: web_origins constraint_web_origins; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT constraint_web_origins PRIMARY KEY (client_id, value);


--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- Name: client_scope_attributes pk_cl_tmpl_attr; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT pk_cl_tmpl_attr PRIMARY KEY (scope_id, name);


--
-- Name: client_scope pk_cli_template; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT pk_cli_template PRIMARY KEY (id);


--
-- Name: resource_server pk_resource_server; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_server
    ADD CONSTRAINT pk_resource_server PRIMARY KEY (id);


--
-- Name: client_scope_role_mapping pk_template_scope; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT pk_template_scope PRIMARY KEY (scope_id, role_id);


--
-- Name: default_client_scope r_def_cli_scope_bind; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT r_def_cli_scope_bind PRIMARY KEY (realm_id, scope_id);


--
-- Name: realm_localizations realm_localizations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm_localizations
    ADD CONSTRAINT realm_localizations_pkey PRIMARY KEY (realm_id, locale);


--
-- Name: resource_attribute res_attr_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT res_attr_pk PRIMARY KEY (id);


--
-- Name: keycloak_group sibling_names; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.keycloak_group
    ADD CONSTRAINT sibling_names UNIQUE (realm_id, parent_group, name);


--
-- Name: identity_provider uk_2daelwnibji49avxsrtuf6xj33; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT uk_2daelwnibji49avxsrtuf6xj33 UNIQUE (provider_alias, realm_id);


--
-- Name: client uk_b71cjlbenv945rb6gcon438at; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT uk_b71cjlbenv945rb6gcon438at UNIQUE (realm_id, client_id);


--
-- Name: client_scope uk_cli_scope; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_scope
    ADD CONSTRAINT uk_cli_scope UNIQUE (realm_id, name);


--
-- Name: user_entity uk_dykn684sl8up1crfei6eckhd7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_dykn684sl8up1crfei6eckhd7 UNIQUE (realm_id, email_constraint);


--
-- Name: user_consent uk_external_consent; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT uk_external_consent UNIQUE (client_storage_provider, external_client_id, user_id);


--
-- Name: resource_server_resource uk_frsr6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5ha6 UNIQUE (name, owner, resource_server_id);


--
-- Name: resource_server_perm_ticket uk_frsr6t700s9v50bu18ws5pmt; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT uk_frsr6t700s9v50bu18ws5pmt UNIQUE (owner, requester, resource_server_id, resource_id, scope_id);


--
-- Name: resource_server_policy uk_frsrpt700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT uk_frsrpt700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: resource_server_scope uk_frsrst700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT uk_frsrst700s9v50bu18ws5ha6 UNIQUE (name, resource_server_id);


--
-- Name: user_consent uk_local_consent; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT uk_local_consent UNIQUE (client_id, user_id);


--
-- Name: org uk_org_alias; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT uk_org_alias UNIQUE (realm_id, alias);


--
-- Name: org uk_org_group; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT uk_org_group UNIQUE (group_id);


--
-- Name: org uk_org_name; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.org
    ADD CONSTRAINT uk_org_name UNIQUE (realm_id, name);


--
-- Name: realm uk_orvsdmla56612eaefiq6wl5oi; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm
    ADD CONSTRAINT uk_orvsdmla56612eaefiq6wl5oi UNIQUE (name);


--
-- Name: user_entity uk_ru8tt6t700s9v50bu18ws5ha6; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_entity
    ADD CONSTRAINT uk_ru8tt6t700s9v50bu18ws5ha6 UNIQUE (realm_id, username);


--
-- Name: fed_user_attr_long_values; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fed_user_attr_long_values ON public.fed_user_attribute USING btree (long_value_hash, name);


--
-- Name: fed_user_attr_long_values_lower_case; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fed_user_attr_long_values_lower_case ON public.fed_user_attribute USING btree (long_value_hash_lower_case, name);


--
-- Name: idx_admin_event_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_admin_event_time ON public.admin_event_entity USING btree (realm_id, admin_event_time);


--
-- Name: idx_assoc_pol_assoc_pol_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assoc_pol_assoc_pol_id ON public.associated_policy USING btree (associated_policy_id);


--
-- Name: idx_auth_config_realm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_auth_config_realm ON public.authenticator_config USING btree (realm_id);


--
-- Name: idx_auth_exec_flow; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_auth_exec_flow ON public.authentication_execution USING btree (flow_id);


--
-- Name: idx_auth_exec_realm_flow; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_auth_exec_realm_flow ON public.authentication_execution USING btree (realm_id, flow_id);


--
-- Name: idx_auth_flow_realm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_auth_flow_realm ON public.authentication_flow USING btree (realm_id);


--
-- Name: idx_cl_clscope; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_cl_clscope ON public.client_scope_client USING btree (scope_id);


--
-- Name: idx_client_att_by_name_value; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_client_att_by_name_value ON public.client_attributes USING btree (name, substr(value, 1, 255));


--
-- Name: idx_client_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_client_id ON public.client USING btree (client_id);


--
-- Name: idx_client_init_acc_realm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_client_init_acc_realm ON public.client_initial_access USING btree (realm_id);


--
-- Name: idx_clscope_attrs; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clscope_attrs ON public.client_scope_attributes USING btree (scope_id);


--
-- Name: idx_clscope_cl; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clscope_cl ON public.client_scope_client USING btree (client_id);


--
-- Name: idx_clscope_protmap; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clscope_protmap ON public.protocol_mapper USING btree (client_scope_id);


--
-- Name: idx_clscope_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_clscope_role ON public.client_scope_role_mapping USING btree (scope_id);


--
-- Name: idx_compo_config_compo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_compo_config_compo ON public.component_config USING btree (component_id);


--
-- Name: idx_component_provider_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_component_provider_type ON public.component USING btree (provider_type);


--
-- Name: idx_component_realm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_component_realm ON public.component USING btree (realm_id);


--
-- Name: idx_composite; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_composite ON public.composite_role USING btree (composite);


--
-- Name: idx_composite_child; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_composite_child ON public.composite_role USING btree (child_role);


--
-- Name: idx_defcls_realm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_defcls_realm ON public.default_client_scope USING btree (realm_id);


--
-- Name: idx_defcls_scope; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_defcls_scope ON public.default_client_scope USING btree (scope_id);


--
-- Name: idx_event_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_event_time ON public.event_entity USING btree (realm_id, event_time);


--
-- Name: idx_fedidentity_feduser; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fedidentity_feduser ON public.federated_identity USING btree (federated_user_id);


--
-- Name: idx_fedidentity_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fedidentity_user ON public.federated_identity USING btree (user_id);


--
-- Name: idx_fu_attribute; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fu_attribute ON public.fed_user_attribute USING btree (user_id, realm_id, name);


--
-- Name: idx_fu_cnsnt_ext; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fu_cnsnt_ext ON public.fed_user_consent USING btree (user_id, client_storage_provider, external_client_id);


--
-- Name: idx_fu_consent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fu_consent ON public.fed_user_consent USING btree (user_id, client_id);


--
-- Name: idx_fu_consent_ru; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fu_consent_ru ON public.fed_user_consent USING btree (realm_id, user_id);


--
-- Name: idx_fu_credential; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fu_credential ON public.fed_user_credential USING btree (user_id, type);


--
-- Name: idx_fu_credential_ru; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fu_credential_ru ON public.fed_user_credential USING btree (realm_id, user_id);


--
-- Name: idx_fu_group_membership; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fu_group_membership ON public.fed_user_group_membership USING btree (user_id, group_id);


--
-- Name: idx_fu_group_membership_ru; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fu_group_membership_ru ON public.fed_user_group_membership USING btree (realm_id, user_id);


--
-- Name: idx_fu_required_action; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fu_required_action ON public.fed_user_required_action USING btree (user_id, required_action);


--
-- Name: idx_fu_required_action_ru; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fu_required_action_ru ON public.fed_user_required_action USING btree (realm_id, user_id);


--
-- Name: idx_fu_role_mapping; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fu_role_mapping ON public.fed_user_role_mapping USING btree (user_id, role_id);


--
-- Name: idx_fu_role_mapping_ru; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_fu_role_mapping_ru ON public.fed_user_role_mapping USING btree (realm_id, user_id);


--
-- Name: idx_group_att_by_name_value; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_group_att_by_name_value ON public.group_attribute USING btree (name, ((value)::character varying(250)));


--
-- Name: idx_group_attr_group; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_group_attr_group ON public.group_attribute USING btree (group_id);


--
-- Name: idx_group_role_mapp_group; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_group_role_mapp_group ON public.group_role_mapping USING btree (group_id);


--
-- Name: idx_id_prov_mapp_realm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_id_prov_mapp_realm ON public.identity_provider_mapper USING btree (realm_id);


--
-- Name: idx_ident_prov_realm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ident_prov_realm ON public.identity_provider USING btree (realm_id);


--
-- Name: idx_idp_for_login; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_idp_for_login ON public.identity_provider USING btree (realm_id, enabled, link_only, hide_on_login, organization_id);


--
-- Name: idx_idp_realm_org; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_idp_realm_org ON public.identity_provider USING btree (realm_id, organization_id);


--
-- Name: idx_keycloak_role_client; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_keycloak_role_client ON public.keycloak_role USING btree (client);


--
-- Name: idx_keycloak_role_realm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_keycloak_role_realm ON public.keycloak_role USING btree (realm);


--
-- Name: idx_offline_uss_by_broker_session_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_offline_uss_by_broker_session_id ON public.offline_user_session USING btree (broker_session_id, realm_id);


--
-- Name: idx_offline_uss_by_last_session_refresh; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_offline_uss_by_last_session_refresh ON public.offline_user_session USING btree (realm_id, offline_flag, last_session_refresh);


--
-- Name: idx_offline_uss_by_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_offline_uss_by_user ON public.offline_user_session USING btree (user_id, realm_id, offline_flag);


--
-- Name: idx_org_domain_org_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_org_domain_org_id ON public.org_domain USING btree (org_id);


--
-- Name: idx_perm_ticket_owner; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_perm_ticket_owner ON public.resource_server_perm_ticket USING btree (owner);


--
-- Name: idx_perm_ticket_requester; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_perm_ticket_requester ON public.resource_server_perm_ticket USING btree (requester);


--
-- Name: idx_protocol_mapper_client; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_protocol_mapper_client ON public.protocol_mapper USING btree (client_id);


--
-- Name: idx_realm_attr_realm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_realm_attr_realm ON public.realm_attribute USING btree (realm_id);


--
-- Name: idx_realm_clscope; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_realm_clscope ON public.client_scope USING btree (realm_id);


--
-- Name: idx_realm_def_grp_realm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_realm_def_grp_realm ON public.realm_default_groups USING btree (realm_id);


--
-- Name: idx_realm_evt_list_realm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_realm_evt_list_realm ON public.realm_events_listeners USING btree (realm_id);


--
-- Name: idx_realm_evt_types_realm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_realm_evt_types_realm ON public.realm_enabled_event_types USING btree (realm_id);


--
-- Name: idx_realm_master_adm_cli; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_realm_master_adm_cli ON public.realm USING btree (master_admin_client);


--
-- Name: idx_realm_supp_local_realm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_realm_supp_local_realm ON public.realm_supported_locales USING btree (realm_id);


--
-- Name: idx_redir_uri_client; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_redir_uri_client ON public.redirect_uris USING btree (client_id);


--
-- Name: idx_req_act_prov_realm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_req_act_prov_realm ON public.required_action_provider USING btree (realm_id);


--
-- Name: idx_res_policy_policy; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_res_policy_policy ON public.resource_policy USING btree (policy_id);


--
-- Name: idx_res_scope_scope; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_res_scope_scope ON public.resource_scope USING btree (scope_id);


--
-- Name: idx_res_serv_pol_res_serv; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_res_serv_pol_res_serv ON public.resource_server_policy USING btree (resource_server_id);


--
-- Name: idx_res_srv_res_res_srv; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_res_srv_res_res_srv ON public.resource_server_resource USING btree (resource_server_id);


--
-- Name: idx_res_srv_scope_res_srv; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_res_srv_scope_res_srv ON public.resource_server_scope USING btree (resource_server_id);


--
-- Name: idx_rev_token_on_expire; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_rev_token_on_expire ON public.revoked_token USING btree (expire);


--
-- Name: idx_role_attribute; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_role_attribute ON public.role_attribute USING btree (role_id);


--
-- Name: idx_role_clscope; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_role_clscope ON public.client_scope_role_mapping USING btree (role_id);


--
-- Name: idx_scope_mapping_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scope_mapping_role ON public.scope_mapping USING btree (role_id);


--
-- Name: idx_scope_policy_policy; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scope_policy_policy ON public.scope_policy USING btree (policy_id);


--
-- Name: idx_update_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_update_time ON public.migration_model USING btree (update_time);


--
-- Name: idx_usconsent_clscope; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_usconsent_clscope ON public.user_consent_client_scope USING btree (user_consent_id);


--
-- Name: idx_usconsent_scope_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_usconsent_scope_id ON public.user_consent_client_scope USING btree (scope_id);


--
-- Name: idx_user_attribute; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_attribute ON public.user_attribute USING btree (user_id);


--
-- Name: idx_user_attribute_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_attribute_name ON public.user_attribute USING btree (name, value);


--
-- Name: idx_user_consent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_consent ON public.user_consent USING btree (user_id);


--
-- Name: idx_user_credential; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_credential ON public.credential USING btree (user_id);


--
-- Name: idx_user_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_email ON public.user_entity USING btree (email);


--
-- Name: idx_user_group_mapping; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_group_mapping ON public.user_group_membership USING btree (user_id);


--
-- Name: idx_user_reqactions; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_reqactions ON public.user_required_action USING btree (user_id);


--
-- Name: idx_user_role_mapping; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_role_mapping ON public.user_role_mapping USING btree (user_id);


--
-- Name: idx_user_service_account; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_service_account ON public.user_entity USING btree (realm_id, service_account_client_link);


--
-- Name: idx_usr_fed_map_fed_prv; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_usr_fed_map_fed_prv ON public.user_federation_mapper USING btree (federation_provider_id);


--
-- Name: idx_usr_fed_map_realm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_usr_fed_map_realm ON public.user_federation_mapper USING btree (realm_id);


--
-- Name: idx_usr_fed_prv_realm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_usr_fed_prv_realm ON public.user_federation_provider USING btree (realm_id);


--
-- Name: idx_web_orig_client; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_web_orig_client ON public.web_origins USING btree (client_id);


--
-- Name: user_attr_long_values; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_attr_long_values ON public.user_attribute USING btree (long_value_hash, name);


--
-- Name: user_attr_long_values_lower_case; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX user_attr_long_values_lower_case ON public.user_attribute USING btree (long_value_hash_lower_case, name);


--
-- Name: identity_provider fk2b4ebc52ae5c3b34; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider
    ADD CONSTRAINT fk2b4ebc52ae5c3b34 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: client_attributes fk3c47c64beacca966; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_attributes
    ADD CONSTRAINT fk3c47c64beacca966 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: federated_identity fk404288b92ef007a6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.federated_identity
    ADD CONSTRAINT fk404288b92ef007a6 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_node_registrations fk4129723ba992f594; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_node_registrations
    ADD CONSTRAINT fk4129723ba992f594 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: redirect_uris fk_1burs8pb4ouj97h5wuppahv9f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redirect_uris
    ADD CONSTRAINT fk_1burs8pb4ouj97h5wuppahv9f FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: user_federation_provider fk_1fj32f6ptolw2qy60cd8n01e8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_federation_provider
    ADD CONSTRAINT fk_1fj32f6ptolw2qy60cd8n01e8 FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_required_credential fk_5hg65lybevavkqfki3kponh9v; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm_required_credential
    ADD CONSTRAINT fk_5hg65lybevavkqfki3kponh9v FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_attribute fk_5hrm2vlf9ql5fu022kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu022kqepovbr FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: user_attribute fk_5hrm2vlf9ql5fu043kqepovbr; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_attribute
    ADD CONSTRAINT fk_5hrm2vlf9ql5fu043kqepovbr FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: user_required_action fk_6qj3w1jw9cvafhe19bwsiuvmd; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_required_action
    ADD CONSTRAINT fk_6qj3w1jw9cvafhe19bwsiuvmd FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: keycloak_role fk_6vyqfe4cn4wlq8r6kt5vdsj5c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.keycloak_role
    ADD CONSTRAINT fk_6vyqfe4cn4wlq8r6kt5vdsj5c FOREIGN KEY (realm) REFERENCES public.realm(id);


--
-- Name: realm_smtp_config fk_70ej8xdxgxd0b9hh6180irr0o; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm_smtp_config
    ADD CONSTRAINT fk_70ej8xdxgxd0b9hh6180irr0o FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_attribute fk_8shxd6l3e9atqukacxgpffptw; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm_attribute
    ADD CONSTRAINT fk_8shxd6l3e9atqukacxgpffptw FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: composite_role fk_a63wvekftu8jo1pnj81e7mce2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_a63wvekftu8jo1pnj81e7mce2 FOREIGN KEY (composite) REFERENCES public.keycloak_role(id);


--
-- Name: authentication_execution fk_auth_exec_flow; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_flow FOREIGN KEY (flow_id) REFERENCES public.authentication_flow(id);


--
-- Name: authentication_execution fk_auth_exec_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authentication_execution
    ADD CONSTRAINT fk_auth_exec_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authentication_flow fk_auth_flow_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authentication_flow
    ADD CONSTRAINT fk_auth_flow_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: authenticator_config fk_auth_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authenticator_config
    ADD CONSTRAINT fk_auth_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_role_mapping fk_c4fqv34p1mbylloxang7b1q3l; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_role_mapping
    ADD CONSTRAINT fk_c4fqv34p1mbylloxang7b1q3l FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: client_scope_attributes fk_cl_scope_attr_scope; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_scope_attributes
    ADD CONSTRAINT fk_cl_scope_attr_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_scope_role_mapping fk_cl_scope_rm_scope; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_scope_role_mapping
    ADD CONSTRAINT fk_cl_scope_rm_scope FOREIGN KEY (scope_id) REFERENCES public.client_scope(id);


--
-- Name: protocol_mapper fk_cli_scope_mapper; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_cli_scope_mapper FOREIGN KEY (client_scope_id) REFERENCES public.client_scope(id);


--
-- Name: client_initial_access fk_client_init_acc_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.client_initial_access
    ADD CONSTRAINT fk_client_init_acc_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: component_config fk_component_config; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.component_config
    ADD CONSTRAINT fk_component_config FOREIGN KEY (component_id) REFERENCES public.component(id);


--
-- Name: component fk_component_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.component
    ADD CONSTRAINT fk_component_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_default_groups fk_def_groups_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm_default_groups
    ADD CONSTRAINT fk_def_groups_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_mapper_config fk_fedmapper_cfg; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_federation_mapper_config
    ADD CONSTRAINT fk_fedmapper_cfg FOREIGN KEY (user_federation_mapper_id) REFERENCES public.user_federation_mapper(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_fedprv; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_fedprv FOREIGN KEY (federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_federation_mapper fk_fedmapperpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_federation_mapper
    ADD CONSTRAINT fk_fedmapperpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: associated_policy fk_frsr5s213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsr5s213xcx4wnkog82ssrfy FOREIGN KEY (associated_policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrasp13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrasp13xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog82sspmt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82sspmt FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_resource fk_frsrho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_server_resource
    ADD CONSTRAINT fk_frsrho213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog83sspmt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog83sspmt FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_server_perm_ticket fk_frsrho213xcx4wnkog84sspmt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrho213xcx4wnkog84sspmt FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: associated_policy fk_frsrpas14xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.associated_policy
    ADD CONSTRAINT fk_frsrpas14xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: scope_policy fk_frsrpass3xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scope_policy
    ADD CONSTRAINT fk_frsrpass3xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_perm_ticket fk_frsrpo2128cx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_server_perm_ticket
    ADD CONSTRAINT fk_frsrpo2128cx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_server_policy fk_frsrpo213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_server_policy
    ADD CONSTRAINT fk_frsrpo213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: resource_scope fk_frsrpos13xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrpos13xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpos53xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpos53xcx4wnkog82ssrfy FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: resource_policy fk_frsrpp213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_policy
    ADD CONSTRAINT fk_frsrpp213xcx4wnkog82ssrfy FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: resource_scope fk_frsrps213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_scope
    ADD CONSTRAINT fk_frsrps213xcx4wnkog82ssrfy FOREIGN KEY (scope_id) REFERENCES public.resource_server_scope(id);


--
-- Name: resource_server_scope fk_frsrso213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_server_scope
    ADD CONSTRAINT fk_frsrso213xcx4wnkog82ssrfy FOREIGN KEY (resource_server_id) REFERENCES public.resource_server(id);


--
-- Name: composite_role fk_gr7thllb9lu8q4vqa4524jjy8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.composite_role
    ADD CONSTRAINT fk_gr7thllb9lu8q4vqa4524jjy8 FOREIGN KEY (child_role) REFERENCES public.keycloak_role(id);


--
-- Name: user_consent_client_scope fk_grntcsnt_clsc_usc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_consent_client_scope
    ADD CONSTRAINT fk_grntcsnt_clsc_usc FOREIGN KEY (user_consent_id) REFERENCES public.user_consent(id);


--
-- Name: user_consent fk_grntcsnt_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_consent
    ADD CONSTRAINT fk_grntcsnt_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: group_attribute fk_group_attribute_group; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_attribute
    ADD CONSTRAINT fk_group_attribute_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: group_role_mapping fk_group_role_group; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.group_role_mapping
    ADD CONSTRAINT fk_group_role_group FOREIGN KEY (group_id) REFERENCES public.keycloak_group(id);


--
-- Name: realm_enabled_event_types fk_h846o4h0w8epx5nwedrf5y69j; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm_enabled_event_types
    ADD CONSTRAINT fk_h846o4h0w8epx5nwedrf5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: realm_events_listeners fk_h846o4h0w8epx5nxev9f5y69j; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm_events_listeners
    ADD CONSTRAINT fk_h846o4h0w8epx5nxev9f5y69j FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: identity_provider_mapper fk_idpm_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider_mapper
    ADD CONSTRAINT fk_idpm_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: idp_mapper_config fk_idpmconfig; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.idp_mapper_config
    ADD CONSTRAINT fk_idpmconfig FOREIGN KEY (idp_mapper_id) REFERENCES public.identity_provider_mapper(id);


--
-- Name: web_origins fk_lojpho213xcx4wnkog82ssrfy; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.web_origins
    ADD CONSTRAINT fk_lojpho213xcx4wnkog82ssrfy FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: scope_mapping fk_ouse064plmlr732lxjcn1q5f1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scope_mapping
    ADD CONSTRAINT fk_ouse064plmlr732lxjcn1q5f1 FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: protocol_mapper fk_pcm_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.protocol_mapper
    ADD CONSTRAINT fk_pcm_realm FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: credential fk_pfyr0glasqyl0dei3kl69r6v0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.credential
    ADD CONSTRAINT fk_pfyr0glasqyl0dei3kl69r6v0 FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: protocol_mapper_config fk_pmconfig; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.protocol_mapper_config
    ADD CONSTRAINT fk_pmconfig FOREIGN KEY (protocol_mapper_id) REFERENCES public.protocol_mapper(id);


--
-- Name: default_client_scope fk_r_def_cli_scope_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.default_client_scope
    ADD CONSTRAINT fk_r_def_cli_scope_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: required_action_provider fk_req_act_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.required_action_provider
    ADD CONSTRAINT fk_req_act_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: resource_uris fk_resource_server_uris; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resource_uris
    ADD CONSTRAINT fk_resource_server_uris FOREIGN KEY (resource_id) REFERENCES public.resource_server_resource(id);


--
-- Name: role_attribute fk_role_attribute_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_attribute
    ADD CONSTRAINT fk_role_attribute_id FOREIGN KEY (role_id) REFERENCES public.keycloak_role(id);


--
-- Name: realm_supported_locales fk_supported_locales_realm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.realm_supported_locales
    ADD CONSTRAINT fk_supported_locales_realm FOREIGN KEY (realm_id) REFERENCES public.realm(id);


--
-- Name: user_federation_config fk_t13hpu1j94r2ebpekr39x5eu5; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_federation_config
    ADD CONSTRAINT fk_t13hpu1j94r2ebpekr39x5eu5 FOREIGN KEY (user_federation_provider_id) REFERENCES public.user_federation_provider(id);


--
-- Name: user_group_membership fk_user_group_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_group_membership
    ADD CONSTRAINT fk_user_group_user FOREIGN KEY (user_id) REFERENCES public.user_entity(id);


--
-- Name: policy_config fkdc34197cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policy_config
    ADD CONSTRAINT fkdc34197cf864c4e43 FOREIGN KEY (policy_id) REFERENCES public.resource_server_policy(id);


--
-- Name: identity_provider_config fkdc4897cf864c4e43; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.identity_provider_config
    ADD CONSTRAINT fkdc4897cf864c4e43 FOREIGN KEY (identity_provider_id) REFERENCES public.identity_provider(internal_id);


--
-- Name: DATABASE keycloak; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE keycloak TO keycloak_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO keycloak_user;


--
-- PostgreSQL database dump complete
--

\unrestrict n1etryO2MJJGAs4QaZ1des44nowfSsYp8G3J4ne3FDa76tb8dPRhRXLV7vxwCrV

--
-- Database "langfuse" dump
--

--
-- PostgreSQL database dump
--

\restrict gTkvYoLR9NbF8klYfA2QcRhzgWyRfBfqf8A2zgwqKEjHHEwvhNhlaEeXbGuEvQJ

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: langfuse; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE langfuse WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE langfuse OWNER TO postgres;

\unrestrict gTkvYoLR9NbF8klYfA2QcRhzgWyRfBfqf8A2zgwqKEjHHEwvhNhlaEeXbGuEvQJ
\connect langfuse
\restrict gTkvYoLR9NbF8klYfA2QcRhzgWyRfBfqf8A2zgwqKEjHHEwvhNhlaEeXbGuEvQJ

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ActionExecutionStatus; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."ActionExecutionStatus" AS ENUM (
    'COMPLETED',
    'ERROR',
    'PENDING',
    'CANCELLED'
);


ALTER TYPE public."ActionExecutionStatus" OWNER TO langfuse_user;

--
-- Name: ActionType; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."ActionType" AS ENUM (
    'WEBHOOK',
    'SLACK',
    'GITHUB_DISPATCH'
);


ALTER TYPE public."ActionType" OWNER TO langfuse_user;

--
-- Name: AnalyticsIntegrationExportSource; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."AnalyticsIntegrationExportSource" AS ENUM (
    'TRACES_OBSERVATIONS',
    'TRACES_OBSERVATIONS_EVENTS',
    'EVENTS'
);


ALTER TYPE public."AnalyticsIntegrationExportSource" OWNER TO langfuse_user;

--
-- Name: AnnotationQueueObjectType; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."AnnotationQueueObjectType" AS ENUM (
    'TRACE',
    'OBSERVATION',
    'SESSION'
);


ALTER TYPE public."AnnotationQueueObjectType" OWNER TO langfuse_user;

--
-- Name: AnnotationQueueStatus; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."AnnotationQueueStatus" AS ENUM (
    'PENDING',
    'COMPLETED'
);


ALTER TYPE public."AnnotationQueueStatus" OWNER TO langfuse_user;

--
-- Name: ApiKeyScope; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."ApiKeyScope" AS ENUM (
    'ORGANIZATION',
    'PROJECT'
);


ALTER TYPE public."ApiKeyScope" OWNER TO langfuse_user;

--
-- Name: AuditLogRecordType; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."AuditLogRecordType" AS ENUM (
    'USER',
    'API_KEY'
);


ALTER TYPE public."AuditLogRecordType" OWNER TO langfuse_user;

--
-- Name: BlobStorageExportMode; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."BlobStorageExportMode" AS ENUM (
    'FULL_HISTORY',
    'FROM_TODAY',
    'FROM_CUSTOM_DATE'
);


ALTER TYPE public."BlobStorageExportMode" OWNER TO langfuse_user;

--
-- Name: BlobStorageIntegrationFileType; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."BlobStorageIntegrationFileType" AS ENUM (
    'JSON',
    'CSV',
    'JSONL',
    'PARQUET'
);


ALTER TYPE public."BlobStorageIntegrationFileType" OWNER TO langfuse_user;

--
-- Name: BlobStorageIntegrationType; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."BlobStorageIntegrationType" AS ENUM (
    'S3',
    'S3_COMPATIBLE',
    'AZURE_BLOB_STORAGE'
);


ALTER TYPE public."BlobStorageIntegrationType" OWNER TO langfuse_user;

--
-- Name: CommentObjectType; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."CommentObjectType" AS ENUM (
    'TRACE',
    'OBSERVATION',
    'SESSION',
    'PROMPT'
);


ALTER TYPE public."CommentObjectType" OWNER TO langfuse_user;

--
-- Name: DashboardWidgetChartType; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."DashboardWidgetChartType" AS ENUM (
    'LINE_TIME_SERIES',
    'BAR_TIME_SERIES',
    'HORIZONTAL_BAR',
    'VERTICAL_BAR',
    'PIE',
    'NUMBER',
    'HISTOGRAM',
    'PIVOT_TABLE',
    'AREA_TIME_SERIES'
);


ALTER TYPE public."DashboardWidgetChartType" OWNER TO langfuse_user;

--
-- Name: DashboardWidgetViews; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."DashboardWidgetViews" AS ENUM (
    'TRACES',
    'OBSERVATIONS',
    'SCORES_NUMERIC',
    'SCORES_CATEGORICAL'
);


ALTER TYPE public."DashboardWidgetViews" OWNER TO langfuse_user;

--
-- Name: DatasetStatus; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."DatasetStatus" AS ENUM (
    'ACTIVE',
    'ARCHIVED'
);


ALTER TYPE public."DatasetStatus" OWNER TO langfuse_user;

--
-- Name: EvalTemplateSourceCodeLanguage; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."EvalTemplateSourceCodeLanguage" AS ENUM (
    'PYTHON',
    'TYPESCRIPT'
);


ALTER TYPE public."EvalTemplateSourceCodeLanguage" OWNER TO langfuse_user;

--
-- Name: EvalTemplateType; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."EvalTemplateType" AS ENUM (
    'LLM_AS_JUDGE',
    'CODE'
);


ALTER TYPE public."EvalTemplateType" OWNER TO langfuse_user;

--
-- Name: EvaluatorBlockReason; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."EvaluatorBlockReason" AS ENUM (
    'LLM_CONNECTION_AUTH_INVALID',
    'LLM_CONNECTION_MISSING',
    'DEFAULT_EVAL_MODEL_MISSING',
    'EVAL_MODEL_CONFIG_INVALID',
    'EVAL_MODEL_UNAVAILABLE',
    'PROVIDER_ACCOUNT_NOT_READY'
);


ALTER TYPE public."EvaluatorBlockReason" OWNER TO langfuse_user;

--
-- Name: InAppAgentConversationVisibilityScope; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."InAppAgentConversationVisibilityScope" AS ENUM (
    'PERSONAL',
    'PROJECT'
);


ALTER TYPE public."InAppAgentConversationVisibilityScope" OWNER TO langfuse_user;

--
-- Name: JobConfigState; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."JobConfigState" AS ENUM (
    'ACTIVE',
    'INACTIVE'
);


ALTER TYPE public."JobConfigState" OWNER TO langfuse_user;

--
-- Name: JobExecutionStatus; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."JobExecutionStatus" AS ENUM (
    'COMPLETED',
    'ERROR',
    'PENDING',
    'CANCELLED',
    'DELAYED'
);


ALTER TYPE public."JobExecutionStatus" OWNER TO langfuse_user;

--
-- Name: JobType; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."JobType" AS ENUM (
    'EVAL'
);


ALTER TYPE public."JobType" OWNER TO langfuse_user;

--
-- Name: MonitorSeverity; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."MonitorSeverity" AS ENUM (
    'PAUSED',
    'UNKNOWN',
    'NO_DATA',
    'OK',
    'WARNING',
    'ALERT'
);


ALTER TYPE public."MonitorSeverity" OWNER TO langfuse_user;

--
-- Name: MonitorStatus; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."MonitorStatus" AS ENUM (
    'PAUSED',
    'ACTIVE',
    'ERROR_BAD_QUERY'
);


ALTER TYPE public."MonitorStatus" OWNER TO langfuse_user;

--
-- Name: MonitorThresholdOperator; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."MonitorThresholdOperator" AS ENUM (
    'GT',
    'GTE',
    'LT',
    'LTE',
    'EQ',
    'NEQ'
);


ALTER TYPE public."MonitorThresholdOperator" OWNER TO langfuse_user;

--
-- Name: MonitorView; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."MonitorView" AS ENUM (
    'OBSERVATIONS',
    'SCORES_NUMERIC',
    'SCORES_CATEGORICAL'
);


ALTER TYPE public."MonitorView" OWNER TO langfuse_user;

--
-- Name: NotificationChannel; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."NotificationChannel" AS ENUM (
    'EMAIL'
);


ALTER TYPE public."NotificationChannel" OWNER TO langfuse_user;

--
-- Name: NotificationType; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."NotificationType" AS ENUM (
    'COMMENT_MENTION'
);


ALTER TYPE public."NotificationType" OWNER TO langfuse_user;

--
-- Name: ObservationLevel; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."ObservationLevel" AS ENUM (
    'DEBUG',
    'DEFAULT',
    'WARNING',
    'ERROR'
);


ALTER TYPE public."ObservationLevel" OWNER TO langfuse_user;

--
-- Name: ObservationType; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."ObservationType" AS ENUM (
    'SPAN',
    'EVENT',
    'GENERATION',
    'AGENT',
    'TOOL',
    'CHAIN',
    'RETRIEVER',
    'EVALUATOR',
    'EMBEDDING',
    'GUARDRAIL'
);


ALTER TYPE public."ObservationType" OWNER TO langfuse_user;

--
-- Name: Role; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."Role" AS ENUM (
    'OWNER',
    'ADMIN',
    'MEMBER',
    'VIEWER',
    'NONE'
);


ALTER TYPE public."Role" OWNER TO langfuse_user;

--
-- Name: ScoreConfigDataType; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."ScoreConfigDataType" AS ENUM (
    'CATEGORICAL',
    'NUMERIC',
    'BOOLEAN',
    'TEXT'
);


ALTER TYPE public."ScoreConfigDataType" OWNER TO langfuse_user;

--
-- Name: ScoreSource; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."ScoreSource" AS ENUM (
    'ANNOTATION',
    'API',
    'EVAL'
);


ALTER TYPE public."ScoreSource" OWNER TO langfuse_user;

--
-- Name: SurveyName; Type: TYPE; Schema: public; Owner: langfuse_user
--

CREATE TYPE public."SurveyName" AS ENUM (
    'org_onboarding',
    'user_onboarding'
);


ALTER TYPE public."SurveyName" OWNER TO langfuse_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Account; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text,
    user_id text NOT NULL,
    expires_in integer,
    ext_expires_in integer,
    refresh_token_expires_in integer,
    created_at integer
);


ALTER TABLE public."Account" OWNER TO langfuse_user;

--
-- Name: Session; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    expires timestamp(3) without time zone NOT NULL,
    session_token text NOT NULL,
    user_id text NOT NULL
);


ALTER TABLE public."Session" OWNER TO langfuse_user;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO langfuse_user;

--
-- Name: actions; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.actions (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL,
    type public."ActionType" NOT NULL,
    config jsonb NOT NULL
);


ALTER TABLE public.actions OWNER TO langfuse_user;

--
-- Name: annotation_queue_assignments; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.annotation_queue_assignments (
    id text NOT NULL,
    project_id text NOT NULL,
    user_id text NOT NULL,
    queue_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.annotation_queue_assignments OWNER TO langfuse_user;

--
-- Name: annotation_queue_items; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.annotation_queue_items (
    id text NOT NULL,
    queue_id text NOT NULL,
    object_id text NOT NULL,
    object_type public."AnnotationQueueObjectType" NOT NULL,
    status public."AnnotationQueueStatus" DEFAULT 'PENDING'::public."AnnotationQueueStatus" NOT NULL,
    locked_at timestamp(3) without time zone,
    locked_by_user_id text,
    annotator_user_id text,
    completed_at timestamp(3) without time zone,
    project_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.annotation_queue_items OWNER TO langfuse_user;

--
-- Name: annotation_queues; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.annotation_queues (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    score_config_ids text[] DEFAULT ARRAY[]::text[],
    project_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.annotation_queues OWNER TO langfuse_user;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.api_keys (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    note text,
    public_key text CONSTRAINT api_keys_publishable_key_not_null NOT NULL,
    hashed_secret_key text NOT NULL,
    display_secret_key text NOT NULL,
    last_used_at timestamp(3) without time zone,
    expires_at timestamp(3) without time zone,
    project_id text,
    fast_hashed_secret_key text,
    organization_id text,
    scope public."ApiKeyScope" DEFAULT 'PROJECT'::public."ApiKeyScope" NOT NULL,
    is_in_app_agent_key boolean DEFAULT false NOT NULL
);


ALTER TABLE public.api_keys OWNER TO langfuse_user;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    user_id text,
    project_id text,
    resource_type text NOT NULL,
    resource_id text NOT NULL,
    action text NOT NULL,
    before text,
    after text,
    org_id text NOT NULL,
    user_org_role text,
    user_project_role text,
    api_key_id text,
    type public."AuditLogRecordType" DEFAULT 'USER'::public."AuditLogRecordType" NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO langfuse_user;

--
-- Name: automation_executions; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.automation_executions (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    source_id text NOT NULL,
    automation_id text NOT NULL,
    trigger_id text NOT NULL,
    action_id text NOT NULL,
    project_id text NOT NULL,
    status public."ActionExecutionStatus" DEFAULT 'PENDING'::public."ActionExecutionStatus" NOT NULL,
    input jsonb NOT NULL,
    output jsonb,
    started_at timestamp(3) without time zone,
    finished_at timestamp(3) without time zone,
    error text
);


ALTER TABLE public.automation_executions OWNER TO langfuse_user;

--
-- Name: automations; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.automations (
    id text NOT NULL,
    name text NOT NULL,
    trigger_id text NOT NULL,
    action_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL
);


ALTER TABLE public.automations OWNER TO langfuse_user;

--
-- Name: background_migrations; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.background_migrations (
    id text NOT NULL,
    name text NOT NULL,
    script text NOT NULL,
    args jsonb NOT NULL,
    finished_at timestamp(3) without time zone,
    failed_at timestamp(3) without time zone,
    failed_reason text,
    worker_id text,
    locked_at timestamp(3) without time zone,
    state jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.background_migrations OWNER TO langfuse_user;

--
-- Name: batch_actions; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.batch_actions (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL,
    user_id text NOT NULL,
    action_type text NOT NULL,
    table_name text NOT NULL,
    status text NOT NULL,
    finished_at timestamp(3) without time zone,
    query jsonb NOT NULL,
    config jsonb,
    total_count integer,
    processed_count integer,
    failed_count integer,
    log text
);


ALTER TABLE public.batch_actions OWNER TO langfuse_user;

--
-- Name: batch_exports; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.batch_exports (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL,
    user_id text NOT NULL,
    finished_at timestamp(3) without time zone,
    expires_at timestamp(3) without time zone,
    name text NOT NULL,
    status text NOT NULL,
    query jsonb NOT NULL,
    format text NOT NULL,
    url text,
    log text
);


ALTER TABLE public.batch_exports OWNER TO langfuse_user;

--
-- Name: billing_meter_backups; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.billing_meter_backups (
    stripe_customer_id text NOT NULL,
    meter_id text NOT NULL,
    start_time timestamp(3) without time zone NOT NULL,
    end_time timestamp(3) without time zone NOT NULL,
    aggregated_value integer NOT NULL,
    event_name text NOT NULL,
    org_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.billing_meter_backups OWNER TO langfuse_user;

--
-- Name: blob_storage_integrations; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.blob_storage_integrations (
    project_id text NOT NULL,
    type public."BlobStorageIntegrationType" NOT NULL,
    bucket_name text NOT NULL,
    prefix text NOT NULL,
    access_key_id text,
    secret_access_key text,
    region text NOT NULL,
    endpoint text,
    force_path_style boolean NOT NULL,
    next_sync_at timestamp(3) without time zone,
    last_sync_at timestamp(3) without time zone,
    enabled boolean NOT NULL,
    export_frequency text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    file_type public."BlobStorageIntegrationFileType" DEFAULT 'CSV'::public."BlobStorageIntegrationFileType" NOT NULL,
    export_mode public."BlobStorageExportMode" DEFAULT 'FULL_HISTORY'::public."BlobStorageExportMode" NOT NULL,
    export_start_date timestamp(3) without time zone,
    export_source public."AnalyticsIntegrationExportSource" DEFAULT 'TRACES_OBSERVATIONS'::public."AnalyticsIntegrationExportSource" NOT NULL,
    last_error text,
    last_error_at timestamp(3) without time zone,
    last_failure_notification_sent_at timestamp(3) without time zone,
    compressed boolean DEFAULT true NOT NULL,
    export_field_groups text[] DEFAULT ARRAY['core'::text, 'basic'::text, 'time'::text, 'io'::text, 'metadata'::text, 'model'::text, 'usage'::text, 'prompt'::text, 'metrics'::text, 'tools'::text, 'trace_context'::text] NOT NULL,
    run_started_at timestamp(3) without time zone,
    export_tuning jsonb
);


ALTER TABLE public.blob_storage_integrations OWNER TO langfuse_user;

--
-- Name: cloud_spend_alerts; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.cloud_spend_alerts (
    id text NOT NULL,
    org_id text NOT NULL,
    title text NOT NULL,
    threshold numeric(65,30) NOT NULL,
    triggered_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.cloud_spend_alerts OWNER TO langfuse_user;

--
-- Name: comment_reactions; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.comment_reactions (
    id text NOT NULL,
    project_id text NOT NULL,
    comment_id text NOT NULL,
    user_id text NOT NULL,
    emoji text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.comment_reactions OWNER TO langfuse_user;

--
-- Name: comments; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.comments (
    id text NOT NULL,
    project_id text NOT NULL,
    object_type public."CommentObjectType" NOT NULL,
    object_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    content text NOT NULL,
    author_user_id text,
    data_field text,
    path text[] DEFAULT '{}'::text[],
    range_start integer[] DEFAULT '{}'::integer[],
    range_end integer[] DEFAULT '{}'::integer[]
);


ALTER TABLE public.comments OWNER TO langfuse_user;

--
-- Name: cron_jobs; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.cron_jobs (
    name text NOT NULL,
    last_run timestamp(3) without time zone,
    state text,
    job_started_at timestamp(3) without time zone
);


ALTER TABLE public.cron_jobs OWNER TO langfuse_user;

--
-- Name: dashboard_widgets; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.dashboard_widgets (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by text,
    updated_by text,
    project_id text,
    name text NOT NULL,
    description text NOT NULL,
    view public."DashboardWidgetViews" NOT NULL,
    dimensions jsonb NOT NULL,
    metrics jsonb NOT NULL,
    filters jsonb NOT NULL,
    chart_type public."DashboardWidgetChartType" NOT NULL,
    chart_config jsonb NOT NULL,
    min_version integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.dashboard_widgets OWNER TO langfuse_user;

--
-- Name: dashboards; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.dashboards (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by text,
    updated_by text,
    project_id text,
    name text NOT NULL,
    description text NOT NULL,
    definition jsonb NOT NULL,
    filters jsonb DEFAULT '[]'::jsonb NOT NULL
);


ALTER TABLE public.dashboards OWNER TO langfuse_user;

--
-- Name: dataset_item_media; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.dataset_item_media (
    id text NOT NULL,
    project_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    media_id text NOT NULL,
    dataset_id text NOT NULL,
    dataset_item_id text NOT NULL,
    dataset_item_valid_from timestamp(3) without time zone,
    field text NOT NULL,
    json_path text,
    reference_string text
);


ALTER TABLE public.dataset_item_media OWNER TO langfuse_user;

--
-- Name: dataset_items; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.dataset_items (
    id text NOT NULL,
    input jsonb,
    expected_output jsonb,
    source_observation_id text,
    dataset_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status public."DatasetStatus" DEFAULT 'ACTIVE'::public."DatasetStatus",
    source_trace_id text,
    metadata jsonb,
    project_id text NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    valid_from timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    valid_to timestamp(3) without time zone
);


ALTER TABLE public.dataset_items OWNER TO langfuse_user;

--
-- Name: dataset_run_items; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.dataset_run_items (
    id text NOT NULL,
    dataset_run_id text NOT NULL,
    dataset_item_id text NOT NULL,
    observation_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    trace_id text NOT NULL,
    project_id text NOT NULL
);


ALTER TABLE public.dataset_run_items OWNER TO langfuse_user;

--
-- Name: dataset_runs; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.dataset_runs (
    id text NOT NULL,
    name text NOT NULL,
    dataset_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    metadata jsonb,
    description text,
    project_id text NOT NULL
);


ALTER TABLE public.dataset_runs OWNER TO langfuse_user;

--
-- Name: datasets; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.datasets (
    id text NOT NULL,
    name text NOT NULL,
    project_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    description text,
    metadata jsonb,
    remote_experiment_payload jsonb,
    remote_experiment_url text,
    expected_output_schema json,
    input_schema json,
    remote_experiment_enabled boolean DEFAULT true NOT NULL
);


ALTER TABLE public.datasets OWNER TO langfuse_user;

--
-- Name: default_llm_models; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.default_llm_models (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL,
    llm_api_key_id text NOT NULL,
    provider text NOT NULL,
    adapter text NOT NULL,
    model text NOT NULL,
    model_params jsonb
);


ALTER TABLE public.default_llm_models OWNER TO langfuse_user;

--
-- Name: default_views; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.default_views (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL,
    user_id text,
    view_name text NOT NULL,
    view_id text NOT NULL
);


ALTER TABLE public.default_views OWNER TO langfuse_user;

--
-- Name: eval_templates; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.eval_templates (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text,
    name text NOT NULL,
    version integer NOT NULL,
    prompt text,
    model text,
    model_params jsonb,
    vars text[] DEFAULT ARRAY[]::text[],
    output_schema jsonb,
    provider text,
    partner text,
    type public."EvalTemplateType" DEFAULT 'LLM_AS_JUDGE'::public."EvalTemplateType" NOT NULL,
    source_code character varying(262144),
    source_code_language public."EvalTemplateSourceCodeLanguage"
);


ALTER TABLE public.eval_templates OWNER TO langfuse_user;

--
-- Name: in_app_agent_conversations; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.in_app_agent_conversations (
    id text NOT NULL,
    project_id text NOT NULL,
    created_by_user_id text,
    title text,
    visibility_scope public."InAppAgentConversationVisibilityScope" DEFAULT 'PERSONAL'::public."InAppAgentConversationVisibilityScope" NOT NULL,
    provider_session_id text,
    deleted_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    renamed_by_user_at timestamp(3) without time zone
);


ALTER TABLE public.in_app_agent_conversations OWNER TO langfuse_user;

--
-- Name: in_app_agent_events; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.in_app_agent_events (
    project_id text NOT NULL,
    conversation_id text NOT NULL,
    run_id text NOT NULL,
    sequence_number integer NOT NULL,
    type text NOT NULL,
    event jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.in_app_agent_events OWNER TO langfuse_user;

--
-- Name: in_app_agent_pending_tool_approvals; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.in_app_agent_pending_tool_approvals (
    project_id text NOT NULL,
    conversation_id text NOT NULL,
    tool_call_id text NOT NULL,
    approval_fingerprint text CONSTRAINT in_app_agent_pending_tool_approva_approval_fingerprint_not_null NOT NULL,
    expires_at timestamp(3) without time zone NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.in_app_agent_pending_tool_approvals OWNER TO langfuse_user;

--
-- Name: in_app_agent_runs; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.in_app_agent_runs (
    id text NOT NULL,
    project_id text NOT NULL,
    conversation_id text NOT NULL,
    triggered_by_user_id text,
    model text,
    mcp_api_key_id text,
    error_code text,
    error_message text,
    finished_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.in_app_agent_runs OWNER TO langfuse_user;

--
-- Name: job_configurations; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.job_configurations (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL,
    job_type public."JobType" NOT NULL,
    eval_template_id text,
    score_name text NOT NULL,
    filter jsonb NOT NULL,
    target_object text NOT NULL,
    variable_mapping jsonb NOT NULL,
    sampling numeric(65,30) NOT NULL,
    delay integer NOT NULL,
    status public."JobConfigState" DEFAULT 'ACTIVE'::public."JobConfigState" NOT NULL,
    time_scope text[] DEFAULT ARRAY['NEW'::text],
    blocked_at timestamp(3) without time zone,
    block_reason public."EvaluatorBlockReason",
    block_message text
);


ALTER TABLE public.job_configurations OWNER TO langfuse_user;

--
-- Name: job_executions; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.job_executions (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL,
    job_configuration_id text NOT NULL,
    status public."JobExecutionStatus" NOT NULL,
    start_time timestamp(3) without time zone,
    end_time timestamp(3) without time zone,
    error text,
    job_input_trace_id text,
    job_output_score_id text,
    job_input_dataset_item_id text,
    job_input_observation_id text,
    job_template_id text,
    job_input_trace_timestamp timestamp(3) without time zone,
    execution_trace_id text,
    job_input_dataset_item_valid_from timestamp(3) without time zone
);


ALTER TABLE public.job_executions OWNER TO langfuse_user;

--
-- Name: llm_api_keys; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.llm_api_keys (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    provider text NOT NULL,
    display_secret_key text NOT NULL,
    secret_key text NOT NULL,
    project_id text NOT NULL,
    base_url text,
    adapter text NOT NULL,
    custom_models text[] DEFAULT '{}'::text[] NOT NULL,
    with_default_models boolean DEFAULT true NOT NULL,
    config jsonb,
    extra_headers text,
    extra_header_keys text[] DEFAULT '{}'::text[] NOT NULL
);


ALTER TABLE public.llm_api_keys OWNER TO langfuse_user;

--
-- Name: llm_schemas; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.llm_schemas (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    schema json NOT NULL
);


ALTER TABLE public.llm_schemas OWNER TO langfuse_user;

--
-- Name: llm_tools; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.llm_tools (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    parameters json NOT NULL
);


ALTER TABLE public.llm_tools OWNER TO langfuse_user;

--
-- Name: media; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.media (
    id text NOT NULL,
    sha_256_hash character(44) NOT NULL,
    project_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    uploaded_at timestamp(3) without time zone,
    upload_http_status integer,
    upload_http_error text,
    bucket_path text NOT NULL,
    bucket_name text NOT NULL,
    content_type text NOT NULL,
    content_length bigint NOT NULL
);


ALTER TABLE public.media OWNER TO langfuse_user;

--
-- Name: membership_invitations; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.membership_invitations (
    id text NOT NULL,
    email text NOT NULL,
    project_id text,
    invited_by_user_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    org_id text NOT NULL,
    org_role public."Role" NOT NULL,
    project_role public."Role"
);


ALTER TABLE public.membership_invitations OWNER TO langfuse_user;

--
-- Name: mixpanel_integrations; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.mixpanel_integrations (
    project_id text NOT NULL,
    encrypted_mixpanel_project_token text NOT NULL,
    mixpanel_region text NOT NULL,
    last_sync_at timestamp(3) without time zone,
    enabled boolean NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    export_source public."AnalyticsIntegrationExportSource" DEFAULT 'TRACES_OBSERVATIONS'::public."AnalyticsIntegrationExportSource" NOT NULL
);


ALTER TABLE public.mixpanel_integrations OWNER TO langfuse_user;

--
-- Name: models; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.models (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text,
    model_name text NOT NULL,
    match_pattern text NOT NULL,
    start_date timestamp(3) without time zone,
    input_price numeric(65,30),
    output_price numeric(65,30),
    total_price numeric(65,30),
    unit text,
    tokenizer_config jsonb,
    tokenizer_id text
);


ALTER TABLE public.models OWNER TO langfuse_user;

--
-- Name: monitors; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.monitors (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_by text,
    updated_by text,
    project_id text NOT NULL,
    view public."MonitorView" NOT NULL,
    filters jsonb NOT NULL,
    metric jsonb NOT NULL,
    window_ms bigint NOT NULL,
    cadence_ms bigint NOT NULL,
    threshold_operator public."MonitorThresholdOperator" NOT NULL,
    alert_threshold numeric(65,30) NOT NULL,
    warning_threshold numeric(65,30),
    severity public."MonitorSeverity" DEFAULT 'UNKNOWN'::public."MonitorSeverity" NOT NULL,
    severity_changed_at timestamp(3) without time zone,
    no_data jsonb NOT NULL,
    renotify jsonb NOT NULL,
    status public."MonitorStatus" DEFAULT 'ACTIVE'::public."MonitorStatus" NOT NULL,
    scheduler_batch_id bigint NOT NULL,
    next_run_at timestamp(3) without time zone,
    last_published_at timestamp(3) without time zone,
    last_completed_at timestamp(3) without time zone,
    name text NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    alerted_at timestamp(3) without time zone,
    trigger_ids text[] DEFAULT ARRAY[]::text[] NOT NULL,
    last_claimed_at timestamp(3) without time zone
);


ALTER TABLE public.monitors OWNER TO langfuse_user;

--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.notification_preferences (
    id text NOT NULL,
    user_id text NOT NULL,
    project_id text NOT NULL,
    channel public."NotificationChannel" NOT NULL,
    type public."NotificationType" NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.notification_preferences OWNER TO langfuse_user;

--
-- Name: observation_media; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.observation_media (
    id text NOT NULL,
    project_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    media_id text NOT NULL,
    trace_id text NOT NULL,
    observation_id text NOT NULL,
    field text NOT NULL
);


ALTER TABLE public.observation_media OWNER TO langfuse_user;

--
-- Name: observations; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.observations (
    id text NOT NULL,
    name text,
    start_time timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    end_time timestamp(3) without time zone,
    parent_observation_id text,
    type public."ObservationType" NOT NULL,
    trace_id text,
    metadata jsonb,
    model text,
    "modelParameters" jsonb,
    input jsonb,
    output jsonb,
    level public."ObservationLevel" DEFAULT 'DEFAULT'::public."ObservationLevel" NOT NULL,
    status_message text,
    completion_start_time timestamp(3) without time zone,
    completion_tokens integer DEFAULT 0 NOT NULL,
    prompt_tokens integer DEFAULT 0 NOT NULL,
    total_tokens integer DEFAULT 0 NOT NULL,
    version text,
    project_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    unit text,
    prompt_id text,
    input_cost numeric(65,30),
    output_cost numeric(65,30),
    total_cost numeric(65,30),
    internal_model text,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    calculated_input_cost numeric(65,30),
    calculated_output_cost numeric(65,30),
    calculated_total_cost numeric(65,30),
    internal_model_id text
);


ALTER TABLE public.observations OWNER TO langfuse_user;

--
-- Name: organization_memberships; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.organization_memberships (
    id text NOT NULL,
    org_id text NOT NULL,
    user_id text NOT NULL,
    role public."Role" NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.organization_memberships OWNER TO langfuse_user;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.organizations (
    id text NOT NULL,
    name text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    cloud_config jsonb,
    metadata jsonb,
    ai_features_enabled boolean DEFAULT false NOT NULL,
    cloud_billing_cycle_anchor timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP,
    cloud_billing_cycle_updated_at timestamp(3) without time zone,
    cloud_current_cycle_usage integer,
    cloud_free_tier_usage_threshold_state text,
    ai_telemetry_enabled boolean DEFAULT true NOT NULL,
    sfdc_org_id text
);


ALTER TABLE public.organizations OWNER TO langfuse_user;

--
-- Name: pending_deletions; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.pending_deletions (
    id text NOT NULL,
    project_id text NOT NULL,
    object text NOT NULL,
    object_id text NOT NULL,
    is_deleted boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.pending_deletions OWNER TO langfuse_user;

--
-- Name: posthog_integrations; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.posthog_integrations (
    project_id text NOT NULL,
    encrypted_posthog_api_key text NOT NULL,
    posthog_host_name text NOT NULL,
    last_sync_at timestamp(3) without time zone,
    enabled boolean NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    export_source public."AnalyticsIntegrationExportSource" DEFAULT 'TRACES_OBSERVATIONS'::public."AnalyticsIntegrationExportSource" NOT NULL
);


ALTER TABLE public.posthog_integrations OWNER TO langfuse_user;

--
-- Name: prices; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.prices (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    model_id text NOT NULL,
    usage_type text NOT NULL,
    price numeric(65,30) NOT NULL,
    project_id text,
    pricing_tier_id text NOT NULL
);


ALTER TABLE public.prices OWNER TO langfuse_user;

--
-- Name: pricing_tiers; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.pricing_tiers (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    model_id text NOT NULL,
    name text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    priority integer NOT NULL,
    conditions jsonb NOT NULL
);


ALTER TABLE public.pricing_tiers OWNER TO langfuse_user;

--
-- Name: project_memberships; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.project_memberships (
    project_id text CONSTRAINT memberships_project_id_not_null NOT NULL,
    user_id text CONSTRAINT memberships_user_id_not_null NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP CONSTRAINT memberships_created_at_not_null NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP CONSTRAINT memberships_updated_at_not_null NOT NULL,
    org_membership_id text NOT NULL,
    role public."Role" NOT NULL
);


ALTER TABLE public.project_memberships OWNER TO langfuse_user;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.projects (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    name text NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    org_id text NOT NULL,
    deleted_at timestamp(3) without time zone,
    retention_days integer,
    metadata jsonb,
    has_traces boolean DEFAULT false NOT NULL
);


ALTER TABLE public.projects OWNER TO langfuse_user;

--
-- Name: prompt_dependencies; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.prompt_dependencies (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL,
    parent_id text NOT NULL,
    child_name text NOT NULL,
    child_label text,
    child_version integer
);


ALTER TABLE public.prompt_dependencies OWNER TO langfuse_user;

--
-- Name: prompt_protected_labels; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.prompt_protected_labels (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL,
    label text NOT NULL
);


ALTER TABLE public.prompt_protected_labels OWNER TO langfuse_user;

--
-- Name: prompts; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.prompts (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL,
    created_by text NOT NULL,
    name text NOT NULL,
    version integer NOT NULL,
    is_active boolean,
    config json DEFAULT '{}'::json NOT NULL,
    prompt jsonb NOT NULL,
    type text DEFAULT 'text'::text NOT NULL,
    tags text[] DEFAULT ARRAY[]::text[],
    labels text[] DEFAULT ARRAY[]::text[],
    commit_message text
);


ALTER TABLE public.prompts OWNER TO langfuse_user;

--
-- Name: score_configs; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.score_configs (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL,
    name text NOT NULL,
    data_type public."ScoreConfigDataType" NOT NULL,
    is_archived boolean DEFAULT false NOT NULL,
    min_value double precision,
    max_value double precision,
    categories jsonb,
    description text
);


ALTER TABLE public.score_configs OWNER TO langfuse_user;

--
-- Name: scores; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.scores (
    id text NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    name text NOT NULL,
    value double precision,
    observation_id text,
    trace_id text NOT NULL,
    comment text,
    source public."ScoreSource" NOT NULL,
    project_id text NOT NULL,
    author_user_id text,
    config_id text,
    data_type public."ScoreConfigDataType" DEFAULT 'NUMERIC'::public."ScoreConfigDataType" NOT NULL,
    string_value text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    queue_id text
);


ALTER TABLE public.scores OWNER TO langfuse_user;

--
-- Name: slack_integrations; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.slack_integrations (
    id text NOT NULL,
    project_id text NOT NULL,
    team_id text NOT NULL,
    team_name text NOT NULL,
    bot_token text NOT NULL,
    bot_user_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.slack_integrations OWNER TO langfuse_user;

--
-- Name: sso_configs; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.sso_configs (
    domain text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    auth_provider text NOT NULL,
    auth_config jsonb
);


ALTER TABLE public.sso_configs OWNER TO langfuse_user;

--
-- Name: surveys; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.surveys (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    survey_name public."SurveyName" NOT NULL,
    response jsonb NOT NULL,
    user_id text,
    user_email text,
    org_id text
);


ALTER TABLE public.surveys OWNER TO langfuse_user;

--
-- Name: table_view_presets; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.table_view_presets (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL,
    name text NOT NULL,
    table_name text NOT NULL,
    created_by text,
    updated_by text,
    filters jsonb NOT NULL,
    column_order jsonb NOT NULL,
    column_visibility jsonb NOT NULL,
    search_query text,
    order_by jsonb
);


ALTER TABLE public.table_view_presets OWNER TO langfuse_user;

--
-- Name: trace_media; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.trace_media (
    id text NOT NULL,
    project_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    media_id text NOT NULL,
    trace_id text NOT NULL,
    field text NOT NULL
);


ALTER TABLE public.trace_media OWNER TO langfuse_user;

--
-- Name: trace_sessions; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.trace_sessions (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL,
    bookmarked boolean DEFAULT false NOT NULL,
    public boolean DEFAULT false NOT NULL,
    environment text DEFAULT 'default'::text NOT NULL
);


ALTER TABLE public.trace_sessions OWNER TO langfuse_user;

--
-- Name: traces; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.traces (
    id text NOT NULL,
    "timestamp" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    name text,
    project_id text NOT NULL,
    metadata jsonb,
    external_id text,
    user_id text,
    release text,
    version text,
    public boolean DEFAULT false NOT NULL,
    bookmarked boolean DEFAULT false NOT NULL,
    input jsonb,
    output jsonb,
    session_id text,
    tags text[] DEFAULT ARRAY[]::text[],
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.traces OWNER TO langfuse_user;

--
-- Name: triggers; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.triggers (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL,
    "eventSource" text NOT NULL,
    "eventActions" text[],
    filter jsonb,
    status public."JobConfigState" DEFAULT 'ACTIVE'::public."JobConfigState" NOT NULL
);


ALTER TABLE public.triggers OWNER TO langfuse_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text,
    email text,
    email_verified timestamp(3) without time zone,
    password text,
    image text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    feature_flags text[] DEFAULT ARRAY[]::text[],
    admin boolean DEFAULT false NOT NULL,
    v4_beta_enabled boolean DEFAULT false NOT NULL
);


ALTER TABLE public.users OWNER TO langfuse_user;

--
-- Name: verification_tokens; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.verification_tokens (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.verification_tokens OWNER TO langfuse_user;

--
-- Name: verified_domains; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.verified_domains (
    id text NOT NULL,
    organization_id text NOT NULL,
    domain text NOT NULL,
    verification_token text NOT NULL,
    verified_at timestamp(3) without time zone,
    created_by_user_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.verified_domains OWNER TO langfuse_user;

--
-- Name: web_callout_endpoints; Type: TABLE; Schema: public; Owner: langfuse_user
--

CREATE TABLE public.web_callout_endpoints (
    id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    project_id text NOT NULL,
    name text DEFAULT 'Default'::text NOT NULL,
    url text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    toast_message text DEFAULT 'Callout sent'::text NOT NULL,
    request_headers text,
    request_header_keys text[] DEFAULT '{}'::text[] NOT NULL
);


ALTER TABLE public.web_callout_endpoints OWNER TO langfuse_user;

--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public."Account" (id, type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state, user_id, expires_in, ext_expires_in, refresh_token_expires_in, created_at) FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public."Session" (id, expires, session_token, user_id) FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
e90ad55c-6227-43d6-9abf-b6be45f8cd74	45fc679b7dbbe0f2954623bfe4e29932374cdc3167f8395728ef5c20115e5665	2026-07-07 00:38:51.419715+00	20230518191501_init	\N	\N	2026-07-07 00:38:51.413946+00	1
942e9db2-a41e-4860-8050-f93140e5f1ea	b9c79e332b90d28b1711534e53622f297a6a888aa7d6c1c1832185d1fef2c929	2026-07-07 00:38:51.422837+00	20230518193415_add_observaionts_and_traces	\N	\N	2026-07-07 00:38:51.420057+00	1
e79b12af-0911-486d-9001-61d1fa2f13c6	2f2fd22c3cc8bd21f6f23c88b7d5ef34674431520d0e55a37f8239e4a58afebd	2026-07-07 00:38:51.512019+00	20230518193521_changes	\N	\N	2026-07-07 00:38:51.423136+00	1
e3550ac1-2491-4e46-a99f-7d09553744c6	d2c9bf829418360a44d1022156aaa8e95df92c940b5dfe962f8a7f7260cb5520	2026-07-07 00:38:51.515242+00	20230522092340_add_metrics_and_observation_types	\N	\N	2026-07-07 00:38:51.512434+00	1
e8c02731-39ec-4f2f-9d65-4627fab97d1e	28c59a2bd9b846d914083efdc1b51eb96a1db66af370b3dddd5040a57ec9088b	2026-07-07 00:38:51.516974+00	20230522094431_endtime_optional	\N	\N	2026-07-07 00:38:51.515637+00	1
bd93648c-e858-4679-9eb4-d4d9d0846bee	755b1309b9c12e892f5a5f6db4e14f15b2d77ab61f76baab4c3621ea5e94fa6c	2026-07-07 00:38:51.518617+00	20230522131516_default_timestamp	\N	\N	2026-07-07 00:38:51.517386+00	1
d1ec8152-c12f-4c6f-aaa8-9529fecd53ca	66607eae9ccdfb92f30d859bcff0838e5df64c76da43ffbb25a65845dc63234e	2026-07-07 00:38:51.521529+00	20230523082455_rename_metrics_to_gradings	\N	\N	2026-07-07 00:38:51.519112+00	1
47a9c342-aa73-42c6-af3e-c2470c605a97	ff4107185d8f98b9d850e571a464bb806dade0f482984b3e29c019cb4d51397c	2026-07-07 00:38:51.524324+00	20230523084523_rename_to_score	\N	\N	2026-07-07 00:38:51.521796+00	1
47c4a4b2-e3ca-4ad0-af42-b23c2e2f93cb	ab80a534dfa4779eeae4ae5aeac192eea19b283671d6083c8f112e3c8a4229df	2026-07-07 00:38:51.526184+00	20230529140133_user_add_pw	\N	\N	2026-07-07 00:38:51.52483+00	1
8f7c1132-4d79-47fb-aa54-86a0b5f32325	f0ef0a5663ceecf04816edea38d3fe93cf07f4c8031d2b7e185ec2e5fe39f0fa	2026-07-07 00:38:51.61317+00	20230530204241_auth_api_ui	\N	\N	2026-07-07 00:38:51.526621+00	1
1e08a8cd-3b5b-4555-8ddc-a702a2ffdd4b	5e2e9d168251bab10d33e5f65a848c48d5f4ab762427ddd0f81e907c3339eb9a	2026-07-07 00:38:51.614799+00	20230618125818_remove_status_from_trace	\N	\N	2026-07-07 00:38:51.613553+00	1
4074077b-11ac-49b0-b2a9-3055b87173be	a7808d643321e4bf3d0628b256abb7d088e964c48698af6fdd7f32969dfd41aa	2026-07-07 00:38:51.617841+00	20230620181114_restructure	\N	\N	2026-07-07 00:38:51.615036+00	1
eea539dd-d47f-4724-acc2-1ccc0bbce161	025c499c8b6f13676087e2e419671177a85a3ebad3a53cf84c7f70b0cfe01efe	2026-07-07 00:38:51.619441+00	20230622114254_new_oservations	\N	\N	2026-07-07 00:38:51.618151+00	1
f036c82d-1a3d-4bc1-8df4-1259432da87d	6462cebefe054956e2fa9948435590bd4dae0d58f75cf2ecba57059f2c0909f8	2026-07-07 00:38:51.621038+00	20230623172401_observation_add_level_and_status_message	\N	\N	2026-07-07 00:38:51.619701+00	1
f4106204-657e-4ca0-988c-b3be55ff0514	2480f771a6b4dea1f541c0b231784e5cebf2c443ac7636da6a411c4914f1cbd4	2026-07-07 00:38:51.622478+00	20230626095337_external_trace_id	\N	\N	2026-07-07 00:38:51.621303+00	1
2340f926-e908-49de-ba60-10a1a9d9d898	e5b55a82f4be9d623abac6ef0d9d00da2bf437f60454ed46bb1defa30e388692	2026-07-07 00:38:51.623842+00	20230705160335_add_created_updated_timestamps	\N	\N	2026-07-07 00:38:51.622701+00	1
7420bbde-0c7b-4564-b260-f171b903319b	83f6a1d39c744faecc145e812f8ecca54267ac363f6315aa8afc3d890bf1f02d	2026-07-07 00:38:51.625148+00	20230706195819_add_completion_start_time	\N	\N	2026-07-07 00:38:51.62406+00	1
a1bace4d-a7b9-4a29-a004-9a3b7a2cd176	ffbe75ad538d26b0864f8b8915115e0fbdd56fbc93a4d3a634d53488b741d403	2026-07-07 00:38:51.626563+00	20230707132314_traces_project_id_index	\N	\N	2026-07-07 00:38:51.625394+00	1
b7478965-0335-47c4-9802-1832cc84ab8d	362123c958d4fd06df3c816b74b4336ad2373f1505be12c84046e1364dd9dc10	2026-07-07 00:38:51.627923+00	20230707133415_user_add_email_index	\N	\N	2026-07-07 00:38:51.62683+00	1
3acf09ee-6273-4d64-8d40-f5abfa5eb637	e7de5bcadea82b38002ead42a8e99f532e5fe2c178ba53d5954ef2c60a0115b3	2026-07-07 00:38:51.630186+00	20230710105741_added_indices	\N	\N	2026-07-07 00:38:51.628273+00	1
68cabb05-b704-4cb4-9dc3-e88b17a25b28	18a5a7ffe2b0ec8c008a1336826e3e07525f42a27e981f0a778533947b09e92d	2026-07-07 00:38:51.631504+00	20230710114928_traces_add_user_id	\N	\N	2026-07-07 00:38:51.630413+00	1
2cd6df74-b1db-416d-88ee-c1a8ab332b98	c418394abc6167c883f1456639e995ab5054a8257e8dba37b7a95c76ba59af0c	2026-07-07 00:38:51.632829+00	20230710200816_scores_add_comment	\N	\N	2026-07-07 00:38:51.63175+00	1
af39516c-8243-4428-bacb-2d1254dffa19	f7c8e195215bf8a82ff89093a94aef748c209361aa05a48273f2084c49f05cd6	2026-07-07 00:38:51.712748+00	20230711104810_traces_add_index	\N	\N	2026-07-07 00:38:51.633164+00	1
580b02de-f7fb-4892-ba5f-2aa0d6ff8222	5755c1c8449e6a74016e9e7e42acc446746a3c41f21e07c317a66417fd399d94	2026-07-07 00:38:51.714189+00	20230711110517_memberships_add_userid_index	\N	\N	2026-07-07 00:38:51.713094+00	1
cb53920b-e6d9-4710-a35a-d937c6a549d0	225ccf9170a395e34586c954db9c71b84f4300a07ef67e5ff116d2d08f80f37f	2026-07-07 00:38:51.716351+00	20230711112235_fix_indices	\N	\N	2026-07-07 00:38:51.714413+00	1
6314068a-6e91-414d-99ed-80750b769ee5	502d73e77f606982c12150e119f9214a7d8116d3d4d947ea37130d6aaf9280cd	2026-07-07 00:38:51.717567+00	20230717190411_users_feature_flags	\N	\N	2026-07-07 00:38:51.716631+00	1
6a71d917-09a9-49b3-8b82-91fd51cd8eab	9d3edea83f7e43616f70059fd0dbe6236133ac5fcd9883ac59b298e97fcd2e68	2026-07-07 00:38:51.718865+00	20230720162550_tokens	\N	\N	2026-07-07 00:38:51.717921+00	1
c784397b-be20-4dc5-90d0-b151377c173d	4cd20328eb9aa4ce2f0fe7dab5e00c412215e2c4423902d79cdebd7b0e2325f0	2026-07-07 00:38:51.719942+00	20230720164603_migrate_tokens	\N	\N	2026-07-07 00:38:51.719127+00	1
637e7eea-fb1a-48b5-8e6b-6ba9f80c3510	9994a7038fc3ba73d3b5e833ded5825ec58505918d6b4eca646dbfca60a899b8	2026-07-07 00:38:51.721529+00	20230720172051_tokens_non_null	\N	\N	2026-07-07 00:38:51.720223+00	1
4a946a72-1532-4baf-97c3-81f8bb8d710a	882b8cd48edf35b50633d13833aa0c8b92f70b707c3fc035fe0e59d2355a3a95	2026-07-07 00:38:51.722955+00	20230721111651_drop_usage_json	\N	\N	2026-07-07 00:38:51.721912+00	1
1b3e517e-1a02-41eb-aeb8-2c38d46cbca3	7f995c9ff2b7e3f70bb5eeebb2108552feaf5f8a51154727c36db9466f0e3ec4	2026-07-07 00:38:51.725617+00	20230731162154_score_value_float	\N	\N	2026-07-07 00:38:51.723245+00	1
7206bc51-f00c-4e79-80fd-ef153f9c0e77	05604cd4b32a7e41e21a314c7e78fd1b5883a9582acb5f4308ee7053af9707d7	2026-07-07 00:38:51.727464+00	20230803093326_add_release_and_version	\N	\N	2026-07-07 00:38:51.725889+00	1
12e5feab-17e0-4870-82c3-37be2b8223c7	ef6d52cd7eae4e95cf21b942289d9efb69e7f60eb5d3ca281d252c54e2b77ede	2026-07-07 00:38:51.729107+00	20230809093636_remove_foreign_keys	\N	\N	2026-07-07 00:38:51.72778+00	1
2cf2d5ae-84c0-4385-98fe-ce739487c86b	056d2e25ef8ebb7b2b7eee99a708ab8feffa348896301c8a1a67524e3c2fddf8	2026-07-07 00:38:51.731276+00	20230809132331_add_project_id_to_observations	\N	\N	2026-07-07 00:38:51.729443+00	1
21820b06-0c9c-43eb-a61c-27bdeed28013	7c025190192fb785a7f3728ebab61bb167f3be07233341678c640bd31360fce5	2026-07-07 00:38:51.732432+00	20230810191452_traceid_nullable_on_observations	\N	\N	2026-07-07 00:38:51.731539+00	1
85aef5ac-cd16-46ae-813a-240b0f2ac846	f409d263846f578bba696959b5ebfaa60a9534a407c6ad8c8fc32604ab7adfd1	2026-07-07 00:38:51.733754+00	20230810191453_project_id_not_null	\N	\N	2026-07-07 00:38:51.732687+00	1
d032c1a1-28b0-40b0-bc64-9c40697a9d9f	f998a3d872a1056949638870ce35fedb364d37297a784ecbcd1f95faf04a4c5c	2026-07-07 00:38:51.73509+00	20230814184705_add_viewer_membership_role	\N	\N	2026-07-07 00:38:51.734002+00	1
b482497b-635d-4064-a29c-722b9be83131	51ccaa1ee0828dcb0cf731b019486c2f39c5b1bdd09046ab90f9ba6ec13be1af	2026-07-07 00:38:51.814326+00	20230901155252_add_pricings_table	\N	\N	2026-07-07 00:38:51.81181+00	1
1b926e36-8d40-4eae-a438-f5eca0277f92	5b8a5e3d5880fa10be8005ca6e4d682104dae3f816e162c3db94c41753a8e1c5	2026-07-07 00:38:51.817078+00	20230901155336_add_pricing_data	\N	\N	2026-07-07 00:38:51.814859+00	1
1d4da40d-6e21-44fa-a2c4-16006a6e2df5	e31a4c1059dcbabbdc2ab6aecb50328bef42e809ed206485aba37c437c5cebc2	2026-07-07 00:38:51.818755+00	20230907204921_add_cron_jobs_table	\N	\N	2026-07-07 00:38:51.817365+00	1
37d61c10-1640-4d12-bf0d-5e96d07bba65	285bbb0b1c1ad7b8ee2d29ae7477b3f5b1b0e53fc58e9d75a287aaac715d498b	2026-07-07 00:38:51.820446+00	20230907225603_projects_updated_at	\N	\N	2026-07-07 00:38:51.819047+00	1
3bbb07ab-a84a-4476-8077-5911b467727c	d11aeff0b05af374c3306cdb12cc18afb7f73c5b8ce2c50757745ce5775340e2	2026-07-07 00:38:51.822454+00	20230907225604_api_keys_publishable_to_public	\N	\N	2026-07-07 00:38:51.820732+00	1
d78eeb47-c3f3-4318-8566-359256c2467c	378a5dd5ba691270826895506d53e8a6acc4ebba29f8226dfa0d78e698040c5e	2026-07-07 00:38:51.823932+00	20230910164603_cron_add_state	\N	\N	2026-07-07 00:38:51.822834+00	1
8ea7fb00-73c2-47bb-9f25-985cb119b112	d4af17aef307dba854b4b896df6f998cef8ac211fb792b7e90c7fe6fa4a9e4c3	2026-07-07 00:38:51.825417+00	20230912115644_add_trace_public_bool	\N	\N	2026-07-07 00:38:51.824284+00	1
5735f35f-bba7-43ef-94a1-f8d17d1dd436	2026ed8d4e73d7d09741dbedf1fe73233e624f3e7f81b2a2b9243f415168ebb2	2026-07-07 00:38:51.827099+00	20230918180320_add_indices	\N	\N	2026-07-07 00:38:51.825686+00	1
d137a302-b2d8-41e2-af1d-9cbaa4601e34	6bfdc95391ba091dc9d96899dbe7f967814cf42eb6388b664d9d76d8982add70	2026-07-07 00:38:51.828352+00	20230922030325_add_observation_index	\N	\N	2026-07-07 00:38:51.827377+00	1
4b24acdd-17c0-4489-9faa-2f07aa3f2958	ea9794f2d79f49b88ab95b90335fe97cd7ccc3d7f1dd156259a5e5aa1c107043	2026-07-07 00:38:51.832625+00	20230924232619_datasets_init	\N	\N	2026-07-07 00:38:51.828595+00	1
4c73dd8c-be91-4dd3-a2bc-4691ce016d55	6db5841932092efa895afe4c027079a9c48ae252181c8e0c3985c6d08f96ba8a	2026-07-07 00:38:51.914586+00	20230924232620_datasets_continued	\N	\N	2026-07-07 00:38:51.911923+00	1
8c3e48c7-3078-4a4d-b813-84fc35471fed	e8f8302423f78da25f0349a5da4083160f574c98ccc2b3e28f91d16cfa1ad499	2026-07-07 00:38:51.91695+00	20231004005909_add_parent_observation_id_index	\N	\N	2026-07-07 00:38:51.915184+00	1
84278b2d-80fc-4683-b3e7-dbf08f9299ef	8f1b13112f4627c886c705d33920578b19fea917471b7367191300eebef544fc	2026-07-07 00:38:51.91966+00	20231005064433_add_release_index	\N	\N	2026-07-07 00:38:51.917703+00	1
e2865561-764f-422a-bd57-ecd0523fd080	dfeb488d9be2f37c669211d8fee91cc67d384eee1532512a00328195fd259e27	2026-07-07 00:38:51.923072+00	20231009095917_add_ondelete_cascade	\N	\N	2026-07-07 00:38:51.919937+00	1
d7d85c47-b936-4b8f-b678-abfbd7c589ca	e08e3d28e1b13a6df4f7eb43bd81d427f86792a9235dfa123db11b67343c1d82	2026-07-07 00:38:51.925847+00	20231012161041_add_events_table	\N	\N	2026-07-07 00:38:51.923403+00	1
649ffb6b-cb7c-4412-be5c-18cb06dae3f8	52d73a2c8f5927da07492f83ffc94ce4a3cdc93232be0291d0faf77bc5ba8eed	2026-07-07 00:38:51.927752+00	20231014131841_users_add_admin_flag	\N	\N	2026-07-07 00:38:51.926185+00	1
b8d93040-faa3-4cfb-9b2a-d0c892154e06	578777f46933e33a0dc8e7c78f054c86dd0ed1413f67dc2d6334365cfda4c6bb	2026-07-07 00:38:51.929043+00	20231018130032_add_per_1000_chars_pricing	\N	\N	2026-07-07 00:38:51.928021+00	1
3104a5b6-40ef-45f3-95f0-eef45614a156	c087cf267a4c8b52ec4cebf0612b840d2136475e4776e9206778830256ce3f32	2026-07-07 00:38:52.013981+00	20231019094815_add_additional_secret_key_column	\N	\N	2026-07-07 00:38:51.929383+00	1
5e81d1e4-969e-42e3-8ed2-19c336214bea	44810e0e19455ef071bec618d10951ba956e7a112631eb3f4c313fe903db7267	2026-07-07 00:38:52.015598+00	20231021182825_user_emails_all_lowercase	\N	\N	2026-07-07 00:38:52.014414+00	1
395b59c3-8c38-407b-961d-77776306452b	6456651794d1f7215c7f39238725764948ce71b7df386639d2d4f58da2e93335	2026-07-07 00:38:52.017612+00	20231025153548_add_headers_to_events	\N	\N	2026-07-07 00:38:52.015889+00	1
7962c158-0c9e-4b7a-94b9-53a53d0eeafd	cc2235e89e6815af4002bd4aa6941e16dd452efe9dc5d59ac0c390589160a7ac	2026-07-07 00:38:52.019269+00	20231030184329_events_add_index_on_projectid	\N	\N	2026-07-07 00:38:52.017862+00	1
37a32e13-71e5-47db-ac08-caa2c4769aba	f5ef1377c36e5301cf312bb60c6bb647bdb3de2db1d847003b4cfd3e24ca9ccc	2026-07-07 00:38:52.020737+00	20231104004529_scores_add_index	\N	\N	2026-07-07 00:38:52.019556+00	1
7fe12cf9-47ca-4089-9d03-1be1da58ba1c	2f634dc6a7e272e3715472968da531e23c9dda562d5d137e6bfe7195d51761ab	2026-07-07 00:38:52.023175+00	20231104005403_fkey_indicies	\N	\N	2026-07-07 00:38:52.021199+00	1
440340e4-5215-4b95-b118-b8f05e91fd19	85bf236e16abc39747ea773383c06cd06208e2d147237beb0b20b48318397e7e	2026-07-07 00:38:52.027249+00	20231106213824_add_openai_models	\N	\N	2026-07-07 00:38:52.023745+00	1
ded8f5d2-e65f-41fc-9e4a-f8c7a77319b3	00cea39de0d75e817cfadcd95f852d4a84e00c1f67930d518ae4d452c93ac177	2026-07-07 00:38:52.029773+00	20231110012457_observation_created_at	\N	\N	2026-07-07 00:38:52.027813+00	1
99f6d91f-a6a4-4e31-b817-27ef6f90c7c0	1074f270d9b48baa51d22c0c90218cdc47dc3338a5f0ea90bd72ef5ea5e2cf88	2026-07-07 00:38:52.032096+00	20231110012829_observation_created_at_index	\N	\N	2026-07-07 00:38:52.030098+00	1
fe0e8d50-b680-4b00-becf-5c43eacff924	3920714d62de04345531777f14fe9a02b8982890c93f0b57512c0ab55755ee79	2026-07-07 00:38:52.033774+00	20231112095703_observations_add_unique_constraint	\N	\N	2026-07-07 00:38:52.032422+00	1
20d49a9a-59b3-4c1a-8d70-95f2115e7596	5881fcf2e0d44375b52e6228413774f3154ab9fab3492f8ff24a24c2f044033b	2026-07-07 00:38:52.035505+00	20231116005353_scores_unique_id_projectid	\N	\N	2026-07-07 00:38:52.03416+00	1
b7758b3e-0fd1-45ee-b714-5df01e345529	8fee27ef5b07ba63a31cf88aee365f6f9c66b8cb5a08492b7f19c2a1eef249e4	2026-07-07 00:38:52.111541+00	20231119171939_cron_add_job_started_at	\N	\N	2026-07-07 00:38:52.035783+00	1
b29b3ac9-b511-4b12-9499-d982fc074a16	800d6b5782b4564cfa092fd57f42ec2283537d439f167419211669aaa7df3ee2	2026-07-07 00:38:52.113262+00	20231119171940_bookmarked	\N	\N	2026-07-07 00:38:52.11196+00	1
c273bcab-f9f9-43a0-a6d1-795531925454	0be96056b9709a8b7899d555e228d5c0098f1e6b358c6e016bb3843b7846b3f6	2026-07-07 00:38:52.115713+00	20231129013314_invites	\N	\N	2026-07-07 00:38:52.113525+00	1
00f250c2-fc05-4939-bb3d-7424a1fb5448	401f5230ee1dccb765509321e8075652e71ae4ec28f5648a6b2ee151fc58d90b	2026-07-07 00:38:52.119012+00	20231130003317_trace_session_input_output	\N	\N	2026-07-07 00:38:52.116077+00	1
10569c40-bb32-4e9c-952a-c214a76971e6	f73f71a1a394677fb4ddd00cfe2238c40190f875525473d9ebf80f15fc89a2e7	2026-07-07 00:38:52.120747+00	20231204223505_add_unit_to_observations	\N	\N	2026-07-07 00:38:52.119456+00	1
9a6eb533-9bc8-4407-96dc-e384f29bf7b8	1b774d2ddbe9ae0f7cf8b60beaef0d27a6f5e8b09840e342ffd85c63c5de517d	2026-07-07 00:38:52.122288+00	20231223230007_cloud_config	\N	\N	2026-07-07 00:38:52.121089+00	1
782a7f1f-90d4-4120-8baf-decd33a2c649	14911fffc711830a28304af98b2c9fe31f5f78fb568281090a75f4f7958ba942	2026-07-07 00:38:52.123562+00	20231223230008_accounts_add_cols_azure_ad_auth	\N	\N	2026-07-07 00:38:52.122662+00	1
e153c712-26b5-4ad3-87f0-8b8365c9c5c7	9f5a355bf0c6c5fa36b37c898b338a234d43efa01d387eca439a95d674721ca2	2026-07-07 00:38:52.126886+00	20231230151856_add_prompt_table	\N	\N	2026-07-07 00:38:52.123836+00	1
c37eeb73-c036-4fd3-9cb1-e2e09c693933	7919b5dfcacec288b646f23c83f6adbf5f69eba50d2de4a35eb2b9d3029e4729	2026-07-07 00:38:52.128124+00	20240103135918_add_pricings	\N	\N	2026-07-07 00:38:52.127191+00	1
4ac7caa9-a4c3-41c6-85aa-f199c1e5c62a	9f7ef155730980f10cf9c84fdcce91b80822a8ff1d7d35720b544f851397a0e5	2026-07-07 00:38:52.130913+00	20240104210051_add_model_indices	\N	\N	2026-07-07 00:38:52.128369+00	1
ca39e3bf-1e4f-49cc-bcfb-f1a92a5afb67	ed03d628f2755b0b16963a8d20b72440588a7ed57a4f1652d9b128e5dcfbf1b3	2026-07-07 00:38:52.21274+00	20240104210052_add_model_indices_pricing	\N	\N	2026-07-07 00:38:52.131169+00	1
0e9018f6-8dda-4349-9d04-6bbb80501974	08918b17989f2bd0e36f80c5255042f807afe428186c68cf334fa01953153807	2026-07-07 00:38:52.215184+00	20240105010215_add_tags_in_traces	\N	\N	2026-07-07 00:38:52.213134+00	1
f1d7336a-578f-4ad5-8f6a-a923926af8a0	18fba86141a537df2fdf6bc8b8d8cd1abcdef25ca0dca43d1983fb23dac4db72	2026-07-07 00:38:52.217416+00	20240105170551_index_tags_in_traces	\N	\N	2026-07-07 00:38:52.215636+00	1
2e6bb142-918a-419c-83f1-f5c2fd4f553b	de4c1bc9e76dc2ad02e5cedc68bc20450c80307c64123469b925b1ba1787449c	2026-07-07 00:38:52.218858+00	20240106195340_drop_dataset_status	\N	\N	2026-07-07 00:38:52.217722+00	1
2f93bf27-2218-4cf7-8bbf-71963350e1c7	9d7148c925f6643b17c1aad933fce92bdcbc8fa2304eb97be11c0aa32747664a	2026-07-07 00:38:52.220309+00	20240111152124_add_gpt_35_pricing	\N	\N	2026-07-07 00:38:52.219195+00	1
f3fa4eb2-84bc-4b56-8fe9-19758c022261	9496ee3af1202cb3f9d6f0d4bb88c521e0e796a04bc8e02622718a63ba79b710	2026-07-07 00:38:52.221999+00	20240117151938_traces_remove_unique_id_external	\N	\N	2026-07-07 00:38:52.220645+00	1
2d25d955-fbd0-45e0-8344-bba8ed175ef7	c5919ee7870f36a7555024eb2256b3a28c8d978032dcd943047e5cff27a86cba	2026-07-07 00:38:52.223156+00	20240117165747_add_cost_to_observations	\N	\N	2026-07-07 00:38:52.222238+00	1
46c54b04-29e6-4bbc-813b-354a9d150041	ad8869aea6b98159c54bd3f2fcfb4ee1114ba54a7bf5726378dc2edd6f8077eb	2026-07-07 00:38:52.225762+00	20240118204639_add_models_table	\N	\N	2026-07-07 00:38:52.2234+00	1
c86ba2b8-5aa9-45b5-bc70-9dae53cb8052	7211b935cb3f52c11c7ebd0ac540bbbd01bb2010e51ad412d2956645c02724b7	2026-07-07 00:38:52.227454+00	20240118204936_add_internal_model	\N	\N	2026-07-07 00:38:52.226111+00	1
9c25a55f-2485-4408-9f9e-80e2150e2716	b79f2ca2011baa6604eec15e549996af3a10e396b706aff73b6ca36c08291d99	2026-07-07 00:38:52.229882+00	20240118204937_add_observations_view	\N	\N	2026-07-07 00:38:52.227737+00	1
61e99f37-5264-4ab5-891c-f0ada64fb5ba	2c075714bdce7df89f328062021733fd62880ff7cdb91a1d0a7aab2659a89d06	2026-07-07 00:38:52.313334+00	20240118235424_add_index_to_models	\N	\N	2026-07-07 00:38:52.230236+00	1
1586ed31-51d0-4627-a467-f9d5f5ebeed8	c76d5a31377660ce77e890a918ffa07bd2db8c8c94b04753befbc27d152492ea	2026-07-07 00:38:52.314912+00	20240119140941_add_tokenizer_id	\N	\N	2026-07-07 00:38:52.313805+00	1
0e406d39-6847-47c8-9788-386c2e99a213	08f7d11bd5deec873669ca10101dd0a05669bb04eb300ef0ee7b6d3517ae0c24	2026-07-07 00:38:52.316468+00	20240119164147_make_model_params_nullable	\N	\N	2026-07-07 00:38:52.315251+00	1
cfd4168d-79da-4b4a-b980-38f1669d1e21	3b0d3c46459cc2770d6e8d9db6fc139f859792da5b89937114dd09b17dac0dd4	2026-07-07 00:38:52.318695+00	20240119164148_add_models	\N	\N	2026-07-07 00:38:52.31682+00	1
0ecac4d4-5772-47f2-9d96-b65b79c78758	73f7212daa54130c6fa91fc17d840262ec948b11aafce49ea3e8ce7d4f3cbef1	2026-07-07 00:38:52.321232+00	20240124140443_session_composite_key	\N	\N	2026-07-07 00:38:52.318983+00	1
fe3d11ce-d1e1-4f39-b2b8-5dde3072a2cd	4ec1ad8229c185a7afaa62357879a60d4f59b35a103975030ce43d67823096c9	2026-07-07 00:38:52.322711+00	20240124164148_correct_models	\N	\N	2026-07-07 00:38:52.321516+00	1
aee9fdc0-07e5-41bd-8eca-34b00ba5400a	546c704d2869f4d382fb591fd20b14c489e99fffaa5655c45a3a86e7a7d488c5	2026-07-07 00:38:52.323909+00	20240126184148_new_models copy	\N	\N	2026-07-07 00:38:52.322957+00	1
7bd76419-8735-4e2b-afc5-4fe180a8d41b	fcbff614561f2c09501be18aad566624e04bf390aef8c072596ac2b793d10cb7	2026-07-07 00:38:52.325423+00	20240130100110_usage_unit_nullable	\N	\N	2026-07-07 00:38:52.324183+00	1
fb68ee6c-e99b-4919-95b7-9eec9fddbe72	c301dfa0db4367a4691bf520cb0c0b377b10e2ef4ca66f39f818284b23d0cfa2	2026-07-07 00:38:52.32678+00	20240130160110_claude_models	\N	\N	2026-07-07 00:38:52.325714+00	1
de28862e-675f-453f-be5e-ce501935060a	af31e8b4be701e97ccf87d4692055d2cc7ece9d74cc424e05dfb2775de5a7efe	2026-07-07 00:38:52.328554+00	20240131184148_add_finetuned_and_vertex_models	\N	\N	2026-07-07 00:38:52.327351+00	1
ec0ff1a7-664d-417b-9f47-3fca49de03c2	3bc4965e82cd4645da383ef6f6582a7efd7f5bf27e912af1efe18ff62e014db1	2026-07-07 00:38:52.329636+00	20240203184148_update_pricing	\N	\N	2026-07-07 00:38:52.328772+00	1
bfc9a9fb-505c-4728-ae1d-85fbfaff4d64	3e0cc893b4ec41ef43740af577aef359e2c742c338c8fc5421f766d75cce1292	2026-07-07 00:38:52.332047+00	20240212175433_add_audit_log_table	\N	\N	2026-07-07 00:38:52.329876+00	1
2b0f0966-fb9b-484e-ae9c-8cdb6f58eccf	4a1b6917569327219e620f0cca78446c360958d5a91226b7f60bd4626ffb38d0	2026-07-07 00:38:52.335739+00	20240213124148_update_openai_pricing	\N	\N	2026-07-07 00:38:52.332334+00	1
ea836ea4-59c7-4b1c-9292-64bd48e858ad	a942356a983650fb3aa2974690956869324993c3a546ea83d3ae26d2a98db7c1	2026-07-07 00:38:52.414017+00	20240214232619_prompts_add_indicies	\N	\N	2026-07-07 00:38:52.336117+00	1
a06707d9-b25d-472a-bb56-33d48c43bd34	00a42d4d8bd4090cf94d90eeb82fe803d23d802dcdb6c058b2371a75d951519a	2026-07-07 00:38:52.415855+00	20240215224148_update_openai_pricing	\N	\N	2026-07-07 00:38:52.414503+00	1
877f8c26-1963-4157-94f3-1d446512bcab	795187b23b16aceb796a10b5a43327cd3f767a0048f7ae8cb4d209695e49f18d	2026-07-07 00:38:52.418897+00	20240215234937_fix_observations_view	\N	\N	2026-07-07 00:38:52.416399+00	1
58c57519-39f4-4093-88f2-8a35830f7aea	540712b04f0fbaf449eaf229210e04dec83280878842c7c3d9956e4ff98334ce	2026-07-07 00:38:52.420477+00	20240219162415_add_prompt_config	\N	\N	2026-07-07 00:38:52.419277+00	1
f30a0041-eccb-48ed-845d-5ff81489c86d	909cae9daaf399b3ab6e9c03142fa4b80d7b09f44165944b9a09007d829d6f28	2026-07-07 00:38:52.422485+00	20240226165118_add_observations_index	\N	\N	2026-07-07 00:38:52.420811+00	1
58bc2cf2-dcef-471c-a119-d8ba5596193c	58e1bb0a84cb20a36c750b9d13c1371e44cd1a4947d5bdb37754a23d664c5e33	2026-07-07 00:38:52.424549+00	20240226182815_add_model_index	\N	\N	2026-07-07 00:38:52.422757+00	1
f3ca9bed-9624-4779-be4d-64b2a183c2aa	2cb0786da90de9c0a6e2983075362c76163e0635f9d347da0686b9c0434b8f0f	2026-07-07 00:38:52.426595+00	20240226183642_add_observations_index	\N	\N	2026-07-07 00:38:52.424812+00	1
d47dee75-b579-4e9c-801f-113c187d2b46	e733981599148cbb086a4eb4e7276fac2059ce3b60b3acf1443c3ec648f1d233	2026-07-07 00:38:52.428401+00	20240226202040_add_observations_trace_id_project_id_start_time_idx	\N	\N	2026-07-07 00:38:52.426919+00	1
294431c6-93f9-4f13-869f-8cbfce5846be	f2af6a57ddd2aab8adeaa5a3c6571cd8ab8538b071fb01e07c35d277203ae6b8	2026-07-07 00:38:52.429954+00	20240226202041_add_observations_trace_id_project_id_type_start_time_idx	\N	\N	2026-07-07 00:38:52.428662+00	1
aac2ef26-4fb8-46c4-b874-703c63612915	e31ee1ec510ded08a1813273056149bfe345651ce02d9ab31883dde10e390afe	2026-07-07 00:38:52.432056+00	20240226203642_rewrite_observations_view	\N	\N	2026-07-07 00:38:52.430258+00	1
a195f09b-9d61-477a-8d02-731b1aabfe93	5603e17abf74b6c9e4191ff261e56e63641a90c5e04d99c5f04be174d1a90d76	2026-07-07 00:38:52.513756+00	20240227112101_index_prompt_id_in_observations	\N	\N	2026-07-07 00:38:52.432289+00	1
782ba2a7-c1cb-489c-b57c-d174623038f8	d498837088f8de279f4c04655af668c34f3febd961c95390a0441cb0ee0a3db6	2026-07-07 00:38:52.51655+00	20240228103642_observations_view_cte	\N	\N	2026-07-07 00:38:52.514145+00	1
9a6eac1a-015c-48f7-a320-cd1c93970cc9	96e0223ba9bb5ec06dc4c53988451298d6cf9df6b83da89262280ceb3c203d59	2026-07-07 00:38:52.519287+00	20240228123642_observations_view_fix	\N	\N	2026-07-07 00:38:52.516806+00	1
35bc1609-dfd9-4a13-9156-27467399151e	83902ab9281b0b9b7257768518cbfb6895d382f30e6594b2058507d173bfa519	2026-07-07 00:38:52.521086+00	20240304123642_traces_view	\N	\N	2026-07-07 00:38:52.519547+00	1
042f0224-5cce-4254-ae6f-7f2c0d61ccf3	2ab605d386e52af31b6328f5542d63ec6a6b19db9bda8f2e4888a7de7154b2ae	2026-07-07 00:38:52.523448+00	20240304123642_traces_view_improvement	\N	\N	2026-07-07 00:38:52.52148+00	1
681797e4-e4ee-450e-ba87-b4c44ddf9371	b9abacb6b7858085eff8230a9950eaffe2e557c67981592097a2b93204b3c5ec	2026-07-07 00:38:52.525221+00	20240304222519_scores_add_index	\N	\N	2026-07-07 00:38:52.523724+00	1
83317564-2900-4d26-9809-cd70dee8b89d	f8e14cfb18416f04c49e67c2e9c97675b1d01a1a60a549d784cfbcd52f308771	2026-07-07 00:38:52.526909+00	20240305095119_add_observations_index	\N	\N	2026-07-07 00:38:52.525472+00	1
128846a1-38f0-4d29-8ffb-0c092ebde7c6	498c50087ca98fffe98b041b77c8ef195888e35e607b3c0d64643d9275e83935	2026-07-07 00:38:52.528757+00	20240305100713_traces_add_index	\N	\N	2026-07-07 00:38:52.527201+00	1
31d2a630-b50d-4ade-ae00-4aa8880071b1	89a9d0e9dd25662dd684333947df23ea4165a4adec9995e281b33fecdd60b775	2026-07-07 00:38:52.530126+00	20240307090110_claude_model_three	\N	\N	2026-07-07 00:38:52.529019+00	1
05351c2e-881c-4d6f-a982-45bf68065f12	7a8d3f1cb3ce402ca6de3b8af2f9f402770d7bb1b9a0ba740dd691b5e88feb1f	2026-07-07 00:38:52.531434+00	20240307185543_score_add_source_nullable	\N	\N	2026-07-07 00:38:52.530372+00	1
b2c7a26d-ebd5-4bef-9882-bb765035d0ee	b9c551f91d345926b3c740563aecff3904717185b84dcdf74c0b2521ffa2cb63	2026-07-07 00:38:52.534019+00	20240307185544_score_add_name_index	\N	\N	2026-07-07 00:38:52.53176+00	1
79aecbac-ab49-4d13-9309-da0adef9db84	0cec970448bd9ff3a78acdcce5519f9c2154378ccc3a3acbd79266478f66238e	2026-07-07 00:38:52.613159+00	20240307185725_backfill_score_source	\N	\N	2026-07-07 00:38:52.534422+00	1
ab28c6f5-34a0-40ee-907b-99901057c7c1	1a476db15f8f2a6becbde3c804623832542a9d2dc1233389e9b4d1c9047a5b43	2026-07-07 00:38:52.61452+00	20240312195727_score_source_drop_default	\N	\N	2026-07-07 00:38:52.613504+00	1
6c46ba8d-402e-4837-9e6b-dc4646072b64	137f83659a950bdc6497c2030f61bd070264ee14387f3e11143f55ae2c3d810e	2026-07-07 00:38:52.615635+00	20240314090110_claude_model	\N	\N	2026-07-07 00:38:52.614769+00	1
0867bdfb-fe73-46b5-ad00-c85b750aed5c	9e7f1d6a2d8e12037a931e8d8c86e552366e8056d2a9adb847f84da5c6972398	2026-07-07 00:38:52.617667+00	20240325211959_remove_example_table	\N	\N	2026-07-07 00:38:52.615892+00	1
e5303dfd-efe4-419e-9dca-99f4093aa9b3	48d049e8d66ed3f4b0336d857ae4bfeb7f39dd9ee1070fbe4bede32630478e7b	2026-07-07 00:38:52.618894+00	20240325212245_dataset_runs_add_metadata	\N	\N	2026-07-07 00:38:52.617948+00	1
4ab4d180-4142-407a-b5fc-8141dce7bca5	3fa446eb946ec9e8f56c4665e02aea106727c4058acd89dd758900273a2183d8	2026-07-07 00:38:52.620961+00	20240326114211_dataset_run_item_bind_to_trace	\N	\N	2026-07-07 00:38:52.619201+00	1
e981e9b3-0980-48cc-9b3c-6b86d26a12bf	f6efc777385ff3f04b4c93745d7a66fe953a4fb4544203ad22808b80468f3578	2026-07-07 00:38:52.622794+00	20240326114337_dataset_run_item_backfill_trace_id	\N	\N	2026-07-07 00:38:52.621262+00	1
fe710291-94ce-4b67-9cb8-b32a9200069e	7c084b86913a91f9b8658084f6b8f6526bce2d0de4842c8f68e07f30f1f46fe9	2026-07-07 00:38:52.624674+00	20240326115136_dataset_run_item_traceid_non_null	\N	\N	2026-07-07 00:38:52.623044+00	1
d43d591d-c914-4c5f-a51e-9aa758bc9c05	afe59690f207d0f4481d9a54af3e743622a88a68ad46d4eb2597c2b7a953fc66	2026-07-07 00:38:52.626393+00	20240326115424_dataset_run_item_index_trace	\N	\N	2026-07-07 00:38:52.625011+00	1
4026f175-368b-4bff-96e0-441e55168d78	10e5a3983b46239bbb0b6ad8617901df3c7eaa53df0b879577528d7e14d84d91	2026-07-07 00:38:52.627522+00	20240328065738_dataset_item_input_nullable	\N	\N	2026-07-07 00:38:52.626649+00	1
51cb2331-01b4-4fd7-bdff-0feebade6751	04c22689adda42b47ce94563fc3e834507c8b214a20ae1d379b2cfa9ed4e6d73	2026-07-07 00:38:52.62913+00	20240404203640_dataset_item_source_trace_id	\N	\N	2026-07-07 00:38:52.627756+00	1
7b9a8439-f332-46db-9fe0-0df1cfbf5874	cbf36bf3115f7c66934d46e7d8f4a21c7465f9d00569d619b7382028ee422eb3	2026-07-07 00:38:52.630263+00	20240404210315_dataset_add_descriptions	\N	\N	2026-07-07 00:38:52.629415+00	1
679a9690-d588-483e-8638-22669d3b5ecb	b5d68c44ed85196b038921cde3faf6241050b76781a9d93981346165436c6ed7	2026-07-07 00:38:52.631197+00	20240404232317_dataset_items_backfill_source_trace_id	\N	\N	2026-07-07 00:38:52.630463+00	1
36facc41-d104-4f18-89b8-5d9a8cb5fe83	82c21f5f2399c1173c734d8a157b4b0dac6821cbbc36dce8ba058caf40681ff7	2026-07-07 00:38:52.6325+00	20240405124810_prompt_to_json	\N	\N	2026-07-07 00:38:52.631395+00	1
ed6280fd-edeb-4cac-998e-bdbb97c7767a	206607c9c910399b23bb8217092e4b17fd428f2890efb49f1ad65dceaa55f3d1	2026-07-07 00:38:52.715181+00	20240408133037_add_objects_for_evals	\N	\N	2026-07-07 00:38:52.632807+00	1
c0d298e4-a78e-4e6e-92fa-bb9b1b8af9f4	b9711c48f8a9d20c8705c31f1a2bd4a4e1e3473e7de6f884ced0776773dea897	2026-07-07 00:38:52.717083+00	20240408134328_prompt_table_add_tags	\N	\N	2026-07-07 00:38:52.715583+00	1
a23bbd12-783d-47d8-8efc-98779a39a508	017eaef133c6ad53c86e655daf6ef310f5e8870d197b32b91b22feea8589c20d	2026-07-07 00:38:52.719079+00	20240408134330_prompt_table_add_index_to_tags	\N	\N	2026-07-07 00:38:52.717442+00	1
8b89ad30-52a7-48dd-9a48-f485850f7070	5b74cc3719cc73c4a9561521df9593a0b72b7f71a7edc6fc962259855d1b4597	2026-07-07 00:38:52.720552+00	20240411134330_model_updates	\N	\N	2026-07-07 00:38:52.719371+00	1
86a1ce9e-fc63-44b8-99b7-670e765dacef	86412f0fd3a38ecf7aba62d2df6bc63f21d8545c6846e7ad450f1ba1054ec0ef	2026-07-07 00:38:52.722197+00	20240411194142_update_job_config_status	\N	\N	2026-07-07 00:38:52.72086+00	1
0ce9f2f4-d521-4e42-8527-9a6cd02f72d4	0f44dce07307ae9364e93449837fe6fc6189780dd94b7d506f8c2f653423b42a	2026-07-07 00:38:52.72378+00	20240411224142_update_models	\N	\N	2026-07-07 00:38:52.722528+00	1
0500ac7b-83a4-4d75-a3b8-aedf915547ce	e0d84647251c69f99883c12c21eb9cbad9f0fc1059b58cce3296edeebdc1b8dc	2026-07-07 00:38:52.726366+00	20240414203636_ee_add_sso_configs	\N	\N	2026-07-07 00:38:52.724261+00	1
8f4bbd88-ed35-4ef2-957c-da0536693702	dcd8dcb804ab5eeb3cc813b88ea510578a6b481e5756628b0fa7d061d9aa79a5	2026-07-07 00:38:52.728682+00	20240415235737_index_models_model_name	\N	\N	2026-07-07 00:38:52.726654+00	1
0822c808-fbc9-4123-ba15-ddd2a73e8eae	20f9110c61428813f2d32bff079f64fe35ee3dbb6eb40241c24885ca87e44226	2026-07-07 00:38:52.730387+00	20240416173813_add_internal_model_index	\N	\N	2026-07-07 00:38:52.72892+00	1
ae1f8d6d-77f9-4399-88b7-22b90c2dd6c0	e79db3e95ce362750535a772337f79cd94bc37890e58ce3c05aa0253afe1d1d6	2026-07-07 00:38:52.73153+00	20240417102742_metadata_on_dataset_and_dataset_item	\N	\N	2026-07-07 00:38:52.730623+00	1
75c3465b-1065-464b-8a71-dcaf6d9469c8	d53f2ddcfda91be76c40f87c0ebdeee510cf7316e6ce8578e16a3a068daf0bd5	2026-07-07 00:38:52.812665+00	20240419152924_posthog_integration_settings	\N	\N	2026-07-07 00:38:52.731765+00	1
1eaeef15-fe6f-4a2d-91f0-068d0b10a2d0	b01064942f09a3e944a7db83a680ba04e135b6aee91569445ba295a2ce443f74	2026-07-07 00:38:52.814871+00	20240420134232_posthog_integration_created_at	\N	\N	2026-07-07 00:38:52.813065+00	1
92c85b86-11ca-4fa5-b1b1-d8ed02f2d3e3	b5153e69a337304509d94116fc42eac4ae838617041d473e361627e99d78eaeb	2026-07-07 00:38:52.816386+00	20240423174013_update_models	\N	\N	2026-07-07 00:38:52.815221+00	1
63ec9f22-70c8-4f2b-b567-863df2bb120c	0a6f2078af2b92a1d61d36449f3646fb8adda99acb6ee214451b8c2a7a62c36c	2026-07-07 00:38:52.819249+00	20240423192655_add_llm_api_keys	\N	\N	2026-07-07 00:38:52.816662+00	1
769ccb97-3765-4aec-91c2-824a51f2e3f1	c8ea9587bcf109835eb4b8cb882e121c35624d5e9f90e21886de3b7ee5793312	2026-07-07 00:38:52.820596+00	20240424150909_add_job_execution_index	\N	\N	2026-07-07 00:38:52.819511+00	1
2d38b77e-2db2-40b6-8f6b-ad46ff91ec26	a2ff78bbd0982e80edcc312bb686a9d33f4bde7e675d0915ba570aff2931307d	2026-07-07 00:38:52.821945+00	20240429124411_add_prompt_version_labels	\N	\N	2026-07-07 00:38:52.820894+00	1
e76dc3cb-4e1f-44e0-90fb-a64445cd5132	caf1f29f946abe2c7774657473a274866a1bab1a4d4b368bac32154c263aba22	2026-07-07 00:38:52.822826+00	20240429194411_add_latest_prompt_tag	\N	\N	2026-07-07 00:38:52.822187+00	1
6f3f5cfc-1485-4e27-903e-f9a3c2e738c8	6c5083ecdb222c9a4566fac6a4364a349351e868bb68eff17a7c8c48bacf39c1	2026-07-07 00:38:52.824264+00	20240503125742_traces_add_createdat_updatedat	\N	\N	2026-07-07 00:38:52.823101+00	1
c7c45fcf-1740-4ccc-b1ba-eb5566edd1ff	a15e5ed199ff9e77ad2ab1920262094a07c63c5bf639929e7912e3ec5b6f1da0	2026-07-07 00:38:52.826124+00	20240503130335_traces_index_created_at	\N	\N	2026-07-07 00:38:52.824596+00	1
008b1c88-0f98-4ae2-9d85-e93853b3181a	6d3ba16762dc0033c95dabd79ef2ac122e8416c7ec5cd15ef761057837b19c92	2026-07-07 00:38:52.827998+00	20240503130520_traces_index_updated_at	\N	\N	2026-07-07 00:38:52.826428+00	1
2f7e7d8d-d588-434d-b4a2-6e32561f5793	86eaf205ba5fd2130957536777d0aa00c8d15cdc2af896ea5b45ed5f26d690b6	2026-07-07 00:38:52.829489+00	20240508132621_scores_add_project_id	\N	\N	2026-07-07 00:38:52.828432+00	1
0231cca6-a91f-4f34-b94a-0d470eb00b5d	644c6246091a13e8e908733347ffd699789d448bb3c80207e53b32223667a292	2026-07-07 00:38:52.91206+00	20240508132735_scores_add_projectid_index	\N	\N	2026-07-07 00:38:52.829728+00	1
3c84bdc4-7e45-4ef1-b310-11cbc77eddde	c1e8301b3c0ad83f46731fa6398565faa586ee89b5dc4ff22a2289a9f7c21d8e	2026-07-07 00:38:52.914005+00	20240508132736_scores_backfill_project_id	\N	\N	2026-07-07 00:38:52.912539+00	1
a678d6c1-b75e-442e-bfa4-3b7e5f0c8d1a	3425cdbd747937bbb512b560a2b8132462d0412191a695e27dc9ae268f3d40f2	2026-07-07 00:38:52.916214+00	20240512151529_rename_memberships_to_project_memberships	\N	\N	2026-07-07 00:38:52.914356+00	1
98a2b1f4-c500-49da-9393-5db9c4ca211a	d010f310671b164935b005b7949c29a46a2f14117e14060702f239cf3bb081cb	2026-07-07 00:38:52.921241+00	20240512155020_rename_enum_membership_role_to_project_role	\N	\N	2026-07-07 00:38:52.916541+00	1
349fac5a-4f2e-40a9-9faa-32659e165661	a398b1ccdba2791a4646955f37522df929dd0e0a2d01603a068f70e096d2f53a	2026-07-07 00:38:52.922684+00	20240512155021_add_pricing_gpt4o	\N	\N	2026-07-07 00:38:52.92164+00	1
60f8db2e-19f5-402f-9e89-d374c14c337b	f9750ea80adc2a175c4455a32779c5a607d741b71ca8354a18d9e8273b70b9a0	2026-07-07 00:38:53.012911+00	20240512155021_scores_drop_fk_on_traces_and_observations	\N	\N	2026-07-07 00:38:52.923021+00	1
2dbd6bab-f976-4a09-8119-f9db19c6c355	18525089d536b836d81e02dab68588e4fe2bf3d0a09e4c349d60db9bbed0cd49	2026-07-07 00:38:53.014807+00	20240512155022_scores_non_null_and_add_fk_project_id	\N	\N	2026-07-07 00:38:53.013328+00	1
954c99c7-a639-41e0-a8f4-80b5889788fb	6f038363d06b8fe9ad5e5ffdebec33d4cde3591c65fe46175a4a821736637482	2026-07-07 00:38:53.016856+00	20240513082203_scores_unique_id_and_projectid_instead_of_id_and_traceid	\N	\N	2026-07-07 00:38:53.01525+00	1
92b6529f-536b-4000-be7e-4d782c038d86	e39e28c4337fa35ab175c703d6ceda8a2d4b78d2bc616200201faff350c61455	2026-07-07 00:38:53.019108+00	20240513082204_scores_unique_id_and_projectid_instead_of_id_and_traceid_index	\N	\N	2026-07-07 00:38:53.017214+00	1
1dcbdf65-51c5-44ef-8f09-0522ce0ccbb0	b8c134bdcba9a016d8ac79927a0d736c67c5bbf109ec584a15b0f6c38f50dc8d	2026-07-07 00:38:53.112297+00	20240513082205_observations_view_add_time_to_first_token	\N	\N	2026-07-07 00:38:53.019423+00	1
5bb7b3f9-6d97-4db9-bd77-ae6fc1f8432e	69b89171901be90854380c467ab615e82864cf72c128a011c0679b6e5af51e96	2026-07-07 00:38:53.113866+00	20240522081254_scores_add_author_user_id	\N	\N	2026-07-07 00:38:53.112815+00	1
ac5c9ba7-292a-4b7e-a90b-618c5eab63ca	1cba5ea95d8968dd4a1dfb6df8e844accbffca9d15e88aa87416eb6115b650e4	2026-07-07 00:38:53.115469+00	20240522095738_scores_add_author_user_id_index	\N	\N	2026-07-07 00:38:53.114171+00	1
2c30b1da-1445-4ac0-b8e3-c1fe8ca8d30f	439692a5f62df8e88a5aa6216e2019092d04f48a22f063861e20da6e3a278a9b	2026-07-07 00:38:53.118531+00	20240523142425_score_config_add_table	\N	\N	2026-07-07 00:38:53.115699+00	1
ed95424b-eb1b-4a34-9ba7-93889c7a31b2	b6930ec8ce14d8a5e0d6792049f3af79bbd1ba1e4990ad2535ebc859edf856d9	2026-07-07 00:38:53.12059+00	20240523142524_scores_add_config_id_idx	\N	\N	2026-07-07 00:38:53.118869+00	1
9ae7848c-183e-4aee-a416-4e2e8f3cb80a	3df7e7fc9c22f17c9e8bdfd663cc2e5c473ec3e6e97129eebb989007943376d5	2026-07-07 00:38:53.212452+00	20240523142610_scores_add_fk_scores_config_id	\N	\N	2026-07-07 00:38:53.120911+00	1
315dc63d-2247-4498-8cdb-9fd9d69edf41	326dfa3b9b80dc55e40ab489fb74671a5c16a4aba84c9696b270880c7bfe46f6	2026-07-07 00:38:53.214641+00	20240524154058_scores_source_enum_add_annotation	\N	\N	2026-07-07 00:38:53.21289+00	1
7d198f80-b972-4a8b-bf8d-d08b9d2b9bfc	7c2d55160da3c5b58bd2710b99a9af01a92fccde03c15703fe59ab2d2c2965a0	2026-07-07 00:38:53.216789+00	20240524156058_scores_source_backfill_annotation_for_review	\N	\N	2026-07-07 00:38:53.215095+00	1
e73a1c2b-0109-4c3f-9052-333f6fda387e	fff8108a9e3a443689ffc664fcb57f386343171b43607da12cc3ea46d7700585	2026-07-07 00:38:53.220603+00	20240524165931_scores_source_enum_drop_review	\N	\N	2026-07-07 00:38:53.217137+00	1
f96a80c6-f737-4565-afb5-ef9dc1a1b91f	d186efeb838e34c83c0174fe727768a3b23487734d222ed8393b8cc0be4e83a3	2026-07-07 00:38:53.222417+00	20240524190433_job_executions_add_fk_index_config_id	\N	\N	2026-07-07 00:38:53.220892+00	1
ebddef2c-d9ab-4f1a-8f9a-cd2455095ec3	ea772561308b485138a96c9fde5666910bc8cfebc30763463acbade405198412	2026-07-07 00:38:53.223775+00	20240524190434_job_executions_add_fk_index_score_id	\N	\N	2026-07-07 00:38:53.222677+00	1
059fdef6-1d50-4ff0-9046-3ad5b4ec1303	200a30bd560504185fd90be17c50db344bd1a71ecd599eefa5dc5d1b8504d0b5	2026-07-07 00:38:53.22545+00	20240524190435_job_executions_add_fk_index_trace_id	\N	\N	2026-07-07 00:38:53.224015+00	1
794ffa52-65b0-4a4e-a0f1-cf7d4d0b76eb	28f7b81fda65228917bc40cbd676aa362538a3e32c328d7ee8069e6195f5319b	2026-07-07 00:38:53.226982+00	20240524190436_job_executions_index_created_at	\N	\N	2026-07-07 00:38:53.225729+00	1
d0d13cbd-9488-4cfe-a3ce-e5074f41846e	41f0f23e453c12cda5517c9f4da23112d7385ad3892f21114d2fcdd20ce1648c	2026-07-07 00:38:53.312335+00	20240528214726_add_cursor_new_columns_observations	\N	\N	2026-07-07 00:38:53.227326+00	1
5832f548-0e4b-4c0c-a06b-4676ede23bfc	dd6ec73dbd2dad9918cacba3f3b36aa35e88eb88a533ba89a9e0589eab28919d	2026-07-07 00:38:53.314391+00	20240528214727_add_cursor_new_columns_scores	\N	\N	2026-07-07 00:38:53.312813+00	1
e83f4119-ab9f-42e2-bcf6-0d8fba289fd1	952e15d6cf5306bb4802cc82fbe9f957196d77cc7f9035908014b205c5245232	2026-07-07 00:38:53.316284+00	20240528214728_add_cursor_index_01	\N	\N	2026-07-07 00:38:53.314688+00	1
1049574c-2c9c-43da-9d8f-64da2391e5e7	78b6379bbc520233c72ece8af40ed3e44c185479a4d65da104e3005394add5b7	2026-07-07 00:38:53.318839+00	20240528214728_add_cursor_index_02	\N	\N	2026-07-07 00:38:53.31661+00	1
581bc0e5-11cb-49f7-b9df-b19d4bbc9e31	193aa18cb545aaa488d5d5c4852d61cd136eea2af6c4ffc9359dcf00cdda60c8	2026-07-07 00:38:53.320909+00	20240528214728_add_cursor_index_03	\N	\N	2026-07-07 00:38:53.319304+00	1
7181764c-00a6-453f-ad3f-6d71ffd0c553	dca517a57077ee57fdbad8c599951dd6e12efbe9608579f211c750d46282ddd8	2026-07-07 00:38:53.322606+00	20240528214728_add_cursor_index_04	\N	\N	2026-07-07 00:38:53.321271+00	1
b228aff7-e755-4d19-af79-f5e8a3090905	75ba9583fb449a727d79158ed02d694b490c2d300c2da3eac7c79439966859d5	2026-07-07 00:38:53.323848+00	20240528214728_add_cursor_index_05	\N	\N	2026-07-07 00:38:53.322838+00	1
182a12c5-8aa3-410b-94e9-cdaeb59cad99	60796f59b086bb8e2c4f4901464cf99afc9baddbd4b9f67b492f93a0d192dac6	2026-07-07 00:38:53.326553+00	20240528214728_add_cursor_index_06	\N	\N	2026-07-07 00:38:53.324074+00	1
c0cdebfb-4d3c-4121-bf5d-5c56e6975838	cd23d112029122106a7bae095c44e7d5ea702d5b5839898dde76855126b70e8d	2026-07-07 00:38:53.328675+00	20240528214728_add_cursor_index_07	\N	\N	2026-07-07 00:38:53.326898+00	1
8a591307-6b52-4ec9-a673-7c7a403722fb	8030bef72fbca691d64e1fe5ca79e3f51e6137d85d73ec9afb97860ce81969dc	2026-07-07 00:38:53.411896+00	20240528214728_add_cursor_index_08	\N	\N	2026-07-07 00:38:53.328943+00	1
b4e35d46-20b0-49fd-be9c-cd55ef51a573	1e687237d6e6b1dbbc0627d78a9eacf6a25a7d9232db4841b7c1be90cfebadd2	2026-07-07 00:38:53.414218+00	20240528214728_add_cursor_index_09	\N	\N	2026-07-07 00:38:53.412469+00	1
101c61a8-fee8-4bb0-bbb3-b58c0f7d95c0	422f4d18f07108fd2a6a4bcae46f66a8afd1374c46f0b29efce0aab376e199a7	2026-07-07 00:38:53.416229+00	20240528214728_add_cursor_index_10	\N	\N	2026-07-07 00:38:53.414492+00	1
446bb511-6c2e-43e8-ae36-9490f8be21bc	ccc9e57838b1cb6a14d7ea38f87a363e256a9ebe54c7799f972880a05951679d	2026-07-07 00:38:53.418491+00	20240528214728_add_cursor_index_11	\N	\N	2026-07-07 00:38:53.416621+00	1
1609ed53-59eb-485f-b90b-4ed606e7151e	43fabe3d60f20b7af6fa380afa5d3caee722ba94b2affffec300f06ae402870a	2026-07-07 00:38:53.420213+00	20240528214728_add_cursor_index_12	\N	\N	2026-07-07 00:38:53.418749+00	1
31b56d6a-f2aa-4cab-aff7-e334921e7d6f	c94c666ca537a5dd8e8c1f8353c337990be02587535bcd31d793714391a35340	2026-07-07 00:38:53.421604+00	20240528214728_add_cursor_index_13	\N	\N	2026-07-07 00:38:53.420451+00	1
2a7e08b0-82d8-4bc8-9600-43eb7dd986fe	372bd565f444f56abba3316b7642994ee2dab8d07a8e918366e235d8282573ed	2026-07-07 00:38:53.422869+00	20240528214728_add_cursor_index_14	\N	\N	2026-07-07 00:38:53.421818+00	1
c9619bfc-0903-439c-b473-4d2717c1e0bc	e64d2f82e0e18bdeb80a75f75a19839cd5e0579e0c13336369191fe582592c98	2026-07-07 00:38:53.424451+00	20240528214728_add_cursor_index_15	\N	\N	2026-07-07 00:38:53.423142+00	1
a2ec8bdf-47a5-44b9-9071-21560bbd6299	0a4105318c8c643b080415ad0d5566252acdefcbf7d95e10d93c0c7837f23202	2026-07-07 00:38:53.428656+00	20240528214728_add_cursor_index_16	\N	\N	2026-07-07 00:38:53.424899+00	1
833bbf61-0dc2-44ca-8b8e-b93d76d624e1	c990b7a6ca81f32c14b6faa15ce64f673fb4ea950ee29295c0216aeb73505dac	2026-07-07 00:38:53.431419+00	20240528214728_add_cursor_index_17	\N	\N	2026-07-07 00:38:53.429132+00	1
8909c02a-9e74-4fc7-8c5b-3fcca0a73339	91bd416591a20ebf4a43e477e96840b27d9d719f228356836debf7aaf5a63c76	2026-07-07 00:38:53.512011+00	20240528214728_add_cursor_index_18	\N	\N	2026-07-07 00:38:53.43177+00	1
6b32aaca-b341-4b00-a377-4508dbc92c54	c4155024314491d05b341db42b38ad22d35084502c842c3003f7e3a9a8278603	2026-07-07 00:38:53.514617+00	20240603212024_dataset_items_add_index_source_trace_id	\N	\N	2026-07-07 00:38:53.512474+00	1
af9d2734-cd8a-4f3b-aba3-d652c24b29b2	c683e1a9bd10c23b0c47a8b24a4abf88a7c6c090f49288f1866308662811ca56	2026-07-07 00:38:53.516568+00	20240604133338_scores_add_index_name	\N	\N	2026-07-07 00:38:53.514944+00	1
639a6428-7045-45c1-94f5-55525ef650ef	a83f3d6ccaf505beb1d4e1e389e75f1e2f908e7f38083cdd0e9fe890b1a32ac5	2026-07-07 00:38:53.517899+00	20240604133339_score_data_type_add_boolean	\N	\N	2026-07-07 00:38:53.516843+00	1
daeb27a3-f107-47ea-981f-fcabe8ee3bd6	4cfdd5861ab132ab402a50a8167c2f85b8dfcd59b9cf657c3a450822b428d421	2026-07-07 00:38:53.520061+00	20240606093356_drop_unused_pricings_table	\N	\N	2026-07-07 00:38:53.518215+00	1
1b708255-c03f-404b-9ae2-5f064cba1232	4dbdbcaf043e14669304021c929c5544297e4c1288814b373ac6180403a8e243	2026-07-07 00:38:53.521399+00	20240606133011_remove_trace_fkey_datasetrunitems	\N	\N	2026-07-07 00:38:53.52035+00	1
83bf4f03-0404-4278-87a3-c41eb683e05c	0e9d74c1cca79b04a49aea0a7590e985b40e87ab425919cf7625b5c9dbd08eae	2026-07-07 00:38:53.522658+00	20240607090858_pricings_add_latest_gemini_models	\N	\N	2026-07-07 00:38:53.521653+00	1
681196fa-b8f3-4434-a559-a0658a1187aa	844d238a2a7adc1bea26071ec926f5deae3bfad1a132498b539a8a73f7cd9b84	2026-07-07 00:38:53.523775+00	20240607212419_model_price_anthropic_via_google_vertex	\N	\N	2026-07-07 00:38:53.522897+00	1
44c8653d-8021-4793-a363-fe6a487d8a79	bfb32da23d69cdd9b16e9b7a9397c199656f43a088d611bb870160be7162e456	2026-07-07 00:38:53.526658+00	20240611105521_llm_api_keys_custom_endpoints	\N	\N	2026-07-07 00:38:53.524226+00	1
bd0c7848-d2f6-4058-bfe3-97878219ffa2	e7110b354d5834e771980c2486a334501fc6c00d60d7489a771e6e32cdf113cf	2026-07-07 00:38:53.528463+00	20240611113517_backfill_manual_score_configs	\N	\N	2026-07-07 00:38:53.526945+00	1
f1418783-e324-43a5-8555-98daa186c1f6	5ffd2fdb41ff144cb14035a9feac869134180508f9ccf5c55f3d04a7c574f560	2026-07-07 00:38:53.530108+00	20240612101858_add_index_observations_project_id_prompt_id	\N	\N	2026-07-07 00:38:53.528721+00	1
7fa565d9-3d0c-48e9-bb6a-9ecfc85e33bd	0c2ce80ed19bda8480a47a63222e518a74233937dd620d6856c85986e56459b5	2026-07-07 00:38:53.531203+00	20240617094803_observations_remove_prompt_fk_constraint	\N	\N	2026-07-07 00:38:53.53034+00	1
e0f1fdc9-7b32-49bc-a517-34aad11e666e	08a92b24efa2f28043e5050f1071c39be9927e759fea2d68ed1a026f85457d25	2026-07-07 00:38:53.612742+00	20240618134129_add_batch_exports_table	\N	\N	2026-07-07 00:38:53.531434+00	1
ab1e62d5-19b6-4df1-89fb-faee67073781	3dc892b57cc62544e92fd075401e0ddb9edd5536a014a1b0abcd8554c8c08f44	2026-07-07 00:38:53.61509+00	20240618164950_drop_observations_parent_observation_id_idx	\N	\N	2026-07-07 00:38:53.613119+00	1
c225e14c-31ce-4f24-867b-64eeb2157d65	2966ccefa13d04e5bbe2fd2e6d199c46ea2915b4158b75b02840a072cbfc506d	2026-07-07 00:38:53.616549+00	20240618164951_drop_observations_updated_at_idx	\N	\N	2026-07-07 00:38:53.615399+00	1
ca37d85d-134a-4e35-baab-52d5b0f80597	cd37d3269447a71e8de058e7391986faf4d1ea88c7fc06e9e9de6d4d6754b7e8	2026-07-07 00:38:53.618766+00	20240618164952_drop_scores_updated_at_idx	\N	\N	2026-07-07 00:38:53.616971+00	1
4dbbaa45-8601-42c1-8505-32784a561fcf	0f6b92ccc813c06eb9263e103d06c49bb31e5681c1eee935ce78b2302129e590	2026-07-07 00:38:53.620325+00	20240618164953_drop_traces_external_id_idx	\N	\N	2026-07-07 00:38:53.619034+00	1
78eb2232-c065-429f-96ea-ccfb3860c59f	e8d748c34b7129a45445356f094c587d6d8abcf6e6b545fdb86c7343503db2a1	2026-07-07 00:38:53.621764+00	20240618164954_drop_traces_release_idx	\N	\N	2026-07-07 00:38:53.62059+00	1
e07d26ed-fd29-4bf3-b6d8-be6f3d34e1d0	189b316f8030f65f38d576d67418f1171c12e642b05d6368cd07b44253fdc7a6	2026-07-07 00:38:53.623273+00	20240618164955_drop_traces_updated_at_idx	\N	\N	2026-07-07 00:38:53.622102+00	1
03fac91f-3a99-40fd-98e0-d656b8e6143a	54fce5d78c8c90abf77f97d3b1411ef0fa9346b08c113f6aa7127b4cba72bf13	2026-07-07 00:38:53.624974+00	20240618164956_create_traces_project_id_timestamp_idx	\N	\N	2026-07-07 00:38:53.623528+00	1
28aef071-56c0-4026-82fc-fb8e6cef28fb	f0a4088b40007ed6f163f39d19c1656d29185f5002d32c902f73e872c3db953d	2026-07-07 00:38:53.626551+00	20240624133412_models_add_anthropic_3_5_sonnet	\N	\N	2026-07-07 00:38:53.625348+00	1
5e4cfb63-7d20-48a0-84d2-747ecb55e7c8	9d90da7cedae6dec276adee4484197e2a07a7007c17ccb309dfe1c228f0afb15	2026-07-07 00:38:53.628167+00	20240625103957_observations_add_calculated_cost_columns	\N	\N	2026-07-07 00:38:53.626794+00	1
793403a7-1b62-4543-ada7-9216b3a6fa81	bd764616a4a133fcc775e140ec8b55f4cbbb553c69ab8d7f7f7095d0a32b2bc6	2026-07-07 00:38:53.629335+00	20240625103958_fix_model_match_gpt4_vision	\N	\N	2026-07-07 00:38:53.628444+00	1
493a28c2-8c74-44da-aa24-c68c8cb82e6e	1fcd4df49e013083ab4d3a0431ec979098eee48f568286401cde8fa4e3e3f5f8	2026-07-07 00:38:53.630464+00	20240703214747_models_anthropic_aws_bedrock	\N	\N	2026-07-07 00:38:53.629588+00	1
041232ae-e605-4bff-9c6e-319a6741e77f	bfe9303dbead984f51c5a743ca1106d5763600146ff1ed32de29676474887ef5	2026-07-07 00:38:53.632838+00	20240704103900_observations_view_read_from_calculated	\N	\N	2026-07-07 00:38:53.63071+00	1
17706211-2dae-41b4-bba8-8f0ad5bd4dc1	83c99f9d7f01ce1809e973fc571f11ce8f9a29c721832406b1632dc1340ce31a	2026-07-07 00:38:53.634534+00	20240704103901_scores_make_value_optional	\N	\N	2026-07-07 00:38:53.633219+00	1
124cb76a-a462-4992-b70f-071fb760dfd1	09738b0d810db898fc0cef843f3ee6a2329a01dc47d03c7120013c70c37b1e33	2026-07-07 00:38:53.714645+00	20240705152639_traces_view_add_created_at_updated_at	\N	\N	2026-07-07 00:38:53.712067+00	1
d641bf18-fcdd-4270-b550-36d5ae378cf4	b4c944a0fccea1e77f5b3026b958dfcf421d7c53794ef63289aa0ac3503b5f0b	2026-07-07 00:38:53.718283+00	20240705154048_observation_view_add_created_at_updated_at	\N	\N	2026-07-07 00:38:53.715077+00	1
b2bd2401-4f37-4964-a718-9ea2f8d0edd2	d3234c35c64e4ab9465ef5d699f2448147093e8d824e9287da35ae03b68276f5	2026-07-07 00:38:53.719335+00	20240710114043_score_configs_drop_empty_categories_array_for_numeric_scores	\N	\N	2026-07-07 00:38:53.71858+00	1
56b069e0-d949-4cd2-b3ab-2ad7aee6380d	ac968e7f259110955d27da88e05de49668356907f0832f7fe609738d515712f5	2026-07-07 00:38:53.720633+00	20240710114044_add_pricing_gpt4o_mini	\N	\N	2026-07-07 00:38:53.719659+00	1
f4c820e6-8ff9-411a-9157-d1185346078b	9ba7731449b181af27b35098e2737877179ecb607c5ee1cdff8ba70c4e973036	2026-07-07 00:38:53.725101+00	20240718004923_datasets_tables_add_projectid_composite_key	\N	\N	2026-07-07 00:38:53.720902+00	1
673891c5-2205-42b5-8146-c8e231112ff0	d4d71b3fd3254ac5a43f13e1ddffab6f77402911e682a8ee7d97f3db68c1c6d9	2026-07-07 00:38:53.726733+00	20240718011733_dataset_runs_add_unique_dataset_id_project_id_name copy	\N	\N	2026-07-07 00:38:53.725367+00	1
4d2d5105-09d5-425d-a4e4-dacd939d9d49	d0e5e3951923f398d25390a608624b8c7bb45349bd421441a0f502e406b04507	2026-07-07 00:38:53.728214+00	20240718011734_dataset_runs_drop_unique_dataset_id_name	\N	\N	2026-07-07 00:38:53.726965+00	1
20147ef1-cfa2-418b-966f-8f9192aadd4b	e30dba696d156c20754c34c32777b890361c2c1541b89ea17ec8f993eb9ae718	2026-07-07 00:38:53.813099+00	20240718011735_observation_view_add_prompt_name_and_version	\N	\N	2026-07-07 00:38:53.728463+00	1
08582056-d255-48ab-9511-0e15ae497e2d	c1608bf5817cd052359ecd3ec19096b5091247931bdc740b91b4ec97bcedeab9	2026-07-07 00:38:53.814797+00	20240807111358_models_add_openai_gpt_4o_2024_08_06	\N	\N	2026-07-07 00:38:53.813483+00	1
12027138-48bd-4ea8-ab17-c35acfc9abd7	8074e5eaabad18a6c7256d13fc7ae8639d038449d5dbb041143a95ca8d0730f1	2026-07-07 00:38:53.821815+00	20240807111359_add_organizations_main_migration	\N	\N	2026-07-07 00:38:53.815258+00	1
6d827ab3-83b8-4ead-8936-4435a0acb8ac	ed0c0eb8eb8228cdac017ac8c31e31b6cc552161806825d38985afd9ee131e48	2026-07-07 00:38:53.823195+00	20240814223824_model_fix_text_embedding_3_large	\N	\N	2026-07-07 00:38:53.822136+00	1
11da4638-45d5-4263-9303-d5e42c706d22	b390309bf9420d1873574d39bfafefe1cc9efb4720ff93aa67e7e6b5ecdb806c	2026-07-07 00:38:53.824898+00	20240814233029_dataset_items_drop_fkey_on_traces_and_observations	\N	\N	2026-07-07 00:38:53.823476+00	1
cfa530c1-a971-4607-881f-44763e296b1e	8c9d61879dd797ba022ada4f8c4ad9f20cf71f6c0e684096c0cdc55e25c192ac	2026-07-07 00:38:53.827412+00	20240815171916_add_comments	\N	\N	2026-07-07 00:38:53.825185+00	1
246e0865-0885-4f8d-9ab9-b805ea6ca64f	03510128bd751e5b3e5ea9599e2ad00cd7f24aed377607ebab1f56a639d73261	2026-07-07 00:38:53.913332+00	20240913095558_models_add_openai_o1_2024-09-12	\N	\N	2026-07-07 00:38:53.827689+00	1
e9a030c4-8676-42b6-8339-abad636fcb02	a5f429c21ec800e22377b61a192f208b8389718e4a950a4397c813b0af55adfc	2026-07-07 00:38:53.915332+00	20240913185822_account_add_refresh_token_expires_in	\N	\N	2026-07-07 00:38:53.913752+00	1
f288d7d3-9165-492e-bdc4-27b4468c7b87	a91283903fab2398cf4119aee153ee91c04697fae59b653aa82d89413507502b	2026-07-07 00:38:53.919103+00	20240917183001_remove_covered_indexes_01	\N	\N	2026-07-07 00:38:53.915826+00	1
b0b8ab39-6622-418e-a95a-1395caf0cb56	16e13d2443a42819ab5693c1f11e1ff6503cea8c54462066c2ddd15e99b007fd	2026-07-07 00:38:53.921296+00	20240917183002_remove_covered_indexes_02	\N	\N	2026-07-07 00:38:53.919577+00	1
64bcb104-3811-4dbe-a280-61d6c6f7ff19	5901031d78a2cbb177c0446288169a4485bba062cfc9a0a614e709931e150433	2026-07-07 00:38:53.922846+00	20240917183003_remove_covered_indexes_03	\N	\N	2026-07-07 00:38:53.921616+00	1
a8d9a800-4a68-4e35-ac03-9abb0bad039e	ad2dd180dc79f9253d1cbe523725b9ef6f2d39c9457ab3528131eb3ddc23d9cc	2026-07-07 00:38:53.9248+00	20240917183004_remove_covered_indexes_04	\N	\N	2026-07-07 00:38:53.923133+00	1
bada096c-ade0-4997-8f1b-635df2d60516	81f3dbc2a12caef5e57f520b573742fe0d143b8914b47c43448638d4379fbd3d	2026-07-07 00:38:53.926804+00	20240917183005_remove_covered_indexes_05	\N	\N	2026-07-07 00:38:53.925219+00	1
06ed43a6-d7da-4766-8e3d-bbf3e065829e	7abe1457f2e45389e5b7b1cb321ea6e487bbe02cd5820186d681bdbc28668e2f	2026-07-07 00:38:53.928332+00	20240917183006_remove_covered_indexes_06	\N	\N	2026-07-07 00:38:53.927117+00	1
ab1d5e30-8d18-4001-95d4-b485b2e6a018	851e507a8c51f16008faff917f9e457e321f4b090f6f197343683a837234f8f5	2026-07-07 00:38:53.930327+00	20240917183007_remove_covered_indexes_07	\N	\N	2026-07-07 00:38:53.92858+00	1
d34c1926-6d4f-44cb-921c-86f4dbe8d475	4f2bdda069ce30156aea5ad798c399078ddbd54b6839cb5f72e2c5d946352a28	2026-07-07 00:38:53.932239+00	20240917183008_remove_covered_indexes_08	\N	\N	2026-07-07 00:38:53.930626+00	1
6062cf83-d1dc-4265-9bc9-17cc88aea9c0	1f7d8f99ea875bcdd3962ab0a13902548718c781f103712051c43e43f3811bd1	2026-07-07 00:38:53.934425+00	20240917183009_remove_covered_indexes_09	\N	\N	2026-07-07 00:38:53.932752+00	1
a9a75fbf-3a87-4c47-bda3-023199f9db13	11f5f9d27072f867214018c24408b28c53e0c2acdba79492d3fe0ba7509d4954	2026-07-07 00:38:53.935983+00	20240917183010_remove_covered_indexes_10	\N	\N	2026-07-07 00:38:53.934736+00	1
b100301a-b463-49e5-a551-e8711541a1e6	6654947f9c4c7d552dff50426840a1bdb54cb8def0ac9697603d0a3f97164338	2026-07-07 00:38:53.937456+00	20240917183011_remove_covered_indexes_11	\N	\N	2026-07-07 00:38:53.936291+00	1
95d677eb-e810-4e19-b5a1-b9b5bf924d78	c4120d71f357eb5571b101e13961534009a45f5a3baefe51ac72f5cc1c31affb	2026-07-07 00:38:53.938786+00	20240917183012_remove_covered_indexes_12	\N	\N	2026-07-07 00:38:53.937694+00	1
ee3cc5cf-94aa-4917-9d1c-fbd86fd25c4d	cd4fa2a3c044b78666d0fc0011d89a5467101aa4322daa7873907f144c70f595	2026-07-07 00:38:54.011911+00	20240917183013_remove_covered_indexes_13	\N	\N	2026-07-07 00:38:53.939087+00	1
6c81d02d-eb90-47e2-8dc9-127d08e7b9b1	d73184a6312e4e7bd67c689865f158eb03c3fda4acd2662aa38fc53ef7bd1052	2026-07-07 00:38:54.014219+00	20240917183014_remove_covered_indexes_14	\N	\N	2026-07-07 00:38:54.012385+00	1
b19a1269-bfe8-4f01-b57c-771ed7c60029	6cd7928e5bf79f84180c78fdd7479bfd81f1aced40338b17b12924be899bc234	2026-07-07 00:38:54.015829+00	20240917183015_remove_covered_indexes_15	\N	\N	2026-07-07 00:38:54.014561+00	1
d53e9696-5945-4109-8072-7e7086829244	af5309595ed33080851fffd2de4c38aa3159df1e89dac976c9f228942b774edb	2026-07-07 00:38:54.017871+00	20240917183016_remove_covered_indexes_16	\N	\N	2026-07-07 00:38:54.016186+00	1
e0c6a350-9d73-4542-b5fa-f201da6381e7	2c12c46fa776893cdc6d215b0c6dec0531dc7bf8474454bf8de4d842ede48f24	2026-07-07 00:38:54.019393+00	20241009042557_auth_add_created_at_for_gitlab	\N	\N	2026-07-07 00:38:54.018195+00	1
df89f225-cccf-4547-aac7-9955dee1e889	58551031c2a3bbd0325b2610234e2316ee4c1d704ff42e402d65edd74ca5d120	2026-07-07 00:38:54.020698+00	20241009110720_scores_add_nullable_queue_id_column	\N	\N	2026-07-07 00:38:54.019633+00	1
bc240e3a-3c4a-4c09-a2cb-3d7acd2a0adf	0dbe91562f26fe8f61373f8447175b7ab7ca248f30b9dba95bd577697a2370d8	2026-07-07 00:38:54.026079+00	20241009113245_add_annotation_queue	\N	\N	2026-07-07 00:38:54.021063+00	1
0f9b6f15-5045-45cb-a4ff-785f8d7ac066	1473c5a5a9a83c6426e26cb71a3f78bff60527109eb8b7452d96afe76097012e	2026-07-07 00:38:54.027676+00	20241010120245_llm_keys_add_config	\N	\N	2026-07-07 00:38:54.026398+00	1
ea5b1000-7f21-42dc-9056-8520691d941a	bb520543fe657f6f0d129953ce797619e91db7479eb154b0e7f9d10664da13fd	2026-07-07 00:38:54.11492+00	20241015110145_prompts_config_to_JSON	\N	\N	2026-07-07 00:38:54.028021+00	1
9b53f29f-318b-45b9-9139-ebd574847551	ded2191a0871be7b5f9bba2c2f4385a756d567d2c6cf203e230fed2e872cb96a	2026-07-07 00:38:54.117924+00	20241022110145_add_claude_sonnet_35	\N	\N	2026-07-07 00:38:54.115431+00	1
87917113-8a1b-416c-bf70-4fea9aa85cdb	484041b7622a917effc1d608423692a072aa9d59e686627b367e4b9e9cffeed3	2026-07-07 00:38:54.119145+00	20241023110145_update_claude_sonnet_35	\N	\N	2026-07-07 00:38:54.118247+00	1
213b2cdc-12f7-49a3-b32a-c3e29ab2f1c5	c4c3bcf2de95f7bfd8f19b53a4714f83520afa1117f251ed444d0a5322e7e217	2026-07-07 00:38:54.122239+00	20241024100928_add_prices_table	\N	\N	2026-07-07 00:38:54.119422+00	1
8067ec63-dc5b-4dd3-98bd-051c92ba919b	44896f4896bfbfc0d1e7157def5d73912c40a49bc76334e71f7e4c9f385788dd	2026-07-07 00:38:54.124083+00	20241024111800_add_background_migrations_table	\N	\N	2026-07-07 00:38:54.122519+00	1
259bdf18-c5e1-4cec-9098-87af8ee3a8e9	47bd20bb7c5bba3d252474ae5bdf69136e40796fb5b0b9f9e988b29bb32cdae1	2026-07-07 00:38:54.125548+00	20241024121500_add_generations_cost_backfill_background_migration	\N	\N	2026-07-07 00:38:54.124388+00	1
545a80e2-3aee-412a-8330-21178ec9a343	df40a8b13f93c3f27304e151a2392b86dc6a1baaaa5979dad05b7fb7b5003f1c	2026-07-07 00:38:54.126596+00	20241024173000_add_traces_pg_to_ch_background_migration	\N	\N	2026-07-07 00:38:54.125779+00	1
bf151548-c7a9-4b5c-805b-97305dfeba1a	cd444613bc0a52ab579553655a9f12655fdf02373ae2195a49c6cb86fec64a11	2026-07-07 00:38:54.127693+00	20241024173700_add_observations_pg_to_ch_background_migration	\N	\N	2026-07-07 00:38:54.126847+00	1
16a421c2-3bc5-47a0-8fa4-2842d3167866	5378729e79a3a38e8ff596e1c147116e4016aeef7e49c3b08cb2dadb0f835bab	2026-07-07 00:38:54.12875+00	20241024173800_add_scores_pg_to_ch_background_migration	\N	\N	2026-07-07 00:38:54.127958+00	1
8430bc47-2591-4f95-82f9-e7be6a2314e9	192d7a00675ac998fbb295d08478ded69b4513286f5e3244af9f3ad99633c9a0	2026-07-07 00:38:54.130414+00	20241029130802_prices_drop_excess_index	\N	\N	2026-07-07 00:38:54.128959+00	1
f267344f-0f6c-4e03-994f-f1e4729a04ec	ef4fc49956097b140e83f2851fd27a551937c35de2d2bce13f38f049d8ff4cfa	2026-07-07 00:38:54.213708+00	20241104111600_background_migrations_add_state_column	\N	\N	2026-07-07 00:38:54.130649+00	1
08ab44a2-0228-4bd4-bfe9-b61121a29a35	122dc03a7a54b31dbca09d8dfcc588d456cf15b7ef10691512fc384a79780683	2026-07-07 00:38:54.215658+00	20241105110900_add_claude_haiku_35	\N	\N	2026-07-07 00:38:54.214257+00	1
74ee7192-e9c9-4b96-97af-7200ad39a52a	5b702f5f10383113f05ee768a48c99dc6e3b8040899d9b814452a94a38aec33d	2026-07-07 00:38:54.220199+00	20241106122605_add_media_tables	\N	\N	2026-07-07 00:38:54.21616+00	1
48ba6dea-029d-48b9-9093-5282dc773424	e6521663ec43b43a44681506fe0528386be64f557d51bb379ff564b908f8c715	2026-07-07 00:38:54.221776+00	20241114175010_job_executions_add_observation_dataset_item_cols	\N	\N	2026-07-07 00:38:54.220474+00	1
0c7f71d6-1a4f-4e30-88ae-43ccdeb46881	0dcf33385c6a828124e5110343582a41f5359e37a907ec56860f142c0685b6d8	2026-07-07 00:38:54.223485+00	20241124115100_add_projects_deleted_at	\N	\N	2026-07-07 00:38:54.222212+00	1
bd38e183-3831-4541-a6e6-a1e645367eae	ed1e394c590f6c66218a1c2d41558add7ee9e7ff67d86252a9abb580e5583b9b	2026-07-07 00:38:54.312586+00	20241125124029_add_chatgpt_4o_prices	\N	\N	2026-07-07 00:38:54.223728+00	1
d0010435-75bf-44b0-afd1-899e670daab9	fff5d82f8882908a3e525595f43bb3c5de3c58a1efe5040d6b7817730f2dfc2f	2026-07-07 00:38:54.314491+00	20241206115829_remove_trace_score_observation_constraints	\N	\N	2026-07-07 00:38:54.312933+00	1
b3223e9f-c434-4c7a-8289-9aabe785c3ea	71ab57e2aaa464d346bac47e4a5591f15a1de841c202e21b25399171055f98d3	2026-07-07 00:38:54.31686+00	20250108220721_add_queue_backup_table	\N	\N	2026-07-07 00:38:54.314736+00	1
001ddc72-2640-43f4-a6b4-38c07f537c14	98a6b3516f6a06d8842352cf238f4d38121dc43dfebda652d525f0975fe2e277	2026-07-07 00:38:54.318918+00	20250109083346_drop_trace_tracesession_fk	\N	\N	2026-07-07 00:38:54.317316+00	1
34f6fd72-dcd2-4809-9679-86c34ae025c4	21581f804308fa8de558ad55fffb7838086e4b061c94e34a07b31057069a6843	2026-07-07 00:38:54.322044+00	20250116154613_add_billing_meter_backups	\N	\N	2026-07-07 00:38:54.319262+00	1
025f27df-6945-4311-8a57-77fec630e060	d8f281a019cf572ad922d52643a82ae29b45cbda3daf91bd417fac5387d1d532	2026-07-07 00:38:54.323382+00	20250122152102_add_llm_api_keys_extra_headers	\N	\N	2026-07-07 00:38:54.322373+00	1
577db20a-b72d-4128-b885-2f1cbabdd13d	07356ee56e34ab4951a14f26f723217027d5e82bd0fc8c8eb5b5ff2660a74559	2026-07-07 00:38:54.324669+00	20250123103200_add_retention_days_to_projects	\N	\N	2026-07-07 00:38:54.323696+00	1
b3c84348-f9cf-49cc-b42a-bc92c5a30514	e36308f7b00615189688122c8d456745fb759e921d947aa686b8e306f70e94f9	2026-07-07 00:38:54.630735+00	20250529071241_make_blobstorage_integration_credentials_optional	\N	\N	2026-07-07 00:38:54.629997+00	1
a4758601-66d7-454f-af67-2a74eadefc41	ddf15ec992a1bf72b5c6d36b801d78303048488f6902c6db5630906a472226c9	2026-07-07 00:38:54.325856+00	20250128144418_llm_adapter_rename_google_vertex_ai	\N	\N	2026-07-07 00:38:54.324902+00	1
4380d1aa-47dc-4842-87d9-f7fa0028db8a	9b9fd8e619a81dfcb4bd5a8688ae99080775e0d64359c4e0c676f390fd164d5e	2026-07-07 00:38:54.513837+00	20250326180640_add_llm_tools_and_schemas_tables	\N	\N	2026-07-07 00:38:54.431372+00	1
53a33ee3-c07a-418a-add4-846548ff668e	916d04931a43f84bb3866ea7dbe91f90886e15902a7efe640685d1ac00a895e9	2026-07-07 00:38:54.327264+00	20250128163035_add_nullable_commit_message_prompts	\N	\N	2026-07-07 00:38:54.326139+00	1
c647159d-4097-4c0f-b2b9-2734a0409ada	fe609f993a2e30b89ee300363c232e23eca9c021650b4175d5ae9440f080add8	2026-07-07 00:38:54.329684+00	20250204180200_add_event_log_table	\N	\N	2026-07-07 00:38:54.327549+00	1
4ba8adb0-cb79-494c-ab7d-9be7d52c81d5	670d411441ecf47bb35fb12776d15c97682274280e0d3f130bb6e6284313c524	2026-07-07 00:38:54.533099+00	20250517273700_add_table_view_presets.sql	\N	\N	2026-07-07 00:38:54.530243+00	1
f938fc15-bb69-4058-aea4-8aaafc738824	c95eba615512a26d16323fb3acbc0e18f8672337faa00347ba5e69ff9add4051	2026-07-07 00:38:54.331701+00	20250211102600_drop_event_log_table	\N	\N	2026-07-07 00:38:54.32995+00	1
c7302f2b-b71a-4b51-805a-9e71b05c69b8	41cde9e5736ce4bf39e7bdecbb8fc45231806c35d831985ed63e095782307f99	2026-07-07 00:38:54.516636+00	20250401122159_add_prompt_protected_labels_table	\N	\N	2026-07-07 00:38:54.514214+00	1
d32f4ebf-856c-4ffb-9b6e-2e00d9a182c7	2b88192f03d6107ae4474626987b67fb04ccd8f2f0bd5df90482060d1fe1be9c	2026-07-07 00:38:54.411582+00	20250211123300_drop_events_table	\N	\N	2026-07-07 00:38:54.33216+00	1
8881bbd7-8cfe-4a3f-9448-a9439af49247	610ca7f00de318e435e411c61fd127cabe0e9e60191ec6342fe32d84d025da29	2026-07-07 00:38:54.414053+00	20250214173309_add_timescope_to_configs	\N	\N	2026-07-07 00:38:54.412171+00	1
999f1959-3b3d-403a-8143-c67f0ec4fd75	155bf498f9c784902de9f436156bd3acc85ab5b46c2090f074709705be358919	2026-07-07 00:38:54.41551+00	20250220141500_add_environment_to_trace_sessions	\N	\N	2026-07-07 00:38:54.414448+00	1
85d59549-bd66-4375-8b0c-32ff9275d848	c5ec79297d62adce8f40b44d95afd64c6959f2af3686d1cfeee7fe915b62af38	2026-07-07 00:38:54.518309+00	20250402142320_add_blobstorage_integration_file_type	\N	\N	2026-07-07 00:38:54.517021+00	1
51912112-398c-461d-a471-f1df0c6e9262	babf160203fb954584ac1aeae8b5e07c9bca0b369811321080617c090d382d4c	2026-07-07 00:38:54.417547+00	20250221143400_drop_trace_view_observation_view	\N	\N	2026-07-07 00:38:54.415773+00	1
89162bbb-1e06-45ff-9810-77ed101d6c1a	b7a6b9dd99177e19294793f80f95c27b71e45523fe6a5763025728da6ca2621b	2026-07-07 00:38:54.420641+00	20250303144044_add_prompt_dependencies_table	\N	\N	2026-07-07 00:38:54.417785+00	1
6a5e3ea4-5819-4322-a828-eda6258f749f	071875a23a2c6410fd22f62019d19ce951284da9567dfc72acb8f7eb42cd8203	2026-07-07 00:38:54.620634+00	20250519145128_resize_dashboard_y_axis_components	\N	\N	2026-07-07 00:38:54.619116+00	1
63f2ecde-c972-4aef-b737-5ec9b70fe21e	f3e96267de3ec2bb07f6a25a7d0d8cfe424bcac8c7619ac6c18609f9b1b0b96f	2026-07-07 00:38:54.424889+00	20250310100328_add_api_key_to_audit_log	\N	\N	2026-07-07 00:38:54.420874+00	1
b00541d3-fde3-414a-998b-87338f1762df	2c7a858dea2387571dd89b9e0a3467a02eab99b1a65fb5ba093eaa12c8a2136c	2026-07-07 00:38:54.520123+00	20250403153555_membership_invitations_no_duplicates	\N	\N	2026-07-07 00:38:54.518546+00	1
6b575508-bc40-46c8-b31b-ae246f29c914	24e39d91e19cb056a39acd9b6592522cab163023a7d10e147d9ececeb63e0d1f	2026-07-07 00:38:54.427687+00	20250321102240_drop_queue_backup_table	\N	\N	2026-07-07 00:38:54.425373+00	1
51f2100d-8b85-463b-a728-e7bd8970a574	8bace424aceba30300d1d2d8d90fcb8209471ee8cef7eb6527117eb63cf96faf	2026-07-07 00:38:54.431083+00	20250324110557_add_blobstorage_integration_table	\N	\N	2026-07-07 00:38:54.428197+00	1
2bbcde22-bb66-43d2-bfca-3d0ac3affe7a	64b1a56e3815187b925f652983db94f37263ce00b1eed612c1b646779ffaf847	2026-07-07 00:38:54.534889+00	20250519073249_add_trace_media_media_id_index	\N	\N	2026-07-07 00:38:54.533491+00	1
53f1c838-1063-4a58-80ff-ecd7a31fed77	65c0994e81c364fb6b01ff38ad5e9e037218af9d11fa001d0e65267ce7fdb3f7	2026-07-07 00:38:54.523605+00	20250409154352_add_dashboard_data_model	\N	\N	2026-07-07 00:38:54.520447+00	1
fbaaa462-6d35-4c14-b263-e0782b28c700	4fe9ed1f12de88f2d66a66c887ced62d4d727fd833eee8b6e2eed0d9944748fa	2026-07-07 00:38:54.527217+00	20250410145712_add_organization_scoped_api_keys	\N	\N	2026-07-07 00:38:54.523885+00	1
00e78b27-b803-488e-ad5e-e2944d802588	79807bab1f3a292d072c99b1fbbf0daa02c9d0c54b4976b98e5477ec3d0b5b12	2026-07-07 00:38:54.52858+00	20250420120553_add_organization_and_project_metadata	\N	\N	2026-07-07 00:38:54.527572+00	1
f81faa44-d821-4427-855b-d89108b176f6	f3b2453254f97d81f8320d460693b02dd3a1a76de7031c572dad0807cbe57327	2026-07-07 00:38:54.536838+00	20250519073327_add_observation_media_media_id_index	\N	\N	2026-07-07 00:38:54.535348+00	1
cbe73092-fd69-49d2-8251-2b8bcc98aeda	4b0562acf18e11c04dfcaeef625db3aede55d5136920b4445a7ede55b733565e	2026-07-07 00:38:54.529934+00	20250517173700_add_event_log_migration_background_migration.sql	\N	\N	2026-07-07 00:38:54.528821+00	1
d1768c02-fc28-4a04-86d2-87613eb5e0ad	000eaa772485b57e9722d1dacbb908a15f47dc5589a8927b292dc4c03c7d9e5b	2026-07-07 00:38:54.626489+00	20250523100511_add_default_eval_model_table	\N	\N	2026-07-07 00:38:54.623865+00	1
d25eef51-a1d8-4e2d-89f6-240c10d01ab8	de0e8d606441950d5aabc18571d3ef62caa9afcae1b06f0145b08d2a6902b2c1	2026-07-07 00:38:54.611489+00	20250519093327_media_add_index_project_id_id	\N	\N	2026-07-07 00:38:54.537088+00	1
13ef8578-996b-4233-ab6b-0e0890dea3fc	1401e17420746a980a3882b9014f6e49bb0750f93f3a217edafc23e1e5268027	2026-07-07 00:38:54.62172+00	20250520123737_add_single_aggregate_chart_type	\N	\N	2026-07-07 00:38:54.620961+00	1
6a258d3d-e731-4132-9ea6-3399a8869209	74b0791deb3c76c8198a1630ae93d98dcdb6083b650ebd69cbcdddf141e40ab2	2026-07-07 00:38:54.618687+00	20250519093328_media_relax_id_uniqueness_to_project_only	\N	\N	2026-07-07 00:38:54.613109+00	1
3c9c6867-526e-41b4-b531-5ad333769d19	9ec7a6cc826777c7826611408a05a674080ad1308b1f9da7daabe2bb720abd61	2026-07-07 00:38:54.623611+00	20250522140357_remove_obsolete_observation_media_index	\N	\N	2026-07-07 00:38:54.621921+00	1
921b0652-38cf-46c8-a16b-b07644e7cf55	abd17ea0a2fdd19e1a9f85b0d3eec2b11284b48edf66705094940904bb2cdfce	2026-07-07 00:38:54.629785+00	20250523120545_add_nullable_job_template_id	\N	\N	2026-07-07 00:38:54.628442+00	1
c7161355-463b-4fb2-b348-5cdae3b63101	39522d14988272c6ba1521efe8f2a8bcbfe5acadafaa6bf4d30af94f52555e3a	2026-07-07 00:38:54.62818+00	20250523110540_modify_nullable_cols_eval_templates	\N	\N	2026-07-07 00:38:54.626845+00	1
399f2c43-a37a-4b0b-affc-04d3bdb9705f	ac7ec936b6dd3b5802ce6bd8a4dccd0d94d2c0466a96744c3e81b4eb0a93531b	2026-07-07 00:38:54.631701+00	20250604085536_add_histogram_chart_type	\N	\N	2026-07-07 00:38:54.630954+00	1
dac13ab1-91f5-4a1d-8a43-d63d7d6e8c3a	ecc1e58ba7f6fa3fd1044b12a212e983cedaa782be717d4607a617b70a9833c1	2026-07-07 00:38:54.633323+00	20250625_add_pivot_table_charttype	\N	\N	2026-07-07 00:38:54.631924+00	1
047c453f-1af5-4787-b6bd-099291ce7260	c2f92d8dfeea88b5d80cf89265442602aefbbd73ca8d32d213ca60afa6b914e5	2026-07-07 00:38:54.638902+00	20250704170658_add_automations	\N	\N	2026-07-07 00:38:54.633592+00	1
507ec3ab-ed37-4270-aca9-c6e7100cee95	53abd9c84fe73a03688103e047ca6f1a969779a25c6fd0802b039d8987d616e1	2026-07-07 00:38:54.713885+00	20250709113103_add_blob_export_schedule_type	\N	\N	2026-07-07 00:38:54.712319+00	1
7dfd19fa-8f53-4b79-a5d8-ffdaeb7189a6	c961689843fb807b69f2dcd58c8fdda00da332be0719e5c9ef375f7dd322ff56	2026-07-07 00:38:54.71589+00	20250711105322_prices_add_project_id	\N	\N	2026-07-07 00:38:54.714241+00	1
676ee9f2-9e1f-4773-b38d-8d6112c9e09e	c4cae7f4e7270fad87303393af989bd34d068da92ac5825f4b4b3c985a4d3c37	2026-07-07 00:38:54.828529+00	20250925133604_organizations_add_ai_features_enabled	\N	\N	2026-07-07 00:38:54.827397+00	1
6d2d3298-c607-4f14-a0cf-d9fac2c41637	8a3f0a48dedf9115d631170de8da45f1aec2d28fc9fb84b1505513a076df8132	2026-07-07 00:38:54.717144+00	20250711134738_add_patch_llm_tool_schema_audit_logs_background_migration	\N	\N	2026-07-07 00:38:54.716288+00	1
8d148fd7-aaca-4e6b-9001-d9d9b8847cce	3384cb6e7e4c50503e6b83a4aa0d6c0c09d6e5f7595913df218ef8baf521d97b	2026-07-07 00:38:54.811268+00	20250814090100_remove_dataset_run_items_pg_to_ch_background_migration	\N	\N	2026-07-07 00:38:54.739341+00	1
d9e52b25-dd7f-4780-8b41-71e498ce7f5f	fc7e946590b81ab44171ead27bb8f1143c335457322c9d5bc4f32025e7d5fbce	2026-07-07 00:38:54.718684+00	20250714151410_add_trace_session_combined_index	\N	\N	2026-07-07 00:38:54.717365+00	1
a5f28634-4bdc-4818-85a3-367392ff7308	4ed5f1308f10ff3ebe621cfde4c6d641d833aa613dd745cd72a1fb1335934cdc	2026-07-07 00:38:54.72004+00	20250714151410_remove_trace_session_created_at_idx	\N	\N	2026-07-07 00:38:54.718921+00	1
6c9830a3-a5a8-4cb0-999b-7bcdb958ad4d	9f47accb94b941e1834732eb90ddea0e70fd0b5910182f539724d0cae7bc4e25	2026-07-07 00:38:54.821728+00	20250820143861_optimize_job_execution_indices_drop_job_executions_updated_at_idx	\N	\N	2026-07-07 00:38:54.820686+00	1
0055265e-0389-4cf1-9166-24084b0b4711	348f9f83e64e8fab1c79c4022c72d167325cfb737170326cd35d80b7ef409aa6	2026-07-07 00:38:54.721244+00	20250714151410_remove_trace_session_project_id_idx	\N	\N	2026-07-07 00:38:54.720276+00	1
2c936eec-fc5b-47e3-8bba-4e4b6a40bf9c	60de9b43a398c2db16209e1502a40e882450f9fada0bdd8ac35114fa8b703bf0	2026-07-07 00:38:54.813139+00	20250814100100_add_dataset_run_items_rmt_pg_to_ch_background_migration	\N	\N	2026-07-07 00:38:54.812108+00	1
0883fcfb-b34d-45ab-b411-008e37da2c38	42953fb349d68dc6c503a42b036a71a9f0f9a8757489e4d5dba7eb90c9f4ada3	2026-07-07 00:38:54.722362+00	20250714151410_remove_trace_session_updated_at_idx	\N	\N	2026-07-07 00:38:54.72145+00	1
af4a55ed-9a02-4f4e-8fe8-cb6f6f22ea85	f782a736c6ccc1a86a86f498ddea3740e3bcae85aaf3e02e427321a5705d9dfe	2026-07-07 00:38:54.723408+00	20250724114251_add_webhooks_datasets	\N	\N	2026-07-07 00:38:54.722598+00	1
52207aed-adaf-4e19-9ab6-e6eb981f3026	0fb15d38e19afb856adafb1a2f6acbd09a1dff8180a40e83b6b67ac452266e84	2026-07-07 00:38:54.724868+00	20250724160133_add_session_object_type_annoation_queue_items	\N	\N	2026-07-07 00:38:54.72363+00	1
e4d71651-7093-43e9-80b9-702ff55ca4e5	6fb46ef58f29f9e6c89119a08367b5eae1c0c85d87472a9efb233d8614bee172	2026-07-07 00:38:54.814713+00	20250820143856_add_observation_types	\N	\N	2026-07-07 00:38:54.813478+00	1
aaf0a17c-1cfc-4e2d-9d0f-ff4313bfddd8	08dc14fe73239faa2538867c30afea5adde1a711c27aefa366bc94e3cab7cc2a	2026-07-07 00:38:54.728482+00	20250730100100_add_slack_integration	\N	\N	2026-07-07 00:38:54.725521+00	1
7e751745-b0c8-4809-9879-7988ba0dacf1	6af356c38b4fd2e90e83079744bf782807b5a787edce92896fda27b012a712b7	2026-07-07 00:38:54.72959+00	20250731100100_add_dataset_run_items_pg_to_ch_background_migration	\N	\N	2026-07-07 00:38:54.728815+00	1
aca0ceb3-3453-4252-88ae-6d454a3eab9f	74b3c62edc7da75b32acd2fea0c1328dc60c93df2b680530e16cd57b461388b2	2026-07-07 00:38:54.732378+00	20250731202005_add_trace_deletion_table	\N	\N	2026-07-07 00:38:54.729845+00	1
ef2ae7b6-d354-4244-9f19-5da720772310	2dc0e1afc2d7479453bd8098a1a8546e0f4ecf6219ce6c9abc5bc42e18d976d3	2026-07-07 00:38:54.816078+00	20250820143857_optimize_job_execution_indices_drop_job_executions_created_at_idx	\N	\N	2026-07-07 00:38:54.814934+00	1
2137f18a-6299-429d-b3f8-0edc92456cda	d6b6df9781377bcbea339d9393e882b6eabdd85adbafd352800dbb3ccb3d84c5	2026-07-07 00:38:54.736233+00	20250806100613_add_annotation_queue_assignment_table	\N	\N	2026-07-07 00:38:54.732671+00	1
b8ce3242-ed52-4a5a-9974-f04167b02d03	572bdbf9cdcc3340da9df55c727b1dc9b48a500034899ea03f3999ac763c0b8c	2026-07-07 00:38:54.739079+00	20250808081624_add_surveys_table	\N	\N	2026-07-07 00:38:54.73654+00	1
e33a767b-9129-4f9a-933d-8e223b28211b	9ea7de5c91e77632b36e6de0054d15e9f4039153513e6aea7d640fa5ea63ae08	2026-07-07 00:38:54.823562+00	20250820143862_optimize_job_execution_indices_create_job_executions_project_id_job_configuration_id_job_input_tr_idx	\N	\N	2026-07-07 00:38:54.821953+00	1
2a8260dc-50c2-4249-a8d6-1652fd6f4af9	b9cf1c9cb82862456abe71bbde6fc174308f9cc8469ef59134129eaab73931ee	2026-07-07 00:38:54.817828+00	20250820143858_optimize_job_execution_indices_drop_job_executions_job_configuration_id_idx	\N	\N	2026-07-07 00:38:54.816543+00	1
dacaabfa-b7fb-4931-8d08-02b54b2dd451	334e32774a908f13d51be259d5028bf928eb1c3863fca390d1427323a91ebd5f	2026-07-07 00:38:54.819253+00	20250820143859_optimize_job_execution_indices_drop_job_executions_job_input_trace_id_idx	\N	\N	2026-07-07 00:38:54.818147+00	1
17e55bc9-376f-477f-9c42-65cc8710a748	be4be890b8c8f91cd9251da7bf82d82dbc37f573d683d514c89c3da5744d04a7	2026-07-07 00:38:54.839145+00	20251014161635_job_executions_add_execution_trace_id	\N	\N	2026-07-07 00:38:54.838337+00	1
0f0c960b-d02b-4523-860c-229d090ecbdc	d6ac911a135d04f0b977a0ac52d87320d2c9cd107ffeaa3a827b75fd0455e2cf	2026-07-07 00:38:54.820474+00	20250820143860_optimize_job_execution_indices_drop_job_executions_job_output_score_id_idx	\N	\N	2026-07-07 00:38:54.819545+00	1
a80e237b-7270-42a1-a46d-88db39071409	e3b5b3307564af4771c047cdd510ceb8586da012f592b576787050b4e9f9a65e	2026-07-07 00:38:54.824914+00	20250822135300_add_dashboard_filters	\N	\N	2026-07-07 00:38:54.823767+00	1
4401f9db-cd81-4548-b8be-b72e22d63b4b	940de62b849aa09cdc5fc2b0513b445665299cc4c1459d45a4eb70de9e53dc57	2026-07-07 00:38:54.830007+00	20250930125453_job_executions_add_output_score_index	\N	\N	2026-07-07 00:38:54.828781+00	1
50b7ed52-73bf-4af8-b76f-3435bbefa96c	408143a40bc48d6cf4ae8d426436fc84f0821a2ee67cf80100b15986c56d728a	2026-07-07 00:38:54.826951+00	20250825100104_job_executions_add_input_trace_timestamp	\N	\N	2026-07-07 00:38:54.825243+00	1
3c8413b5-f3d0-4d3a-a8bb-2bf4913d86a6	e5a9d371c59274908a0150af35bf8f3819f284d216f2c0ab0dee8d8485a1d7eb	2026-07-07 00:38:54.835112+00	20251006173445_add_cloud_spend_alerts	\N	\N	2026-07-07 00:38:54.83257+00	1
43d42e90-0a97-4885-a160-1559e751b55a	6fc55b6c5b091b7e395f7751db8fceae2cab4e2785c65042b8ffde8908d9212e	2026-07-07 00:38:54.831202+00	20251001161539_organization_cloud_billing_cycle_columns	\N	\N	2026-07-07 00:38:54.83024+00	1
112a535e-ea2c-41ce-8ede-d1b56925ffaa	57097b2938a7fda042b5db34f3a91029f0675e2592b03fc43f0559494fc7470d	2026-07-07 00:38:54.83808+00	20251013134801_drop_atla_llm_keys	\N	\N	2026-07-07 00:38:54.837211+00	1
289dcd58-eca5-428f-bf5b-8056951ea6a0	611a6b69f24468a3ac4a2b406ddd1d70c10d578da13bdf6339f354edd79f9294	2026-07-07 00:38:54.832141+00	20251002153814_add_backfill_billing_cycle_anchors_background_migration	\N	\N	2026-07-07 00:38:54.831427+00	1
e9d5d34e-461b-417d-adb4-29befd969d8b	559b1271c4adf52add455e108aa5069153cd4dfb852c1d67f0dfe0626341c996	2026-07-07 00:38:54.836915+00	20251006173446_optimize_cloud_spend_alerts_add_index	\N	\N	2026-07-07 00:38:54.835514+00	1
74479d63-76bd-408a-9f93-90d05a4519c0	05a0c8fd515f1aa78a48bfb5502cf5af48f8c601ec3266d4154a2239c622b4f5	2026-07-07 00:38:54.84129+00	20251024193002_add_mixpanel_integration	\N	\N	2026-07-07 00:38:54.839388+00	1
3c65dd8b-0ce1-4c50-b5e5-111b7eb16455	c3cad749af120dc14bf302723bc3806135630e58b075eaf72ae440e120e701af	2026-07-07 00:38:54.844189+00	20251028143653_add_notification_preferences	\N	\N	2026-07-07 00:38:54.841614+00	1
46d511f4-0ee3-4e44-8107-ab3c5a7e04a9	87eb15389554a98df66bd168788d1a49c9bfac4c64278319ce34182566c0b871	2026-07-07 00:38:54.913911+00	20251028143654_add_notification_preferences_redundant_index	\N	\N	2026-07-07 00:38:54.912028+00	1
94ef3b25-b1b6-41f4-bf61-83911f856402	6d38c6b3f5ba31276d9864bf455bd778d3afeb1f276f387056127ffd0a2868c5	2026-07-07 00:38:54.916708+00	20251029000042_add_comment_reactions	\N	\N	2026-07-07 00:38:54.914279+00	1
78eb72ae-8f8e-49bd-9eaa-686770a0e235	19badff17c8e669b6ed1411e3ebf940cc877e37eb7a4210b8b2d6628881de326	2026-07-07 00:38:54.919586+00	20251029000045_add_comment_reaction_idx3	\N	\N	2026-07-07 00:38:54.917026+00	1
97ea183e-bec1-42b8-bc87-0d92382d9f3d	4f4dcf1eaac921bfeea3964ab373d045b6c4513bda63bba4b055e3085efaea3d	2026-07-07 00:38:54.92075+00	20251104091248_add_dataset_schema_enforcement	\N	\N	2026-07-07 00:38:54.919871+00	1
7922b57e-6f2a-40f3-91d3-8e635f10a0ba	7e286e323329b6d3bc9fd50dca4339ba090178e63a77cda8df768b174e63a14d	2026-07-07 00:38:55.021471+00	20251215230232_dataset_items_add_idx_project_id_id_valid_from	\N	\N	2026-07-07 00:38:55.01975+00	1
04bb4646-6188-4b8e-902c-e5269d67820a	86ecef35a440c002ea0d8d4f80771adf795b18354a661d9699702cfb1b66652a	2026-07-07 00:38:54.92264+00	20251118153536_add_dataset_item_event_table	\N	\N	2026-07-07 00:38:54.921023+00	1
e579b2db-ce3f-4982-8b8c-7f30c1d08b3d	c5f612d41358710b4c9519658195a03a838b2fa6769bd8121726c0356bff05ab	2026-07-07 00:38:54.923773+00	20251118162943_add_idx_dataset_item_events	\N	\N	2026-07-07 00:38:54.922858+00	1
56fa298f-a290-4c25-9633-6f6fa191fee6	a45575fa7d4b08d9d05d6e2f76000f0eb7587e4fd933ffed717ce8a69335b0cb	2026-07-07 00:38:54.926212+00	20251126000000_add_comment_search_indexes	\N	\N	2026-07-07 00:38:54.923966+00	1
92ac18ac-0b94-4e36-8796-38b9d8094e79	d0fb58dacf858ea7c37eef7a8e6910e5c54f8761cfa9c05a09a1cb5749a91357	2026-07-07 00:38:55.023092+00	20251215233730_dataset_items_add_valid_to	\N	\N	2026-07-07 00:38:55.021728+00	1
81a0e6f3-4b77-4a1c-82d7-86b65308299f	559aaa80783eb4acfe389802a7432bd964b6672a7ed6536041fe5dd89c848050	2026-07-07 00:38:54.930723+00	20251127105316_add_pricing_tiers	\N	\N	2026-07-07 00:38:54.926712+00	1
9a8fc080-c552-4508-9101-0a347a9a5d57	58438531bb4b75c51d0c9a593338733b2cd1d0e84f13d0be4091222c5cd4da84	2026-07-07 00:38:54.933168+00	20251127181728_add_prices_index_on_pricing_tier_id	\N	\N	2026-07-07 00:38:54.931112+00	1
59352d42-d44e-4bc8-bed6-b540d9fa11e8	d92afa52972e3dcf5d966f7ffb99840a70c55dd62ccac1227a0c0bfcfa84f8c6	2026-07-07 00:38:54.935193+00	20251201095227_dataset_items_add_version_cols	\N	\N	2026-07-07 00:38:54.933491+00	1
9a967717-b64c-441c-ad24-418a1ecee49b	f0d7f563d10672112f5160b37969154c530dbcbc1d96cec4c2a9f8768799b600	2026-07-07 00:38:55.024441+00	20251215233903_dataset_items_add_idx_project_id_valid_to	\N	\N	2026-07-07 00:38:55.023338+00	1
3e067f58-ea71-489d-9a26-94a5dd409b55	53fd2972f4df0ee5c7773fc196a530ad33b4d3241eb44ce48d47c0e05c81b66f	2026-07-07 00:38:54.936345+00	20251204213345_add_github_dispatch_action_type	\N	\N	2026-07-07 00:38:54.935524+00	1
b8320c5c-3c30-408b-b4c4-0a6f42cab285	82bc083acaae0a9ed8cfc493bdd250ebcf4b89fe1d3e88476dcfb4249e8da136	2026-07-07 00:38:55.011994+00	20251208121203_dataset_run_items_drop_fk_dataset_items	\N	\N	2026-07-07 00:38:54.936776+00	1
4643b4cd-f0e2-4d15-a144-bb2d35c1a5c9	806d18eacef84e9b0c8a8c79da5c8190e6ccd40a5c978d666d868de21ddfa6dd	2026-07-07 00:38:55.015093+00	20251210130559_add_batch_action_table	\N	\N	2026-07-07 00:38:55.012492+00	1
81686232-0706-47fe-b634-bee82780e35f	881641199d1c5b8cf4754b07577ce8e82f5b49c41a9899e86d8ccf8af1f94c89	2026-07-07 00:38:55.025794+00	20251215233905_backfill_dataset_items_valid_to	\N	\N	2026-07-07 00:38:55.024844+00	1
47ab00af-35be-4fd0-8a01-a30cdde59533	1e6e8780a44a31978a3f32c39113ae8110a575087d0f0a74d1b543ec4afc9cb5	2026-07-07 00:38:55.017518+00	20251210133946_dataset_items_create_idx_id_project_id_valid_from	\N	\N	2026-07-07 00:38:55.015661+00	1
f1a97a95-46e2-4790-9f70-c86716cf0015	32ab1e85bd472674934e5c3e70bf84e79b047f6d09a745bb9cbfcdb761295734	2026-07-07 00:38:55.019477+00	20251211204006_dataset_items_switch_pk	\N	\N	2026-07-07 00:38:55.017813+00	1
03905055-b590-4481-9c9f-c17b4e4d327a	edad5e239834fe3b31c73c9ac3eeb82a24768932bccbf5c51f8ce36c478fd097	2026-07-07 00:38:55.027249+00	20251218102933_score_configs_rename_score_data_type_enum	\N	\N	2026-07-07 00:38:55.026068+00	1
892ea68b-f441-41f5-9319-489f901d9c79	e620a7766633fff68a4bae8cecdc62b15bacd4a2af10154e1edefd6e7bfa8311	2026-07-07 00:38:55.028422+00	20260106120000_add_encrypt_blob_storage_secrets_background_migration	\N	\N	2026-07-07 00:38:55.027514+00	1
88627b51-7c0b-4835-8276-0c839ba7651c	41ddbd43f29adf1a6d297a286e98d001f771f8c8eafd955c0c3b767c25ed6831	2026-07-07 00:38:55.02979+00	20260106130000_add_inline_comment_columns	\N	\N	2026-07-07 00:38:55.028684+00	1
7dc08bc6-754e-44ab-ac6c-42ecbae73e6c	fa60bebbe2d6e6db5daf85839e3af65144e3109a04a75815c33da4e9ad8c41f4	2026-07-07 00:38:55.030956+00	20260113102907_dataset_items_drop_sys_id_col	\N	\N	2026-07-07 00:38:55.030096+00	1
b5f89488-534f-464d-9f57-aaabc9120f6f	823ac1fd282b501d46fac831e839b658652858d247eda89fccba954706c1127b	2026-07-07 00:38:55.032232+00	20260113112907_dataset_item_events_drop_fk_datasets	\N	\N	2026-07-07 00:38:55.031237+00	1
e3e6c4c9-a2fb-41dc-83e6-71b42c178970	b1835fc9a864e4fb464a6071070cb4a43963a1ea595b6627864213af57ef1ce4	2026-07-07 00:38:55.034974+00	20260113114006_dataset_item_events_drop_table	\N	\N	2026-07-07 00:38:55.032785+00	1
290e2259-6256-4559-afe6-bbf723b1ca15	50f0d3a26bf21ac8b39e67811548497b7cdcc474cadde963fd293f78fdf6a809	2026-07-07 00:38:55.037006+00	20260122124934_add_export_source_to_analytics_integrations	\N	\N	2026-07-07 00:38:55.035301+00	1
c42c9d48-e913-4a03-9c38-09a125eb47ba	d45059979f1908757384e8d9a91a0475cf05d2ebd6fbc60a232964b463a41b11	2026-07-07 00:38:55.038903+00	20260129183823_add_media_project_id_created_at_index	\N	\N	2026-07-07 00:38:55.037306+00	1
a110fe0c-63db-4d30-a7a0-e104e080916e	4923b1a9a575192eabcb001b0fc5cb141a2f65a4fa6a035a9aa724f88e0a36c0	2026-07-07 00:38:55.11165+00	20260130000000_add_v4_beta_enabled	\N	\N	2026-07-07 00:38:55.039318+00	1
4d8965c9-d5e9-430f-8af7-3b80b54ad810	6c355423fc7bf8b0f9d67ac5fd322630c9b60d747c3fbddedb30251c85c6f9a7	2026-07-07 00:38:55.113418+00	20260203102941_job_execution_add_dataset_version_col	\N	\N	2026-07-07 00:38:55.111966+00	1
21ec619d-6e48-454a-a428-16534101e66e	ce0f82cd7dfba380136f607e0decebe00d754d9f4d59fd50af1aae8193916fa9	2026-07-07 00:38:55.115352+00	20260203220623_pending_deletions_object_id_idx	\N	\N	2026-07-07 00:38:55.11378+00	1
e66c5146-8459-4507-88c2-846e940ca0a7	6ada6e6b4bd2023cbee4115d66fb5efd671e4774313b7d8cf7384d1616b540ab	2026-07-07 00:38:55.116921+00	20260209000000_add_project_has_traces	\N	\N	2026-07-07 00:38:55.115608+00	1
09e9f2fb-5718-402f-a379-392fcb5b8dee	c081472afa393bcd712aaffff7b4fd46a51aa0db3d823ab24ef7da6bc1eaf023	2026-07-07 00:38:55.118759+00	20260211132728_add_chart_type_area_time_series	\N	\N	2026-07-07 00:38:55.117418+00	1
3f88f522-9906-4c6a-ad5a-a7072ebbe0d7	e168f14a7531ed608e1b457501364ccbd369e9fc351b461094defd95a2ef4b4f	2026-07-07 00:38:55.122248+00	20260211164349_add_default_views	\N	\N	2026-07-07 00:38:55.119213+00	1
5b18a57d-fd06-4de2-9257-1e4f4f3c69d9	c4746f96f4a30550430066a870e49d4a7330f57d57faf715aeab9192e8d6de43	2026-07-07 00:38:55.123574+00	20260224000000_add_widget_version	\N	\N	2026-07-07 00:38:55.122583+00	1
3ce29864-bfe1-403f-aa17-95235a0d2ff1	15c095a8a79cda1a89e48446f43b41ae2080a6f9f40853b33b98dc521a2ab13b	2026-07-07 00:38:55.124961+00	20260306143000_add_eval_config_block_fields	\N	\N	2026-07-07 00:38:55.123801+00	1
eedbece3-9a8e-445b-a944-6987f472b54b	c5c3746871856389e459e48d64e189ea0f0a80795d9d41e6046f9c1b33eed44f	2026-07-07 00:38:55.126702+00	20260312000000_add_blob_storage_integration_error_fields	\N	\N	2026-07-07 00:38:55.125286+00	1
8eb4842b-76da-4b9f-9b08-52e9c036c393	206b0c92efb8b74e697bebde5fb00ca0d9c321cf31531b76e174b5d217420b4a	2026-07-07 00:38:55.128214+00	20260316000000_add_blob_storage_failure_notification_sent_at	\N	\N	2026-07-07 00:38:55.127176+00	1
da333ea9-5e7a-4cd3-b8a4-c69527118b24	898c5c2dc4959f9140dbc38c3361ad39413a283a073749dc7a332dc57676bd2d	2026-07-07 00:38:55.129813+00	20260318100000_drop_job_executions_project_id_status_idx	\N	\N	2026-07-07 00:38:55.128463+00	1
00f6621b-4ab6-4558-a662-8f901aa92ed7	f95f3d8ff87127216667b643b771b279d624767814f4b6727e311904b5265f98	2026-07-07 00:38:55.131372+00	20260318100001_drop_job_executions_project_id_id_idx	\N	\N	2026-07-07 00:38:55.130133+00	1
73750773-8c32-45eb-bce2-f5a4cccd7e21	45dd06b952805a01d09c90ffb544e56e5ed35b90d254e15f6300a650e9539a0e	2026-07-07 00:38:55.132786+00	20260323000000_add_blob_storage_compression	\N	\N	2026-07-07 00:38:55.131649+00	1
b84ccf4b-ef87-4685-89a7-bfeebcdd8d8c	f0767dc0e30f49be7c131267911d595624d1b8c0c2debdb14954e489134c5ca1	2026-07-07 00:38:55.135097+00	20260324000000_add_job_executions_job_configuration_id_idx	\N	\N	2026-07-07 00:38:55.133219+00	1
db3b252b-aa65-4cb9-819c-372aee674764	f866fa56a4dd6c72818b08fdb3547a88e3477e2e09dc80b194186cc9ca7c9efa	2026-07-07 00:38:55.136811+00	20260327000000_add_free_form_score_config_data_type	\N	\N	2026-07-07 00:38:55.135552+00	1
f3905985-844f-492a-8beb-9d4203f35561	cf54f83334a73f1315dcb747579860defef8a889b79e1174441aa9d350e714d4	2026-07-07 00:38:55.138355+00	20260423084654_add_datasets_remote_experiment_enabled_col	\N	\N	2026-07-07 00:38:55.137106+00	1
9ad7057c-f881-4d45-a926-cd396566c2f6	a481f728c16ef54431dec5801baa19e4818148eba07bbc48d6194770c721f8ef	2026-07-07 00:38:55.139836+00	20260506000000_add_blob_storage_export_field_groups	\N	\N	2026-07-07 00:38:55.138609+00	1
6b2dd74d-035f-49c4-8851-844a57948cb7	2de594704ede26b75cc6a9b359cccebd4e8cde35dfe2151f3d4dd56225a3f1a6	2026-07-07 00:38:55.21303+00	20260506144028_add_verified_domains	\N	\N	2026-07-07 00:38:55.140153+00	1
fc4b28c4-2bd4-4efc-bf83-494ec7d25cb7	5fb1ab7b2d9260a5004af07f7d6794928b3a0bf22ec11a2e1d2be4082fb15269	2026-07-07 00:38:55.215201+00	20260507120000_share_pending_verified_domains	\N	\N	2026-07-07 00:38:55.213524+00	1
d2c76fe1-f95a-4b17-852a-26b06f07c390	aefd8733deccecee2357a9bd888eb09eb54964fa2bd6be1b2f0195b96bf90d8c	2026-07-07 00:38:55.217346+00	20260518090000_add_code_eval_template_fields	\N	\N	2026-07-07 00:38:55.215511+00	1
42732aa0-cb9e-465f-a675-824457bb875e	2b591c746fb484a6c0a353ad447650e32857cf633b0bfe2081ef1a6cc039d5d5	2026-07-07 00:38:55.221621+00	20260518092907_add_monitors	\N	\N	2026-07-07 00:38:55.217656+00	1
759739d5-3337-49bf-b4aa-9f22514b1f74	7ae88cadff0743ddae4f30a6cc237092d04a3853f4a0a679f23306a42fbc60d6	2026-07-07 00:38:55.228724+00	20260521000000_monitor_severity_status_reorder_drop_message	\N	\N	2026-07-07 00:38:55.221934+00	1
9838c8e5-a74f-4fd3-a811-ccb658ebcc44	a301ba80f565fa76ce58e99893c38a57a83e4d7c4ddf2a68bfac3c252d9385f8	2026-07-07 00:38:55.230568+00	20260521130000_add_in_app_agent_api_key_marker	\N	\N	2026-07-07 00:38:55.229127+00	1
7dd4caa5-f288-4b25-90eb-843836222f01	14e4942c56df23fcce14ed762c6c22bceb71029bbbb80637729505d56d289a85	2026-07-07 00:38:55.313835+00	20260522113010_add_paused_monitor_severity	\N	\N	2026-07-07 00:38:55.230915+00	1
177033b3-5867-4d19-8847-6a5510db1a9f	15fd5b77bc70499247a84e7cd4b18888b438fc51968b81dc572c4a0807e7203a	2026-07-07 00:38:55.317313+00	20260527110000_monitor_wallclock_lifecycle	\N	\N	2026-07-07 00:38:55.314314+00	1
4a39fb6d-2138-450e-ad10-a8a7e65fc13d	2631cd620bb6ae8176d29ad7f1d2d1fd79c436be46531d92d89adaedbbcb54c3	2026-07-07 00:38:55.320047+00	20260529120000_add_organization_ai_telemetry_enabled	\N	\N	2026-07-07 00:38:55.317685+00	1
fbea8cc4-0dcd-4bda-9988-689d3dab07e6	53ad1c0502333180e6d3328c57ad5eb2908cb3d9096427ef0901c958db142bc9	2026-07-07 00:38:55.325747+00	20260601190000_add_in_app_agent_persistence	\N	\N	2026-07-07 00:38:55.320455+00	1
d480a689-d194-4d94-af14-4785754c4e59	0eda042fe0017b77f64e539571d4eab8b8c41be9c0fc42fff60c5e090759c7b7	2026-07-07 00:38:55.328287+00	20260608191624_remove_foreign_keys_media	\N	\N	2026-07-07 00:38:55.326148+00	1
0b8be40f-9abf-44dc-b9ae-0c2b4c3f686a	5ce3c5ec69f47dbb0baf2283fec5e3bb42711f8b4d9b80dcca4dcca8da769205	2026-07-07 00:38:55.414264+00	20260610000000_add_web_callout_endpoints	\N	\N	2026-07-07 00:38:55.328694+00	1
2cdf8989-dd25-42b9-9712-567d7d9f308f	b192fa6e950916bfa3f862a54c72c3640ea3eda26d8b04135ca02e734a26a76b	2026-07-07 00:38:55.417025+00	20260610170000_remove_media_link_foreign_keys	\N	\N	2026-07-07 00:38:55.414669+00	1
418bde69-d8b9-4fbb-9232-b417233f1d74	02f53a8efba0dd58297e50ea313c2b847a124e2116b1ecba358e21e720ca9310	2026-07-07 00:38:55.420795+00	20260612000000_add_dataset_item_media	\N	\N	2026-07-07 00:38:55.417495+00	1
3c058374-507e-47c3-924b-aa77f05538fb	abb77c98e5fdbb4eeab9475e7f09d8122b44fee2a05ddc902db7a86a063aa3b1	2026-07-07 00:38:55.423049+00	20260612000000_drop_job_executions_job_template_id_fkey	\N	\N	2026-07-07 00:38:55.421273+00	1
f220309f-e9dc-477b-bf95-33452e70bbc0	821ead908577d479b214f9678b79f6b4e3440be02ae671ef03362c4323501d44	2026-07-07 00:38:55.425102+00	20260616000000_add_blob_storage_run_started_at	\N	\N	2026-07-07 00:38:55.423595+00	1
d564e655-dc33-4bbb-9264-93002903a8b3	bdb8c2d7f0db5d6f9ff60442cb1efa93f5a99305c346dc2cc058b33f83f64c23	2026-07-07 00:38:55.427266+00	20260617000000_slack_integrations_pending_columns	\N	\N	2026-07-07 00:38:55.42564+00	1
54d8f710-4940-4bf3-885c-2186021bec2e	28c1e9d69148a79c82cf9eb5c33c623101ce6849fadc0e83237a313a7e3d3abf	2026-07-07 00:38:55.428754+00	20260619120000_add_blob_storage_export_tuning	\N	\N	2026-07-07 00:38:55.427648+00	1
fb6b032e-3126-4f6f-a4dd-7b6bd3c5c475	c20955ee7fa57e00b9aa284bab9c29fe389c7cff85e3e211b3154f718056e504	2026-07-07 00:38:55.430839+00	20260619120000_revert_slack_pending_install_columns	\N	\N	2026-07-07 00:38:55.429017+00	1
04bc3871-4c52-4002-9b03-460097d8db8e	1d37a7b73f4a14d0b08c1932b11861e7762245b4f4fffdebb2a244c988c4b56b	2026-07-07 00:38:55.432186+00	20260623093628_add_sfdc_id_columns	\N	\N	2026-07-07 00:38:55.431157+00	1
95e35ad8-64a9-465f-bc23-0ced37848750	32b2133f3ec567d3c0de68c89baf2b0756095499f069bc9e8d50178dbf7e10e1	2026-07-07 00:38:55.433629+00	20260629000000_add_parquet_blob_storage_file_type	\N	\N	2026-07-07 00:38:55.432411+00	1
b6958e90-5ca7-4602-9ce6-f6e25c15d945	4385d083f3a783b2039ebe8b333c08832f9cedfd58e6d552cfc087ff5e4fcc7a	2026-07-07 00:38:55.513703+00	20260629091506_add_in_app_agent_pending_tool_approvals	\N	\N	2026-07-07 00:38:55.434027+00	1
08b33480-1cf9-44b4-8279-ac739e1bc6fc	4674bd4a608dddac95359383d7730566d5923c83b5e2fae5fd4a623444235969	2026-07-07 00:38:55.515923+00	20260701115500_add_create_root_spans_background_migration	\N	\N	2026-07-07 00:38:55.514313+00	1
03dc42a7-9552-491e-ac55-73d1b4c7d186	ee279fae169099a5bc8fc75128347b7e3b4e62f46c512fe085a57ab5098aa853	2026-07-07 00:38:55.517805+00	20260701115501_add_rewrite_observations_to_pid_tid_sorting_background_migration	\N	\N	2026-07-07 00:38:55.516367+00	1
68f9ed9a-ef03-4368-93d1-1055859bbdc4	3f36bbd926d35fb14cd30485750186446ce16030b21b6e24fb4f5149aa181a71	2026-07-07 00:38:55.519307+00	20260701115502_add_backfill_events_full_from_observations_background_migration	\N	\N	2026-07-07 00:38:55.518268+00	1
7d176409-cd64-49ec-984e-094b539b1fd7	b54ce782d1ea88453fb18bc9d78ed4287c25318f0580b7e2d614b8c222398c59	2026-07-07 00:38:55.52052+00	20260701115503_add_backfill_events_full_from_dris_background_migration	\N	\N	2026-07-07 00:38:55.51959+00	1
2a7f910f-b610-4f81-b1c8-4cf7a76cde9b	20e5ec6b478f684f28806810bb56db84faa4286f0eca1a77e164cbcb7abc5792	2026-07-07 00:38:55.521812+00	20260701115504_add_drop_pid_tid_sorting_tables_background_migration	\N	\N	2026-07-07 00:38:55.520801+00	1
8855e177-8268-4c48-84d0-4d84c1a2c321	16433b08dd8ebc3dc821e2d7c95a17e1c4ac249bb41e75218ec46b9916fb51dc	2026-07-07 00:38:55.523534+00	20260702130000_add_in_app_agent_conversation_renamed_by_user_at	\N	\N	2026-07-07 00:38:55.522107+00	1
\.


--
-- Data for Name: actions; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.actions (id, created_at, updated_at, project_id, type, config) FROM stdin;
\.


--
-- Data for Name: annotation_queue_assignments; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.annotation_queue_assignments (id, project_id, user_id, queue_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: annotation_queue_items; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.annotation_queue_items (id, queue_id, object_id, object_type, status, locked_at, locked_by_user_id, annotator_user_id, completed_at, project_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: annotation_queues; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.annotation_queues (id, name, description, score_config_ids, project_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.api_keys (id, created_at, note, public_key, hashed_secret_key, display_secret_key, last_used_at, expires_at, project_id, fast_hashed_secret_key, organization_id, scope, is_in_app_agent_key) FROM stdin;
cmr9x86im0001ti0asdojmn2p	2026-07-07 00:38:57.791	Provisioned API Key	pk-lf-agentshield-dev-local-0001	$2a$11$j/Whez5LkZH/wLyC4CCHTe2v1WbeSwn/7B2NjiUlDgxKSOSgRqWa6	sk-lf-...0001	\N	\N	00000000-0000-0000-0001-agentshield01	d2f1b3f9924d9664031b20b1b7c6de16a393ed5b8b1e08557a23cf90742e6c42	\N	PROJECT	f
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.audit_logs (id, created_at, updated_at, user_id, project_id, resource_type, resource_id, action, before, after, org_id, user_org_role, user_project_role, api_key_id, type) FROM stdin;
\.


--
-- Data for Name: automation_executions; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.automation_executions (id, created_at, updated_at, source_id, automation_id, trigger_id, action_id, project_id, status, input, output, started_at, finished_at, error) FROM stdin;
\.


--
-- Data for Name: automations; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.automations (id, name, trigger_id, action_id, created_at, project_id) FROM stdin;
\.


--
-- Data for Name: background_migrations; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.background_migrations (id, name, script, args, finished_at, failed_at, failed_reason, worker_id, locked_at, state) FROM stdin;
32859a35-98f5-4a4a-b438-ebc579349e00	20241024_1216_add_generations_cost_backfill	addGenerationsCostBackfill	{}	\N	\N	\N	\N	\N	{}
5960f22a-748f-480c-b2f3-bc4f9d5d84bc	20241024_1730_migrate_traces_from_pg_to_ch	migrateTracesFromPostgresToClickhouse	{}	\N	\N	\N	\N	\N	{}
7526e7c9-0026-4595-af2c-369dfd9176ec	20241024_1737_migrate_observations_from_pg_to_ch	migrateObservationsFromPostgresToClickhouse	{}	\N	\N	\N	\N	\N	{}
94e50334-50d3-4e49-ad2e-9f6d92c85ef7	20241024_1738_migrate_scores_from_pg_to_ch	migrateScoresFromPostgresToClickhouse	{}	\N	\N	\N	\N	\N	{}
c19b91d9-f9a2-468b-8209-95578f970c5b	20250417_1737_migrate_event_log_to_blob_storage	migrateEventLogToBlobStorageRefTable	{}	\N	\N	\N	\N	\N	{}
3445cac4-d9d5-4750-8b65-351135c1b85e	20250711_1347_patch_llm_tool_schema_audit_logs	patchLLMToolAndLLLMSchemaAuditLogs	{}	\N	\N	\N	\N	\N	{}
9f32e84c-7b1d-4f59-a803-d67ae5c9b2e8	20250814_1001_migrate_dataset_run_items_rmt_pg_to_ch	migrateDatasetRunItemsFromPostgresToClickhouseRmt	{}	\N	\N	\N	\N	\N	{}
0199b890-1093-7d1f-b662-be3c03527e93	20250102_backfill_billing_cycle_anchors	backfillBillingCycleAnchors	{}	\N	\N	\N	\N	\N	{}
d4f5a6b7-c8d9-4e1f-a2b3-c4d5e6f7a8b8	20251216_1001_backfill_dataset_items_valid_to	backfillValidToForDatasetItems	{}	\N	\N	\N	\N	\N	{}
01a0c890-2094-8e2f-c773-cf4d14638fa4	20260106_encrypt_blob_storage_secrets	encryptBlobStorageSecrets	{}	\N	\N	\N	\N	\N	{}
8e1f4a2b-5c63-4d8e-9a47-1b2f3c4d5e6f	20260701_v4_step_1_create_root_spans_from_traces	createRootSpansFromTraces	{"envGate": "LANGFUSE_BACKGROUND_MIGRATION_V4_ENABLE_HISTORIC_BACKFILL"}	\N	\N	\N	\N	\N	{}
9c2d5a4f-7b8e-4f6a-a91c-3e5d7f8a2b1c	20260701_v4_step_2_rewrite_observations_to_pid_tid_sorting	rewriteObservationsToPidTidSorting	{"envGate": "LANGFUSE_BACKGROUND_MIGRATION_V4_ENABLE_HISTORIC_BACKFILL"}	\N	\N	\N	\N	\N	{}
7a3f8d6e-2c91-4b5e-8d72-f4a5b6c7d8e9	20260701_v4_step_3_backfill_events_full_from_observations	backfillEventsFullFromObservations	{"envGate": "LANGFUSE_BACKGROUND_MIGRATION_V4_ENABLE_HISTORIC_BACKFILL"}	\N	\N	\N	\N	\N	{}
9d4f8a12-7b35-4e6c-9f48-a2b3c4d5e6f7	20260701_v4_step_4_backfill_events_full_from_dataset_run_items	backfillEventsFullFromDatasetRunItems	{"envGate": "LANGFUSE_BACKGROUND_MIGRATION_V4_ENABLE_HISTORIC_BACKFILL"}	\N	\N	\N	\N	\N	{}
b3f1c5d8-9e47-4a26-8b3f-5c6d7e8f9a01	20260701_v4_step_5_drop_pid_tid_sorting_tables	dropPidTidSortingTables	{"envGate": "LANGFUSE_BACKGROUND_MIGRATION_V4_DROP_PID_TID_SORTING_TABLES"}	\N	\N	\N	\N	\N	{}
\.


--
-- Data for Name: batch_actions; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.batch_actions (id, created_at, updated_at, project_id, user_id, action_type, table_name, status, finished_at, query, config, total_count, processed_count, failed_count, log) FROM stdin;
\.


--
-- Data for Name: batch_exports; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.batch_exports (id, created_at, updated_at, project_id, user_id, finished_at, expires_at, name, status, query, format, url, log) FROM stdin;
\.


--
-- Data for Name: billing_meter_backups; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.billing_meter_backups (stripe_customer_id, meter_id, start_time, end_time, aggregated_value, event_name, org_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: blob_storage_integrations; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.blob_storage_integrations (project_id, type, bucket_name, prefix, access_key_id, secret_access_key, region, endpoint, force_path_style, next_sync_at, last_sync_at, enabled, export_frequency, created_at, updated_at, file_type, export_mode, export_start_date, export_source, last_error, last_error_at, last_failure_notification_sent_at, compressed, export_field_groups, run_started_at, export_tuning) FROM stdin;
\.


--
-- Data for Name: cloud_spend_alerts; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.cloud_spend_alerts (id, org_id, title, threshold, triggered_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: comment_reactions; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.comment_reactions (id, project_id, comment_id, user_id, emoji, created_at) FROM stdin;
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.comments (id, project_id, object_type, object_id, created_at, updated_at, content, author_user_id, data_field, path, range_start, range_end) FROM stdin;
\.


--
-- Data for Name: cron_jobs; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.cron_jobs (name, last_run, state, job_started_at) FROM stdin;
\.


--
-- Data for Name: dashboard_widgets; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.dashboard_widgets (id, created_at, updated_at, created_by, updated_by, project_id, name, description, view, dimensions, metrics, filters, chart_type, chart_config, min_version) FROM stdin;
\.


--
-- Data for Name: dashboards; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.dashboards (id, created_at, updated_at, created_by, updated_by, project_id, name, description, definition, filters) FROM stdin;
\.


--
-- Data for Name: dataset_item_media; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.dataset_item_media (id, project_id, created_at, updated_at, media_id, dataset_id, dataset_item_id, dataset_item_valid_from, field, json_path, reference_string) FROM stdin;
\.


--
-- Data for Name: dataset_items; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.dataset_items (id, input, expected_output, source_observation_id, dataset_id, created_at, updated_at, status, source_trace_id, metadata, project_id, is_deleted, valid_from, valid_to) FROM stdin;
\.


--
-- Data for Name: dataset_run_items; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.dataset_run_items (id, dataset_run_id, dataset_item_id, observation_id, created_at, updated_at, trace_id, project_id) FROM stdin;
\.


--
-- Data for Name: dataset_runs; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.dataset_runs (id, name, dataset_id, created_at, updated_at, metadata, description, project_id) FROM stdin;
\.


--
-- Data for Name: datasets; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.datasets (id, name, project_id, created_at, updated_at, description, metadata, remote_experiment_payload, remote_experiment_url, expected_output_schema, input_schema, remote_experiment_enabled) FROM stdin;
\.


--
-- Data for Name: default_llm_models; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.default_llm_models (id, created_at, updated_at, project_id, llm_api_key_id, provider, adapter, model, model_params) FROM stdin;
\.


--
-- Data for Name: default_views; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.default_views (id, created_at, updated_at, project_id, user_id, view_name, view_id) FROM stdin;
\.


--
-- Data for Name: eval_templates; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.eval_templates (id, created_at, updated_at, project_id, name, version, prompt, model, model_params, vars, output_schema, provider, partner, type, source_code, source_code_language) FROM stdin;
\.


--
-- Data for Name: in_app_agent_conversations; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.in_app_agent_conversations (id, project_id, created_by_user_id, title, visibility_scope, provider_session_id, deleted_at, created_at, updated_at, renamed_by_user_at) FROM stdin;
\.


--
-- Data for Name: in_app_agent_events; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.in_app_agent_events (project_id, conversation_id, run_id, sequence_number, type, event, created_at) FROM stdin;
\.


--
-- Data for Name: in_app_agent_pending_tool_approvals; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.in_app_agent_pending_tool_approvals (project_id, conversation_id, tool_call_id, approval_fingerprint, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: in_app_agent_runs; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.in_app_agent_runs (id, project_id, conversation_id, triggered_by_user_id, model, mcp_api_key_id, error_code, error_message, finished_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: job_configurations; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.job_configurations (id, created_at, updated_at, project_id, job_type, eval_template_id, score_name, filter, target_object, variable_mapping, sampling, delay, status, time_scope, blocked_at, block_reason, block_message) FROM stdin;
\.


--
-- Data for Name: job_executions; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.job_executions (id, created_at, updated_at, project_id, job_configuration_id, status, start_time, end_time, error, job_input_trace_id, job_output_score_id, job_input_dataset_item_id, job_input_observation_id, job_template_id, job_input_trace_timestamp, execution_trace_id, job_input_dataset_item_valid_from) FROM stdin;
\.


--
-- Data for Name: llm_api_keys; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.llm_api_keys (id, created_at, updated_at, provider, display_secret_key, secret_key, project_id, base_url, adapter, custom_models, with_default_models, config, extra_headers, extra_header_keys) FROM stdin;
\.


--
-- Data for Name: llm_schemas; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.llm_schemas (id, created_at, updated_at, project_id, name, description, schema) FROM stdin;
\.


--
-- Data for Name: llm_tools; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.llm_tools (id, created_at, updated_at, project_id, name, description, parameters) FROM stdin;
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.media (id, sha_256_hash, project_id, created_at, updated_at, uploaded_at, upload_http_status, upload_http_error, bucket_path, bucket_name, content_type, content_length) FROM stdin;
\.


--
-- Data for Name: membership_invitations; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.membership_invitations (id, email, project_id, invited_by_user_id, created_at, updated_at, org_id, org_role, project_role) FROM stdin;
\.


--
-- Data for Name: mixpanel_integrations; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.mixpanel_integrations (project_id, encrypted_mixpanel_project_token, mixpanel_region, last_sync_at, enabled, created_at, export_source) FROM stdin;
\.


--
-- Data for Name: models; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.models (id, created_at, updated_at, project_id, model_name, match_pattern, start_date, input_price, output_price, total_price, unit, tokenizer_config, tokenizer_id) FROM stdin;
clrntkjgy000f08jx79v9g1xj	2026-07-07 00:38:52.317	2026-07-07 00:38:52.317	\N	gpt-4	(?i)^(gpt-4)$	\N	0.000030000000000000000000000000	0.000060000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4", "tokensPerMessage": 3}	openai
clrkwk4cc000908l537kl0rx3	2026-07-07 00:38:52.317	2026-07-07 00:38:52.317	\N	gpt-4-0613	(?i)^(gpt-4-0613)$	\N	0.000030000000000000000000000000	0.000060000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4-0613", "tokensPerMessage": 3}	openai
clrntkjgy000e08jx4x6uawoo	2026-07-07 00:38:52.317	2026-07-07 00:38:52.317	\N	gpt-4-0314	(?i)^(gpt-4-0314)$	\N	0.000030000000000000000000000000	0.000060000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4-0314", "tokensPerMessage": 3}	openai
clrkvyzgw000308jue4hse4j9	2026-07-07 00:38:52.317	2026-07-07 00:38:52.317	\N	gpt-4-32k	(?i)^(gpt-4-32k)$	\N	0.000060000000000000000000000000	0.000120000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4-32k", "tokensPerMessage": 3}	openai
clrkwk4cb000108l5hwwh3zdi	2026-07-07 00:38:52.317	2026-07-07 00:38:52.317	\N	gpt-4-32k-0613	(?i)^(gpt-4-32k-0613)$	\N	0.000060000000000000000000000000	0.000120000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4-32k-0613", "tokensPerMessage": 3}	openai
clrntkjgy000d08jx0p4y9h4l	2026-07-07 00:38:52.317	2026-07-07 00:38:52.317	\N	gpt-4-32k-0314	(?i)^(gpt-4-32k-0314)$	\N	0.000060000000000000000000000000	0.000120000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4-32k-0314", "tokensPerMessage": 3}	openai
clrkwk4cc000a08l562uc3s9g	2026-07-07 00:38:52.317	2026-07-07 00:38:52.317	\N	gpt-3.5-turbo-instruct	(?i)^(gpt-)(35|3.5)(-turbo-instruct)$	\N	0.000001500000000000000000000000	0.000002000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-3.5-turbo", "tokensPerMessage": 3}	openai
clrkwk4cb000408l576jl7koo	2026-07-07 00:38:52.317	2026-07-07 00:38:52.317	\N	gpt-3.5-turbo	(?i)^(gpt-)(35|3.5)(-turbo)$	2023-11-06 00:00:00	0.000001000000000000000000000000	0.000002000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-3.5-turbo", "tokensPerMessage": 3}	openai
clrkwk4cb000208l59yvb9yq8	2026-07-07 00:38:52.317	2026-07-07 00:38:52.317	\N	gpt-3.5-turbo-1106	(?i)^(gpt-)(35|3.5)(-turbo-1106)$	\N	0.000001000000000000000000000000	0.000002000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-3.5-turbo-1106", "tokensPerMessage": 3}	openai
clrntkjgy000c08jxesb30p3f	2026-07-07 00:38:52.317	2026-07-07 00:38:52.317	\N	gpt-3.5-turbo	(?i)^(gpt-)(35|3.5)(-turbo)$	2023-06-27 00:00:00	0.000001500000000000000000000000	0.000002000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-3.5-turbo", "tokensPerMessage": 3}	openai
clrkwk4cc000808l51xmk4uic	2026-07-07 00:38:52.317	2026-07-07 00:38:52.317	\N	gpt-3.5-turbo-0613	(?i)^(gpt-)(35|3.5)(-turbo-0613)$	\N	0.000001500000000000000000000000	0.000002000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-3.5-turbo-0613", "tokensPerMessage": 3}	openai
clrntkjgy000b08jx769q1bah	2026-07-07 00:38:52.317	2026-07-07 00:38:52.317	\N	gpt-3.5-turbo	(?i)^(gpt-)(35|3.5)(-turbo)$	\N	0.000002000000000000000000000000	0.000002000000000000000000000000	\N	TOKENS	{"tokensPerName": -1, "tokenizerModel": "gpt-3.5-turbo", "tokensPerMessage": 4}	openai
clrntkjgy000a08jx4e062mr0	2026-07-07 00:38:52.317	2026-07-07 00:38:52.317	\N	gpt-3.5-turbo-0301	(?i)^(gpt-)(35|3.5)(-turbo-0301)$	\N	0.000002000000000000000000000000	0.000002000000000000000000000000	\N	TOKENS	{"tokensPerName": -1, "tokenizerModel": "gpt-3.5-turbo-0301", "tokensPerMessage": 4}	openai
clrntjt89000908jwhvkz5crm	2026-07-07 00:38:52.322	2026-07-07 00:38:52.322	\N	text-embedding-ada-002	(?i)^(text-embedding-ada-002)$	2022-12-06 00:00:00	\N	\N	0.000000100000000000000000000000	TOKENS	{"tokenizerModel": "text-embedding-ada-002"}	openai
clrntjt89000908jwhvkz5crg	2026-07-07 00:38:52.322	2026-07-07 00:38:52.322	\N	text-embedding-ada-002-v2	(?i)^(text-embedding-ada-002-v2)$	2022-12-06 00:00:00	\N	\N	0.000000100000000000000000000000	TOKENS	{"tokenizerModel": "text-embedding-ada-002"}	openai
clrntjt89000108jwcou1af71	2026-07-07 00:38:52.322	2026-07-07 00:38:52.322	\N	text-ada-001	(?i)^(text-ada-001)$	\N	\N	\N	0.000004000000000000000000000000	TOKENS	{"tokenizerModel": "text-ada-001"}	openai
clrntjt89000208jwawjr894q	2026-07-07 00:38:52.322	2026-07-07 00:38:52.322	\N	text-babbage-001	(?i)^(text-babbage-001)$	\N	\N	\N	0.000000500000000000000000000000	TOKENS	{"tokenizerModel": "text-babbage-001"}	openai
clrntjt89000308jw0jtfa4rs	2026-07-07 00:38:52.322	2026-07-07 00:38:52.322	\N	text-curie-001	(?i)^(text-curie-001)$	\N	\N	\N	0.000020000000000000000000000000	TOKENS	{"tokenizerModel": "text-curie-001"}	openai
clrntjt89000408jwc2c93h6i	2026-07-07 00:38:52.322	2026-07-07 00:38:52.322	\N	text-davinci-001	(?i)^(text-davinci-001)$	\N	\N	\N	0.000020000000000000000000000000	TOKENS	{"tokenizerModel": "text-davinci-001"}	openai
clrntjt89000508jw192m64qi	2026-07-07 00:38:52.322	2026-07-07 00:38:52.322	\N	text-davinci-002	(?i)^(text-davinci-002)$	\N	\N	\N	0.000020000000000000000000000000	TOKENS	{"tokenizerModel": "text-davinci-002"}	openai
clrntjt89000608jw4m3x5s55	2026-07-07 00:38:52.322	2026-07-07 00:38:52.322	\N	text-davinci-003	(?i)^(text-davinci-003)$	\N	\N	\N	0.000020000000000000000000000000	TOKENS	{"tokenizerModel": "text-davinci-003"}	openai
clruwn3pc00010al7bl611c8o	2026-07-07 00:38:52.323	2026-07-07 00:38:52.323	\N	text-embedding-3-small	(?i)^(text-embedding-3-small)$	\N	\N	\N	0.000000020000000000000000000000	TOKENS	{"tokenizerModel": "text-embedding-ada-002"}	openai
clruwnahl00030al7ab9rark7	2026-07-07 00:38:52.323	2026-07-07 00:38:52.323	\N	gpt-3.5-turbo-0125	(?i)^(gpt-)(35|3.5)(-turbo-0125)$	\N	0.000000500000000000000000000000	0.000001500000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-3.5-turbo", "tokensPerMessage": 3}	openai
clruwnahl00050al796ck3p44	2026-07-07 00:38:52.323	2026-07-07 00:38:52.323	\N	gpt-4-0125-preview	(?i)^(gpt-4-0125-preview)$	\N	0.000010000000000000000000000000	0.000030000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4", "tokensPerMessage": 3}	openai
clruwnahl00060al74fcfehas	2026-07-07 00:38:52.323	2026-07-07 00:38:52.323	\N	gpt-4-turbo-preview	(?i)^(gpt-4-turbo-preview)$	\N	0.000030000000000000000000000000	0.000060000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4", "tokensPerMessage": 3}	openai
clrs2dnql000108l46vo0gp2t	2026-07-07 00:38:52.323	2026-07-07 00:38:52.323	\N	babbage-002	(?i)^(babbage-002)$	\N	0.000000400000000000000000000000	0.000001600000000000000000000000	\N	TOKENS	{"tokenizerModel": "babbage-002"}	openai
clrs2ds35000208l4g4b0hi3u	2026-07-07 00:38:52.323	2026-07-07 00:38:52.323	\N	davinci-002	(?i)^(davinci-002)$	\N	0.000006000000000000000000000000	0.000012000000000000000000000000	\N	TOKENS	{"tokenizerModel": "davinci-002"}	openai
clrnwbota000908jsgg9mb1ml	2026-07-07 00:38:52.326	2026-07-07 00:38:52.326	\N	claude-instant-1	(?i)^(claude-instant-1)$	\N	0.000001630000000000000000000000	0.000005510000000000000000000000	\N	TOKENS	\N	claude
clrnwb41q000308jsfrac9uh6	2026-07-07 00:38:52.326	2026-07-07 00:38:52.326	\N	claude-instant-1.2	(?i)^(claude-instant-1.2)$	\N	0.000001630000000000000000000000	0.000005510000000000000000000000	\N	TOKENS	\N	claude
clrnwbd1m000508js4hxu6o7n	2026-07-07 00:38:52.326	2026-07-07 00:38:52.326	\N	claude-2.1	(?i)^(claude-2.1)$	\N	0.000008000000000000000000000000	0.000024000000000000000000000000	\N	TOKENS	\N	claude
clrnwb836000408jsallr6u11	2026-07-07 00:38:52.326	2026-07-07 00:38:52.326	\N	claude-2.0	(?i)^(claude-2.0)$	\N	0.000008000000000000000000000000	0.000024000000000000000000000000	\N	TOKENS	\N	claude
clrnwbg2b000608jse2pp4q2d	2026-07-07 00:38:52.326	2026-07-07 00:38:52.326	\N	claude-1.3	(?i)^(claude-1.3)$	\N	0.000008000000000000000000000000	0.000024000000000000000000000000	\N	TOKENS	\N	claude
clrnwbi9d000708jseiy44k26	2026-07-07 00:38:52.326	2026-07-07 00:38:52.326	\N	claude-1.2	(?i)^(claude-1.2)$	\N	0.000008000000000000000000000000	0.000024000000000000000000000000	\N	TOKENS	\N	claude
clrnwblo0000808jsc1385hdp	2026-07-07 00:38:52.326	2026-07-07 00:38:52.326	\N	claude-1.1	(?i)^(claude-1.1)$	\N	0.000008000000000000000000000000	0.000024000000000000000000000000	\N	TOKENS	\N	claude
cls08r8sq000308jq14ae96f0	2026-07-07 00:38:52.328	2026-07-07 00:38:52.328	\N	ft:gpt-3.5-turbo-1106	(?i)^(ft:)(gpt-3.5-turbo-1106:)(.+)(:)(.*)(:)(.+)$	\N	0.000003000000000000000000000000	0.000006000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-3.5-turbo-1106", "tokensPerMessage": 3}	openai
cls08rp99000408jqepxoakjv	2026-07-07 00:38:52.328	2026-07-07 00:38:52.328	\N	ft:gpt-3.5-turbo-0613	(?i)^(ft:)(gpt-3.5-turbo-0613:)(.+)(:)(.*)(:)(.+)$	\N	0.000012000000000000000000000000	0.000016000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-3.5-turbo-0613", "tokensPerMessage": 3}	openai
cls08rv9g000508jq5p4z4nlr	2026-07-07 00:38:52.328	2026-07-07 00:38:52.328	\N	ft:davinci-002	(?i)^(ft:)(davinci-002:)(.+)(:)(.*)(:)(.+)$$	\N	0.000012000000000000000000000000	0.000012000000000000000000000000	\N	TOKENS	{"tokenizerModel": "davinci-002"}	openai
cls08s2bw000608jq57wj4un2	2026-07-07 00:38:52.328	2026-07-07 00:38:52.328	\N	ft:babbage-002	(?i)^(ft:)(babbage-002:)(.+)(:)(.*)(:)(.+)$$	\N	0.000001600000000000000000000000	0.000001600000000000000000000000	\N	TOKENS	{"tokenizerModel": "babbage-002"}	openai
cls0k4lqt000008ky1o1s8wd5	2026-07-07 00:38:52.328	2026-07-07 00:38:52.328	\N	gemini-pro	(?i)^(gemini-pro)(@[a-zA-Z0-9]+)?$	\N	0.000000250000000000000000000000	0.000000500000000000000000000000	\N	CHARACTERS	\N	\N
cls0jni4t000008jk3kyy803r	2026-07-07 00:38:52.328	2026-07-07 00:38:52.328	\N	chat-bison-32k	(?i)^(chat-bison-32k)(@[a-zA-Z0-9]+)?$	\N	0.000000250000000000000000000000	0.000000500000000000000000000000	\N	CHARACTERS	\N	\N
cls0iv12d000108l251gf3038	2026-07-07 00:38:52.328	2026-07-07 00:38:52.328	\N	chat-bison	(?i)^(chat-bison)(@[a-zA-Z0-9]+)?$	\N	0.000000250000000000000000000000	0.000000500000000000000000000000	\N	CHARACTERS	\N	\N
cls0jmjt3000108l83ix86w0d	2026-07-07 00:38:52.328	2026-07-07 00:38:52.328	\N	text-bison-32k	(?i)^(text-bison-32k)(@[a-zA-Z0-9]+)?$	\N	0.000000250000000000000000000000	0.000000500000000000000000000000	\N	CHARACTERS	\N	\N
cls0juygp000308jk2a6x9my2	2026-07-07 00:38:52.328	2026-07-07 00:38:52.328	\N	text-bison	(?i)^(text-bison)(@[a-zA-Z0-9]+)?$	\N	0.000000250000000000000000000000	0.000000500000000000000000000000	\N	CHARACTERS	\N	\N
cls0jungb000208jk12gm4gk1	2026-07-07 00:38:52.328	2026-07-07 00:38:52.328	\N	text-unicorn	(?i)^(text-unicorn)(@[a-zA-Z0-9]+)?$	\N	0.000002500000000000000000000000	0.000007500000000000000000000000	\N	CHARACTERS	\N	\N
cls1nyj5q000208l33ne901d8	2026-07-07 00:38:52.328	2026-07-07 00:38:52.328	\N	textembedding-gecko	(?i)^(textembedding-gecko)(@[a-zA-Z0-9]+)?$	\N	\N	\N	0.000000100000000000000000000000	CHARACTERS	\N	\N
cls1nyyjp000308l31gxy1bih	2026-07-07 00:38:52.328	2026-07-07 00:38:52.328	\N	textembedding-gecko-multilingual	(?i)^(textembedding-gecko-multilingual)(@[a-zA-Z0-9]+)?$	\N	\N	\N	0.000000100000000000000000000000	CHARACTERS	\N	\N
cls1nzjt3000508l3dnwad3g0	2026-07-07 00:38:52.328	2026-07-07 00:38:52.328	\N	code-gecko	(?i)^(code-gecko)(@[a-zA-Z0-9]+)?$	\N	0.000000250000000000000000000000	0.000000500000000000000000000000	\N	CHARACTERS	\N	\N
cls1nzwx4000608l38va7e4tv	2026-07-07 00:38:52.328	2026-07-07 00:38:52.328	\N	code-bison	(?i)^(code-bison)(@[a-zA-Z0-9]+)?$	\N	0.000000250000000000000000000000	0.000000500000000000000000000000	\N	CHARACTERS	\N	\N
cls1o053j000708l39f8g4bgs	2026-07-07 00:38:52.328	2026-07-07 00:38:52.328	\N	code-bison-32k	(?i)^(code-bison-32k)(@[a-zA-Z0-9]+)?$	\N	0.000000250000000000000000000000	0.000000500000000000000000000000	\N	CHARACTERS	\N	\N
cls0j33v1000008joagkc4lql	2026-07-07 00:38:52.328	2026-07-07 00:38:52.328	\N	codechat-bison-32k	(?i)^(codechat-bison-32k)(@[a-zA-Z0-9]+)?$	\N	0.000000250000000000000000000000	0.000000500000000000000000000000	\N	CHARACTERS	\N	\N
cls0jmc9v000008l8ee6r3gsd	2026-07-07 00:38:52.328	2026-07-07 00:38:52.328	\N	codechat-bison	(?i)^(codechat-bison)(@[a-zA-Z0-9]+)?$	\N	0.000000250000000000000000000000	0.000000500000000000000000000000	\N	CHARACTERS	\N	\N
clrkwk4cb000308l5go4b6otm	2026-07-07 00:38:52.329	2026-07-07 00:38:52.329	\N	gpt-3.5-turbo-16k	(?i)^(gpt-)(35|3.5)(-turbo-16k)$	\N	0.000003000000000000000000000000	0.000004000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-3.5-turbo-16k", "tokensPerMessage": 3}	openai
clrntjt89000a08jw0gcdbd5a	2026-07-07 00:38:52.329	2026-07-07 00:38:52.329	\N	gpt-3.5-turbo-16k-0613	(?i)^(gpt-)(35|3.5)(-turbo-16k-0613)$	\N	0.000003000000000000000000000000	0.000004000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-3.5-turbo-16k-0613", "tokensPerMessage": 3}	openai
clruwn76700020al7gp8e4g4l	2026-07-07 00:38:52.323	2026-07-07 00:38:52.323	\N	text-embedding-3-large	(?i)^(text-embedding-3-large)$	\N	\N	\N	0.000000130000000000000000000000	TOKENS	{"tokenizerModel": "text-embedding-ada-002"}	openai
clruwnahl00040al78f1lb0at	2026-07-07 00:38:52.333	2026-07-07 00:38:52.333	\N	gpt-3.5-turbo	(?i)^(gpt-)(35|3.5)(-turbo)$	2024-02-16 00:00:00	0.000000500000000000000000000000	0.000001500000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-3.5-turbo", "tokensPerMessage": 3}	openai
clsk9lntu000008jwfc51bbqv	2026-07-07 00:38:52.333	2026-07-07 00:38:52.333	\N	gpt-3.5-turbo-16k	(?i)^(gpt-)(35|3.5)(-turbo-16k)$	2024-02-16 00:00:00	0.000000500000000000000000000000	0.000001500000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-3.5-turbo-16k", "tokensPerMessage": 3}	openai
clsnq07bn000008l4e46v1ll8	2026-07-07 00:38:52.415	2026-07-07 00:38:52.415	\N	gpt-4-turbo-preview	(?i)^(gpt-4-turbo-preview)$	2023-11-06 00:00:00	0.000010000000000000000000000000	0.000030000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4", "tokensPerMessage": 3}	openai
cluv2sjeo000008ih0fv23hi0	2026-07-07 00:38:52.72	2026-07-07 00:38:52.72	\N	gemini-1.0-pro-latest	(?i)^(gemini-1.0-pro-latest)(@[a-zA-Z0-9]+)?$	\N	0.000000250000000000000000000000	0.000000500000000000000000000000	\N	CHARACTERS	\N	\N
cluv2subq000108ih2mlrga6a	2026-07-07 00:38:52.72	2026-07-07 00:38:52.72	\N	gemini-1.0-pro	(?i)^(gemini-1.0-pro)(@[a-zA-Z0-9]+)?$	2024-02-15 00:00:00	0.000000125000000000000000000000	0.000000375000000000000000000000	\N	CHARACTERS	\N	\N
cluv2sx04000208ihbek75lsz	2026-07-07 00:38:52.72	2026-07-07 00:38:52.72	\N	gemini-1.0-pro-001	(?i)^(gemini-1.0-pro-001)(@[a-zA-Z0-9]+)?$	2024-02-15 00:00:00	0.000000125000000000000000000000	0.000000375000000000000000000000	\N	CHARACTERS	\N	\N
cluv2szw0000308ihch3n79x7	2026-07-07 00:38:52.72	2026-07-07 00:38:52.72	\N	gemini-pro	(?i)^(gemini-pro)(@[a-zA-Z0-9]+)?$	2024-02-15 00:00:00	0.000000125000000000000000000000	0.000000375000000000000000000000	\N	CHARACTERS	\N	\N
cluv2t2x0000408ihfytl45l1	2026-07-07 00:38:52.72	2026-07-07 00:38:52.72	\N	gemini-1.5-pro-latest	(?i)^(gemini-1.5-pro-latest)(@[a-zA-Z0-9]+)?$	\N	0.000002500000000000000000000000	0.000007500000000000000000000000	\N	CHARACTERS	\N	\N
cluvpl4ls000008l6h2gx3i07	2026-07-07 00:38:52.723	2026-07-07 00:38:52.723	\N	gpt-4-turbo	(?i)^(gpt-4-turbo)$	\N	0.000010000000000000000000000000	0.000030000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4-1106-preview", "tokensPerMessage": 3}	openai
cluv2t5k3000508ih5kve9zag	2026-07-07 00:38:52.816	2026-07-07 00:38:52.816	\N	gpt-4-turbo-2024-04-09	(?i)^(gpt-4-turbo-2024-04-09)$	\N	0.000010000000000000000000000000	0.000030000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4-turbo-2024-04-09", "tokensPerMessage": 3}	openai
clrkvq6iq000008ju6c16gynt	2026-07-07 00:38:52.816	2026-07-07 00:38:52.816	\N	gpt-4-1106-preview	(?i)^(gpt-4-1106-preview)$	\N	0.000010000000000000000000000000	0.000030000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4-1106-preview", "tokensPerMessage": 3}	openai
clv2o2x0p000008jsf9afceau	2026-07-07 00:38:52.816	2026-07-07 00:38:52.816	\N	 gpt-4-preview	(?i)^(gpt-4-preview)$	\N	0.000010000000000000000000000000	0.000030000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4-turbo-preview", "tokensPerMessage": 3}	openai
b9854a5c92dc496b997d99d20	2026-07-07 00:38:52.922	2026-07-07 00:38:52.922	\N	gpt-4o	(?i)^(gpt-4o)$	\N	0.000005000000000000000000000000	0.000015000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4o", "tokensPerMessage": 3}	openai
b9854a5c92dc496b997d99d21	2026-07-07 00:38:52.922	2026-07-07 00:38:52.922	\N	gpt-4o-2024-05-13	(?i)^(gpt-4o-2024-05-13)$	\N	0.000005000000000000000000000000	0.000015000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4o-2024-05-13", "tokensPerMessage": 3}	openai
clx30djsn0000w9mzebiv41we	2026-07-07 00:38:53.522	2026-07-07 00:38:53.522	\N	gemini-1.5-flash	(?i)^(gemini-1.5-flash)(@[a-zA-Z0-9]+)?$	\N	\N	\N	\N	CHARACTERS	\N	\N
clx30hkrx0000w9mz7lqi0ial	2026-07-07 00:38:53.522	2026-07-07 00:38:53.522	\N	gemini-1.5-pro	(?i)^(gemini-1.5-pro)(@[a-zA-Z0-9]+)?$	\N	\N	\N	\N	CHARACTERS	\N	\N
clrkvx5gp000108juaogs54ea	2026-07-07 00:38:52.317	2026-07-07 00:38:52.317	\N	gpt-4-turbo-vision	(?i)^(gpt-4(-\\d{4})?-vision-preview)$	\N	0.000010000000000000000000000000	0.000030000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4-vision-preview", "tokensPerMessage": 3}	openai
cltr0w45b000008k1407o9qv1	2026-07-07 00:38:52.615	2026-07-07 00:38:52.615	\N	claude-3-haiku-20240307	(?i)^(claude-3-haiku-20240307|anthropic\\.claude-3-haiku-20240307-v1:0|claude-3-haiku@20240307)$	\N	0.000000250000000000000000000000	0.000001250000000000000000000000	\N	TOKENS	\N	claude
cltgy0pp6000108le56se7bl3	2026-07-07 00:38:52.53	2026-07-07 00:38:52.53	\N	claude-3-sonnet-20240229	(?i)^(claude-3-sonnet-20240229|anthropic\\.claude-3-sonnet-20240229-v1:0|claude-3-sonnet@20240229)$	\N	0.000003000000000000000000000000	0.000015000000000000000000000000	\N	TOKENS	\N	claude
cltgy0iuw000008le3vod1hhy	2026-07-07 00:38:52.53	2026-07-07 00:38:52.53	\N	claude-3-opus-20240229	(?i)^(claude-3-opus-20240229|anthropic\\.claude-3-opus-20240229-v1:0|claude-3-opus@20240229)$	\N	0.000015000000000000000000000000	0.000075000000000000000000000000	\N	TOKENS	\N	claude
clxt0n0m60000pumz1j5b7zsf	2026-07-07 00:38:53.626	2026-07-07 00:38:53.626	\N	claude-3-5-sonnet-20240620	(?i)^(claude-3-5-sonnet-20240620|anthropic\\.claude-3-5-sonnet-20240620-v1:0|claude-3-5-sonnet@20240620)$	\N	0.000003000000000000000000000000	0.000015000000000000000000000000	\N	TOKENS	\N	claude
clyrjp56f0000t0mzapoocd7u	2026-07-07 00:38:53.72	2026-07-07 00:38:53.72	\N	gpt-4o-mini	(?i)^(gpt-4o-mini)$	\N	0.000000150000000000000000000000	0.000000600000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4o", "tokensPerMessage": 3}	openai
clyrjpbe20000t0mzcbwc42rg	2026-07-07 00:38:53.72	2026-07-07 00:38:53.72	\N	gpt-4o-mini-2024-07-18	(?i)^(gpt-4o-mini-2024-07-18)$	\N	0.000000150000000000000000000000	0.000000600000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4o", "tokensPerMessage": 3}	openai
clzjr85f70000ymmzg7hqffra	2026-07-07 00:38:53.814	2026-07-07 00:38:53.814	\N	gpt-4o-2024-08-06	(?i)^(gpt-4o-2024-08-06)$	\N	0.000002500000000000000000000000	0.000010000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4o", "tokensPerMessage": 3}	openai
cm10ivcdp0000gix7lelmbw80	2026-07-07 00:38:53.912	2026-07-07 00:38:53.912	\N	o1-preview	(?i)^(o1-preview)$	\N	0.000015000000000000000000000000	0.000060000000000000000000000000	\N	TOKENS	\N	\N
cm10ivo130000n8x7qopcjjcg	2026-07-07 00:38:53.912	2026-07-07 00:38:53.912	\N	o1-preview-2024-09-12	(?i)^(o1-preview-2024-09-12)$	\N	0.000015000000000000000000000000	0.000060000000000000000000000000	\N	TOKENS	\N	\N
cm10ivwo40000r1x7gg3syjq0	2026-07-07 00:38:53.912	2026-07-07 00:38:53.912	\N	o1-mini	(?i)^(o1-mini)$	\N	0.000003000000000000000000000000	0.000012000000000000000000000000	\N	TOKENS	\N	\N
cm10iw6p20000wgx7it1hlb22	2026-07-07 00:38:53.912	2026-07-07 00:38:53.912	\N	o1-mini-2024-09-12	(?i)^(o1-mini-2024-09-12)$	\N	0.000003000000000000000000000000	0.000012000000000000000000000000	\N	TOKENS	\N	\N
cm2krz1uf000208jjg5653iud	2026-07-07 00:38:54.117	2026-07-07 00:38:54.117	\N	claude-3.5-sonnet-20241022	(?i)^(claude-3-5-sonnet-20241022|anthropic\\.claude-3-5-sonnet-20241022-v2:0|claude-3-5-sonnet-V2@20241022)$	\N	0.000003000000000000000000000000	0.000015000000000000000000000000	\N	TOKENS	\N	claude
cm2ks2vzn000308jjh4ze1w7q	2026-07-07 00:38:54.117	2026-07-07 00:38:54.117	\N	claude-3.5-sonnet-latest	(?i)^(claude-3-5-sonnet-latest)$	\N	0.000003000000000000000000000000	0.000015000000000000000000000000	\N	TOKENS	\N	claude
cm34aq60d000207ml0j1h31ar	2026-07-07 00:38:54.215	2026-07-07 00:38:54.215	\N	claude-3-5-haiku-20241022	(?i)^(claude-3-5-haiku-20241022|anthropic\\.claude-3-5-haiku-20241022-v1:0|claude-3-5-haiku-V1@20241022)$	\N	0.000001000000000000000000000000	0.000005000000000000000000000000	\N	TOKENS	\N	claude
cm34aqb9h000307ml6nypd618	2026-07-07 00:38:54.215	2026-07-07 00:38:54.215	\N	claude-3.5-haiku-latest	(?i)^(claude-3-5-haiku-latest)$	\N	0.000001000000000000000000000000	0.000005000000000000000000000000	\N	TOKENS	\N	claude
cm3x0p8ev000008kyd96800c8	2026-07-07 00:38:54.224	2026-07-07 00:38:54.224	\N	chatgpt-4o-latest	(?i)^(chatgpt-4o-latest)$	\N	0.000005000000000000000000000000	0.000015000000000000000000000000	\N	TOKENS	{"tokensPerName": 1, "tokenizerModel": "gpt-4o", "tokensPerMessage": 3}	openai
\.


--
-- Data for Name: monitors; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.monitors (id, created_at, updated_at, created_by, updated_by, project_id, view, filters, metric, window_ms, cadence_ms, threshold_operator, alert_threshold, warning_threshold, severity, severity_changed_at, no_data, renotify, status, scheduler_batch_id, next_run_at, last_published_at, last_completed_at, name, tags, alerted_at, trigger_ids, last_claimed_at) FROM stdin;
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.notification_preferences (id, user_id, project_id, channel, type, enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: observation_media; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.observation_media (id, project_id, created_at, updated_at, media_id, trace_id, observation_id, field) FROM stdin;
\.


--
-- Data for Name: observations; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.observations (id, name, start_time, end_time, parent_observation_id, type, trace_id, metadata, model, "modelParameters", input, output, level, status_message, completion_start_time, completion_tokens, prompt_tokens, total_tokens, version, project_id, created_at, unit, prompt_id, input_cost, output_cost, total_cost, internal_model, updated_at, calculated_input_cost, calculated_output_cost, calculated_total_cost, internal_model_id) FROM stdin;
\.


--
-- Data for Name: organization_memberships; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.organization_memberships (id, org_id, user_id, role, created_at, updated_at) FROM stdin;
cmr9x86pz0004ti0aryn5ynyj	00000000-0000-0000-0000-agentshield01	cmr9x86pu0002ti0ajfa48ma2	OWNER	2026-07-07 00:38:58.055	2026-07-07 00:38:58.055
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.organizations (id, name, created_at, updated_at, cloud_config, metadata, ai_features_enabled, cloud_billing_cycle_anchor, cloud_billing_cycle_updated_at, cloud_current_cycle_usage, cloud_free_tier_usage_threshold_state, ai_telemetry_enabled, sfdc_org_id) FROM stdin;
00000000-0000-0000-0000-agentshield01	AgentShield	2026-07-07 00:38:57.641	2026-07-07 00:38:57.641	\N	\N	f	2026-07-07 00:38:57.641	\N	\N	\N	t	\N
\.


--
-- Data for Name: pending_deletions; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.pending_deletions (id, project_id, object, object_id, is_deleted, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: posthog_integrations; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.posthog_integrations (project_id, encrypted_posthog_api_key, posthog_host_name, last_sync_at, enabled, created_at, export_source) FROM stdin;
\.


--
-- Data for Name: prices; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.prices (id, created_at, updated_at, model_id, usage_type, price, project_id, pricing_tier_id) FROM stdin;
cm34ax6mc000008jkfqed92mb	2026-07-07 00:38:54.215	2026-07-07 00:38:54.215	cm34aq60d000207ml0j1h31ar	input	0.000001000000000000000000000000	\N	cm34aq60d000207ml0j1h31ar_tier_default
cm34axb2o000108jk09wn9b47	2026-07-07 00:38:54.215	2026-07-07 00:38:54.215	cm34aqb9h000307ml6nypd618	input	0.000001000000000000000000000000	\N	cm34aqb9h000307ml6nypd618_tier_default
cm34axeie000208jk8b2ke2t8	2026-07-07 00:38:54.215	2026-07-07 00:38:54.215	cm34aq60d000207ml0j1h31ar	output	0.000005000000000000000000000000	\N	cm34aq60d000207ml0j1h31ar_tier_default
cm34axi67000308jk7x1a7qko	2026-07-07 00:38:54.215	2026-07-07 00:38:54.215	cm34aqb9h000307ml6nypd618	output	0.000005000000000000000000000000	\N	cm34aqb9h000307ml6nypd618_tier_default
cm3x0psrz000108kydpxg9o2k	2026-07-07 00:38:54.224	2026-07-07 00:38:54.224	cm3x0p8ev000008kyd96800c8	input	0.000005000000000000000000000000	\N	cm3x0p8ev000008kyd96800c8_tier_default
cm3x0pyt7000208ky8737gdla	2026-07-07 00:38:54.224	2026-07-07 00:38:54.224	cm3x0p8ev000008kyd96800c8	output	0.000015000000000000000000000000	\N	cm3x0p8ev000008kyd96800c8_tier_default
\.


--
-- Data for Name: pricing_tiers; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.pricing_tiers (id, created_at, updated_at, model_id, name, is_default, priority, conditions) FROM stdin;
cm34aq60d000207ml0j1h31ar_tier_default	2026-07-07 00:38:54.927	2026-07-07 00:38:54.927	cm34aq60d000207ml0j1h31ar	Standard	t	0	[]
cm34aqb9h000307ml6nypd618_tier_default	2026-07-07 00:38:54.927	2026-07-07 00:38:54.927	cm34aqb9h000307ml6nypd618	Standard	t	0	[]
cm3x0p8ev000008kyd96800c8_tier_default	2026-07-07 00:38:54.927	2026-07-07 00:38:54.927	cm3x0p8ev000008kyd96800c8	Standard	t	0	[]
\.


--
-- Data for Name: project_memberships; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.project_memberships (project_id, user_id, created_at, updated_at, org_membership_id, role) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.projects (id, created_at, name, updated_at, org_id, deleted_at, retention_days, metadata, has_traces) FROM stdin;
00000000-0000-0000-0001-agentshield01	2026-07-07 00:38:57.648	AgentShield Platform	2026-07-07 00:38:57.648	00000000-0000-0000-0000-agentshield01	\N	\N	\N	f
\.


--
-- Data for Name: prompt_dependencies; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.prompt_dependencies (id, created_at, updated_at, project_id, parent_id, child_name, child_label, child_version) FROM stdin;
\.


--
-- Data for Name: prompt_protected_labels; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.prompt_protected_labels (id, created_at, updated_at, project_id, label) FROM stdin;
\.


--
-- Data for Name: prompts; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.prompts (id, created_at, updated_at, project_id, created_by, name, version, is_active, config, prompt, type, tags, labels, commit_message) FROM stdin;
\.


--
-- Data for Name: score_configs; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.score_configs (id, created_at, updated_at, project_id, name, data_type, is_archived, min_value, max_value, categories, description) FROM stdin;
\.


--
-- Data for Name: scores; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.scores (id, "timestamp", name, value, observation_id, trace_id, comment, source, project_id, author_user_id, config_id, data_type, string_value, created_at, updated_at, queue_id) FROM stdin;
\.


--
-- Data for Name: slack_integrations; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.slack_integrations (id, project_id, team_id, team_name, bot_token, bot_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_configs; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.sso_configs (domain, created_at, updated_at, auth_provider, auth_config) FROM stdin;
\.


--
-- Data for Name: surveys; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.surveys (id, created_at, survey_name, response, user_id, user_email, org_id) FROM stdin;
\.


--
-- Data for Name: table_view_presets; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.table_view_presets (id, created_at, updated_at, project_id, name, table_name, created_by, updated_by, filters, column_order, column_visibility, search_query, order_by) FROM stdin;
\.


--
-- Data for Name: trace_media; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.trace_media (id, project_id, created_at, updated_at, media_id, trace_id, field) FROM stdin;
\.


--
-- Data for Name: trace_sessions; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.trace_sessions (id, created_at, updated_at, project_id, bookmarked, public, environment) FROM stdin;
\.


--
-- Data for Name: traces; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.traces (id, "timestamp", name, project_id, metadata, external_id, user_id, release, version, public, bookmarked, input, output, session_id, tags, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: triggers; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.triggers (id, created_at, updated_at, project_id, "eventSource", "eventActions", filter, status) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.users (id, name, email, email_verified, password, image, created_at, updated_at, feature_flags, admin, v4_beta_enabled) FROM stdin;
cmr9x86pu0002ti0ajfa48ma2	AgentShield Admin	admin@agentshield.local	\N	$2a$12$0fVpR1EXVq34LfKpm0CvR.a62CPReSJfEWrOc9tcir/gufcMRAV3e	\N	2026-07-07 00:38:58.05	2026-07-07 00:38:58.05	{}	f	f
\.


--
-- Data for Name: verification_tokens; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.verification_tokens (identifier, token, expires) FROM stdin;
\.


--
-- Data for Name: verified_domains; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.verified_domains (id, organization_id, domain, verification_token, verified_at, created_by_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: web_callout_endpoints; Type: TABLE DATA; Schema: public; Owner: langfuse_user
--

COPY public.web_callout_endpoints (id, created_at, updated_at, project_id, name, url, enabled, toast_message, request_headers, request_header_keys) FROM stdin;
\.


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: actions actions_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.actions
    ADD CONSTRAINT actions_pkey PRIMARY KEY (id);


--
-- Name: annotation_queue_assignments annotation_queue_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.annotation_queue_assignments
    ADD CONSTRAINT annotation_queue_assignments_pkey PRIMARY KEY (id);


--
-- Name: annotation_queue_items annotation_queue_items_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.annotation_queue_items
    ADD CONSTRAINT annotation_queue_items_pkey PRIMARY KEY (id);


--
-- Name: annotation_queues annotation_queues_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.annotation_queues
    ADD CONSTRAINT annotation_queues_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: automation_executions automation_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.automation_executions
    ADD CONSTRAINT automation_executions_pkey PRIMARY KEY (id);


--
-- Name: automations automations_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.automations
    ADD CONSTRAINT automations_pkey PRIMARY KEY (id);


--
-- Name: background_migrations background_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.background_migrations
    ADD CONSTRAINT background_migrations_pkey PRIMARY KEY (id);


--
-- Name: batch_actions batch_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.batch_actions
    ADD CONSTRAINT batch_actions_pkey PRIMARY KEY (id);


--
-- Name: batch_exports batch_exports_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.batch_exports
    ADD CONSTRAINT batch_exports_pkey PRIMARY KEY (id);


--
-- Name: blob_storage_integrations blob_storage_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.blob_storage_integrations
    ADD CONSTRAINT blob_storage_integrations_pkey PRIMARY KEY (project_id);


--
-- Name: cloud_spend_alerts cloud_spend_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.cloud_spend_alerts
    ADD CONSTRAINT cloud_spend_alerts_pkey PRIMARY KEY (id);


--
-- Name: comment_reactions comment_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.comment_reactions
    ADD CONSTRAINT comment_reactions_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: cron_jobs cron_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.cron_jobs
    ADD CONSTRAINT cron_jobs_pkey PRIMARY KEY (name);


--
-- Name: dashboard_widgets dashboard_widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.dashboard_widgets
    ADD CONSTRAINT dashboard_widgets_pkey PRIMARY KEY (id);


--
-- Name: dashboards dashboards_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_pkey PRIMARY KEY (id);


--
-- Name: dataset_item_media dataset_item_media_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.dataset_item_media
    ADD CONSTRAINT dataset_item_media_pkey PRIMARY KEY (id);


--
-- Name: dataset_items dataset_items_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.dataset_items
    ADD CONSTRAINT dataset_items_pkey PRIMARY KEY (id, project_id, valid_from);


--
-- Name: dataset_run_items dataset_run_items_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.dataset_run_items
    ADD CONSTRAINT dataset_run_items_pkey PRIMARY KEY (id, project_id);


--
-- Name: dataset_runs dataset_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.dataset_runs
    ADD CONSTRAINT dataset_runs_pkey PRIMARY KEY (id, project_id);


--
-- Name: datasets datasets_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_pkey PRIMARY KEY (id, project_id);


--
-- Name: default_llm_models default_llm_models_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.default_llm_models
    ADD CONSTRAINT default_llm_models_pkey PRIMARY KEY (id);


--
-- Name: default_llm_models default_llm_models_project_id_key; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.default_llm_models
    ADD CONSTRAINT default_llm_models_project_id_key UNIQUE (project_id);


--
-- Name: default_views default_views_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.default_views
    ADD CONSTRAINT default_views_pkey PRIMARY KEY (id);


--
-- Name: eval_templates eval_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.eval_templates
    ADD CONSTRAINT eval_templates_pkey PRIMARY KEY (id);


--
-- Name: in_app_agent_conversations in_app_agent_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.in_app_agent_conversations
    ADD CONSTRAINT in_app_agent_conversations_pkey PRIMARY KEY (id, project_id);


--
-- Name: in_app_agent_events in_app_agent_events_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.in_app_agent_events
    ADD CONSTRAINT in_app_agent_events_pkey PRIMARY KEY (project_id, conversation_id, sequence_number);


--
-- Name: in_app_agent_pending_tool_approvals in_app_agent_pending_tool_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.in_app_agent_pending_tool_approvals
    ADD CONSTRAINT in_app_agent_pending_tool_approvals_pkey PRIMARY KEY (project_id, conversation_id, tool_call_id);


--
-- Name: in_app_agent_runs in_app_agent_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.in_app_agent_runs
    ADD CONSTRAINT in_app_agent_runs_pkey PRIMARY KEY (id, project_id);


--
-- Name: job_configurations job_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.job_configurations
    ADD CONSTRAINT job_configurations_pkey PRIMARY KEY (id);


--
-- Name: job_executions job_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.job_executions
    ADD CONSTRAINT job_executions_pkey PRIMARY KEY (id);


--
-- Name: llm_api_keys llm_api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.llm_api_keys
    ADD CONSTRAINT llm_api_keys_pkey PRIMARY KEY (id);


--
-- Name: llm_schemas llm_schemas_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.llm_schemas
    ADD CONSTRAINT llm_schemas_pkey PRIMARY KEY (id);


--
-- Name: llm_tools llm_tools_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.llm_tools
    ADD CONSTRAINT llm_tools_pkey PRIMARY KEY (id);


--
-- Name: membership_invitations membership_invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.membership_invitations
    ADD CONSTRAINT membership_invitations_pkey PRIMARY KEY (id);


--
-- Name: mixpanel_integrations mixpanel_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.mixpanel_integrations
    ADD CONSTRAINT mixpanel_integrations_pkey PRIMARY KEY (project_id);


--
-- Name: models models_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_pkey PRIMARY KEY (id);


--
-- Name: monitors monitors_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.monitors
    ADD CONSTRAINT monitors_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: observation_media observation_media_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.observation_media
    ADD CONSTRAINT observation_media_pkey PRIMARY KEY (id);


--
-- Name: observations observations_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.observations
    ADD CONSTRAINT observations_pkey PRIMARY KEY (id);


--
-- Name: organization_memberships organization_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.organization_memberships
    ADD CONSTRAINT organization_memberships_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: pending_deletions pending_deletions_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.pending_deletions
    ADD CONSTRAINT pending_deletions_pkey PRIMARY KEY (id);


--
-- Name: posthog_integrations posthog_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.posthog_integrations
    ADD CONSTRAINT posthog_integrations_pkey PRIMARY KEY (project_id);


--
-- Name: prices prices_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.prices
    ADD CONSTRAINT prices_pkey PRIMARY KEY (id);


--
-- Name: pricing_tiers pricing_tiers_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.pricing_tiers
    ADD CONSTRAINT pricing_tiers_pkey PRIMARY KEY (id);


--
-- Name: project_memberships project_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.project_memberships
    ADD CONSTRAINT project_memberships_pkey PRIMARY KEY (project_id, user_id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: prompt_dependencies prompt_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.prompt_dependencies
    ADD CONSTRAINT prompt_dependencies_pkey PRIMARY KEY (id);


--
-- Name: prompt_protected_labels prompt_protected_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.prompt_protected_labels
    ADD CONSTRAINT prompt_protected_labels_pkey PRIMARY KEY (id);


--
-- Name: prompts prompts_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.prompts
    ADD CONSTRAINT prompts_pkey PRIMARY KEY (id);


--
-- Name: score_configs score_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.score_configs
    ADD CONSTRAINT score_configs_pkey PRIMARY KEY (id);


--
-- Name: scores scores_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.scores
    ADD CONSTRAINT scores_pkey PRIMARY KEY (id);


--
-- Name: slack_integrations slack_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.slack_integrations
    ADD CONSTRAINT slack_integrations_pkey PRIMARY KEY (id);


--
-- Name: sso_configs sso_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.sso_configs
    ADD CONSTRAINT sso_configs_pkey PRIMARY KEY (domain);


--
-- Name: surveys surveys_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.surveys
    ADD CONSTRAINT surveys_pkey PRIMARY KEY (id);


--
-- Name: table_view_presets table_view_presets_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.table_view_presets
    ADD CONSTRAINT table_view_presets_pkey PRIMARY KEY (id);


--
-- Name: trace_media trace_media_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.trace_media
    ADD CONSTRAINT trace_media_pkey PRIMARY KEY (id);


--
-- Name: trace_sessions trace_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.trace_sessions
    ADD CONSTRAINT trace_sessions_pkey PRIMARY KEY (id, project_id);


--
-- Name: traces traces_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.traces
    ADD CONSTRAINT traces_pkey PRIMARY KEY (id);


--
-- Name: triggers triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.triggers
    ADD CONSTRAINT triggers_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: verified_domains verified_domains_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.verified_domains
    ADD CONSTRAINT verified_domains_pkey PRIMARY KEY (id);


--
-- Name: web_callout_endpoints web_callout_endpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.web_callout_endpoints
    ADD CONSTRAINT web_callout_endpoints_pkey PRIMARY KEY (id);


--
-- Name: Account_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX "Account_provider_providerAccountId_key" ON public."Account" USING btree (provider, "providerAccountId");


--
-- Name: Account_user_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX "Account_user_id_idx" ON public."Account" USING btree (user_id);


--
-- Name: Session_session_token_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX "Session_session_token_key" ON public."Session" USING btree (session_token);


--
-- Name: actions_project_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX actions_project_id_idx ON public.actions USING btree (project_id);


--
-- Name: annotation_queue_assignments_project_id_queue_id_user_id_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX annotation_queue_assignments_project_id_queue_id_user_id_key ON public.annotation_queue_assignments USING btree (project_id, queue_id, user_id);


--
-- Name: annotation_queue_items_annotator_user_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX annotation_queue_items_annotator_user_id_idx ON public.annotation_queue_items USING btree (annotator_user_id);


--
-- Name: annotation_queue_items_created_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX annotation_queue_items_created_at_idx ON public.annotation_queue_items USING btree (created_at);


--
-- Name: annotation_queue_items_id_project_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX annotation_queue_items_id_project_id_idx ON public.annotation_queue_items USING btree (id, project_id);


--
-- Name: annotation_queue_items_object_id_object_type_project_id_que_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX annotation_queue_items_object_id_object_type_project_id_que_idx ON public.annotation_queue_items USING btree (object_id, object_type, project_id, queue_id);


--
-- Name: annotation_queue_items_project_id_queue_id_status_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX annotation_queue_items_project_id_queue_id_status_idx ON public.annotation_queue_items USING btree (project_id, queue_id, status);


--
-- Name: annotation_queues_id_project_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX annotation_queues_id_project_id_idx ON public.annotation_queues USING btree (id, project_id);


--
-- Name: annotation_queues_project_id_created_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX annotation_queues_project_id_created_at_idx ON public.annotation_queues USING btree (project_id, created_at);


--
-- Name: annotation_queues_project_id_name_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX annotation_queues_project_id_name_key ON public.annotation_queues USING btree (project_id, name);


--
-- Name: api_keys_fast_hashed_secret_key_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX api_keys_fast_hashed_secret_key_idx ON public.api_keys USING btree (fast_hashed_secret_key);


--
-- Name: api_keys_fast_hashed_secret_key_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX api_keys_fast_hashed_secret_key_key ON public.api_keys USING btree (fast_hashed_secret_key);


--
-- Name: api_keys_hashed_secret_key_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX api_keys_hashed_secret_key_idx ON public.api_keys USING btree (hashed_secret_key);


--
-- Name: api_keys_hashed_secret_key_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX api_keys_hashed_secret_key_key ON public.api_keys USING btree (hashed_secret_key);


--
-- Name: api_keys_id_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX api_keys_id_key ON public.api_keys USING btree (id);


--
-- Name: api_keys_organization_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX api_keys_organization_id_idx ON public.api_keys USING btree (organization_id);


--
-- Name: api_keys_project_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX api_keys_project_id_idx ON public.api_keys USING btree (project_id);


--
-- Name: api_keys_public_key_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX api_keys_public_key_idx ON public.api_keys USING btree (public_key);


--
-- Name: api_keys_public_key_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX api_keys_public_key_key ON public.api_keys USING btree (public_key);


--
-- Name: audit_logs_api_key_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX audit_logs_api_key_id_idx ON public.audit_logs USING btree (api_key_id);


--
-- Name: audit_logs_created_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX audit_logs_created_at_idx ON public.audit_logs USING btree (created_at);


--
-- Name: audit_logs_org_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX audit_logs_org_id_idx ON public.audit_logs USING btree (org_id);


--
-- Name: audit_logs_project_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX audit_logs_project_id_idx ON public.audit_logs USING btree (project_id);


--
-- Name: audit_logs_updated_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX audit_logs_updated_at_idx ON public.audit_logs USING btree (updated_at);


--
-- Name: audit_logs_user_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX audit_logs_user_id_idx ON public.audit_logs USING btree (user_id);


--
-- Name: automation_executions_action_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX automation_executions_action_id_idx ON public.automation_executions USING btree (action_id);


--
-- Name: automation_executions_project_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX automation_executions_project_id_idx ON public.automation_executions USING btree (project_id);


--
-- Name: automation_executions_trigger_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX automation_executions_trigger_id_idx ON public.automation_executions USING btree (trigger_id);


--
-- Name: automations_project_id_action_id_trigger_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX automations_project_id_action_id_trigger_id_idx ON public.automations USING btree (project_id, action_id, trigger_id);


--
-- Name: automations_project_id_name_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX automations_project_id_name_idx ON public.automations USING btree (project_id, name);


--
-- Name: background_migrations_name_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX background_migrations_name_key ON public.background_migrations USING btree (name);


--
-- Name: batch_actions_project_id_action_type_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX batch_actions_project_id_action_type_idx ON public.batch_actions USING btree (project_id, action_type);


--
-- Name: batch_actions_project_id_user_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX batch_actions_project_id_user_id_idx ON public.batch_actions USING btree (project_id, user_id);


--
-- Name: batch_actions_status_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX batch_actions_status_idx ON public.batch_actions USING btree (status);


--
-- Name: batch_exports_project_id_user_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX batch_exports_project_id_user_id_idx ON public.batch_exports USING btree (project_id, user_id);


--
-- Name: batch_exports_status_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX batch_exports_status_idx ON public.batch_exports USING btree (status);


--
-- Name: billing_meter_backups_stripe_customer_id_meter_id_start_tim_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX billing_meter_backups_stripe_customer_id_meter_id_start_tim_idx ON public.billing_meter_backups USING btree (stripe_customer_id, meter_id, start_time, end_time);


--
-- Name: billing_meter_backups_stripe_customer_id_meter_id_start_tim_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX billing_meter_backups_stripe_customer_id_meter_id_start_tim_key ON public.billing_meter_backups USING btree (stripe_customer_id, meter_id, start_time, end_time);


--
-- Name: cloud_spend_alerts_org_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX cloud_spend_alerts_org_id_idx ON public.cloud_spend_alerts USING btree (org_id);


--
-- Name: comment_reactions_comment_id_user_id_emoji_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX comment_reactions_comment_id_user_id_emoji_key ON public.comment_reactions USING btree (comment_id, user_id, emoji);


--
-- Name: comments_project_id_object_type_object_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX comments_project_id_object_type_object_id_idx ON public.comments USING btree (project_id, object_type, object_id);


--
-- Name: dataset_item_media_item_version_field_path_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX dataset_item_media_item_version_field_path_key ON public.dataset_item_media USING btree (project_id, dataset_item_id, dataset_item_valid_from, field, json_path);


--
-- Name: dataset_item_media_pending_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX dataset_item_media_pending_key ON public.dataset_item_media USING btree (project_id, dataset_item_id, field, media_id) WHERE (dataset_item_valid_from IS NULL);


--
-- Name: dataset_item_media_project_id_dataset_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_item_media_project_id_dataset_id_idx ON public.dataset_item_media USING btree (project_id, dataset_id);


--
-- Name: dataset_item_media_project_id_media_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_item_media_project_id_media_id_idx ON public.dataset_item_media USING btree (project_id, media_id);


--
-- Name: dataset_items_created_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_items_created_at_idx ON public.dataset_items USING btree (created_at);


--
-- Name: dataset_items_dataset_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_items_dataset_id_idx ON public.dataset_items USING hash (dataset_id);


--
-- Name: dataset_items_project_id_id_valid_from_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_items_project_id_id_valid_from_idx ON public.dataset_items USING btree (project_id, id, valid_from);


--
-- Name: dataset_items_project_id_valid_to_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_items_project_id_valid_to_idx ON public.dataset_items USING btree (project_id, valid_to);


--
-- Name: dataset_items_source_observation_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_items_source_observation_id_idx ON public.dataset_items USING hash (source_observation_id);


--
-- Name: dataset_items_source_trace_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_items_source_trace_id_idx ON public.dataset_items USING hash (source_trace_id);


--
-- Name: dataset_items_updated_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_items_updated_at_idx ON public.dataset_items USING btree (updated_at);


--
-- Name: dataset_run_items_created_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_run_items_created_at_idx ON public.dataset_run_items USING btree (created_at);


--
-- Name: dataset_run_items_dataset_item_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_run_items_dataset_item_id_idx ON public.dataset_run_items USING hash (dataset_item_id);


--
-- Name: dataset_run_items_dataset_run_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_run_items_dataset_run_id_idx ON public.dataset_run_items USING hash (dataset_run_id);


--
-- Name: dataset_run_items_observation_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_run_items_observation_id_idx ON public.dataset_run_items USING hash (observation_id);


--
-- Name: dataset_run_items_trace_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_run_items_trace_id_idx ON public.dataset_run_items USING btree (trace_id);


--
-- Name: dataset_run_items_updated_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_run_items_updated_at_idx ON public.dataset_run_items USING btree (updated_at);


--
-- Name: dataset_runs_created_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_runs_created_at_idx ON public.dataset_runs USING btree (created_at);


--
-- Name: dataset_runs_dataset_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_runs_dataset_id_idx ON public.dataset_runs USING hash (dataset_id);


--
-- Name: dataset_runs_dataset_id_project_id_name_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX dataset_runs_dataset_id_project_id_name_key ON public.dataset_runs USING btree (dataset_id, project_id, name);


--
-- Name: dataset_runs_updated_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX dataset_runs_updated_at_idx ON public.dataset_runs USING btree (updated_at);


--
-- Name: datasets_created_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX datasets_created_at_idx ON public.datasets USING btree (created_at);


--
-- Name: datasets_project_id_name_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX datasets_project_id_name_key ON public.datasets USING btree (project_id, name);


--
-- Name: datasets_updated_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX datasets_updated_at_idx ON public.datasets USING btree (updated_at);


--
-- Name: default_views_project_id_view_name_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX default_views_project_id_view_name_idx ON public.default_views USING btree (project_id, view_name);


--
-- Name: default_views_project_user_view_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX default_views_project_user_view_key ON public.default_views USING btree (project_id, user_id, view_name) WHERE (user_id IS NOT NULL);


--
-- Name: default_views_project_view_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX default_views_project_view_key ON public.default_views USING btree (project_id, view_name) WHERE (user_id IS NULL);


--
-- Name: eval_templates_project_id_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX eval_templates_project_id_id_idx ON public.eval_templates USING btree (project_id, id);


--
-- Name: eval_templates_project_id_name_version_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX eval_templates_project_id_name_version_key ON public.eval_templates USING btree (project_id, name, version);


--
-- Name: idx_comments_content_gin; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX idx_comments_content_gin ON public.comments USING gin (to_tsvector('english'::regconfig, content));


--
-- Name: in_app_agent_conversations_project_user_list_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX in_app_agent_conversations_project_user_list_idx ON public.in_app_agent_conversations USING btree (project_id, created_by_user_id, deleted_at, updated_at, id);


--
-- Name: in_app_agent_events_project_run_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX in_app_agent_events_project_run_idx ON public.in_app_agent_events USING btree (project_id, run_id);


--
-- Name: in_app_agent_pending_tool_approvals_expires_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX in_app_agent_pending_tool_approvals_expires_at_idx ON public.in_app_agent_pending_tool_approvals USING btree (expires_at);


--
-- Name: in_app_agent_runs_project_conversation_created_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX in_app_agent_runs_project_conversation_created_idx ON public.in_app_agent_runs USING btree (project_id, conversation_id, created_at);


--
-- Name: job_configurations_project_id_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX job_configurations_project_id_id_idx ON public.job_configurations USING btree (project_id, id);


--
-- Name: job_executions_job_configuration_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX job_executions_job_configuration_id_idx ON public.job_executions USING btree (job_configuration_id);


--
-- Name: job_executions_project_id_job_configuration_id_job_input_tr_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX job_executions_project_id_job_configuration_id_job_input_tr_idx ON public.job_executions USING btree (project_id, job_configuration_id, job_input_trace_id);


--
-- Name: job_executions_project_id_job_output_score_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX job_executions_project_id_job_output_score_id_idx ON public.job_executions USING btree (project_id, job_output_score_id);


--
-- Name: llm_api_keys_id_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX llm_api_keys_id_key ON public.llm_api_keys USING btree (id);


--
-- Name: llm_api_keys_project_id_provider_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX llm_api_keys_project_id_provider_key ON public.llm_api_keys USING btree (project_id, provider);


--
-- Name: llm_schemas_project_id_name_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX llm_schemas_project_id_name_key ON public.llm_schemas USING btree (project_id, name);


--
-- Name: llm_tools_project_id_name_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX llm_tools_project_id_name_key ON public.llm_tools USING btree (project_id, name);


--
-- Name: media_project_id_created_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX media_project_id_created_at_idx ON public.media USING btree (project_id, created_at);


--
-- Name: media_project_id_id_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX media_project_id_id_key ON public.media USING btree (project_id, id);


--
-- Name: media_project_id_sha_256_hash_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX media_project_id_sha_256_hash_key ON public.media USING btree (project_id, sha_256_hash);


--
-- Name: membership_invitations_email_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX membership_invitations_email_idx ON public.membership_invitations USING btree (email);


--
-- Name: membership_invitations_email_org_id_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX membership_invitations_email_org_id_key ON public.membership_invitations USING btree (email, org_id);


--
-- Name: membership_invitations_id_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX membership_invitations_id_key ON public.membership_invitations USING btree (id);


--
-- Name: membership_invitations_org_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX membership_invitations_org_id_idx ON public.membership_invitations USING btree (org_id);


--
-- Name: membership_invitations_project_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX membership_invitations_project_id_idx ON public.membership_invitations USING btree (project_id);


--
-- Name: models_model_name_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX models_model_name_idx ON public.models USING btree (model_name);


--
-- Name: models_project_id_model_name_start_date_unit_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX models_project_id_model_name_start_date_unit_key ON public.models USING btree (project_id, model_name, start_date, unit);


--
-- Name: monitors_project_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX monitors_project_id_idx ON public.monitors USING btree (project_id);


--
-- Name: monitors_scheduler_batch_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX monitors_scheduler_batch_id_idx ON public.monitors USING btree (scheduler_batch_id);


--
-- Name: monitors_scheduler_rescue_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX monitors_scheduler_rescue_idx ON public.monitors USING btree (last_published_at) WHERE ((last_completed_at IS NULL) OR (last_completed_at < last_published_at));


--
-- Name: monitors_scheduler_tick_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX monitors_scheduler_tick_idx ON public.monitors USING btree (next_run_at, scheduler_batch_id);


--
-- Name: notification_preferences_user_id_project_id_channel_type_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX notification_preferences_user_id_project_id_channel_type_key ON public.notification_preferences USING btree (user_id, project_id, channel, type);


--
-- Name: observation_media_project_id_media_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX observation_media_project_id_media_id_idx ON public.observation_media USING btree (project_id, media_id);


--
-- Name: observation_media_project_id_trace_id_observation_id_media__key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX observation_media_project_id_trace_id_observation_id_media__key ON public.observation_media USING btree (project_id, trace_id, observation_id, media_id, field);


--
-- Name: observations_created_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX observations_created_at_idx ON public.observations USING btree (created_at);


--
-- Name: observations_id_project_id_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX observations_id_project_id_key ON public.observations USING btree (id, project_id);


--
-- Name: observations_internal_model_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX observations_internal_model_idx ON public.observations USING btree (internal_model);


--
-- Name: observations_model_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX observations_model_idx ON public.observations USING btree (model);


--
-- Name: observations_project_id_internal_model_start_time_unit_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX observations_project_id_internal_model_start_time_unit_idx ON public.observations USING btree (project_id, internal_model, start_time, unit);


--
-- Name: observations_project_id_prompt_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX observations_project_id_prompt_id_idx ON public.observations USING btree (project_id, prompt_id);


--
-- Name: observations_project_id_start_time_type_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX observations_project_id_start_time_type_idx ON public.observations USING btree (project_id, start_time, type);


--
-- Name: observations_prompt_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX observations_prompt_id_idx ON public.observations USING btree (prompt_id);


--
-- Name: observations_start_time_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX observations_start_time_idx ON public.observations USING btree (start_time);


--
-- Name: observations_trace_id_project_id_start_time_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX observations_trace_id_project_id_start_time_idx ON public.observations USING btree (trace_id, project_id, start_time);


--
-- Name: observations_trace_id_project_id_type_start_time_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX observations_trace_id_project_id_type_start_time_idx ON public.observations USING btree (trace_id, project_id, type, start_time);


--
-- Name: observations_type_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX observations_type_idx ON public.observations USING btree (type);


--
-- Name: organization_memberships_org_id_user_id_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX organization_memberships_org_id_user_id_key ON public.organization_memberships USING btree (org_id, user_id);


--
-- Name: organization_memberships_user_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX organization_memberships_user_id_idx ON public.organization_memberships USING btree (user_id);


--
-- Name: pending_deletions_object_id_object_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX pending_deletions_object_id_object_idx ON public.pending_deletions USING btree (object_id, object);


--
-- Name: pending_deletions_project_id_object_is_deleted_object_id_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX pending_deletions_project_id_object_is_deleted_object_id_id_idx ON public.pending_deletions USING btree (project_id, object, is_deleted, object_id, id);


--
-- Name: prices_model_id_usage_type_pricing_tier_id_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX prices_model_id_usage_type_pricing_tier_id_key ON public.prices USING btree (model_id, usage_type, pricing_tier_id);


--
-- Name: prices_pricing_tier_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX prices_pricing_tier_id_idx ON public.prices USING btree (pricing_tier_id);


--
-- Name: pricing_tiers_model_id_name_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX pricing_tiers_model_id_name_key ON public.pricing_tiers USING btree (model_id, name);


--
-- Name: pricing_tiers_model_id_priority_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX pricing_tiers_model_id_priority_key ON public.pricing_tiers USING btree (model_id, priority);


--
-- Name: project_memberships_org_membership_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX project_memberships_org_membership_id_idx ON public.project_memberships USING btree (org_membership_id);


--
-- Name: project_memberships_project_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX project_memberships_project_id_idx ON public.project_memberships USING btree (project_id);


--
-- Name: project_memberships_user_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX project_memberships_user_id_idx ON public.project_memberships USING btree (user_id);


--
-- Name: projects_org_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX projects_org_id_idx ON public.projects USING btree (org_id);


--
-- Name: prompt_dependencies_project_id_child_name; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX prompt_dependencies_project_id_child_name ON public.prompt_dependencies USING btree (project_id, child_name);


--
-- Name: prompt_dependencies_project_id_parent_id; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX prompt_dependencies_project_id_parent_id ON public.prompt_dependencies USING btree (project_id, parent_id);


--
-- Name: prompt_protected_labels_project_id_label_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX prompt_protected_labels_project_id_label_key ON public.prompt_protected_labels USING btree (project_id, label);


--
-- Name: prompts_created_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX prompts_created_at_idx ON public.prompts USING btree (created_at);


--
-- Name: prompts_project_id_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX prompts_project_id_id_idx ON public.prompts USING btree (project_id, id);


--
-- Name: prompts_project_id_name_version_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX prompts_project_id_name_version_key ON public.prompts USING btree (project_id, name, version);


--
-- Name: prompts_tags_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX prompts_tags_idx ON public.prompts USING gin (tags);


--
-- Name: prompts_updated_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX prompts_updated_at_idx ON public.prompts USING btree (updated_at);


--
-- Name: score_configs_categories_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX score_configs_categories_idx ON public.score_configs USING btree (categories);


--
-- Name: score_configs_created_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX score_configs_created_at_idx ON public.score_configs USING btree (created_at);


--
-- Name: score_configs_data_type_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX score_configs_data_type_idx ON public.score_configs USING btree (data_type);


--
-- Name: score_configs_id_project_id_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX score_configs_id_project_id_key ON public.score_configs USING btree (id, project_id);


--
-- Name: score_configs_is_archived_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX score_configs_is_archived_idx ON public.score_configs USING btree (is_archived);


--
-- Name: score_configs_project_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX score_configs_project_id_idx ON public.score_configs USING btree (project_id);


--
-- Name: score_configs_updated_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX score_configs_updated_at_idx ON public.score_configs USING btree (updated_at);


--
-- Name: scores_author_user_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX scores_author_user_id_idx ON public.scores USING btree (author_user_id);


--
-- Name: scores_config_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX scores_config_id_idx ON public.scores USING btree (config_id);


--
-- Name: scores_created_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX scores_created_at_idx ON public.scores USING btree (created_at);


--
-- Name: scores_id_project_id_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX scores_id_project_id_key ON public.scores USING btree (id, project_id);


--
-- Name: scores_observation_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX scores_observation_id_idx ON public.scores USING hash (observation_id);


--
-- Name: scores_project_id_name_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX scores_project_id_name_idx ON public.scores USING btree (project_id, name);


--
-- Name: scores_source_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX scores_source_idx ON public.scores USING btree (source);


--
-- Name: scores_timestamp_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX scores_timestamp_idx ON public.scores USING btree ("timestamp");


--
-- Name: scores_trace_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX scores_trace_id_idx ON public.scores USING hash (trace_id);


--
-- Name: scores_value_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX scores_value_idx ON public.scores USING btree (value);


--
-- Name: slack_integrations_project_id_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX slack_integrations_project_id_key ON public.slack_integrations USING btree (project_id);


--
-- Name: slack_integrations_team_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX slack_integrations_team_id_idx ON public.slack_integrations USING btree (team_id);


--
-- Name: table_view_presets_project_id_table_name_name_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX table_view_presets_project_id_table_name_name_key ON public.table_view_presets USING btree (project_id, table_name, name);


--
-- Name: trace_media_project_id_media_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX trace_media_project_id_media_id_idx ON public.trace_media USING btree (project_id, media_id);


--
-- Name: trace_media_project_id_trace_id_media_id_field_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX trace_media_project_id_trace_id_media_id_field_key ON public.trace_media USING btree (project_id, trace_id, media_id, field);


--
-- Name: trace_sessions_project_id_created_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX trace_sessions_project_id_created_at_idx ON public.trace_sessions USING btree (project_id, created_at DESC);


--
-- Name: traces_created_at_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX traces_created_at_idx ON public.traces USING btree (created_at);


--
-- Name: traces_id_user_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX traces_id_user_id_idx ON public.traces USING btree (id, user_id);


--
-- Name: traces_name_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX traces_name_idx ON public.traces USING btree (name);


--
-- Name: traces_project_id_timestamp_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX traces_project_id_timestamp_idx ON public.traces USING btree (project_id, "timestamp");


--
-- Name: traces_session_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX traces_session_id_idx ON public.traces USING btree (session_id);


--
-- Name: traces_tags_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX traces_tags_idx ON public.traces USING gin (tags);


--
-- Name: traces_timestamp_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX traces_timestamp_idx ON public.traces USING btree ("timestamp");


--
-- Name: traces_user_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX traces_user_id_idx ON public.traces USING btree (user_id);


--
-- Name: triggers_project_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX triggers_project_id_idx ON public.triggers USING btree (project_id);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: verification_tokens_identifier_token_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX verification_tokens_identifier_token_key ON public.verification_tokens USING btree (identifier, token);


--
-- Name: verification_tokens_token_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX verification_tokens_token_key ON public.verification_tokens USING btree (token);


--
-- Name: verified_domains_domain_verified_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX verified_domains_domain_verified_key ON public.verified_domains USING btree (domain) WHERE (verified_at IS NOT NULL);


--
-- Name: verified_domains_organization_id_domain_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX verified_domains_organization_id_domain_key ON public.verified_domains USING btree (organization_id, domain);


--
-- Name: verified_domains_organization_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX verified_domains_organization_id_idx ON public.verified_domains USING btree (organization_id);


--
-- Name: verified_domains_verification_token_key; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE UNIQUE INDEX verified_domains_verification_token_key ON public.verified_domains USING btree (verification_token);


--
-- Name: web_callout_endpoints_project_id_enabled_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX web_callout_endpoints_project_id_enabled_idx ON public.web_callout_endpoints USING btree (project_id, enabled);


--
-- Name: web_callout_endpoints_project_id_idx; Type: INDEX; Schema: public; Owner: langfuse_user
--

CREATE INDEX web_callout_endpoints_project_id_idx ON public.web_callout_endpoints USING btree (project_id);


--
-- Name: Account Account_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: actions actions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.actions
    ADD CONSTRAINT actions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: annotation_queue_assignments annotation_queue_assignments_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.annotation_queue_assignments
    ADD CONSTRAINT annotation_queue_assignments_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: annotation_queue_assignments annotation_queue_assignments_queue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.annotation_queue_assignments
    ADD CONSTRAINT annotation_queue_assignments_queue_id_fkey FOREIGN KEY (queue_id) REFERENCES public.annotation_queues(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: annotation_queue_assignments annotation_queue_assignments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.annotation_queue_assignments
    ADD CONSTRAINT annotation_queue_assignments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: annotation_queue_items annotation_queue_items_annotator_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.annotation_queue_items
    ADD CONSTRAINT annotation_queue_items_annotator_user_id_fkey FOREIGN KEY (annotator_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: annotation_queue_items annotation_queue_items_locked_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.annotation_queue_items
    ADD CONSTRAINT annotation_queue_items_locked_by_user_id_fkey FOREIGN KEY (locked_by_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: annotation_queue_items annotation_queue_items_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.annotation_queue_items
    ADD CONSTRAINT annotation_queue_items_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: annotation_queue_items annotation_queue_items_queue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.annotation_queue_items
    ADD CONSTRAINT annotation_queue_items_queue_id_fkey FOREIGN KEY (queue_id) REFERENCES public.annotation_queues(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: annotation_queues annotation_queues_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.annotation_queues
    ADD CONSTRAINT annotation_queues_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: api_keys api_keys_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: api_keys api_keys_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: automation_executions automation_executions_action_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.automation_executions
    ADD CONSTRAINT automation_executions_action_id_fkey FOREIGN KEY (action_id) REFERENCES public.actions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: automation_executions automation_executions_automation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.automation_executions
    ADD CONSTRAINT automation_executions_automation_id_fkey FOREIGN KEY (automation_id) REFERENCES public.automations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: automation_executions automation_executions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.automation_executions
    ADD CONSTRAINT automation_executions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: automation_executions automation_executions_trigger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.automation_executions
    ADD CONSTRAINT automation_executions_trigger_id_fkey FOREIGN KEY (trigger_id) REFERENCES public.triggers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: automations automations_action_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.automations
    ADD CONSTRAINT automations_action_id_fkey FOREIGN KEY (action_id) REFERENCES public.actions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: automations automations_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.automations
    ADD CONSTRAINT automations_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: automations automations_trigger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.automations
    ADD CONSTRAINT automations_trigger_id_fkey FOREIGN KEY (trigger_id) REFERENCES public.triggers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: batch_actions batch_actions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.batch_actions
    ADD CONSTRAINT batch_actions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: batch_exports batch_exports_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.batch_exports
    ADD CONSTRAINT batch_exports_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: blob_storage_integrations blob_storage_integrations_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.blob_storage_integrations
    ADD CONSTRAINT blob_storage_integrations_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cloud_spend_alerts cloud_spend_alerts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.cloud_spend_alerts
    ADD CONSTRAINT cloud_spend_alerts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: comment_reactions comment_reactions_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.comment_reactions
    ADD CONSTRAINT comment_reactions_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: comment_reactions comment_reactions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.comment_reactions
    ADD CONSTRAINT comment_reactions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: comment_reactions comment_reactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.comment_reactions
    ADD CONSTRAINT comment_reactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: comments comments_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dashboard_widgets dashboard_widgets_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.dashboard_widgets
    ADD CONSTRAINT dashboard_widgets_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dashboard_widgets dashboard_widgets_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.dashboard_widgets
    ADD CONSTRAINT dashboard_widgets_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dashboard_widgets dashboard_widgets_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.dashboard_widgets
    ADD CONSTRAINT dashboard_widgets_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dashboards dashboards_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dashboards dashboards_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dashboards dashboards_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: dataset_items dataset_items_dataset_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.dataset_items
    ADD CONSTRAINT dataset_items_dataset_id_project_id_fkey FOREIGN KEY (dataset_id, project_id) REFERENCES public.datasets(id, project_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dataset_run_items dataset_run_items_dataset_run_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.dataset_run_items
    ADD CONSTRAINT dataset_run_items_dataset_run_id_project_id_fkey FOREIGN KEY (dataset_run_id, project_id) REFERENCES public.dataset_runs(id, project_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dataset_runs dataset_runs_dataset_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.dataset_runs
    ADD CONSTRAINT dataset_runs_dataset_id_project_id_fkey FOREIGN KEY (dataset_id, project_id) REFERENCES public.datasets(id, project_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: datasets datasets_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.datasets
    ADD CONSTRAINT datasets_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: default_llm_models default_llm_models_llm_api_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.default_llm_models
    ADD CONSTRAINT default_llm_models_llm_api_key_id_fkey FOREIGN KEY (llm_api_key_id) REFERENCES public.llm_api_keys(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: default_llm_models default_llm_models_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.default_llm_models
    ADD CONSTRAINT default_llm_models_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: default_views default_views_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.default_views
    ADD CONSTRAINT default_views_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: default_views default_views_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.default_views
    ADD CONSTRAINT default_views_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: eval_templates eval_templates_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.eval_templates
    ADD CONSTRAINT eval_templates_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: in_app_agent_conversations in_app_agent_conversations_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.in_app_agent_conversations
    ADD CONSTRAINT in_app_agent_conversations_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: in_app_agent_conversations in_app_agent_conversations_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.in_app_agent_conversations
    ADD CONSTRAINT in_app_agent_conversations_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: in_app_agent_events in_app_agent_events_conversation_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.in_app_agent_events
    ADD CONSTRAINT in_app_agent_events_conversation_id_project_id_fkey FOREIGN KEY (conversation_id, project_id) REFERENCES public.in_app_agent_conversations(id, project_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: in_app_agent_events in_app_agent_events_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.in_app_agent_events
    ADD CONSTRAINT in_app_agent_events_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: in_app_agent_events in_app_agent_events_run_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.in_app_agent_events
    ADD CONSTRAINT in_app_agent_events_run_id_project_id_fkey FOREIGN KEY (run_id, project_id) REFERENCES public.in_app_agent_runs(id, project_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: in_app_agent_pending_tool_approvals in_app_agent_pending_tool_approvals_conversation_id_projec_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.in_app_agent_pending_tool_approvals
    ADD CONSTRAINT in_app_agent_pending_tool_approvals_conversation_id_projec_fkey FOREIGN KEY (conversation_id, project_id) REFERENCES public.in_app_agent_conversations(id, project_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: in_app_agent_pending_tool_approvals in_app_agent_pending_tool_approvals_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.in_app_agent_pending_tool_approvals
    ADD CONSTRAINT in_app_agent_pending_tool_approvals_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: in_app_agent_runs in_app_agent_runs_conversation_id_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.in_app_agent_runs
    ADD CONSTRAINT in_app_agent_runs_conversation_id_project_id_fkey FOREIGN KEY (conversation_id, project_id) REFERENCES public.in_app_agent_conversations(id, project_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: in_app_agent_runs in_app_agent_runs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.in_app_agent_runs
    ADD CONSTRAINT in_app_agent_runs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: in_app_agent_runs in_app_agent_runs_triggered_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.in_app_agent_runs
    ADD CONSTRAINT in_app_agent_runs_triggered_by_user_id_fkey FOREIGN KEY (triggered_by_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: job_configurations job_configurations_eval_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.job_configurations
    ADD CONSTRAINT job_configurations_eval_template_id_fkey FOREIGN KEY (eval_template_id) REFERENCES public.eval_templates(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: job_configurations job_configurations_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.job_configurations
    ADD CONSTRAINT job_configurations_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: job_executions job_executions_job_configuration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.job_executions
    ADD CONSTRAINT job_executions_job_configuration_id_fkey FOREIGN KEY (job_configuration_id) REFERENCES public.job_configurations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: job_executions job_executions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.job_executions
    ADD CONSTRAINT job_executions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: llm_api_keys llm_api_keys_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.llm_api_keys
    ADD CONSTRAINT llm_api_keys_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: llm_schemas llm_schemas_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.llm_schemas
    ADD CONSTRAINT llm_schemas_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: llm_tools llm_tools_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.llm_tools
    ADD CONSTRAINT llm_tools_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: media media_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: membership_invitations membership_invitations_invited_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.membership_invitations
    ADD CONSTRAINT membership_invitations_invited_by_user_id_fkey FOREIGN KEY (invited_by_user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: membership_invitations membership_invitations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.membership_invitations
    ADD CONSTRAINT membership_invitations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: membership_invitations membership_invitations_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.membership_invitations
    ADD CONSTRAINT membership_invitations_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: mixpanel_integrations mixpanel_integrations_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.mixpanel_integrations
    ADD CONSTRAINT mixpanel_integrations_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: models models_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.models
    ADD CONSTRAINT models_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: monitors monitors_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.monitors
    ADD CONSTRAINT monitors_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: monitors monitors_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.monitors
    ADD CONSTRAINT monitors_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: monitors monitors_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.monitors
    ADD CONSTRAINT monitors_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: notification_preferences notification_preferences_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: observations observations_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.observations
    ADD CONSTRAINT observations_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: organization_memberships organization_memberships_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.organization_memberships
    ADD CONSTRAINT organization_memberships_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: organization_memberships organization_memberships_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.organization_memberships
    ADD CONSTRAINT organization_memberships_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pending_deletions pending_deletions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.pending_deletions
    ADD CONSTRAINT pending_deletions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: posthog_integrations posthog_integrations_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.posthog_integrations
    ADD CONSTRAINT posthog_integrations_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: prices prices_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.prices
    ADD CONSTRAINT prices_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.models(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: prices prices_pricing_tier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.prices
    ADD CONSTRAINT prices_pricing_tier_id_fkey FOREIGN KEY (pricing_tier_id) REFERENCES public.pricing_tiers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: prices prices_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.prices
    ADD CONSTRAINT prices_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pricing_tiers pricing_tiers_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.pricing_tiers
    ADD CONSTRAINT pricing_tiers_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.models(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_memberships project_memberships_org_membership_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.project_memberships
    ADD CONSTRAINT project_memberships_org_membership_id_fkey FOREIGN KEY (org_membership_id) REFERENCES public.organization_memberships(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_memberships project_memberships_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.project_memberships
    ADD CONSTRAINT project_memberships_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_memberships project_memberships_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.project_memberships
    ADD CONSTRAINT project_memberships_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: projects projects_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: prompt_dependencies prompt_dependencies_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.prompt_dependencies
    ADD CONSTRAINT prompt_dependencies_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.prompts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: prompt_dependencies prompt_dependencies_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.prompt_dependencies
    ADD CONSTRAINT prompt_dependencies_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: prompt_protected_labels prompt_protected_labels_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.prompt_protected_labels
    ADD CONSTRAINT prompt_protected_labels_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: prompts prompts_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.prompts
    ADD CONSTRAINT prompts_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: score_configs score_configs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.score_configs
    ADD CONSTRAINT score_configs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: scores scores_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.scores
    ADD CONSTRAINT scores_config_id_fkey FOREIGN KEY (config_id) REFERENCES public.score_configs(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: scores scores_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.scores
    ADD CONSTRAINT scores_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: slack_integrations slack_integrations_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.slack_integrations
    ADD CONSTRAINT slack_integrations_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: surveys surveys_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.surveys
    ADD CONSTRAINT surveys_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: surveys surveys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.surveys
    ADD CONSTRAINT surveys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: table_view_presets table_view_presets_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.table_view_presets
    ADD CONSTRAINT table_view_presets_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: table_view_presets table_view_presets_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.table_view_presets
    ADD CONSTRAINT table_view_presets_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: table_view_presets table_view_presets_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.table_view_presets
    ADD CONSTRAINT table_view_presets_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: trace_sessions trace_sessions_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.trace_sessions
    ADD CONSTRAINT trace_sessions_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: traces traces_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.traces
    ADD CONSTRAINT traces_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: triggers triggers_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.triggers
    ADD CONSTRAINT triggers_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: verified_domains verified_domains_organization_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.verified_domains
    ADD CONSTRAINT verified_domains_organization_id_fkey FOREIGN KEY (organization_id) REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: web_callout_endpoints web_callout_endpoints_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: langfuse_user
--

ALTER TABLE ONLY public.web_callout_endpoints
    ADD CONSTRAINT web_callout_endpoints_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: DATABASE langfuse; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE langfuse TO langfuse_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO langfuse_user;


--
-- PostgreSQL database dump complete
--

\unrestrict gTkvYoLR9NbF8klYfA2QcRhzgWyRfBfqf8A2zgwqKEjHHEwvhNhlaEeXbGuEvQJ

--
-- Database "langgraph" dump
--

--
-- PostgreSQL database dump
--

\restrict TBaPqmcnwJC5IJVGbU1KikmJzef8WR93F6k6iqHl9MKJZdvcqBzKhfESRFVhDF9

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: langgraph; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE langgraph WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE langgraph OWNER TO postgres;

\unrestrict TBaPqmcnwJC5IJVGbU1KikmJzef8WR93F6k6iqHl9MKJZdvcqBzKhfESRFVhDF9
\connect langgraph
\restrict TBaPqmcnwJC5IJVGbU1KikmJzef8WR93F6k6iqHl9MKJZdvcqBzKhfESRFVhDF9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE langgraph; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE langgraph TO langgraph_user;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO langgraph_user;


--
-- PostgreSQL database dump complete
--

\unrestrict TBaPqmcnwJC5IJVGbU1KikmJzef8WR93F6k6iqHl9MKJZdvcqBzKhfESRFVhDF9

--
-- Database "postgres" dump
--

--
-- PostgreSQL database dump
--

\restrict b1sJ4ZgvbGIGnGxiTs05GTM5N2yWe4w8ojiynJ9pO6dL3gg6tn6dRnHtMYuWSRB

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF-8';


ALTER DATABASE postgres OWNER TO postgres;

\unrestrict b1sJ4ZgvbGIGnGxiTs05GTM5N2yWe4w8ojiynJ9pO6dL3gg6tn6dRnHtMYuWSRB
\connect postgres
\restrict b1sJ4ZgvbGIGnGxiTs05GTM5N2yWe4w8ojiynJ9pO6dL3gg6tn6dRnHtMYuWSRB

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- PostgreSQL database dump complete
--

\unrestrict b1sJ4ZgvbGIGnGxiTs05GTM5N2yWe4w8ojiynJ9pO6dL3gg6tn6dRnHtMYuWSRB

--
-- PostgreSQL database cluster dump complete
--

